<?php
/**
 * AI Article Writer & HTML Converter backed by per-business custom prompts.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Article_Generator service.
 */
class Article_Generator {

	/**
	 * Deterministic key for a suggested article row.
	 *
	 * @param string $title Article title.
	 * @return string
	 */
	public static function make_key( $title ) {
		$norm = preg_replace( '/\s+/u', ' ', mb_strtolower( trim( (string) $title ) ) );
		return md5( $norm );
	}

	/**
	 * Reliably resolve a valid business ID from parameter, payload, or single active business.
	 *
	 * @param int   $business_id Business ID candidate.
	 * @param array $payload     Optional request payload.
	 * @return int
	 */
	public static function resolve_business_id( $business_id, array $payload = array() ) {
		$biz_id = absint( $business_id );

		// 1. Invalidate candidate if it does not actually exist in the database.
		if ( $biz_id && ! Business::exists( $biz_id ) ) {
			$biz_id = 0;
		}

		// 2. Try candidate from payload if primary ID is missing or invalid.
		if ( ! $biz_id && ! empty( $payload['business_id'] ) ) {
			$candidate = absint( $payload['business_id'] );
			if ( $candidate && Business::exists( $candidate ) ) {
				$biz_id = $candidate;
			}
		}

		// 3. Fall back to the first available business in the database.
		if ( ! $biz_id ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$biz_id = absint( $all_biz[0]['id'] );
			}
		}

		return $biz_id;
	}

	/**
	 * Lightweight map of saved drafts for a business.
	 *
	 * @param int $business_id Business ID.
	 * @return array<string, array{has_article:bool,has_html:bool,updated_at:string}>
	 */
	public static function get_drafts_map( $business_id ) {
		global $wpdb;
		$business_id = self::resolve_business_id( $business_id );
		$table       = Database::table( 'article_drafts' );
		$rows        = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT article_key,
					(article_content IS NOT NULL AND CHAR_LENGTH(TRIM(article_content)) > 0) AS has_article,
					(article_content LIKE '%<a %href=%' OR article_content LIKE '%<a href=%') AS has_links,
					(article_html IS NOT NULL AND CHAR_LENGTH(TRIM(article_html)) > 0) AS has_html,
					(featured_image_url IS NOT NULL AND CHAR_LENGTH(TRIM(featured_image_url)) > 0) AS has_image,
					images_json,
					remote_post_id,
					remote_post_url,
					remote_status,
					scheduled_for,
					updated_at
				FROM {$table}
				WHERE business_id = %d",
				$business_id
			),
			ARRAY_A
		); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$map = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $r ) {
				$imgs       = self::parse_images_json( $r['images_json'] ?? '', ! empty( $r['has_image'] ) ? 'legacy' : '', 0 );
				$in_content = false;
				foreach ( $imgs as $im ) {
					if ( ! empty( $im['is_in_content'] ) ) {
						$in_content = true;
						break;
					}
				}
				$map[ $r['article_key'] ] = array(
					'has_article'         => ! empty( $r['has_article'] ),
					'has_links'           => ! empty( $r['has_links'] ),
					'has_html'            => ! empty( $r['has_html'] ),
					'has_image'           => ! empty( $r['has_image'] ),
					'images_count'        => count( $imgs ),
					'has_in_content_image' => $in_content,
					'remote_post_id'      => (int) ( $r['remote_post_id'] ?? 0 ),
					'remote_post_url'     => (string) ( $r['remote_post_url'] ?? '' ),
					'remote_status'       => (string) ( $r['remote_status'] ?? '' ),
					'scheduled_for'       => $r['scheduled_for'] ?? null,
					'updated_at'          => (string) ( $r['updated_at'] ?? '' ),
				);
			}
		}
		return $map;
	}

	/**
	 * Get a saved draft for an article.
	 *
	 * @param int    $business_id Business ID.
	 * @param string $article_key Article key (MD5).
	 * @return array|null
	 */
	public static function get_draft( $business_id, $article_key ) {
		global $wpdb;
		$business_id = self::resolve_business_id( $business_id );
		$article_key = sanitize_key( $article_key );
		if ( ! $business_id || '' === $article_key ) {
			return null;
		}
		$table = Database::table( 'article_drafts' );
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE business_id = %d AND article_key = %s",
				$business_id,
				$article_key
			),
			ARRAY_A
		); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return $row ? self::format_draft( $row ) : null;
	}

	/**
	 * Save / upsert an article draft (rich text and/or HTML code).
	 *
	 * @param int    $business_id Business ID.
	 * @param string $article_key Article key.
	 * @param array  $fields      Fields to update.
	 * @return array|\WP_Error
	 */
	public static function save_draft( $business_id, $article_key, array $fields ) {
		global $wpdb;
		$business_id = self::resolve_business_id( $business_id, $fields );
		$article_key = sanitize_key( $article_key );
		if ( ! $business_id || ! Business::exists( $business_id ) ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
			}
		}
		if ( ! $business_id || ! Business::exists( $business_id ) ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'کسب‌وکار معتبر نیست.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		if ( '' === $article_key ) {
			$title = trim( sanitize_text_field( $fields['title'] ?? '' ) );
			if ( '' === $title ) {
				return new \WP_Error( 'seopm_missing_key', __( 'شناسه یا عنوان مقاله الزامی است.', 'seo-project-manager' ), array( 'status' => 400 ) );
			}
			$article_key = self::make_key( $title );
		}

		$table    = Database::table( 'article_drafts' );
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE business_id = %d AND article_key = %s",
				$business_id,
				$article_key
			),
			ARRAY_A
		); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$now = Database::now();

		$data = array(
			'updated_at' => $now,
		);
		$formats = array( '%s' );

		if ( isset( $fields['title'] ) ) {
			$data['title'] = mb_substr( sanitize_text_field( $fields['title'] ), 0, 255 );
			$formats[]     = '%s';
		}
		if ( isset( $fields['keyword'] ) ) {
			$data['keyword'] = mb_substr( sanitize_text_field( $fields['keyword'] ), 0, 191 );
			$formats[]       = '%s';
		}
		if ( isset( $fields['url_slug'] ) ) {
			$data['url_slug'] = mb_substr( Content_Suggester::clean_slug( $fields['url_slug'] ), 0, 191 );
			$formats[]        = '%s';
		}
		if ( array_key_exists( 'article_content', $fields ) ) {
			$data['article_content'] = self::clean_rich_html( (string) $fields['article_content'] );
			$formats[]               = '%s';
		}
		if ( array_key_exists( 'article_html', $fields ) ) {
			$data['article_html'] = self::clean_raw_code( (string) $fields['article_html'] );
			$formats[]            = '%s';
		}
		if ( array_key_exists( 'images', $fields ) && is_array( $fields['images'] ) ) {
			$clean_imgs = self::sanitize_images_list( $fields['images'] );
			$data['images_json'] = wp_json_encode( $clean_imgs, JSON_UNESCAPED_UNICODE );
			$formats[]           = '%s';

			$feat_url        = '';
			$feat_id         = 0;
			$in_content_imgs = array();
			foreach ( $clean_imgs as $im ) {
				if ( ! empty( $im['is_featured'] ) ) {
					$feat_url = $im['url'];
					$feat_id  = (int) $im['attachment_id'];
				}
				if ( ! empty( $im['is_in_content'] ) ) {
					$in_content_imgs[] = $im;
				}
			}
			$data['featured_image_url'] = $feat_url;
			$formats[]                  = '%s';
			$data['featured_image_id']  = $feat_id;
			$formats[]                  = '%d';

			// Automatically sync in-content full-size image(s) inside article_html right before the next <h2>.
			$base_html = array_key_exists( 'article_html', $data )
				? (string) $data['article_html']
				: (string) ( $existing['article_html'] ?? '' );
			if ( '' !== trim( $base_html ) ) {
				$alt_title   = (string) ( $data['title'] ?? ( $existing['title'] ?? '' ) );
				$synced_html = self::inject_in_content_images( $base_html, $in_content_imgs, $alt_title );
				if ( array_key_exists( 'article_html', $data ) ) {
					$data['article_html'] = $synced_html;
				} else {
					$data['article_html'] = $synced_html;
					$formats[]            = '%s';
				}
			}
		} else {
			if ( array_key_exists( 'featured_image_url', $fields ) ) {
				$data['featured_image_url'] = esc_url_raw( (string) $fields['featured_image_url'] );
				$formats[]                  = '%s';
			}
			if ( array_key_exists( 'featured_image_id', $fields ) ) {
				$data['featured_image_id'] = absint( $fields['featured_image_id'] );
				$formats[]                 = '%d';
			}
		}
		if ( array_key_exists( 'image_prompt', $fields ) ) {
			$data['image_prompt'] = sanitize_textarea_field( (string) $fields['image_prompt'] );
			$formats[]            = '%s';
		}
		if ( array_key_exists( 'seo_title', $fields ) ) {
			$data['seo_title'] = mb_substr( sanitize_text_field( (string) $fields['seo_title'] ), 0, 255 );
			$formats[]         = '%s';
		}
		if ( array_key_exists( 'seo_description', $fields ) ) {
			$data['seo_description'] = sanitize_textarea_field( (string) $fields['seo_description'] );
			$formats[]               = '%s';
		}
		if ( array_key_exists( 'remote_post_id', $fields ) ) {
			$data['remote_post_id'] = absint( $fields['remote_post_id'] );
			$formats[]              = '%d';
		}
		if ( array_key_exists( 'remote_post_url', $fields ) ) {
			$data['remote_post_url'] = esc_url_raw( (string) $fields['remote_post_url'] );
			$formats[]               = '%s';
		}
		if ( array_key_exists( 'remote_status', $fields ) ) {
			$data['remote_status'] = sanitize_key( (string) $fields['remote_status'] );
			$formats[]             = '%s';
		}
		if ( array_key_exists( 'scheduled_for', $fields ) ) {
			$data['scheduled_for'] = ! empty( $fields['scheduled_for'] ) ? sanitize_text_field( (string) $fields['scheduled_for'] ) : null;
			$formats[]             = '%s';
		}
		if ( array_key_exists( 'published_at', $fields ) ) {
			$data['published_at'] = ! empty( $fields['published_at'] ) ? sanitize_text_field( (string) $fields['published_at'] ) : null;
			$formats[]            = '%s';
		}
		if ( isset( $fields['provider'] ) ) {
			$data['provider'] = sanitize_key( $fields['provider'] );
			$formats[]        = '%s';
		}
		if ( isset( $fields['model'] ) ) {
			$data['model'] = mb_substr( sanitize_text_field( $fields['model'] ), 0, 64 );
			$formats[]     = '%s';
		}

		if ( $existing ) {
			$wpdb->update(
				$table,
				$data,
				array( 'id' => (int) $existing['id'] ),
				$formats,
				array( '%d' )
			);
		} else {
			$insert = array_merge(
				array(
					'business_id'        => $business_id,
					'article_key'        => $article_key,
					'title'              => '',
					'keyword'            => '',
					'url_slug'           => '',
					'article_content'    => '',
					'article_html'       => '',
					'featured_image_url' => '',
					'featured_image_id'  => 0,
					'images_json'        => '',
					'image_prompt'       => '',
					'seo_title'          => '',
					'seo_description'    => '',
					'remote_post_id'     => 0,
					'remote_post_url'    => '',
					'remote_status'      => '',
					'scheduled_for'      => null,
					'published_at'       => null,
					'provider'           => '',
					'model'              => '',
					'created_by'         => get_current_user_id(),
					'created_at'         => $now,
					'updated_at'         => $now,
				),
				$data
			);
			$wpdb->insert(
				$table,
				$insert,
				array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
			);
		}

		return self::get_draft( $business_id, $article_key );
	}

	/**
	 * Delete a draft permanently.
	 *
	 * @param int    $business_id Business ID.
	 * @param string $article_key Article key.
	 * @return bool
	 */
	public static function delete_draft( $business_id, $article_key ) {
		global $wpdb;
		$business_id = self::resolve_business_id( $business_id );
		$article_key = sanitize_key( $article_key );
		if ( ! $business_id || '' === $article_key ) {
			return false;
		}
		$table = Database::table( 'article_drafts' );
		$res   = $wpdb->delete(
			$table,
			array(
				'business_id' => $business_id,
				'article_key' => $article_key,
			),
			array( '%d', '%s' )
		);
		return false !== $res;
	}

	/**
	 * Generate full SEO article text (rich HTML with live hyperlinks) using brief + business writing prompt.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $brief       Suggestion brief payload.
	 * @return array|\WP_Error
	 */
	public static function generate_article( $business_id, array $brief ) {
		$business_id = self::resolve_business_id( $business_id, $brief );
		$biz         = $business_id ? Business::get( $business_id, false ) : null;
		if ( ! $biz ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$biz         = Business::get( $business_id, false );
			}
		}
		if ( ! $biz ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'هیچ کسب‌وکاری در سامانه یافت نشد. لطفاً ابتدا در بخش کسب‌وکارها یک کسب‌وکار تعریف کنید.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$title = trim( sanitize_text_field( $brief['best_title'] ?? $brief['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'seopm_missing_title', __( 'عنوان مقاله برای نگارش مشخص نشده است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$ai_check = self::ensure_ai_ready();
		if ( is_wp_error( $ai_check ) ) {
			return $ai_check;
		}

		$keyword       = trim( sanitize_text_field( $brief['keyword'] ?? '' ) );
		$url_slug      = Content_Suggester::clean_slug( $brief['url_slug'] ?? '' );
		$intent_fa     = trim( sanitize_text_field( $brief['search_intent_fa'] ?? '' ) );
		$core_need     = trim( sanitize_text_field( $brief['user_core_need'] ?? '' ) );
		$decision_txt  = trim( sanitize_text_field( $brief['decision_reason'] ?? '' ) );
		$alt_titles    = isset( $brief['titles'] ) && is_array( $brief['titles'] ) ? array_map( 'sanitize_text_field', $brief['titles'] ) : array();
		$pillar        = isset( $brief['pillar'] ) && is_array( $brief['pillar'] ) ? $brief['pillar'] : array();
		$pillar_title  = trim( sanitize_text_field( $pillar['target_pillar_title'] ?? '' ) );
		$pillar_url    = esc_url_raw( $pillar['target_pillar_url'] ?? $biz['website_url'] ?? '' );
		$primary_anc   = trim( sanitize_text_field( $pillar['primary_anchor'] ?? $keyword ) );
		$sec_anchors   = isset( $pillar['secondary_anchors'] ) && is_array( $pillar['secondary_anchors'] ) ? array_map( 'sanitize_text_field', $pillar['secondary_anchors'] ) : array();
		$placement     = isset( $pillar['placement_strategy'] ) && is_array( $pillar['placement_strategy'] ) ? $pillar['placement_strategy'] : array();
		$article_info    = array_merge( $brief, array(
			'title'           => $title,
			'best_title'      => $title,
			'keyword'         => $keyword,
			'url_slug'        => $url_slug,
			'summary'         => $core_need ?: $intent_fa,
			'user_core_need'  => $core_need,
			'search_intent_fa'=> $intent_fa,
			'article_content' => '',
		) );
		$custom_prompt   = Business::expand_shortcodes( trim( (string) ( $biz['prompt_article_writing'] ?? '' ) ), $biz, $article_info );
		$prompt_internal = Business::expand_shortcodes( trim( (string) ( $biz['prompt_internal_links'] ?? '' ) ), $biz, $article_info );
		$prompt_external = Business::expand_shortcodes( trim( (string) ( $biz['prompt_sources_external_links'] ?? '' ) ), $biz, $article_info );

		// Fetch complete crawled site content & sitemap data.
		$report      = Site_Crawler::get_report( $business_id );
		$sitemap_url = trim( (string) ( $biz['sitemap_url'] ?? '' ) );

		$pages = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['pages'] ) ) ? $report['pages'] : array();
		$posts = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['posts'] ) ) ? $report['posts'] : array();

		// Build structured sitemap reference lines (pages + relevant posts).
		$sitemap_summary = array();
		if ( ! empty( $sitemap_url ) ) {
			$sitemap_summary[] = '- آدرس دقیق نقشه سایت (Sitemap URL): ' . $sitemap_url;
		}

		if ( ! empty( $pages ) ) {
			$sitemap_summary[] = '';
			$sitemap_summary[] = 'صفحات لندینگ، پیلارها و خدمات اصلی از نقشه سایت (جهت پیاده‌سازی لینک‌دهی به پیلارها و خدمات مرتبط):';
			$p_count = 0;
			foreach ( $pages as $p ) {
				if ( ! empty( $p['title'] ) && ! empty( $p['url'] ) ) {
					$sitemap_summary[] = '- ' . $p['title'] . ' | URL: ' . $p['url'];
					$p_count++;
					if ( $p_count >= 35 ) {
						break;
					}
				}
			}
		}

		if ( ! empty( $posts ) ) {
			$sitemap_summary[] = '';
			$sitemap_summary[] = 'مقالات و مطالب منتشرشده وبلاگ از نقشه سایت (جهت لینک‌دهی داخلی مکمل و استناد موضوعی):';
			$ranked_posts      = self::rank_posts_for_article( $posts, $keyword, $title );
			$post_count        = 0;
			foreach ( $ranked_posts as $rp ) {
				if ( ! empty( $rp['title'] ) && ! empty( $rp['url'] ) ) {
					$sitemap_summary[] = '- ' . $rp['title'] . ' | URL: ' . $rp['url'];
					$post_count++;
					if ( $post_count >= 50 ) {
						break;
					}
				}
			}
		}

		$system_prompt = "تو یک نویسنده ارشد سئو و استراتژیست محتوای فارسی هستی.\n" .
			"خروجی تو باید مستقیماً به صورت متن غنی HTML تمیز و قابل نمایش در ادیتور متنی باشد (فقط بدنه مقاله با تگ‌های <h2>، <h3>، <p>، <ul>، <ol>، <li>، <strong>، <table> و هایپرلینک‌های واقعی <a href=\"...\" target=\"_blank\" rel=\"noopener\">انکرتکست</a>).\n" .
			"قوانین الزامی خروجی:\n" .
			"- هرگز تگ‌های <html>، <head>، <body>، <style> یا <h1> و هرگز علامت‌های Markdown (مثل ```html یا ## یا ** یا [متن](لینک)) در خروجی قرار نده.\n" .
			"- تمام لینک‌های داخلی (به‌ویژه لینک به صفحه پیلار هدف) و منابع خارجی را حتماً به‌صورت تگ واقعی <a href=\"آدرس_دقیق\" target=\"_blank\" rel=\"noopener\">انکرتکست</a> داخل متن جایگذاری کن.\n" .
			"- متن باید کاملاً طبیعی، تخصصی، ساختارمند، بدون کلیشه‌گویی و دقیقاً مطابق نیت جستجوی کاربر باشد.";

		if ( '' !== $custom_prompt ) {
			$system_prompt .= "\n\n=== پرامپت و دستورالعمل اختصاصی نگارش مقاله این کسب‌وکار ===\n" . $custom_prompt;
		}
		if ( '' !== $prompt_internal ) {
			$system_prompt .= "\n\n=== پرامپت و دستورالعمل اختصاصی لینک‌دهی داخلی این کسب‌وکار ===\n" . $prompt_internal;
		}
		if ( '' !== $prompt_external ) {
			$system_prompt .= "\n\n=== پرامپت و دستورالعمل اختصاصی منابع مورد استفاده و لینک‌دهی خارجی این کسب‌وکار ===\n" . $prompt_external;
		}

		// Final overriding boundary rule so editor output ALWAYS contains ONLY the publishable article body.
		$system_prompt .= "\n\n=== قانون قطعی و غیرقابل‌تخطی مرز خروجی ادیتور مقاله (اولویت مطلق بر تمام بخش‌های بالا) ===\n" .
			"- خروجی تو باید منحصراً شامل «متن اصلی و قابل‌انتشار مقاله» باشد؛ هیچ‌گونه بخش تحلیلی، متادیتا، کد یا گزارش اضافی در ابتدا یا انتهای خروجی نیاور.\n" .
			"- مطلقاً در ابتدای خروجی، بلوک «تحلیل Search Intent و Information Gain» (شامل Intent / Gap / Angle) یا هیچ مقدمه و توضیح پیش از مقاله ننویس. مستقیماً از ابتدای بدنه مقاله (مثلاً بخش «خلاصه مقاله» یا «مقدمه») شروع کن و تگ <h1> نیاور.\n" .
			"- مقاله باید دقیقاً با پایان آخرین پاسخ بخش «سوالات متداول (FAQ)» تمام شود.\n" .
			"- مطلقاً در انتهای خروجی (یا بعد از FAQ) هیچ‌یک از موارد زیر را قرار نده:\n" .
			"  1. باکس یا بخش تبلیغاتی/درخواست اعزام یا مشاوره جداگانه بعد از سوالات متداول (لینک‌های داخلی را فقط به‌صورت طبیعی درون جملات مقدمه، بدنه و نتیجه‌گیری جایگذاری کن).\n" .
			"  2. جدول متادیتای سئو (Title Tag، Discover Title، Meta Description، URL Slug، شمارش کاراکتر).\n" .
			"  3. کد Schema Markup یا JSON-LD.\n" .
			"  4. گزارش توزیع لینک‌های خارجی یا لیست پیشنهاد لینک‌دهی داخلی.\n" .
			"  5. هرگونه کدبلاک مارک‌داون (```text، ```json، ```html).\n" .
			"- تمام متن را به صورت HTML غنی تمیز تحویل بده و تمام لینک‌ها را با تگ <a href=\"...\" target=\"_blank\" rel=\"noopener\">...</a> بنویس (منابع خارجی درون پرانتز را بولد نکن).";

		$brief_lines = array(
			'لطفاً متن کامل و حرفه‌ای مقاله زیر را دقیقاً بر اساس بریف محتوایی، نقشه سایت (Sitemap) و دستورالعمل نگارش این کسب‌وکار بنویس:',
			'',
			'اطلاعات کسب‌وکار:',
			'- نام کسب‌وکار: ' . $biz['name'],
			'- وب‌سایت: ' . ( $biz['website_url'] ?: '—' ),
			'- نقشه سایت (Sitemap URL): ' . ( $sitemap_url ?: '—' ),
		);
		if ( ! empty( $biz['description'] ) ) {
			$brief_lines[] = '- توضیحات برند: ' . $biz['description'];
		}
		if ( ! empty( $biz['industry_services'] ) ) {
			$brief_lines[] = '- حوزه فعالیت و خدمات یا محصولات اصلی: ' . $biz['industry_services'];
		}
		if ( ! empty( $biz['target_location'] ) ) {
			$brief_lines[] = '- شهر یا محدوده جغرافیایی هدف: ' . $biz['target_location'];
		}
		if ( ! empty( $biz['focus_products_services'] ) ) {
			$brief_lines[] = '- خدمات یا محصولات با اولویت تمرکز: ' . $biz['focus_products_services'];
		}
		if ( ! empty( $biz['content_goals'] ) && is_array( $biz['content_goals'] ) ) {
			$goal_labels = array(
				'traffic_google'  => 'جذب ورودی از گوگل',
				'leads_calls'     => 'دریافت تماس، مشاوره یا درخواست خدمات',
				'sales'           => 'فروش محصول یا خدمت',
				'brand_awareness' => 'افزایش آگاهی از برند',
				'rank_support'    => 'حمایت از رتبه صفحات خدمات و دسته‌بندی‌ها',
			);
			$active_goals = array();
			foreach ( $biz['content_goals'] as $gk ) {
				if ( isset( $goal_labels[ $gk ] ) ) {
					$active_goals[] = $goal_labels[ $gk ];
				}
			}
			if ( ! empty( $active_goals ) ) {
				$brief_lines[] = '- هدف اصلی این محتوا برای کسب‌وکار: ' . implode( '، ', $active_goals );
			}
		}
		if ( ! empty( $biz['target_audience'] ) ) {
			$brief_lines[] = '- پرسونای مخاطب هدف و دغدغه‌های آنها: ' . $biz['target_audience'];
		}

		$brief_lines[] = '';
		$brief_lines[] = 'بریف محتوایی مقاله:';
		$brief_lines[] = '- عنوان اصلی مقاله: ' . $title;
		if ( ! empty( $alt_titles ) ) {
			$brief_lines[] = '- عناوین جایگزین / زوایای مرتبط: ' . implode( ' | ', $alt_titles );
		}
		if ( '' !== $keyword ) {
			$brief_lines[] = '- کلمه کلیدی اصلی: ' . $keyword;
		}
		if ( '' !== $url_slug ) {
			$brief_lines[] = '- اسلاگ پیشنهادی: ' . $url_slug;
		}
		if ( '' !== $intent_fa ) {
			$brief_lines[] = '- هدف جستجو (Search Intent): ' . $intent_fa;
		}
		if ( '' !== $core_need ) {
			$brief_lines[] = '- نیاز اصلی کاربر: ' . $core_need;
		}
		if ( '' !== $decision_txt ) {
			$brief_lines[] = '- رویکرد استراتژیک سئو: ' . $decision_txt;
		}

		$secondary_kws = isset( $brief['secondary_keywords'] ) && is_array( $brief['secondary_keywords'] ) ? $brief['secondary_keywords'] : array();
		if ( ! empty( $secondary_kws ) ) {
			$brief_lines[] = '- کلمات کلیدی فرعی و هم‌خانواده (LSI & Semantic Keywords - حتماً به‌صورت طبیعی در طول متن و سرفصل‌ها به کار روند): ' . implode( '، ', array_map( 'sanitize_text_field', $secondary_kws ) );
		}

		$approved_headings = isset( $brief['headings'] ) && is_array( $brief['headings'] ) ? $brief['headings'] : array();
		if ( ! empty( $approved_headings ) ) {
			$brief_lines[] = '';
			$brief_lines[] = '=== ساختار سرفصل‌ها و تیترهای مصوب مقاله (H2 / H3 Approved Outline) ===';
			$brief_lines[] = 'استراتژیست سئو ساختار سرفصل‌های زیر را مصوب نموده است؛ بدنه اصلی مقاله باید حتماً بر اساس این سرفصل‌های H2 و H3 ساختاربندی و تدوین شود:';
			foreach ( $approved_headings as $hd ) {
				$clean_h = trim( sanitize_text_field( $hd ) );
				if ( '' !== $clean_h ) {
					$brief_lines[] = '- ' . $clean_h;
				}
			}
		}

		if ( '' !== $keyword && class_exists( 'SEOPM\\SERP_Analyzer' ) ) {
			$art_serp = SERP_Analyzer::get_serp_digest( array( $keyword ), 5 );
			if ( ! empty( $art_serp ) ) {
				$brief_lines[] = '';
				$brief_lines[] = $art_serp;
			}
		}

		$brief_lines[] = '';
		$brief_lines[] = 'استراتژی لینک‌سازی داخلی (حتماً با تگ <a> واقعی در متن قرار داده شود):';
		if ( '' !== $pillar_title || '' !== $pillar_url ) {
			$brief_lines[] = '- صفحه پیلار هدف: ' . $pillar_title . ' | URL دقیق: ' . $pillar_url;
		}
		if ( '' !== $primary_anc ) {
			$brief_lines[] = '- انکرتکست دقیق اصلی (Exact Match): ' . $primary_anc;
		}
		if ( ! empty( $sec_anchors ) ) {
			$brief_lines[] = '- انکرتکست‌های مکمل / توصیفی: ' . implode( '، ', $sec_anchors );
		}
		if ( ! empty( $placement['intro_link'] ) ) {
			$brief_lines[] = '- لینک مقدمه: ' . sanitize_text_field( $placement['intro_link'] );
		}
		if ( ! empty( $placement['body_link'] ) ) {
			$brief_lines[] = '- لینک بدنه: ' . sanitize_text_field( $placement['body_link'] );
		}
		if ( ! empty( $placement['cta_link'] ) ) {
			$brief_lines[] = '- لینک طبیعی در پاراگراف نتیجه‌گیری (درون متن نتیجه‌گیری و بدون ایجاد باکس تبلیغاتی جداگانه بعد از FAQ): ' . sanitize_text_field( $placement['cta_link'] );
		}

		$sister = isset( $brief['sister_cluster_link'] ) && is_array( $brief['sister_cluster_link'] ) ? $brief['sister_cluster_link'] : array();
		if ( ! empty( $sister['target_topic'] ) ) {
			$brief_lines[] = '- پیشنهاد لینک بین‌خوشه‌ای (Sister Cluster Link): به مقاله/موضوع «' . sanitize_text_field( $sister['target_topic'] ) . '» با انکرتکست «' . sanitize_text_field( $sister['anchor_text'] ?? '' ) . '» جهت تقویت معماری تاپیک کلاستر پیوند داده شود.';
		}

		if ( ! empty( $sitemap_summary ) ) {
			$brief_lines[] = '';
			$brief_lines[] = '=== نقشه سایت و ساختار محتوایی وب‌سایت (Sitemap Data) ===';
			$brief_lines   = array_merge( $brief_lines, $sitemap_summary );
			$brief_lines[] = '';
			$brief_lines[] = 'دستورالعمل تطبیق با نقشه سایت: در پرامپت اختصاصی این کسب‌وکار به نقشه سایت (Sitemap) اشاره شده است. حتماً از ساختار، صفحات پیلار و مقالات استخراج‌شده از نقشه سایت در بالا برای لینک‌دهی داخلی طبیعی در طول مقاله استفاده کن. تمام لینک‌های داخلی را با تگ واقعی <a href="..." target="_blank" rel="noopener">انکرتکست دقیق</a> در دل متن جایگذاری نما.';
		}

		if ( '' !== $custom_prompt ) {
			$brief_lines[] = '';
			$brief_lines[] = 'توجه: تمام اصول کیفی، لحن، ساختار محتوایی و قوانین استناددهی «پرامپت اختصاصی نگارش مقاله» این کسب‌وکار را دقیقاً رعایت کن، اما فقط و فقط متن قابل‌انتشار مقاله را (بدون بلوک تحلیل Search Intent و Information Gain در ابتدا، بدون باکس تبلیغاتی پس از FAQ، بدون جدول متادیتا، بدون کد Schema JSON-LD و بدون گزارش لینک‌ها در انتها) تحویل بده.';
		} else {
			$brief_lines[] = '';
			$brief_lines[] = 'ساختار پیشنهادی: خلاصه کوتاه، مقدمه جذاب (دارای لینک اول به پیلار)، حداقل ۴ تا ۶ بخش تخصصی با هدینگ‌های <h2> و <h3>، نکات کاربردی به‌صورت لیست بولت، یک جدول مقایسه‌ای یا راهنما (در صورت تناسب موضوع)، جمع‌بندی با لینک طبیعی به پیلار و بخش سوالات متداول (FAQ) به عنوان بخش پایانی مقاله.';
		}

		if ( '' !== $prompt_internal ) {
			$brief_lines[] = '';
			$brief_lines[] = '=== دستورالعمل اختصاصی لینک‌دهی داخلی این کسب‌وکار (الزامی) ===';
			$brief_lines[] = $prompt_internal;
		}

		if ( '' !== $prompt_external ) {
			$brief_lines[] = '';
			$brief_lines[] = '=== دستورالعمل اختصاصی منابع مورد استفاده و لینک‌دهی خارجی این کسب‌وکار (الزامی) ===';
			$brief_lines[] = $prompt_external;
		}

		$user_prompt = implode( "\n", $brief_lines );

		$ai_res = AI_Client::generate(
			$user_prompt,
			$system_prompt,
			array(
				'max_tokens' => 8192,
				'timeout'    => 120,
			)
		);

		if ( empty( $ai_res['success'] ) || empty( $ai_res['text'] ) ) {
			return new \WP_Error(
				'seopm_ai_failed',
				$ai_res['message'] ?? __( 'خطا در تولید متن مقاله توسط هوش مصنوعی.', 'seo-project-manager' ),
				array( 'status' => 502 )
			);
		}

		$rich_html = self::normalize_rich_article( $ai_res['text'] );
		$key       = ! empty( $brief['article_key'] ) ? sanitize_key( $brief['article_key'] ) : self::make_key( $title );

		$saved = self::save_draft(
			$business_id,
			$key,
			array(
				'title'           => $title,
				'keyword'         => $keyword,
				'url_slug'        => $url_slug,
				'article_content' => $rich_html,
				'provider'        => $ai_check['provider'],
				'model'           => $ai_check['model'],
			)
		);

		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		$saved['used_custom_prompt'] = ( '' !== $custom_prompt );
		return $saved;
	}

	/**
	 * Convert edited article content into final HTML code using business's HTML conversion prompt.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $payload     Payload with article_key, title, article_content, brief metadata.
	 * @return array|\WP_Error
	 */
	public static function convert_to_html( $business_id, array $payload ) {
		$business_id = self::resolve_business_id( $business_id, $payload );
		$biz         = $business_id ? Business::get( $business_id, false ) : null;
		if ( ! $biz ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$biz         = Business::get( $business_id, false );
			}
		}
		if ( ! $biz ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'هیچ کسب‌وکاری در سامانه یافت نشد. لطفاً ابتدا در بخش کسب‌وکارها یک کسب‌وکار تعریف کنید.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$title       = trim( sanitize_text_field( $payload['title'] ?? $payload['best_title'] ?? '' ) );
		$article_key = ! empty( $payload['article_key'] ) ? sanitize_key( $payload['article_key'] ) : ( '' !== $title ? self::make_key( $title ) : '' );
		if ( '' === $article_key ) {
			return new \WP_Error( 'seopm_missing_key', __( 'شناسه مقاله مشخص نیست.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$existing        = self::get_draft( $business_id, $article_key );
		$article_content = isset( $payload['article_content'] ) ? trim( (string) $payload['article_content'] ) : '';
		if ( '' === $article_content && $existing ) {
			$article_content = trim( (string) ( $existing['article_content'] ?? '' ) );
		}

		if ( '' === wp_strip_all_tags( $article_content ) ) {
			return new \WP_Error(
				'seopm_empty_article',
				__( 'ابتدا باید متن مقاله نگارش شود تا بتوان آن را به کد HTML تبدیل کرد.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$ai_check = self::ensure_ai_ready();
		if ( is_wp_error( $ai_check ) ) {
			return $ai_check;
		}

		$keyword       = trim( sanitize_text_field( $payload['keyword'] ?? ( $existing['keyword'] ?? '' ) ) );
		$url_slug      = Content_Suggester::clean_slug( $payload['url_slug'] ?? ( $existing['url_slug'] ?? '' ) );
		$pillar        = isset( $payload['pillar'] ) && is_array( $payload['pillar'] ) ? $payload['pillar'] : array();
		$pillar_url    = esc_url_raw( $pillar['target_pillar_url'] ?? $biz['website_url'] ?? '' );
		$article_info  = array_merge( is_array( $existing ) ? $existing : array(), $payload, array(
			'title'           => $title,
			'best_title'      => $title,
			'keyword'         => $keyword,
			'url_slug'        => $url_slug,
			'article_content' => $article_content,
			'content'         => $article_content,
		) );
		$custom_prompt = Business::expand_shortcodes( trim( (string) ( $biz['prompt_html_conversion'] ?? '' ) ), $biz, $article_info );

		$system_prompt = "تو یک متخصص ارشد فرانت‌اند وردپرس و سئو فنی هستی. وظیفه تو تبدیل متن مقاله به کد HTML تمیز، استاندارد، واکنش‌گرا (RTL فارسی) و آماده انتشار در وردپرس است.\n" .
			"قوانین الزامی:\n" .
			"- فقط و فقط کد HTML نهایی را خروجی بده (بدون هیچ توضیح اضافی قبل یا بعد از کد، و بدون بلاک Markdown مانند ```html).\n" .
			"- تمام متن، هدینگ‌ها و به‌ویژه تمام هایپرلینک‌ها (<a href=\"...\">...</a>) موجود در متن ورودی را دقیقاً بدون حذف یا تغییر آدرس حفظ کن.\n" .
			"- از محتوای ورودی چیزی حذف یا خلاصه نکن.";

		if ( '' !== $custom_prompt ) {
			$system_prompt .= "\n\n=== پرامپت و دستورالعمل اختصاصی تبدیل مقاله به کد HTML این کسب‌وکار (اولویت اول و لازم‌الاجرا) ===\n" . $custom_prompt;
		} else {
			$system_prompt .= "\n\nساختار پیش‌فرض: کد HTML معنایی تمیز (فقط بدنه مقاله بدون <html> و <body>)، با ساختار منظم <article>، <h2>، <h3>، <p>، لیست‌ها، جداول ریسپانسیو، باکس نکات کلیدی، بخش سوالات متداول (FAQ) و باکس دعوت به اقدام (CTA) مناسب وب‌سایت فارسی RTL.";
		}

		$user_prompt = "اطلاعات مقاله:\n" .
			'- نام کسب‌وکار: ' . $biz['name'] . "\n" .
			'- وب‌سایت: ' . ( $biz['website_url'] ?: '—' ) . "\n" .
			'- عنوان مقاله: ' . ( $title ?: ( $existing['title'] ?? '' ) ) . "\n" .
			'- کلمه کلیدی اصلی: ' . ( $keyword ?: '—' ) . "\n" .
			'- اسلاگ مقاله: ' . ( $url_slug ?: '—' ) . "\n" .
			( $pillar_url ? '- لینک صفحه پیلار هدف: ' . $pillar_url . "\n" : '' ) .
			"\nمتن مقاله (همراه با هایپرلینک‌ها) جهت تبدیل به کد HTML:\n\n" .
			$article_content;

		$ai_res = AI_Client::generate(
			$user_prompt,
			$system_prompt,
			array(
				'max_tokens' => 8192,
				'timeout'    => 120,
			)
		);

		if ( empty( $ai_res['success'] ) || empty( $ai_res['text'] ) ) {
			return new \WP_Error(
				'seopm_ai_failed',
				$ai_res['message'] ?? __( 'خطا در تبدیل مقاله به کد HTML توسط هوش مصنوعی.', 'seo-project-manager' ),
				array( 'status' => 502 )
			);
		}

		$html_code = self::strip_code_fences( $ai_res['text'] );

		// If the draft already has image(s) ticked as in-content, automatically inject them full-size before <h2>.
		if ( ! empty( $existing['images'] ) && is_array( $existing['images'] ) ) {
			$in_content = array_values(
				array_filter(
					$existing['images'],
					static function ( $im ) {
						return ! empty( $im['is_in_content'] ) && ! empty( $im['url'] );
					}
				)
			);
			if ( ! empty( $in_content ) ) {
				$html_code = self::inject_in_content_images( $html_code, $in_content, $title ?: ( $existing['title'] ?? '' ) );
			}
		}

		$save_fields = array(
			'title'        => $title ?: ( $existing['title'] ?? '' ),
			'keyword'      => $keyword,
			'url_slug'     => $url_slug,
			'article_html' => $html_code,
			'provider'     => $ai_check['provider'],
			'model'        => $ai_check['model'],
		);
		if ( isset( $payload['article_content'] ) && '' !== trim( (string) $payload['article_content'] ) ) {
			$save_fields['article_content'] = (string) $payload['article_content'];
		}

		$saved = self::save_draft( $business_id, $article_key, $save_fields );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		$saved['used_custom_prompt'] = ( '' !== $custom_prompt );
		return $saved;
	}

	/**
	 * Perform internal linking on article content using business's internal linking prompt and sitemap structure.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $payload     Payload with article_key, title, keyword, article_content, optional custom_prompt.
	 * @return array|\WP_Error
	 */
	public static function generate_internal_links( $business_id, array $payload ) {
		$business_id = self::resolve_business_id( $business_id, $payload );
		$biz         = $business_id ? Business::get( $business_id, false ) : null;
		if ( ! $biz ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$biz         = Business::get( $business_id, false );
			}
		}
		if ( ! $biz ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'هیچ کسب‌وکاری در سامانه یافت نشد. لطفاً ابتدا در بخش کسب‌وکارها یک کسب‌وکار تعریف کنید.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$title       = trim( sanitize_text_field( $payload['title'] ?? $payload['best_title'] ?? '' ) );
		$article_key = ! empty( $payload['article_key'] ) ? sanitize_key( $payload['article_key'] ) : ( '' !== $title ? self::make_key( $title ) : '' );
		if ( '' === $article_key ) {
			return new \WP_Error( 'seopm_missing_key', __( 'شناسه یا عنوان مقاله مشخص نیست.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$existing        = self::get_draft( $business_id, $article_key );
		$article_content = isset( $payload['article_content'] ) ? trim( (string) $payload['article_content'] ) : '';
		if ( '' === $article_content && $existing ) {
			$article_content = trim( (string) ( $existing['article_content'] ?? '' ) );
		}

		if ( '' === wp_strip_all_tags( $article_content ) ) {
			return new \WP_Error(
				'seopm_empty_article',
				__( 'ابتدا باید متن مقاله نگارش شود تا بتوان روی آن لینک‌سازی داخلی انجام داد.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$ai_check = self::ensure_ai_ready();
		if ( is_wp_error( $ai_check ) ) {
			return $ai_check;
		}

		$keyword      = trim( sanitize_text_field( $payload['keyword'] ?? ( $existing['keyword'] ?? '' ) ) );
		$url_slug     = Content_Suggester::clean_slug( $payload['url_slug'] ?? ( $existing['url_slug'] ?? '' ) );
		$pillar       = isset( $payload['pillar'] ) && is_array( $payload['pillar'] ) ? $payload['pillar'] : array();
		$pillar_title = trim( sanitize_text_field( $pillar['target_pillar_title'] ?? '' ) );
		$pillar_url   = esc_url_raw( $pillar['target_pillar_url'] ?? '' );
		$primary_anc  = trim( sanitize_text_field( $pillar['primary_anchor'] ?? $keyword ) );
		$sec_anchors  = isset( $pillar['secondary_anchors'] ) && is_array( $pillar['secondary_anchors'] ) ? array_map( 'sanitize_text_field', $pillar['secondary_anchors'] ) : array();

		// Fetch complete crawled site content & sitemap data.
		$report      = Site_Crawler::get_report( $business_id );
		$sitemap_url = trim( (string) ( $biz['sitemap_url'] ?? '' ) );
		$pages       = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['pages'] ) ) ? $report['pages'] : array();
		$posts       = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['posts'] ) ) ? $report['posts'] : array();

		// If pillar URL was not provided, attempt to detect from crawled pages.
		if ( empty( $pillar_url ) && ! empty( $pages ) ) {
			$detected_pillar = Content_Suggester::find_target_pillar( $keyword, $pages, $biz );
			if ( ! empty( $detected_pillar['target_pillar_url'] ) ) {
				$pillar_title = $detected_pillar['target_pillar_title'] ?? '';
				$pillar_url   = $detected_pillar['target_pillar_url'];
				if ( empty( $primary_anc ) ) {
					$primary_anc = $detected_pillar['primary_anchor'] ?? $keyword;
				}
				if ( empty( $sec_anchors ) && ! empty( $detected_pillar['secondary_anchors'] ) ) {
					$sec_anchors = $detected_pillar['secondary_anchors'];
				}
			}
		}

		// Build structured sitemap reference lines (pages + relevant posts).
		$candidate_links = array();
		if ( ! empty( $pillar_url ) ) {
			$candidate_links[] = '- [صفحه پیلار هدف اصلی] ' . ( $pillar_title ?: 'پیلار خدمات' ) . ' | URL: ' . $pillar_url;
		}

		// Add crawled pages (landing pages, service pages, categories).
		$p_count = 0;
		foreach ( $pages as $p ) {
			if ( ! empty( $p['title'] ) && ! empty( $p['url'] ) ) {
				if ( ! empty( $pillar_url ) && untrailingslashit( $p['url'] ) === untrailingslashit( $pillar_url ) ) {
					continue;
				}
				$candidate_links[] = '- [صفحه خدمات/لندینگ] ' . $p['title'] . ' | URL: ' . $p['url'];
				$p_count++;
				if ( $p_count >= 30 ) {
					break;
				}
			}
		}

		// Add top relevant crawled blog posts.
		if ( ! empty( $posts ) ) {
			$ranked_posts = self::rank_posts_for_article( $posts, $keyword, $title );
			$post_count   = 0;
			foreach ( $ranked_posts as $rp ) {
				if ( ! empty( $rp['title'] ) && ! empty( $rp['url'] ) ) {
					if ( ! empty( $pillar_url ) && untrailingslashit( $rp['url'] ) === untrailingslashit( $pillar_url ) ) {
						continue;
					}
					if ( ! empty( $url_slug ) && false !== stripos( $rp['url'], $url_slug ) ) {
						continue;
					}
					$candidate_links[] = '- [مقاله مرتبط وبلاگ] ' . $rp['title'] . ' | URL: ' . $rp['url'];
					$post_count++;
					if ( $post_count >= 25 ) {
						break;
					}
				}
			}
		}

		$article_info  = array_merge( is_array( $existing ) ? $existing : array(), $payload, array(
			'title'           => $title ?: ( $existing['title'] ?? '' ),
			'best_title'      => $title ?: ( $existing['title'] ?? '' ),
			'keyword'         => $keyword,
			'url_slug'        => $url_slug,
			'article_content' => $article_content,
			'content'         => $article_content,
			'pillar'          => $pillar,
		) );
		$custom_prompt = Business::expand_shortcodes( trim( (string) ( $biz['prompt_internal_links'] ?? '' ) ), $biz, $article_info );

		$system_prompt = "تو یک استراتژیست ارشد سئو داخلی (On-Page SEO) و متخصص معماری پیوند یکپارچه (Internal Linking & Topic Cluster) در وب فارسی هستی.\n" .
			"وظیفه تو این است که متن مقاله ارائه‌شده را با دقت بررسی کنی و پیوندهای داخلی متنی، استراتژیک و کاملاً طبیعی (Contextual Internal Hyperlinks) را با تگ استاندارد HTML در دل پاراگراف‌های مقاله قرار دهی.\n\n" .
			"قوانین حیاتی و غیرقابل تخطی:\n" .
			"۱. حفظ صددرصدی متن و ساختار: به هیچ عنوان محتوای مقاله را حذف، خلاصه یا بازنویسی کلی نکن. تمام هدینگ‌ها (<h2> و <h3>)، لیست‌ها و جداول باید دست‌نخورده باقی بمانند. فقط کلمات یا عبارات مناسب درون پاراگراف‌ها را داخل تگ <a href=\"...\" target=\"_blank\" rel=\"noopener\">انکرتکست</a> قرار بده.\n" .
			"۲. استفاده انحصاری از URLهای تاییدشده: اکیداً و تحت هیچ شرایطی حق نداری هیچ آدرسی را اختراع کنی، حدس بزنی یا تغییر دهی. فقط و فقط از لیست «صفحات و مقالات تاییدشده وب‌سایت» که در اختیارت قرار گرفته استفاده کن.\n" .
			"۳. لینک به صفحه پیلار هدف (Target Pillar): اگر صفحه پیلار مشخص است، حتماً در بخش‌های ابتدایی مقاله (مقدمه یا بخش اول/دوم) یک پیوند قوی و زمینه‌ای با انکرتکست دقیق یا عبارتی مرتبط به این صفحه بده.\n" .
			"۴. توزیع متعادل و طبیعی (Natural Distribution): تعداد ۳ تا ۶ پیوند داخلی متنی در طول کل مقاله پخش کن. در یک پاراگراف بیش از یک لینک نگذار و از ایجاد انکرتکست‌های مصنوعی یا اسپم‌گونه جداً پرهیز کن.\n" .
			"۵. انکرتکست‌های طبیعی و توصیفی: انکرتکست‌ها باید عبارات معنادار فارسی (۲ تا ۵ کلمه) باشند و مخاطب را مشتاق به کلیک کنند. هرگز از عبارات تک‌کلمه‌ای نامفهوم مانند «اینجا»، «کلیک کنید» یا «بخوانید» استفاده نکن.\n" .
			"۶. اولویت اولین لینک (First Link Priority): مهم‌ترین انکرتکست باید در اولین ارجاع به هر URL قرار گیرد.\n" .
			"۷. فرمت خروجی: فقط و فقط متن کامل مقاله را همراه با هایپرلینک‌های درج‌شده خروجی بده، بدون هیچ توضیح اضافی، بدون پیش‌گفتار یا پس‌گفتار، و بدون کدهای Markdown یا ```html.";

		if ( '' !== $custom_prompt ) {
			$system_prompt .= "\n\n=== دستورالعمل و پرامپت اختصاصی لینک‌سازی داخلی این کسب‌وکار (اولویت اول و لازم‌الاجرا) ===\n" . $custom_prompt;
		}

		$user_lines = array(
			'اطلاعات کسب‌وکار و مقاله:',
			'- نام برند: ' . $biz['name'],
			'- وب‌سایت: ' . ( $biz['website_url'] ?: '—' ),
			'- نقشه سایت: ' . ( $sitemap_url ?: '—' ),
			'- عنوان مقاله: ' . ( $title ?: ( $existing['title'] ?? '' ) ),
			'- کلمه کلیدی اصلی: ' . ( $keyword ?: '—' ),
			'- اسلاگ مقاله: ' . ( $url_slug ?: '—' ),
		);

		if ( ! empty( $pillar_url ) ) {
			$user_lines[] = '';
			$user_lines[] = 'صفحه پیلار هدف (پیلار کلاستر):';
			$user_lines[] = '- عنوان پیلار: ' . ( $pillar_title ?: 'پیلار خدمات' );
			$user_lines[] = '- آدرس دقیق (URL): ' . $pillar_url;
			if ( ! empty( $primary_anc ) ) {
				$user_lines[] = '- انکرتکست پیشنهادی اصلی: ' . $primary_anc;
			}
			if ( ! empty( $sec_anchors ) ) {
				$user_lines[] = '- انکرتکست‌های مکمل: ' . implode( '، ', $sec_anchors );
			}
		}

		if ( ! empty( $candidate_links ) ) {
			$user_lines[] = '';
			$user_lines[] = '=== صفحات و مقالات معتبر و تاییدشده وب‌سایت جهت انتخاب لینک داخلی (فقط مجاز به استفاده از این URLها هستید) ===';
			$user_lines   = array_merge( $user_lines, $candidate_links );
		}

		$user_lines[] = '';
		$user_lines[] = 'متن مقاله ورودی جهت پیاده‌سازی و درج هایپرلینک‌های داخلی:';
		$user_lines[] = $article_content;

		$user_prompt = implode( "\n", $user_lines );

		$ai_res = AI_Client::generate(
			$user_prompt,
			$system_prompt,
			array(
				'max_tokens' => 8192,
				'timeout'    => 120,
			)
		);

		if ( empty( $ai_res['success'] ) || empty( $ai_res['text'] ) ) {
			return new \WP_Error(
				'seopm_ai_failed',
				$ai_res['message'] ?? __( 'خطا در لینک‌سازی داخلی مقاله توسط هوش مصنوعی.', 'seo-project-manager' ),
				array( 'status' => 502 )
			);
		}

		$enriched = self::normalize_rich_article( self::strip_code_fences( $ai_res['text'] ) );

		// Extract all links to summarize for frontend.
		$found_links = array();
		if ( preg_match_all( '/<a\b[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/isu', $enriched, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $m ) {
				$found_links[] = array(
					'url'    => esc_url_raw( $m[1] ),
					'anchor' => trim( wp_strip_all_tags( $m[2] ) ),
				);
			}
		}

		$save_fields = array(
			'title'           => $title ?: ( $existing['title'] ?? '' ),
			'keyword'         => $keyword,
			'url_slug'        => $url_slug,
			'article_content' => $enriched,
			'provider'        => $ai_check['provider'],
			'model'           => $ai_check['model'],
		);

		$saved = self::save_draft( $business_id, $article_key, $save_fields );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		$saved['links']              = $found_links;
		$saved['link_count']         = count( $found_links );
		$saved['has_links']          = count( $found_links ) > 0;
		$saved['used_custom_prompt'] = ( '' !== $custom_prompt );

		return $saved;
	}

	/**
	 * Rank existing posts so those matching the target keyword or title tokens appear first.
	 *
	 * @param array  $posts   All posts from crawler.
	 * @param string $keyword Target keyword.
	 * @param string $title   Article title.
	 * @return array
	 */
	private static function rank_posts_for_article( array $posts, $keyword, $title ) {
		$query_str = mb_strtolower( trim( (string) $keyword . ' ' . (string) $title ) );
		$tokens    = array_unique(
			array_filter(
				preg_split( '/[\s\-_،,؟?]+/u', $query_str ),
				static function ( $t ) {
					return mb_strlen( $t ) > 2 && ! in_array( $t, array( 'در', 'به', 'با', 'از', 'برای', 'های', 'یک', 'این', 'آن', 'چیست', 'چه', 'چگونه', 'است', 'کند' ), true );
				}
			)
		);

		if ( empty( $tokens ) ) {
			return $posts;
		}

		$scored = array();
		foreach ( $posts as $idx => $p ) {
			$score = 0;
			$text  = mb_strtolower( ( $p['title'] ?? '' ) . ' ' . ( $p['url'] ?? '' ) );
			foreach ( $tokens as $t ) {
				if ( false !== mb_stripos( $text, $t ) ) {
					$score += 10;
				}
			}
			$scored[] = array(
				'score' => $score,
				'idx'   => $idx,
				'post'  => $p,
			);
		}

		usort(
			$scored,
			static function ( $a, $b ) {
				if ( $a['score'] === $b['score'] ) {
					return $a['idx'] <=> $b['idx'];
				}
				return $b['score'] <=> $a['score'];
			}
		);

		return array_column( $scored, 'post' );
	}

	/**
	 * Verify active AI provider & API key.
	 *
	 * @return array{provider:string,model:string}|\WP_Error
	 */
	private static function ensure_ai_ready() {
		$settings  = Settings::all();
		$provider  = $settings['ai_active_provider'] ?? 'none';
		$providers = AI_Client::get_providers();

		if ( 'none' === $provider || ! isset( $providers[ $provider ] ) ) {
			return new \WP_Error(
				'seopm_no_ai_provider',
				__( 'هیچ موتور هوش مصنوعی فعالی انتخاب نشده است. لطفاً ابتدا از بخش «تنظیمات ← اتصال به هوش مصنوعی» یکی از سرویس‌های جمنای، چت‌جی‌پی‌تی، دیپ‌سیک یا کلود را فعال کنید.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$api_key = trim( (string) ( $settings[ $provider . '_api_key' ] ?? '' ) );
		if ( '' === $api_key ) {
			return new \WP_Error(
				'seopm_no_ai_key',
				sprintf(
					/* translators: %s: provider short name */
					__( 'کلید API برای %s در تنظیمات افزونه ثبت نشده است.', 'seo-project-manager' ),
					$providers[ $provider ]['short_name']
				),
				array( 'status' => 400 )
			);
		}

		$model = $settings[ $provider . '_model' ] ?? $providers[ $provider ]['default_model'];
		if ( 'avalai' === $provider && ! empty( $settings['avalai_custom_model'] ) ) {
			$model = trim( (string) $settings['avalai_custom_model'] );
		}
		return array(
			'provider' => $provider,
			'model'    => $model,
		);
	}

	/**
	 * Strip outer markdown code fences from AI response.
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	private static function strip_code_fences( $text ) {
		$text = trim( (string) $text );
		if ( preg_match( '/^```(?:html|htm|xml|markdown|md)?\s*([\s\S]*?)\s*```$/i', $text, $m ) ) {
			return trim( $m[1] );
		}
		if ( preg_match( '/```(?:html|htm)\s*([\s\S]*?)\s*```/i', $text, $m ) ) {
			return trim( $m[1] );
		}
		return $text;
	}

	/**
	 * Strip non-article leading/trailing meta blocks (Search Intent analysis, SEO metadata tables,
	 * JSON-LD Schema code blocks, outbound/internal link reports).
	 *
	 * @param string $text Raw or partially normalized article text.
	 * @return string
	 */
	private static function strip_non_article_blocks( $text ) {
		$text = trim( (string) $text );
		if ( '' === $text ) {
			return '';
		}

		// 1. Remove any fenced code blocks containing SEO metadata tables, JSON-LD Schema, or link reports.
		$meta_block_re = '/@context|schema\.org|MedicalWebPage|FAQPage|Title\s*Tag|Discover\s*Title|Meta\s*Description|URL\s*Slug|تعداد\s*کاراکتر|گزارش\s*توزیع\s*لینک|پیشنهاد\s*لینک|برنامه\s*لینک/iu';
		$text          = preg_replace_callback(
			'/```[a-zA-Z0-9_-]*\s*([\s\S]*?)(?:```|\z)/u',
			static function ( $m ) use ( $meta_block_re ) {
				return preg_match( $meta_block_re, $m[1] ) ? '' : $m[0];
			},
			$text
		);

		// Also strip <pre>...</pre> or <code>...</code> blocks carrying those same meta outputs.
		$text = preg_replace_callback(
			'#<(pre|code)\b[^>]*>([\s\S]*?)</\1>#iu',
			static function ( $m ) use ( $meta_block_re ) {
				return preg_match( $meta_block_re, $m[2] ) ? '' : $m[0];
			},
			$text
		);

		// 2. Remove leading "تحلیل Search Intent و Information Gain" (Intent / Gap / Angle) block if present.
		$head_sample = mb_substr( $text, 0, 400 );
		if ( preg_match( '/تحلیل\s*Search\s*Intent|Search\s*Intent\s*و\s*Information\s*Gain|Information\s*Gain\s*[:：]/iu', $head_sample ) ) {
			$search_zone = mb_substr( $text, 0, 3500 );
			if ( preg_match( '/(?:Angle\s*[:：]|زاویه(?:‌|ی)?\s*تمایز\s*این\s*مقاله)/iu', $search_zone, $am, PREG_OFFSET_CAPTURE ) ) {
				$angle_byte_pos = $am[0][1];
				$after_angle    = substr( $text, $angle_byte_pos );
				$cut_offset     = null;

				// Check if Angle is inside an HTML list (<ol> / <ul>).
				if ( preg_match( '#</(?:ol|ul)>#i', substr( $after_angle, 0, 1200 ), $lm, PREG_OFFSET_CAPTURE ) ) {
					$cut_offset = $angle_byte_pos + $lm[0][1] + strlen( $lm[0][0] );
				} elseif ( preg_match( '#</p>#i', substr( $after_angle, 0, 1000 ), $pm, PREG_OFFSET_CAPTURE ) ) {
					$cut_offset = $angle_byte_pos + $pm[0][1] + strlen( $pm[0][0] );
				} elseif ( preg_match( '/\r?\n/', $after_angle, $nm, PREG_OFFSET_CAPTURE ) ) {
					$cut_offset = $angle_byte_pos + $nm[0][1] + strlen( $nm[0][0] );
				}

				if ( null !== $cut_offset && $cut_offset < strlen( $text ) ) {
					$text = ltrim( substr( $text, $cut_offset ) );
					$text = preg_replace( '#^(?:\s*<hr\s*/?>\s*|\s*---+\s*)+#i', '', $text );
				}
			}
		}

		// 3. Remove trailing non-fenced meta sections (SEO metadata table, Schema JSON-LD, link reports)
		//    ONLY when they appear in the second half of the text so real body content is never harmed.
		$total_bytes = strlen( $text );
		$min_offset  = (int) floor( $total_bytes * 0.45 );
		// Advance to a valid UTF-8 character boundary so /u regexes never hit PREG_BAD_UTF8_ERROR.
		while ( $min_offset < $total_bytes && ( ord( $text[ $min_offset ] ) & 0xC0 ) === 0x80 ) {
			$min_offset++;
		}
		$tail = substr( $text, $min_offset );

		$trailing_markers = array(
			'/(?:^|\n)\s*(?:#{1,4}\s*|<h[2-4][^>]*>|<p[^>]*>\s*(?:<strong[^>]*>)?|\*\*)\s*(?:\d+[\.\)]\s*)?جدول\s+متادیتای\s+سئو/iu',
			'/(?:^|\n)\s*(?:#{1,4}\s*|<h[2-4][^>]*>|<p[^>]*>\s*(?:<strong[^>]*>)?|\*\*)\s*(?:\d+[\.\)]\s*)?(?:کد\s+آماده\s+Schema|Schema\s+Markup)/iu',
			'/(?:^|\n)\s*(?:#{1,4}\s*|<h[2-4][^>]*>|<p[^>]*>\s*(?:<strong[^>]*>)?|\*\*)\s*(?:\d+[\.\)]\s*)?گزارش\s+توزیع\s+لینک/iu',
			'/(?:^|\n)\s*(?:#{1,4}\s*|<h[2-4][^>]*>|<p[^>]*>\s*(?:<strong[^>]*>)?|\*\*)\s*(?:\d+[\.\)]\s*)?(?:برنامه\s+لینک[‌\s]*سازی\s+داخلی|پیشنهاد\s+لینک[‌\s]*دهی\s+داخلی)/iu',
			'/(?:^|\n)\s*\|\s*فیلد\s*\|\s*مقدار\s*\|/iu',
			'/\{\s*"@context"\s*:\s*"https?:\/\/schema\.org"/iu',
		);

		$earliest_tail_pos = null;
		foreach ( $trailing_markers as $pattern ) {
			if ( preg_match( $pattern, $tail, $tm, PREG_OFFSET_CAPTURE ) ) {
				$pos = $tm[0][1];
				if ( null === $earliest_tail_pos || $pos < $earliest_tail_pos ) {
					$earliest_tail_pos = $pos;
				}
			}
		}

		if ( null !== $earliest_tail_pos ) {
			$text = rtrim( substr( $text, 0, $min_offset + $earliest_tail_pos ) );
		}

		// Also remove any trailing HTML <table> that is an SEO metadata table (contains Title Tag + Meta Description).
		$text = preg_replace_callback(
			'#(?:<(?:h[2-4]|p)[^>]*>[^<]*متادیتا[^<]*</(?:h[2-4]|p)>\s*)?<table\b[^>]*>[\s\S]*?</table>\s*$#iu',
			static function ( $m ) {
				return ( false !== stripos( $m[0], 'Title Tag' ) && false !== stripos( $m[0], 'Meta Description' ) ) ? '' : $m[0];
			},
			$text
		);

		// Clean stray trailing horizontal rules or empty fences.
		$text = preg_replace( '#(?:\s*<hr\s*/?>\s*|\s*---+\s*|\s*```+\s*)+$#i', '', $text );

		return trim( $text );
	}

	/**
	 * Convert a group of Markdown table lines into clean HTML <table>.
	 *
	 * @param array $rows Raw table lines starting with '|'.
	 * @return string
	 */
	private static function markdown_table_to_html( array $rows ) {
		if ( count( $rows ) < 2 ) {
			return '<p>' . implode( '<br>', $rows ) . '</p>';
		}
		$parse_cells = static function ( $row ) {
			$row = trim( $row );
			$row = trim( $row, '|' );
			return array_map( 'trim', explode( '|', $row ) );
		};

		$header_cells = $parse_cells( $rows[0] );
		$sep_line     = trim( $rows[1] );
		$has_sep      = (bool) preg_match( '/^\|?[\s:\-\|]+\|?$/', $sep_line );
		$body_start   = $has_sep ? 2 : 1;

		$html = '<table><thead><tr>';
		foreach ( $header_cells as $cell ) {
			$html .= '<th>' . $cell . '</th>';
		}
		$html .= '</tr></thead><tbody>';

		for ( $i = $body_start; $i < count( $rows ); $i++ ) {
			$cells = $parse_cells( $rows[ $i ] );
			$html .= '<tr>';
			foreach ( $cells as $cell ) {
				$html .= '<td>' . $cell . '</td>';
			}
			$html .= '</tr>';
		}
		$html .= '</tbody></table>';
		return $html;
	}

	/**
	 * Normalize rich article HTML (strip non-article meta blocks + fallback conversion if model returned Markdown).
	 *
	 * @param string $raw Raw AI output.
	 * @return string
	 */
	private static function normalize_rich_article( $raw ) {
		$text = self::strip_code_fences( $raw );
		// Strip accidental document wrapper tags.
		$text = preg_replace( '#<!DOCTYPE[^>]*>#i', '', $text );
		if ( preg_match( '#<body[^>]*>([\s\S]*?)</body>#i', $text, $bm ) ) {
			$text = trim( $bm[1] );
		}

		// Strip leading Search Intent analysis and trailing metadata/schema/link-report blocks.
		$text = self::strip_non_article_blocks( $text );

		// Convert any leftover Markdown links [anchor](https://...) into real <a> tags.
		$text = preg_replace_callback(
			'/\[([^\]]+)\]\((https?:\/\/[^\s\)]+)\)/u',
			static function ( $m ) {
				return '<a href="' . esc_url( $m[2] ) . '" target="_blank" rel="noopener">' . esc_html( $m[1] ) . '</a>';
			},
			$text
		);

		// Unbold parenthesized external citations like **(<a ...>NIH</a>)** or <strong>(<a ...>NIH</a>)</strong>.
		$text = preg_replace( '/\*\*\(\s*(<a\b[^>]*>[^<]+<\/a>)\s*\)\*\*/iu', '($1)', $text );
		$text = preg_replace( '#<(?:strong|b)>\s*\(\s*(<a\b[^>]*>[^<]+</a>)\s*\)\s*</(?:strong|b)>#iu', '($1)', $text );

		// If response lacks HTML block tags, convert Markdown headings/tables/bold/lists/paragraphs.
		if ( ! preg_match( '/<(?:p|h2|h3|ul|ol|div|article)\b/i', $text ) ) {
			$lines      = preg_split( '/\r\n|\r|\n/', $text );
			$out        = array();
			$in_ul      = false;
			$in_ol      = false;
			$table_buf  = array();
			$flush_list = static function () use ( &$out, &$in_ul, &$in_ol ) {
				if ( $in_ul ) {
					$out[] = '</ul>';
					$in_ul = false;
				}
				if ( $in_ol ) {
					$out[] = '</ol>';
					$in_ol = false;
				}
			};
			$flush_table = static function () use ( &$out, &$table_buf ) {
				if ( ! empty( $table_buf ) ) {
					$out[]     = self::markdown_table_to_html( $table_buf );
					$table_buf = array();
				}
			};

			foreach ( $lines as $line ) {
				$trimmed = trim( $line );
				if ( '' === $trimmed ) {
					$flush_table();
					$flush_list();
					continue;
				}
				// Inline bold.
				$trimmed = preg_replace( '/\*\*([^\*]+)\*\*/u', '<strong>$1</strong>', $trimmed );

				// Markdown table row.
				if ( preg_match( '/^\|.+\|$/u', $trimmed ) ) {
					$flush_list();
					$table_buf[] = $trimmed;
					continue;
				}
				$flush_table();

				if ( preg_match( '/^####\s+(.+)$/u', $trimmed, $hm ) ) {
					$flush_list();
					$out[] = '<h4>' . $hm[1] . '</h4>';
				} elseif ( preg_match( '/^###\s+(.+)$/u', $trimmed, $hm ) ) {
					$flush_list();
					$out[] = '<h3>' . $hm[1] . '</h3>';
				} elseif ( preg_match( '/^##?\s+(.+)$/u', $trimmed, $hm ) ) {
					$flush_list();
					$out[] = '<h2>' . $hm[1] . '</h2>';
				} elseif ( preg_match( '/^[\-\*•]\s+(.+)$/u', $trimmed, $lm ) ) {
					if ( $in_ol ) {
						$out[] = '</ol>';
						$in_ol = false;
					}
					if ( ! $in_ul ) {
						$out[] = '<ul>';
						$in_ul = true;
					}
					$out[] = '<li>' . $lm[1] . '</li>';
				} elseif ( preg_match( '/^(?:\d+|[۰-۹]+)[\.\)]\s+(.+)$/u', $trimmed, $lm ) ) {
					if ( $in_ul ) {
						$out[] = '</ul>';
						$in_ul = false;
					}
					if ( ! $in_ol ) {
						$out[] = '<ol>';
						$in_ol = true;
					}
					$out[] = '<li>' . $lm[1] . '</li>';
				} else {
					$flush_list();
					$out[] = '<p>' . $trimmed . '</p>';
				}
			}
			$flush_table();
			$flush_list();
			$text = implode( "\n", $out );
		}

		// Run non-article block cleanup once more on normalized HTML to catch any remaining meta sections.
		$text = self::strip_non_article_blocks( $text );

		return self::clean_rich_html( $text );
	}

	/**
	 * Clean rich article HTML while keeping formatting and clickable hyperlinks intact.
	 *
	 * @param string $html HTML content.
	 * @return string
	 */
	private static function clean_rich_html( $html ) {
		$html = wp_check_invalid_utf8( (string) $html );
		$html = str_replace( "\0", '', $html );
		// Strip dangerous scripts/handlers while preserving semantic content & hyperlinks.
		$html = preg_replace( '#<script\b[^>]*>[\s\S]*?</script>#i', '', $html );
		$html = preg_replace( '/\son[a-z]+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html );
		return trim( $html );
	}

	/**
	 * Clean raw HTML code output (preserving classes, styles, attributes, and structure).
	 *
	 * @param string $code HTML code.
	 * @return string
	 */
	private static function clean_raw_code( $code ) {
		$code = wp_check_invalid_utf8( (string) $code );
		$code = str_replace( "\0", '', $code );
		$code = preg_replace( '#<script\b[^>]*>[\s\S]*?</script>#i', '', $code );
		return trim( $code );
	}

	/**
	 * Parse stored images_json into a normalized array (with legacy featured_image_url fallback).
	 *
	 * @param string $json         Stored JSON string.
	 * @param string $fallback_url Legacy featured_image_url.
	 * @param int    $fallback_id  Legacy featured_image_id.
	 * @return array
	 */
	private static function parse_images_json( $json, $fallback_url = '', $fallback_id = 0 ) {
		$decoded = is_string( $json ) && '' !== trim( $json ) ? json_decode( $json, true ) : null;
		if ( is_array( $decoded ) ) {
			return self::sanitize_images_list( $decoded );
		}
		$fallback_url = trim( (string) $fallback_url );
		if ( '' !== $fallback_url && 'legacy' !== $fallback_url ) {
			return array(
				array(
					'id'            => 'img_legacy',
					'url'           => esc_url_raw( $fallback_url ),
					'attachment_id' => absint( $fallback_id ),
					'prompt'        => '',
					'model'         => '',
					'is_featured'   => true,
					'is_in_content' => false,
				),
			);
		}
		if ( 'legacy' === $fallback_url ) {
			return array(
				array(
					'id'            => 'img_legacy',
					'url'           => '',
					'attachment_id' => 0,
					'prompt'        => '',
					'model'         => '',
					'is_featured'   => true,
					'is_in_content' => false,
				),
			);
		}
		return array();
	}

	/**
	 * Sanitize an images list array, ensuring at most one image has is_featured=true.
	 *
	 * @param array $images Raw images list.
	 * @return array
	 */
	private static function sanitize_images_list( array $images ) {
		$out           = array();
		$featured_seen = false;
		foreach ( $images as $idx => $im ) {
			if ( ! is_array( $im ) ) {
				continue;
			}
			$url = esc_url_raw( (string) ( $im['url'] ?? '' ) );
			if ( '' === $url ) {
				continue;
			}
			$is_feat = ! empty( $im['is_featured'] ) && ! $featured_seen;
			if ( $is_feat ) {
				$featured_seen = true;
			}
			$out[] = array(
				'id'            => sanitize_key( (string) ( $im['id'] ?? ( 'img_' . ( $idx + 1 ) . '_' . substr( md5( $url ), 0, 6 ) ) ) ),
				'url'           => $url,
				'attachment_id' => absint( $im['attachment_id'] ?? 0 ),
				'prompt'        => sanitize_textarea_field( (string) ( $im['prompt'] ?? '' ) ),
				'model'         => sanitize_text_field( (string) ( $im['model'] ?? '' ) ),
				'is_featured'   => $is_feat,
				'is_in_content' => ! empty( $im['is_in_content'] ),
			);
		}
		return $out;
	}

	/**
	 * Idempotently inject full-size in-content image(s) at the end of a paragraph, immediately before
	 * the next <h2> heading (stripping any previously injected markers first).
	 *
	 * @param string $html              Article HTML body.
	 * @param array  $in_content_images List of images with { url, alt? }.
	 * @param string $alt_fallback      Fallback alt text (article title).
	 * @return string
	 */
	public static function inject_in_content_images( $html, array $in_content_images, $alt_fallback = '' ) {
		$html = (string) $html;
		// Strip previously injected seopm in-content figure blocks cleanly.
		$html = preg_replace( '#\s*<figure\b[^>]*class="[^"]*seopm-in-content-figure[^"]*"[^>]*>[\s\S]*?</figure>\s*#iu', "\n", $html );
		$html = trim( $html );

		if ( '' === $html || empty( $in_content_images ) ) {
			return $html;
		}

		// Find all <h2> occurrences with byte offsets.
		$h2_positions = array();
		if ( preg_match_all( '/<h2\b[^>]*>/iu', $html, $matches, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $matches[0] as $m ) {
				$h2_positions[] = (int) $m[1];
			}
		}

		// Choose insertion points: right before the 3rd <h2> (after intro + 1st major section),
		// or before 2nd <h2> if fewer headings exist; distribute multiple images across consecutive <h2>s.
		$target_offsets = array();
		$h2_count       = count( $h2_positions );
		if ( $h2_count >= 2 ) {
			$start_idx = ( $h2_count >= 3 ) ? 2 : 1;
			$img_count = count( $in_content_images );
			for ( $i = 0; $i < $img_count; $i++ ) {
				$pick = min( $h2_count - 1, $start_idx + $i );
				$pos  = $h2_positions[ $pick ];

				// If this <h2> sits immediately after an opening section wrapper (<div class="content-section"> or <section>),
				// step back before that wrapper so the image sits cleanly at the end of the previous section's paragraph and before the next <h2>.
				$before_len   = min( 180, $pos );
				$before_slice = substr( $html, $pos - $before_len, $before_len );
				if ( preg_match( '/<(?:section|div)\b[^>]*class="[^"]*(?:content-section|funnel-section)[^"]*"[^>]*>\s*$/iu', $before_slice, $wm, PREG_OFFSET_CAPTURE ) ) {
					$pos = ( $pos - $before_len ) + (int) $wm[0][1];
				}
				$target_offsets[] = $pos;
			}
		} else {
			// Fallback if fewer than 2 <h2> headings exist: after the 2nd </p> (or 1st </p>).
			$p_ends = array();
			if ( preg_match_all( '#</p>#iu', $html, $pm, PREG_OFFSET_CAPTURE ) ) {
				foreach ( $pm[0] as $m ) {
					$p_ends[] = (int) $m[1] + strlen( $m[0] );
				}
			}
			foreach ( $in_content_images as $i => $unused ) {
				if ( ! empty( $p_ends ) ) {
					$pick             = min( count( $p_ends ) - 1, $i + 1 );
					$target_offsets[] = $p_ends[ $pick ];
				} else {
					$target_offsets[] = strlen( $html );
				}
			}
		}

		// Insert from the highest offset backwards so earlier byte offsets remain valid.
		$pairs = array();
		foreach ( $in_content_images as $i => $im ) {
			$url = esc_url( (string) ( $im['url'] ?? '' ) );
			if ( '' === $url ) {
				continue;
			}
			$alt     = esc_attr( trim( (string) ( $im['alt'] ?? $alt_fallback ) ) );
			$figure  = "\n" . '<figure class="wp-block-image size-full seopm-in-content-figure" style="margin:24px 0;width:100%;"><img src="' . $url . '" alt="' . $alt . '" class="size-full" style="width:100%;height:auto;display:block;border-radius:12px;" loading="lazy" /></figure>' . "\n";
			$pairs[] = array(
				'offset' => $target_offsets[ $i ] ?? strlen( $html ),
				'html'   => $figure,
			);
		}

		usort(
			$pairs,
			static function ( $a, $b ) {
				return $b['offset'] <=> $a['offset'];
			}
		);

		foreach ( $pairs as $p ) {
			$off  = max( 0, min( strlen( $html ), (int) $p['offset'] ) );
			$html = substr( $html, 0, $off ) . $p['html'] . substr( $html, $off );
		}

		return trim( $html );
	}

	/**
	 * Generate 2 distinct article images via AI (ChatGPT gpt-image-1 / dall-e-3) strictly using
	 * the business's saved `prompt_image_generation`.
	 *
	 * STRICT PREREQUISITE: Both article_content AND article_html MUST exist before generating images.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $payload     { article_key, title, keyword, url_slug, image_prompt, image_model, count, replace }.
	 * @return array|\WP_Error
	 */
	public static function generate_image( $business_id, array $payload ) {
		$business_id = self::resolve_business_id( $business_id, $payload );
		$biz         = $business_id ? Business::get( $business_id, false ) : null;
		if ( ! $biz ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$biz         = Business::get( $business_id, false );
			}
		}
		if ( ! $biz ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'هیچ کسب‌وکاری در سامانه یافت نشد. لطفاً ابتدا در بخش کسب‌وکارها یک کسب‌وکار تعریف کنید.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$title       = trim( sanitize_text_field( $payload['title'] ?? $payload['best_title'] ?? '' ) );
		$article_key = ! empty( $payload['article_key'] ) ? sanitize_key( $payload['article_key'] ) : ( '' !== $title ? self::make_key( $title ) : '' );
		if ( '' === $article_key ) {
			return new \WP_Error( 'seopm_missing_key', __( 'شناسه یا عنوان مقاله برای تولید تصویر الزامی است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$existing = self::get_draft( $business_id, $article_key );

		// STRICT PREREQUISITE: Refuse image generation until BOTH article text AND HTML code exist!
		$has_article = ! empty( $existing['has_article'] );
		$has_html    = ! empty( $existing['has_html'] );
		if ( ! $has_article || ! $has_html ) {
			return new \WP_Error(
				'seopm_image_prereq',
				__( 'تا زمانی که هم متن مقاله و هم کد HTML مقاله تولید نشده باشند، امکان تولید تصویر وجود ندارد. لطفاً ابتدا متن مقاله را بنویسید و به کد HTML تبدیل کنید.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$title       = '' !== $title ? $title : ( $existing['title'] ?? '' );
		$keyword     = trim( sanitize_text_field( $payload['keyword'] ?? ( $existing['keyword'] ?? '' ) ) );
		$url_slug    = Content_Suggester::clean_slug( $payload['url_slug'] ?? ( $existing['url_slug'] ?? '' ) );

		// Extract concise article context (headings + opening excerpt) so images match the real written article.
		$article_headings = self::extract_article_headings( $existing['article_content'] ?? '' );
		$article_excerpt  = self::extract_article_visual_context( $existing['article_content'] ?? '' );

		$article_info = array_merge( is_array( $existing ) ? $existing : array(), array(
			'title'           => $title,
			'best_title'      => $title,
			'keyword'         => $keyword,
			'url_slug'        => $url_slug,
			'headings'        => $article_headings,
			'summary'         => $article_excerpt,
			'article_content' => $existing['article_content'] ?? '',
			'content'         => $existing['article_content'] ?? '',
		) );

		$user_prompt = Business::expand_shortcodes( trim( sanitize_textarea_field( $payload['image_prompt'] ?? '' ) ), $biz, $article_info );
		$biz_prompt  = Business::expand_shortcodes( trim( (string) ( $biz['prompt_image_generation'] ?? '' ) ), $biz, $article_info );
		$model       = trim( sanitize_text_field( $payload['image_model'] ?? '' ) );
		if ( in_array( $model, array( 'gpt-image-1', 'dall-e-3' ), true ) ) {
			$model = 'gemini-2.5-flash-image';
		}
		$count       = isset( $payload['count'] ) ? max( 1, min( 2, absint( $payload['count'] ) ) ) : 2;
		$replace     = ! empty( $payload['replace'] );

		// Build 2 distinct prompts (or 1 if requested), strictly following business's prompt_image_generation with Smart Subject Fusion.
		$prompts = array();
		if ( '' !== $user_prompt ) {
			// Ensure custom prompt is tied to this specific article if not already mentioned.
			if ( false === mb_stripos( $user_prompt, $title ) && '' !== $title ) {
				$user_prompt .= "\n\nMain Subject / Article Topic: " . $title . ( '' !== $keyword ? ' (Focus Keyword: ' . $keyword . ')' : '' );
			}
			$prompts[] = $user_prompt;
			if ( $count > 1 ) {
				$prompts[] = $user_prompt . ' (Alternative distinct framing and complementary angle for editorial variety)';
			}
		} else {
			$prompts = self::craft_image_prompts( $biz, $title, $keyword, $biz_prompt, $article_excerpt, $count );
		}

		$generated_items = array();
		$last_error      = '';
		$base            = '' !== $url_slug ? sanitize_file_name( $url_slug ) : ( 'article-' . substr( $article_key, 0, 10 ) );

		foreach ( $prompts as $idx => $final_prompt ) {
			$img_res = AI_Client::generate_image(
				$final_prompt,
				array(
					'model'   => $model,
					'size'    => '1536x1024',
					'timeout' => 90,
				)
			);

			// Automatic fallback to gemini-2.5-flash-image if requested model failed.
			if ( empty( $img_res['success'] ) && 'gemini-2.5-flash-image' !== $model ) {
				$fallback_res = AI_Client::generate_image(
					$final_prompt,
					array(
						'model'   => 'gemini-2.5-flash-image',
						'size'    => '1536x1024',
						'timeout' => 90,
					)
				);
				if ( ! empty( $fallback_res['success'] ) ) {
					$img_res = $fallback_res;
				}
			}

			if ( empty( $img_res['success'] ) ) {
				$last_error = $img_res['message'] ?? __( 'خطا در تولید تصویر مقاله با هوش مصنوعی.', 'seo-project-manager' );
				continue;
			}

			$bytes = '';
			$mime  = $img_res['mime'] ?? 'image/png';
			if ( ! empty( $img_res['b64'] ) ) {
				$bytes = base64_decode( $img_res['b64'] ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			} elseif ( ! empty( $img_res['url'] ) ) {
				$dl = wp_remote_get( $img_res['url'], array( 'timeout' => 60, 'sslverify' => false, 'headers' => array( 'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' ) ) );
				if ( ! is_wp_error( $dl ) && wp_remote_retrieve_response_code( $dl ) >= 200 && wp_remote_retrieve_response_code( $dl ) < 300 ) {
					$bytes = wp_remote_retrieve_body( $dl );
					$ct    = wp_remote_retrieve_header( $dl, 'content-type' );
					if ( is_string( $ct ) && 0 === strpos( $ct, 'image/' ) ) {
						$mime = trim( explode( ';', $ct )[0] );
					}
				}
			}

			if ( ! is_string( $bytes ) || '' === $bytes ) {
				$last_error = __( 'داده تصویر دریافت‌شده خالی است.', 'seo-project-manager' );
				continue;
			}

			// Automatically convert to WebP format for fast loading and modern SEO standards.
			$webp_bytes = self::convert_to_webp( $bytes, 85 );
			if ( self::is_webp( $webp_bytes ) ) {
				$bytes = $webp_bytes;
				$mime  = 'image/webp';
				$ext   = 'webp';
			} else {
				$ext   = self::mime_to_ext( $mime );
			}

			$filename = $base . '-' . ( $idx + 1 ) . '-' . time() . '.' . $ext;
			$stored   = self::store_image_in_media_library( $bytes, $filename, $title ?: $keyword, $mime );
			if ( is_wp_error( $stored ) ) {
				$last_error = $stored->get_error_message();
				continue;
			}

			$generated_items[] = array(
				'id'            => 'img_' . ( $idx + 1 ) . '_' . substr( md5( $stored['url'] . microtime() ), 0, 6 ),
				'url'           => $stored['url'],
				'attachment_id' => (int) $stored['attachment_id'],
				'prompt'        => $final_prompt,
				'model'         => (string) ( $img_res['model'] ?? $model ),
				'is_featured'   => false,
				'is_in_content' => false,
			);
		}

		if ( empty( $generated_items ) ) {
			return new \WP_Error(
				'seopm_image_failed',
				$last_error ?: __( 'خطا در تولید تصویر مقاله با هوش مصنوعی.', 'seo-project-manager' ),
				array( 'status' => 502 )
			);
		}

		$current_imgs = ( ! $replace && ! empty( $existing['images'] ) && is_array( $existing['images'] ) )
			? $existing['images']
			: array();
		$all_imgs     = array_merge( $current_imgs, $generated_items );

		$saved = self::save_draft(
			$business_id,
			$article_key,
			array(
				'title'        => $title,
				'keyword'      => $keyword,
				'url_slug'     => $url_slug,
				'images'       => $all_imgs,
				'image_prompt' => $prompts[0] ?? '',
			)
		);
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		$saved['generated_count'] = count( $generated_items );
		return $saved;
	}

	/**
	 * Upload a custom image (base64 data URI) and append it to an article draft's image options.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $payload     { article_key, title, keyword, url_slug, data_url, filename, is_featured, is_in_content }.
	 * @return array|\WP_Error
	 */
	public static function upload_image( $business_id, array $payload ) {
		$business_id = self::resolve_business_id( $business_id, $payload );
		$biz         = $business_id ? Business::get( $business_id, false ) : null;
		if ( ! $biz ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$biz         = Business::get( $business_id, false );
			}
		}
		if ( ! $biz ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'هیچ کسب‌وکاری در سامانه یافت نشد. لطفاً ابتدا در بخش کسب‌وکارها یک کسب‌وکار تعریف کنید.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$title       = trim( sanitize_text_field( $payload['title'] ?? '' ) );
		$article_key = ! empty( $payload['article_key'] ) ? sanitize_key( $payload['article_key'] ) : ( '' !== $title ? self::make_key( $title ) : '' );
		if ( '' === $article_key ) {
			return new \WP_Error( 'seopm_missing_key', __( 'شناسه یا عنوان مقاله الزامی است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$data_url = trim( (string) ( $payload['data_url'] ?? '' ) );
		if ( ! preg_match( '#^data:(image/(?:png|jpeg|jpg|webp|gif));base64,(.+)$#is', $data_url, $m ) ) {
			return new \WP_Error( 'seopm_invalid_image', __( 'فرمت تصویر انتخاب‌شده معتبر نیست (فقط PNG، JPG یا WebP).', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$mime  = strtolower( $m[1] );
		$bytes = base64_decode( $m[2] ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( ! is_string( $bytes ) || '' === $bytes || strlen( $bytes ) > 8 * 1024 * 1024 ) {
			return new \WP_Error( 'seopm_image_size', __( 'حجم تصویر باید کمتر از ۸ مگابایت باشد.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$existing = self::get_draft( $business_id, $article_key );
		$url_slug = Content_Suggester::clean_slug( $payload['url_slug'] ?? ( $existing['url_slug'] ?? '' ) );
		$keyword  = trim( sanitize_text_field( $payload['keyword'] ?? ( $existing['keyword'] ?? '' ) ) );
		$title    = '' !== $title ? $title : ( $existing['title'] ?? '' );

		// Convert manual upload to WebP format for fast loading and uniform modern storage.
		$webp_bytes = self::convert_to_webp( $bytes, 85 );
		if ( self::is_webp( $webp_bytes ) ) {
			$bytes = $webp_bytes;
			$mime  = 'image/webp';
			$ext   = 'webp';
		} else {
			$ext   = self::mime_to_ext( $mime );
		}

		$base     = '' !== $url_slug ? sanitize_file_name( $url_slug ) : ( 'article-' . substr( $article_key, 0, 10 ) );
		$filename = $base . '-' . time() . '.' . $ext;
		$stored   = self::store_image_in_media_library( $bytes, $filename, $title ?: $keyword, $mime );
		if ( is_wp_error( $stored ) ) {
			return $stored;
		}

		$current_imgs = ( ! empty( $existing['images'] ) && is_array( $existing['images'] ) ) ? $existing['images'] : array();
		$has_featured = false;
		foreach ( $current_imgs as $ci ) {
			if ( ! empty( $ci['is_featured'] ) ) {
				$has_featured = true;
				break;
			}
		}

		$current_imgs[] = array(
			'id'            => 'img_up_' . substr( md5( $stored['url'] . microtime() ), 0, 6 ),
			'url'           => $stored['url'],
			'attachment_id' => (int) $stored['attachment_id'],
			'prompt'        => '',
			'model'         => 'manual-upload',
			'is_featured'   => ! empty( $payload['is_featured'] ) || ! $has_featured,
			'is_in_content' => ! empty( $payload['is_in_content'] ),
		);

		return self::save_draft(
			$business_id,
			$article_key,
			array(
				'title'    => $title,
				'keyword'  => $keyword,
				'url_slug' => $url_slug,
				'images'   => $current_imgs,
			)
		);
	}

	/**
	 * Extract concise headings & intro excerpt from the written article for richer image prompt context.
	 *
	 * @param string $article_content Rich HTML article content.
	 * @return string
	 */
	private static function extract_article_visual_context( $article_content ) {
		$headings = array();
		if ( preg_match_all( '#<h2[^>]*>(.*?)</h2>#iu', (string) $article_content, $hm ) ) {
			foreach ( array_slice( $hm[1], 0, 5 ) as $h ) {
				$clean = trim( wp_strip_all_tags( $h ) );
				if ( '' !== $clean ) {
					$headings[] = $clean;
				}
			}
		}
		$plain   = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $article_content ) ) );
		$excerpt = mb_substr( $plain, 0, 320 );
		$parts   = array();
		if ( ! empty( $headings ) ) {
			$parts[] = 'سرفصل‌های مقاله: ' . implode( ' | ', $headings );
		}
		if ( '' !== $excerpt ) {
			$parts[] = 'خلاصه شروع مقاله: ' . $excerpt;
		}
		return implode( "\n", $parts );
	}

	/**
	 * Extract H2 and H3 headings from article HTML content for shortcode replacement and AI context.
	 *
	 * @param string $article_content Rich HTML article content.
	 * @return string
	 */
	private static function extract_article_headings( $article_content ) {
		$headings = array();
		if ( preg_match_all( '#<h[23][^>]*>(.*?)<\/h[23]>#iu', (string) $article_content, $hm ) ) {
			foreach ( array_slice( $hm[1], 0, 8 ) as $h ) {
				$clean = trim( wp_strip_all_tags( $h ) );
				if ( '' !== $clean ) {
					$headings[] = $clean;
				}
			}
		}
		return implode( ' | ', $headings );
	}

	/**
	 * Craft 1 or 2 distinct visual prompts strictly obeying the business's saved `prompt_image_generation`
	 * combined with Smart Subject Fusion (subject derived from the specific article, style/palette from business prompt).
	 *
	 * @param array  $biz             Business data.
	 * @param string $title           Article title.
	 * @param string $keyword         Main keyword.
	 * @param string $biz_prompt      Business's custom prompt_image_generation.
	 * @param string $article_context Headings/intro excerpt from the written article.
	 * @param int    $count           Number of distinct prompts (1 or 2).
	 * @return string[]
	 */
	private static function craft_image_prompts( array $biz, $title, $keyword, $biz_prompt = '', $article_context = '', $count = 2 ) {
		$biz_prompt = trim( (string) $biz_prompt );
		$count      = max( 1, min( 2, (int) $count ) );

		if ( '' !== $biz_prompt ) {
			$expanded = str_replace(
				array( '{title}', '{{title}}', '[title]', '[article_title]', '{keyword}', '{{keyword}}', '[keyword]', '[article_keyword]', '{business}', '{{business}}', '[business_name]' ),
				array( $title, $title, $title, $title, $keyword, $keyword, $keyword, $keyword, (string) ( $biz['name'] ?? '' ), (string) ( $biz['name'] ?? '' ), (string) ( $biz['name'] ?? '' ) ),
				$biz_prompt
			);

			if ( $count > 1 ) {
				$prompt_req = "وظیفه تو ساخت دقیقاً ۲ پرامپت انگلیسی متفاوت، چشم‌نواز و مکمل برای تولید ۲ تصویر با مدل تصویری هوش مصنوعی (Gemini 2.5 Flash Image / DALL-E) است.\n\n" .
					"اطلاعات مقاله جاری (سوژه و سناریوی هر دو تصویر باید ۱۰۰٪ به این مقاله اختصاص داشته باشد):\n" .
					"- نام برند/کسب‌وکار: " . ( $biz['name'] ?? '' ) . "\n" .
					"- عنوان دقیق مقاله جاری: " . $title . "\n" .
					"- کلمه کلیدی اصلی مقاله: " . $keyword . "\n" .
					( '' !== $article_context ? $article_context . "\n" : '' ) . "\n" .
					"=== پرامپت استانداردهای بصری و هویت برند کسب‌وکار ===\n" .
					$expanded . "\n\n" .
					"قوانین تفکیک و تلفیق هوشمند (Smart Fusion Rules):\n" .
					"۱. سوژه محوری و سناریوی صحنه (Subject & Action): باید ۱۰۰٪ نمایانگر و تصویرگر موضوع همین مقاله («" . $title . "») و کلمه کلیدی («" . $keyword . "») باشد. اگر در پرامپت کسب‌وکار سناریوی ثابتی (مانند سالمند روی صندلی یا سوژه دیگری) نوشته شده بود، آن را نادیده بگیر یا صرفاً به عنوان نمونه در نظر داشته باش و سوژه واقعی صحنه را کاملاً بر اساس موضوع این مقاله جدید و کلمه کلیدی آن طراحی کن.\n" .
					"۲. سبک بصری، رنگ‌بندی و نور (Visual Style & Palette): تمام استانداردهای مربوط به پالت رنگی برند، نورپردازی طبیعی، نوع عکاسی (رئالیستی / لایف‌استایل)، زاویه لنز و نسبت ابعاد را دقیقاً از پرامپت کسب‌وکار پیاده کن.\n" .
					"۳. قانون قطعی عدم وجود متن (Strictly Zero Text): هر دو تصویر باید مطلقاً بدون هرگونه متن، حروف، کلمه، عدد، تایپوگرافی، واترمارک یا لوگو باشند (completely devoid of any text, letters, typography, watermark, or logo).\n" .
					"۴. تنوع ۲ تصویر:\n" .
					"   - تصویر ۱: زاویه اصلی و محوری برای تصویر شاخص مقاله (Hero Featured Image).\n" .
					"   - تصویر ۲: زاویه یا صحنه مکمل متفاوت و کاربردی از موضوع مقاله برای تصویر میان‌متنی یا شاخص جایگزین.\n\n" .
					"خروجی را فقط و فقط به‌صورت یک JSON معتبر به زبان انگلیسی با فرمت زیر برگردان:\n" .
					'{"prompts": ["English prompt 1 ready to send to image generator", "English prompt 2 ready to send to image generator"]}';

				$ai = AI_Client::generate(
					$prompt_req,
					'You are an expert prompt engineer and art director for modern editorial AI image generators. Strictly ensure the subject illustrates the specific article topic while preserving the business visual style and color palette. Output ONLY valid JSON {"prompts": ["...", "..."]} with zero text overlay.',
					array(
						'max_tokens' => 2500,
						'timeout'    => 45,
					)
				);
				if ( ! empty( $ai['success'] ) && ! empty( $ai['text'] ) ) {
					$parsed = AI_Client::parse_json( $ai['text'] );
					if ( is_array( $parsed ) && ! empty( $parsed['prompts'] ) && is_array( $parsed['prompts'] ) ) {
						$clean = array_values( array_filter( array_map( 'trim', array_map( 'strval', $parsed['prompts'] ) ) ) );
						if ( count( $clean ) >= 2 ) {
							return array_slice( $clean, 0, 2 );
						}
					}
				}
			}

			$single = self::craft_image_prompt( $biz, $title, $keyword, $biz_prompt );
			if ( 1 === $count ) {
				return array( $single );
			}
			return array(
				$single,
				$single . ' — Second distinct composition: complementary editorial perspective illustrating practical detail from ' . ( $keyword ?: $title ),
			);
		}

		// No custom business prompt: generate 2 distinct clean editorial prompts.
		if ( $count > 1 ) {
			$prompt_req = "Write TWO distinct, concise, vivid English image-generation prompts (each max 80 words) for wide 16:9 editorial blog photographs representing this Persian article:\n" .
				"Business: " . ( $biz['name'] ?? '' ) . "\n" .
				"Article Title: " . $title . "\n" .
				"Keyword: " . $keyword . "\n" .
				( '' !== $article_context ? $article_context . "\n" : '' ) .
				"Prompt 1: Main hero featured image composition illustrating " . $title . ".\n" .
				"Prompt 2: Complementary scene / angle suitable as an alternative featured image or an in-article editorial visual.\n" .
				"Rules: photorealistic warm natural lighting, clean modern editorial composition, strictly NO text, NO letters, NO watermarks, NO logos inside either image.\n" .
				'Return ONLY valid JSON: {"prompts": ["prompt 1", "prompt 2"]}';

			$ai = AI_Client::generate(
				$prompt_req,
				'You are an expert editorial art director. Output ONLY valid JSON {"prompts": ["...", "..."]} with zero text overlay in images.',
				array(
					'max_tokens' => 2500,
					'timeout'    => 45,
				)
			);
			if ( ! empty( $ai['success'] ) && ! empty( $ai['text'] ) ) {
				$parsed = AI_Client::parse_json( $ai['text'] );
				if ( is_array( $parsed ) && ! empty( $parsed['prompts'] ) && is_array( $parsed['prompts'] ) ) {
					$clean = array_values( array_filter( array_map( 'trim', array_map( 'strval', $parsed['prompts'] ) ) ) );
					if ( count( $clean ) >= 2 ) {
						return array_slice( $clean, 0, 2 );
					}
				}
			}
		}

		$base_prompt = self::craft_image_prompt( $biz, $title, $keyword, '' );
		if ( 1 === $count ) {
			return array( $base_prompt );
		}
		return array(
			$base_prompt,
			'Alternative close-up editorial lifestyle photograph illustrating ' . ( $keyword ?: $title ) . ', calm bright interior, soft natural light, shallow depth of field, wide 16:9 composition, strictly no text, no letters, no watermark.',
		);
	}

	/**
	 * Craft the final visual prompt for image generation models, strictly honoring the business's
	 * saved `prompt_image_generation` combined with the article's real topic as Priority #1.
	 *
	 * @param array  $biz        Business data.
	 * @param string $title      Article title.
	 * @param string $keyword    Main keyword.
	 * @param string $biz_prompt Business's custom prompt_image_generation.
	 * @return string
	 */
	private static function craft_image_prompt( array $biz, $title, $keyword, $biz_prompt = '' ) {
		$biz_prompt = trim( (string) $biz_prompt );

		if ( '' !== $biz_prompt ) {
			// Replace common placeholders if the user included them directly in their custom image prompt.
			$expanded = str_replace(
				array( '{title}', '{{title}}', '[title]', '[article_title]', '{keyword}', '{{keyword}}', '[keyword]', '[article_keyword]', '{business}', '{{business}}', '[business_name]' ),
				array( $title, $title, $title, $title, $keyword, $keyword, $keyword, $keyword, (string) ( $biz['name'] ?? '' ), (string) ( $biz['name'] ?? '' ), (string) ( $biz['name'] ?? '' ) ),
				$biz_prompt
			);

			$prompt_req = "وظیفه تو ساخت یک پرامپت نهایی انگلیسی برای تولید تصویر با هوش مصنوعی بر اساس مقاله جاری و سبک بصری کسب‌وکار است.\n\n" .
				"اطلاعات مقاله جاری:\n" .
				"- نام کسب‌وکار: " . ( $biz['name'] ?? '' ) . "\n" .
				"- عنوان دقیق مقاله: " . $title . "\n" .
				"- کلمه کلیدی: " . $keyword . "\n\n" .
				"=== پرامپت و سبک بصری کسب‌وکار ===\n" .
				$expanded . "\n\n" .
				"قوانین تلفیق:\n" .
				"۱. سوژه صحنه باید منحصراً بازتاب‌دهنده موضوع همین مقاله («" . $title . "») باشد (نه صحنه‌های پیش‌فرض قدیمی پرامپت).\n" .
				"۲. سبک بصری، نور، رنگ برند و نسبت ابعاد دقیقاً مطابق پرامپت کسب‌وکار باشد.\n" .
				"۳. کاملاً بدون هرگونه متن، لوگو یا واترمارک (strictly no text, no letters, no watermark).\n\n" .
				"خروجی: فقط و فقط متن نهایی پرامپت انگلیسی آماده ارسال را بدون هیچ متن یا توضیح اضافی برگردان.";

			$ai = AI_Client::generate(
				$prompt_req,
				'You are an expert prompt engineer for modern editorial image models. Strictly follow the business visual style and color palette while ensuring the subject is tailored to the article title. Output ONLY the final ready-to-use English image generation prompt with zero text overlay.',
				array(
					'max_tokens' => 2048,
					'timeout'    => 45,
				)
			);
			if ( ! empty( $ai['success'] ) && ! empty( trim( (string) ( $ai['text'] ?? '' ) ) ) ) {
				return trim( (string) $ai['text'] );
			}

			// Fallback: pass the business's exact custom image prompt + article topic directly to image generator.
			return $expanded . "\n\nMain Subject / Article Topic: " . $title . ( '' !== $keyword ? ' (Focus Keyword: ' . $keyword . ')' : '' );
		}

		$prompt_req = "Write ONE concise, vivid English image-generation prompt (max 90 words) for a wide 16:9 editorial blog featured photograph/illustration representing this Persian article.\n" .
			"Business: " . ( $biz['name'] ?? '' ) . "\n" .
			"Article Title: " . $title . "\n" .
			"Keyword: " . $keyword . "\n" .
			"Rules: photorealistic warm natural lighting, clean modern editorial composition, strictly NO text, NO letters, NO watermarks, NO logos inside the image. Return ONLY the English prompt text.";

		$ai = AI_Client::generate(
			$prompt_req,
			'You are an expert editorial art director. Output only a single clean English image prompt with zero text overlay.',
			array(
				'max_tokens' => 2048,
				'timeout'    => 45,
			)
		);
		if ( ! empty( $ai['success'] ) && ! empty( trim( (string) ( $ai['text'] ?? '' ) ) ) ) {
			return trim( (string) $ai['text'] );
		}

		return 'High-resolution warm editorial photograph illustrating ' . ( $keyword ?: $title ) . ', clean modern environment, soft natural daylight, shallow depth of field, trustworthy professional atmosphere, wide 16:9 composition, strictly no text, no letters, no watermark.';
	}

	/**
	 * Check whether binary data is in WebP format (RIFF....WEBP).
	 *
	 * @param string $bytes Binary data.
	 * @return bool
	 */
	public static function is_webp( $bytes ) {
		return is_string( $bytes )
			&& strlen( $bytes ) >= 12
			&& 0 === substr_compare( $bytes, 'RIFF', 0, 4 )
			&& 0 === substr_compare( $bytes, 'WEBP', 8, 4 );
	}

	/**
	 * Convert raw image bytes (PNG, JPEG, GIF, etc.) into WebP format.
	 * If the image is already WebP, returns the original bytes.
	 * Leverages PHP GD (imagewebp) with Imagick fallback.
	 *
	 * @param string $bytes   Raw image binary bytes.
	 * @param int    $quality WebP compression quality (0-100, default 85).
	 * @return string Converted WebP bytes or original bytes if conversion is unavailable.
	 */
	public static function convert_to_webp( $bytes, $quality = 85 ) {
		if ( ! is_string( $bytes ) || '' === $bytes ) {
			return $bytes;
		}

		if ( self::is_webp( $bytes ) ) {
			return $bytes;
		}

		// 1. Try PHP GD extension.
		if ( function_exists( 'imagecreatefromstring' ) && function_exists( 'imagewebp' ) ) {
			$img = @imagecreatefromstring( $bytes );
			if ( false !== $img ) {
				// Handle transparency for PNG/GIF.
				if ( function_exists( 'imagepalettetotruecolor' ) && ! imageistruecolor( $img ) ) {
					imagepalettetotruecolor( $img );
				}
				if ( function_exists( 'imagealphablending' ) && function_exists( 'imagesavealpha' ) ) {
					imagealphablending( $img, true );
					imagesavealpha( $img, true );
				}

				ob_start();
				$success   = imagewebp( $img, null, $quality );
				$webp_data = ob_get_clean();
				imagedestroy( $img );

				if ( $success && is_string( $webp_data ) && '' !== $webp_data && self::is_webp( $webp_data ) ) {
					return $webp_data;
				}
			}
		}

		// 2. Fallback to Imagick if available.
		if ( class_exists( '\Imagick' ) ) {
			try {
				$im = new \Imagick();
				$im->readImageBlob( $bytes );
				$im->setImageFormat( 'webp' );
				$im->setImageCompressionQuality( $quality );
				$webp_data = $im->getImageBlob();
				$im->clear();
				$im->destroy();
				if ( is_string( $webp_data ) && '' !== $webp_data && self::is_webp( $webp_data ) ) {
					return $webp_data;
				}
			} catch ( \Exception $e ) {
				// Fallback below.
			}
		}

		return $bytes;
	}

	/**
	 * Map image MIME type to file extension.
	 *
	 * @param string $mime MIME type.
	 * @return string
	 */
	private static function mime_to_ext( $mime ) {
		switch ( strtolower( trim( $mime ) ) ) {
			case 'image/jpeg':
			case 'image/jpg':
				return 'jpg';
			case 'image/webp':
				return 'webp';
			case 'image/gif':
				return 'gif';
			default:
				return 'png';
		}
	}

	/**
	 * Save raw image bytes into the local WordPress Media Library.
	 *
	 * @param string $bytes    Raw binary bytes.
	 * @param string $filename Safe file name.
	 * @param string $title    Attachment title / alt text.
	 * @param string $mime     MIME type.
	 * @return array{attachment_id:int,url:string,file:string}|\WP_Error
	 */
	private static function store_image_in_media_library( $bytes, $filename, $title, $mime ) {
		$upload = wp_upload_bits( $filename, null, $bytes );
		if ( ! empty( $upload['error'] ) || empty( $upload['file'] ) || empty( $upload['url'] ) ) {
			return new \WP_Error(
				'seopm_upload_failed',
				__( 'خطا در ذخیره فایل تصویر روی سرور: ', 'seo-project-manager' ) . ( $upload['error'] ?? '' ),
				array( 'status' => 500 )
			);
		}

		$attachment = array(
			'post_mime_type' => $mime,
			'post_title'     => sanitize_text_field( $title ?: pathinfo( $filename, PATHINFO_FILENAME ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);
		$attach_id  = wp_insert_attachment( $attachment, $upload['file'] );
		if ( ! is_wp_error( $attach_id ) && $attach_id > 0 ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$meta = wp_generate_attachment_metadata( $attach_id, $upload['file'] );
			if ( is_array( $meta ) ) {
				wp_update_attachment_metadata( $attach_id, $meta );
			}
			update_post_meta( $attach_id, '_wp_attachment_image_alt', sanitize_text_field( $title ) );
		} else {
			$attach_id = 0;
		}

		return array(
			'attachment_id' => (int) $attach_id,
			'url'           => esc_url_raw( $upload['url'] ),
			'file'          => (string) $upload['file'],
		);
	}

	/**
	 * Format a draft row for REST API response.
	 *
	 * @param array $row DB row.
	 * @return array
	 */
	private static function format_draft( array $row ) {
		$content    = (string) ( $row['article_content'] ?? '' );
		$html       = (string) ( $row['article_html'] ?? '' );
		$img_url    = (string) ( $row['featured_image_url'] ?? '' );
		$img_id     = (int) ( $row['featured_image_id'] ?? 0 );
		$images     = self::parse_images_json( $row['images_json'] ?? '', $img_url, $img_id );
		$plain      = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $content ) ) );
		$word_count = '' === $plain ? 0 : count( preg_split( '/\s+/u', $plain ) );
		$link_count = preg_match_all( '/<a\b[^>]*href\s*=\s*["\'][^"\']+["\']/i', $content );

		return array(
			'id'                 => (int) $row['id'],
			'business_id'        => (int) $row['business_id'],
			'article_key'        => (string) $row['article_key'],
			'title'              => (string) $row['title'],
			'keyword'            => (string) $row['keyword'],
			'url_slug'           => (string) $row['url_slug'],
			'article_content'    => $content,
			'article_html'       => $html,
			'featured_image_url' => $img_url,
			'featured_image_id'  => $img_id,
			'images'             => $images,
			'images_count'       => count( $images ),
			'image_prompt'       => (string) ( $row['image_prompt'] ?? '' ),
			'seo_title'          => (string) ( $row['seo_title'] ?? '' ),
			'seo_description'    => (string) ( $row['seo_description'] ?? '' ),
			'remote_post_id'     => (int) ( $row['remote_post_id'] ?? 0 ),
			'remote_post_url'    => (string) ( $row['remote_post_url'] ?? '' ),
			'remote_status'      => (string) ( $row['remote_status'] ?? '' ),
			'scheduled_for'      => $row['scheduled_for'] ?? null,
			'published_at'       => $row['published_at'] ?? null,
			'has_article'        => '' !== trim( $content ),
			'has_links'          => ( (int) $link_count > 0 ),
			'has_html'           => '' !== trim( $html ),
			'has_image'          => '' !== trim( $img_url ),
			'word_count'         => $word_count,
			'link_count'         => (int) $link_count,
			'provider'           => (string) ( $row['provider'] ?? '' ),
			'model'              => (string) ( $row['model'] ?? '' ),
			'updated_at'         => (string) ( $row['updated_at'] ?? '' ),
		);
	}
}

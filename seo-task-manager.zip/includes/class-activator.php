<?php
/**
 * Activation routines.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Activator.
 */
class Activator {

	const ROLE = 'seopm_manager';

	/**
	 * Plugin activation.
	 */
	public static function activate() {
		// Ensure dependencies are loaded even if autoloader has file permissions quirks.
		if ( defined( 'SEOPM_PATH' ) ) {
			if ( file_exists( SEOPM_PATH . 'includes/class-security.php' ) ) {
				require_once SEOPM_PATH . 'includes/class-security.php';
			}
			if ( file_exists( SEOPM_PATH . 'includes/class-settings.php' ) ) {
				require_once SEOPM_PATH . 'includes/class-settings.php';
			}
			if ( file_exists( SEOPM_PATH . 'includes/class-database.php' ) ) {
				require_once SEOPM_PATH . 'includes/class-database.php';
			}
			if ( file_exists( SEOPM_PATH . 'includes/class-pdf-generator.php' ) ) {
				require_once SEOPM_PATH . 'includes/class-pdf-generator.php';
			}
		}

		try {
			if ( class_exists( 'SEOPM\\Database' ) ) {
				Database::install();
			}
		} catch ( \Throwable $e ) {
			error_log( 'SEOPM activation error in Database::install: ' . $e->getMessage() );
		}

		try {
			if ( class_exists( 'SEOPM\\Settings' ) ) {
				Settings::ensure_defaults();
			}
		} catch ( \Throwable $e ) {
			error_log( 'SEOPM activation error in Settings::ensure_defaults: ' . $e->getMessage() );
		}

		try {
			self::setup_capabilities();
		} catch ( \Throwable $e ) {
			error_log( 'SEOPM activation error in setup_capabilities: ' . $e->getMessage() );
		}

		try {
			if ( class_exists( 'SEOPM\\Pdf_Generator' ) ) {
				Pdf_Generator::ensure_storage();
			}
		} catch ( \Throwable $e ) {
			error_log( 'SEOPM activation error in Pdf_Generator::ensure_storage: ' . $e->getMessage() );
		}
	}

	/**
	 * Grant capability to administrators and register the dedicated role.
	 */
	public static function setup_capabilities() {
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( Security::CAP ) ) {
			$admin->add_cap( Security::CAP );
		}

		if ( ! get_role( self::ROLE ) ) {
			add_role(
				self::ROLE,
				__( 'مدیر پروژه سئو', 'seo-project-manager' ),
				array(
					'read'          => true,
					'upload_files'  => true,
					Security::CAP   => true,
				)
			);
		}
	}
}

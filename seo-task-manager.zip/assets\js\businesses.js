/**
 * Businesses & keywords page.
 */
( function ( window, document, $ ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var ui = SEOPM.ui;
	var J = SEOPM.jalali;
	var el = ui.el;
	var C = SEOPM.config;
	var root = document.getElementById( 'seopm-businesses' );
	var search = document.getElementById( 'seopm-business-search' );
	var PALETTE = [ '#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#8b5cf6', '#14b8a6', '#f97316', '#64748b' ];
	var all = [];

	if ( ! root ) {
		return;
	}

	function suggestionsPageUrl( bizId, tab ) {
		var base = ( C.urls && C.urls.suggestions ) ? C.urls.suggestions : 'admin.php?page=seopm-suggestions';
		return base + '&business=' + bizId + '&tab=' + ( tab || 'suggestions' );
	}

	function populate( list ) {
		all = list;
		C.businesses = list.map( function ( b ) {
			return { id: b.id, name: b.name, color: b.color };
		} );
		render();
	}

	function load() {
		return ui.api( '/businesses' ).then( populate );
	}

	function render() {
		var term = ( search.value || '' ).trim().toLowerCase();
		var list = all.filter( function ( b ) {
			return ! term || b.name.toLowerCase().indexOf( term ) !== -1 || ( b.website_url || '' ).toLowerCase().indexOf( term ) !== -1;
		} );
		ui.clear( root );
		if ( ! all.length ) {
			root.appendChild( ui.emptyState( 'هنوز کسب‌وکاری ثبت نشده است. اولین کارفرمای خود را اضافه کنید.', ui.button( 'کسب‌وکار جدید', 'primary', function () {
				openForm();
			}, 'plus-alt2' ) ) );
			return;
		}
		if ( ! list.length ) {
			root.appendChild( ui.emptyState( 'نتیجه‌ای یافت نشد.' ) );
			return;
		}
		list.forEach( function ( b ) {
			root.appendChild( card( b ) );
		} );
	}

	function card( b ) {
		var sugUrl = suggestionsPageUrl( b.id, 'suggestions' );
		var reportUrl = suggestionsPageUrl( b.id, 'keywords' );

		var menu = el( 'div', { class: 'seopm-card-menu', 'aria-label': 'عملیات کسب‌وکار' }, [
			el( 'a', { class: 'seopm-icon-btn seopm-icon-sug', title: 'مقالات و استراتژی محتوا', 'aria-label': 'مقالات ' + b.name, href: sugUrl }, ui.icon( 'lightbulb' ) ),
			el( 'a', { class: 'seopm-icon-btn seopm-icon-report', title: 'گزارش سایت و کلمات کلیدی', 'aria-label': 'گزارش سایت و مقالات ' + b.name, href: reportUrl }, ui.icon( 'chart-bar' ) ),
			el( 'button', { type: 'button', class: 'seopm-icon-btn', title: 'ویرایش', 'aria-label': 'ویرایش ' + b.name, onclick: function () {
				openForm( b.id );
			} }, ui.icon( 'edit' ) ),
			el( 'a', { class: 'seopm-icon-btn', title: 'تسک‌ها', 'aria-label': 'تسک‌های ' + b.name, href: C.urls.tasks + '&business=' + b.id }, ui.icon( 'list-view' ) ),
			el( 'a', { class: 'seopm-icon-btn', title: 'ایجاد گزارش', 'aria-label': 'ایجاد گزارش', href: C.urls.reports + '&new=1&business=' + b.id }, ui.icon( 'media-document' ) ),
			el( 'div', { class: 'seopm-menu-divider' } ),
			el( 'button', { type: 'button', class: 'seopm-icon-btn seopm-danger-hover', title: 'حذف', 'aria-label': 'حذف ' + b.name, onclick: function () {
				removeBusiness( b );
			} }, ui.icon( 'trash' ) )
		] );

		var titleLink = el( 'a', {
			href: sugUrl,
			class: 'seopm-biz-clickable-title',
			title: 'مشاهده صفحه استراتژی محتوا، مقالات و گزارش سایت ' + b.name,
			'aria-label': 'مشاهده صفحه پروژه ' + b.name
		}, [
			el( 'span', { text: b.name } ),
			el( 'span', { class: 'dashicons dashicons-external seopm-title-icon', 'aria-hidden': 'true' } )
		] );

		var cardBody = el( 'div', { class: 'seopm-biz-card-body' }, [
			el( 'div', { class: 'seopm-biz-card-head' }, [
				el( 'a', {
					href: sugUrl,
					class: 'seopm-biz-avatar',
					style: { background: b.color, color: ui.contrast( b.color ), textDecoration: 'none' },
					text: b.name.trim().charAt( 0 ),
					title: 'مشاهده صفحه پروژه و مقالات'
				} ),
				el( 'div', { class: 'seopm-biz-card-title' }, [
					titleLink,
					b.website_url ? el( 'a', { href: b.website_url, target: '_blank', rel: 'noopener noreferrer', dir: 'ltr', class: 'seopm-small', text: b.website_url.replace( /^https?:\/\//, '' ) } ) : el( 'span', { class: 'seopm-muted seopm-small', text: 'بدون وب‌سایت' } )
				] )
			] ),
			b.description ? el( 'p', { class: 'seopm-biz-desc seopm-muted', text: b.description } ) : null,
			el( 'div', { class: 'seopm-biz-meta' }, [
				el( 'span', {}, [ ui.icon( 'tag' ), J.faDigits( b.keyword_count ) + ' کلمه کلیدی' ] ),
				el( 'a', {
					href: sugUrl,
					class: 'seopm-biz-quick-link',
					title: 'ورود به صفحه مقالات و استراتژی محتوا'
				}, [ ui.icon( 'lightbulb' ), 'مقالات' ] ),
				el( 'span', {}, [ ui.icon( 'list-view' ), J.faDigits( b.task_total ) + ' تسک' ] ),
				b.wp_connected ? el( 'span', { class: 'seopm-wp-connected-pill', title: 'اتصال انتشار خودکار وردپرس فعال است (ساعت ' + J.faDigits( b.wp_publish_time || '21:00' ) + ')' }, [ ui.icon( 'cloud-upload' ), 'متصل به وردپرس' ] ) : null,
				b.task_overdue ? el( 'span', { class: 'seopm-text-danger' }, [ ui.icon( 'warning' ), J.faDigits( b.task_overdue ) + ' عقب‌افتاده' ] ) : null
			] ),
			el( 'div', { class: 'seopm-biz-progress' }, [ ui.progress( b.completion, b.color ), el( 'span', { class: 'seopm-small', text: J.faDigits( b.completion + '%' ) + ' تکمیل' } ) ] )
		] );

		return el( 'article', { class: 'seopm-card seopm-biz-card', style: { '--seopm-biz': b.color } }, [
			cardBody,
			menu
		] );
	}

	/* ------------------------------- Form ------------------------------- */

	function openForm( id, initialTab ) {
		if ( id ) {
			ui.api( '/businesses/' + id ).then( function ( b ) {
				form( b, initialTab );
			} );
		} else {
			form( null, initialTab );
		}
	}

	function form( biz, initialTab ) {
		var keywords = biz ? biz.keywords.map( function ( k ) {
			return { id: k.id, keyword: k.keyword, weight: k.weight };
		} ) : [];

		var name = el( 'input', { type: 'text', required: true, maxlength: '191', value: biz ? biz.name : '', autofocus: true } );
		var website = el( 'input', { type: 'url', dir: 'ltr', placeholder: 'https://example.com', value: biz ? biz.website_url : '' } );
		var sitemap = el( 'input', { type: 'url', dir: 'ltr', placeholder: 'https://example.com/sitemap.xml', value: biz ? biz.sitemap_url : '' } );
		var colorValue = biz ? biz.color : PALETTE[ all.length % PALETTE.length ];
		var color = el( 'input', { type: 'text', class: 'seopm-color', value: colorValue } );
		var desc = el( 'textarea', { rows: '3' } );
		desc.value = biz ? biz.description : '';
		var error = el( 'div', { class: 'seopm-form-error', role: 'alert', hidden: true } );

		website.addEventListener( 'blur', function () {
			if ( website.value && ! sitemap.value ) {
				var base = website.value.trim().replace( /\/+$/, '' );
				if ( ! /^https?:\/\//i.test( base ) ) {
					base = 'https://' + base;
				}
				sitemap.placeholder = base + '/sitemap.xml';
			}
		} );

		/* ---------------- Shortcode Badges & Copy Helpers ---------------- */
		function copyShortcode( code ) {
			if ( navigator.clipboard && navigator.clipboard.writeText ) {
				navigator.clipboard.writeText( code ).then( function () {
					ui.toast( 'شورت‌کد ' + code + ' کپی شد! می‌توانید آن را در پرامپت‌ها قرار دهید.', 'success' );
				} ).catch( function () {
					fallbackCopy( code );
				} );
			} else {
				fallbackCopy( code );
			}
		}

		function fallbackCopy( text ) {
			var ta = document.createElement( 'textarea' );
			ta.value = text;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild( ta );
			ta.select();
			try {
				document.execCommand( 'copy' );
				ui.toast( 'شورت‌کد ' + text + ' کپی شد!', 'success' );
			} catch ( e ) {
				window.prompt( 'لطفاً شورت‌کد را کپی کنید:', text );
			}
			document.body.removeChild( ta );
		}

		function createShortcodeTag( code, title ) {
			var tag = el( 'span', {
				class: 'seopm-shortcode-tag',
				title: title || ( 'کلیک برای کپی شورت‌کد ' + code ),
				'data-code': code
			}, [
				el( 'span', { class: 'seopm-shortcode-code', text: code } ),
				ui.icon( 'admin-page' )
			] );
			tag.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				copyShortcode( code );
			} );
			return tag;
		}

		function createTabShortcode( code, title ) {
			var tag = el( 'span', {
				class: 'seopm-tab-shortcode',
				title: title || ( 'کلیک برای کپی شورت‌کد ' + code ),
				'data-code': code
			}, [
				el( 'span', { text: code } )
			] );
			tag.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				copyShortcode( code );
			} );
			return tag;
		}

		function createShortcodePill( code, desc ) {
			var pill = el( 'button', {
				type: 'button',
				class: 'seopm-shortcode-pill',
				title: 'کلیک کنید تا ' + code + ' کپی شود'
			}, [
				el( 'code', { text: code } ),
				el( 'span', { class: 'seopm-shortcode-pill-desc', text: desc } )
			] );
			pill.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				copyShortcode( code );
			} );
			return pill;
		}

		/* ---------------- Section 1: اطلاعات کسب و کار ---------------- */
		var industryServices = el( 'textarea', {
			rows: '2',
			placeholder: 'مثال: کلینیک تخصصی فیزیوتراپی و توانبخشی، درمان دیسک کمر، گردن و سکته مغزی',
			value: biz ? ( biz.industry_services || '' ) : ''
		} );
		var targetLocation = el( 'input', {
			type: 'text',
			placeholder: 'مثال: تهران و حومه (فعالیت محلی) یا سراسر کشور',
			value: biz ? ( biz.target_location || '' ) : ''
		} );
		var focusProductsServices = el( 'textarea', {
			rows: '2',
			placeholder: 'مثال: فیزیوتراپی در منزل، لیزردرمانی پرتوان و تمرین‌درمانی اختصاصی',
			value: biz ? ( biz.focus_products_services || '' ) : ''
		} );

		var section1 = el( 'div', { class: 'seopm-biz-section-card' }, [
			el( 'div', { class: 'seopm-biz-section-head' }, [
				el( 'div', { class: 'seopm-biz-section-title-wrap' }, [
					el( 'span', { class: 'seopm-biz-section-badge', text: '۱' } ),
					el( 'span', { class: 'seopm-biz-section-title', text: 'بخش اول: اطلاعات کسب‌وکار' } )
				] ),
				createShortcodeTag( '[business_profile]', 'کپی شورت‌کد بخش اول برای استفاده در پرامپت‌ها' )
			] ),
			el( 'div', { class: 'seopm-form-grid' }, [
				ui.field( 'نام کسب‌وکار *', name, 'seopm-span-2' ),
				ui.field( 'آدرس وب‌سایت', website ),
				ui.field( 'آدرس نقشه سایت (Sitemap URL) *', sitemap ),
				el( 'div', { class: 'seopm-field seopm-span-2', style: { margin: '-4px 0 6px 0' } }, [
					el( 'small', { class: 'seopm-muted seopm-small', text: '💡 توجه: ثبت آدرس معتبر نقشه سایت (مانند https://example.com/wp-sitemap.xml یا sitemap_index.xml) و کلمات کلیدی هدف برای ارائه مقالات پیشنهادی و ارزیابی همنوع‌خواری الزامی است.' } )
				] ),
				ui.field( 'حوزه فعالیت و خدمات یا محصولات اصلی', industryServices, 'seopm-span-2' ),
				ui.field( 'شهر یا کشور هدف، اگر فعالیتتان محلی است', targetLocation, 'seopm-span-2' ),
				ui.field( 'خدمات یا محصولاتی که می‌خواهید بیشتر روی آن‌ها تمرکز کنیم', focusProductsServices, 'seopm-span-2' )
			] )
		] );

		/* ---------------- Section 2: هدف تولید محتوا ---------------- */
		var GOAL_OPTIONS = [
			{ key: 'traffic_google', label: 'جذب ورودی از گوگل', icon: 'search' },
			{ key: 'leads_calls', label: 'دریافت تماس، مشاوره یا درخواست خدمات', icon: 'phone' },
			{ key: 'sales', label: 'فروش محصول', icon: 'cart' },
			{ key: 'brand_awareness', label: 'افزایش آگاهی از برند', icon: 'megaphone' },
			{ key: 'rank_support', label: 'حمایت از رتبه صفحات خدمات یا دسته‌بندی‌ها', icon: 'chart-line' }
		];
		var savedGoals = ( biz && Array.isArray( biz.content_goals ) ) ? biz.content_goals : [];
		var goalCheckboxes = {};

		var goalsGrid = el( 'div', { class: 'seopm-goals-grid' }, GOAL_OPTIONS.map( function ( opt ) {
			var cb = el( 'input', { type: 'checkbox', value: opt.key } );
			if ( savedGoals.indexOf( opt.key ) !== -1 ) {
				cb.checked = true;
			}
			goalCheckboxes[ opt.key ] = cb;
			return el( 'label', { class: 'seopm-goal-item' }, [
				cb,
				ui.icon( opt.icon ),
				el( 'span', { text: opt.label } )
			] );
		} ) );

		var section2 = el( 'div', { class: 'seopm-biz-section-card' }, [
			el( 'div', { class: 'seopm-biz-section-head' }, [
				el( 'div', { class: 'seopm-biz-section-title-wrap' }, [
					el( 'span', { class: 'seopm-biz-section-badge', text: '۲' } ),
					el( 'span', { class: 'seopm-biz-section-title', text: 'بخش دوم: هدف تولید محتوا' } )
				] ),
				createShortcodeTag( '[content_goals]', 'کپی شورت‌کد بخش دوم برای استفاده در پرامپت‌ها' )
			] ),
			el( 'p', { class: 'seopm-muted seopm-small', style: { margin: '0 0 10px 0' }, text: 'مشخص کنید اولویت شما چیست (امکان انتخاب یک یا چند مورد):' } ),
			goalsGrid
		] );

		/* ---------------- Section 3: ویژگی های مخاطب هدف ---------------- */
		var targetAudience = el( 'textarea', {
			rows: '3',
			placeholder: 'مثال: بیماران دارای درد حاد اسکلتی، سالمندان یا افرادی که به دنبال درمان سریع و غیرتهاجمی هستند و دغدغه هزینه، بیمه، تخصص و بهبودی دارند...',
			value: biz ? ( biz.target_audience || '' ) : ''
		} );

		var section3 = el( 'div', { class: 'seopm-biz-section-card' }, [
			el( 'div', { class: 'seopm-biz-section-head' }, [
				el( 'div', { class: 'seopm-biz-section-title-wrap' }, [
					el( 'span', { class: 'seopm-biz-section-badge', text: '۳' } ),
					el( 'span', { class: 'seopm-biz-section-title', text: 'بخش سوم: ویژگی‌های مخاطب هدف' } )
				] ),
				createShortcodeTag( '[target_audience]', 'کپی شورت‌کد بخش سوم برای استفاده در پرامپت‌ها' )
			] ),
			ui.field( 'ویژگی‌های مخاطب هدف (چه کسانی هستند و چه دغدغه‌هایی دارند):', targetAudience )
		] );

		/* ---------------- Section 4: دسترسی های خارجی ---------------- */
		var sitemapTestResult = el( 'div', { class: 'seopm-test-result' } );
		var sitemapTestBtn = ui.button( 'تست دسترسی به سایت‌مپ', 'ghost seopm-btn-sm', function () {
			var smUrl = sitemap.value.trim();
			var webUrl = website.value.trim();
			if ( ! smUrl && ! webUrl ) {
				ui.toast( 'ابتدا آدرس نقشه سایت یا وب‌سایت را وارد کنید.', 'error' );
				return;
			}
			sitemapTestBtn.disabled = true;
			sitemapTestResult.className = 'seopm-test-result seopm-test-running';
			ui.clear( sitemapTestResult );
			sitemapTestResult.appendChild( el( 'span', { class: 'seopm-test-spinner' } ) );
			sitemapTestResult.appendChild( document.createTextNode( ' در حال تست دسترسی به نقشه سایت...' ) );

			ui.api( ( biz && biz.id ? '/businesses/' + biz.id : '/businesses' ) + '/test-sitemap', {
				method: 'POST',
				data: { sitemap_url: smUrl, website_url: webUrl },
				silent: true
			} ).then( function ( res ) {
				sitemapTestBtn.disabled = false;
				if ( res && res.success ) {
					sitemapTestResult.className = 'seopm-test-result seopm-test-success';
					sitemapTestResult.textContent = '✓ ' + ( res.message || 'نقشه سایت با موفقیت تأیید شد.' );
				} else {
					sitemapTestResult.className = 'seopm-test-result seopm-test-error';
					sitemapTestResult.textContent = '✕ ' + ( ( res && res.message ) || 'دسترسی به نقشه سایت ناموفق بود.' );
				}
			} ).catch( function ( err ) {
				sitemapTestBtn.disabled = false;
				sitemapTestResult.className = 'seopm-test-result seopm-test-error';
				sitemapTestResult.textContent = '✕ ' + ( ( err && err.message ) || 'خطا در ارتباط با سرور هنگام تست نقشه سایت.' );
			} );
		}, 'rss' );

		var gscTestResult = el( 'div', { class: 'seopm-test-result' } );
		var gscTestBtn = ui.button( 'تست دسترسی به گوگل سرچ کنسول', 'ghost seopm-btn-sm', function () {
			var webUrl = website.value.trim();
			if ( ! webUrl ) {
				ui.toast( 'ابتدا آدرس وب‌سایت کسب‌وکار را وارد کنید.', 'error' );
				return;
			}
			gscTestBtn.disabled = true;
			gscTestResult.className = 'seopm-test-result seopm-test-running';
			ui.clear( gscTestResult );
			gscTestResult.appendChild( el( 'span', { class: 'seopm-test-spinner' } ) );
			gscTestResult.appendChild( document.createTextNode( ' در حال بررسی اتصال به API و دیتای گوگل سرچ کنسول...' ) );

			ui.api( ( biz && biz.id ? '/businesses/' + biz.id : '/businesses' ) + '/test-gsc', {
				method: 'POST',
				data: { website_url: webUrl },
				silent: true
			} ).then( function ( res ) {
				gscTestBtn.disabled = false;
				ui.clear( gscTestResult );
				if ( res && res.success && res.verified ) {
					gscTestResult.className = 'seopm-test-result seopm-test-success';
					var okText = res.message || 'اتصال زنده به دیتای گوگل سرچ کنسول برقرار است.';
					gscTestResult.appendChild( document.createTextNode( '✓ ' + okText ) );
					if ( res.property ) {
						var pill = el( 'span', {
							class: 'seopm-badge',
							style: 'margin-right:8px;background:rgba(34,197,94,0.15);color:#16a34a;font-weight:600;',
							text: res.property
						} );
						gscTestResult.appendChild( pill );
					}
				} else if ( res && res.success ) {
					gscTestResult.className = 'seopm-test-result seopm-test-warning';
					var warnText = res.message || 'پراپرتی این وب‌سایت در سرچ کنسول متصل نیست.';
					gscTestResult.appendChild( document.createTextNode( '⚠️ ' + warnText ) );
					if ( res.service_account_email ) {
						var copyBtn = el( 'button', {
							type: 'button',
							class: 'seopm-btn seopm-btn-sm',
							style: 'margin-right:8px;padding:2px 8px;font-size:11px;',
							text: '📋 کپی ایمیل سرویس اکانت'
						} );
						copyBtn.addEventListener( 'click', function ( e ) {
							e.preventDefault();
							navigator.clipboard.writeText( res.service_account_email ).then( function () {
								ui.toast( 'ایمیل سرویس اکانت کپی شد: ' + res.service_account_email, 'success' );
							} );
						} );
						gscTestResult.appendChild( el( 'div', { style: 'margin-top:6px;' }, [ copyBtn ] ) );
					}
				} else {
					gscTestResult.className = 'seopm-test-result seopm-test-error';
					gscTestResult.textContent = '✕ ' + ( ( res && res.message ) || 'بررسی وضعیت سرچ کنسول ناموفق بود.' );
				}
			} ).catch( function ( err ) {
				gscTestBtn.disabled = false;
				ui.clear( gscTestResult );
				gscTestResult.className = 'seopm-test-result seopm-test-error';
				gscTestResult.textContent = '✕ ' + ( ( err && err.message ) || 'خطا در بررسی دسترسی گوگل سرچ کنسول.' );
			} );
		}, 'search' );

		var serpTestResult = el( 'div', { class: 'seopm-test-result' } );
		var serpTestBtn = ui.button( 'تست آنالیز زنده SERP و رقبا', 'ghost seopm-btn-sm', function () {
			var testKw = ( keywords && keywords.length ) ? keywords[0].keyword : '';
			serpTestBtn.disabled = true;
			serpTestResult.className = 'seopm-test-result seopm-test-running';
			ui.clear( serpTestResult );
			serpTestResult.appendChild( el( 'span', { class: 'seopm-test-spinner' } ) );
			serpTestResult.appendChild( document.createTextNode( ' در حال استخراج زنده رقبای صفحه اول گوگل و نتایج SERP...' ) );

			ui.api( ( biz && biz.id ? '/businesses/' + biz.id : '/businesses' ) + '/test-serp', {
				method: 'POST',
				data: { keyword: testKw },
				silent: true
			} ).then( function ( res ) {
				serpTestBtn.disabled = false;
				ui.clear( serpTestResult );
				if ( res && res.success && res.verified ) {
					serpTestResult.className = 'seopm-test-result seopm-test-success';
					var okText = res.message || 'آنالیز زنده SERP با موفقیت انجام شد.';
					serpTestResult.appendChild( document.createTextNode( '✓ ' + okText ) );
					if ( res.keyword ) {
						var pill = el( 'span', {
							class: 'seopm-badge',
							style: 'margin-right:8px;background:rgba(59,130,246,0.15);color:#2563eb;font-weight:600;',
							text: '«' + res.keyword + '»'
						} );
						serpTestResult.appendChild( pill );
					}
				} else {
					serpTestResult.className = 'seopm-test-result seopm-test-error';
					serpTestResult.textContent = '✕ ' + ( ( res && res.message ) || 'آنالیز زنده SERP ناموفق بود.' );
				}
			} ).catch( function ( err ) {
				serpTestBtn.disabled = false;
				ui.clear( serpTestResult );
				serpTestResult.className = 'seopm-test-result seopm-test-error';
				serpTestResult.textContent = '✕ ' + ( ( err && err.message ) || 'خطا در ارتباط با سرور هنگام تست آنالیز زنده SERP.' );
			} );
		}, 'admin-site-alt3' );

		var section4 = el( 'div', { class: 'seopm-biz-section-card' }, [
			el( 'div', { class: 'seopm-biz-section-head' }, [
				el( 'div', { class: 'seopm-biz-section-title-wrap' }, [
					el( 'span', { class: 'seopm-biz-section-badge', text: '۴' } ),
					el( 'span', { class: 'seopm-biz-section-title', text: 'بخش چهارم: دسترسی‌های خارجی، دیتای سرچ کنسول و آنالیز زنده SERP' } )
				] ),
				createShortcodeTag( '[gsc_data]', 'کپی شورت‌کد اختصاصی دیتای سرچ کنسول (کوئری‌های پرایمپرشن و فرصت‌های طلایی)' ),
				createShortcodeTag( '[serp_data]', 'کپی شورت‌کد آنالیز زنده نتایج صفحه اول گوگل و رقبای ارگانیک (Information Gain)' )
			] ),
			el( 'div', { class: 'seopm-biz-test-box' }, [
				el( 'span', { class: 'seopm-muted seopm-small', text: 'اعتبارسنجی زنده ابزارها و اتصالات:' } ),
				el( 'div', { class: 'seopm-biz-test-buttons' }, [
					sitemapTestBtn,
					gscTestBtn,
					serpTestBtn
				] ),
				el( 'div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } }, [
					sitemapTestResult,
					gscTestResult,
					serpTestResult
				] ),
				el( 'small', { class: 'seopm-muted seopm-small', style: { marginTop: '4px' }, text: '💡 با قرار دادن شورت‌کدهای [gsc_data] و [serp_data] در پرامپت‌ها، آخرین دیتای زنده عملکردی سرچ کنسول و تحلیل ۵ رقیب برتر صفحه اول گوگل به هوش مصنوعی ارسال می‌شود.' } )
			] )
		] );

		var infoPane = el( 'div', { class: 'seopm-biz-sections-container' }, [
			section1,
			section2,
			section3,
			section4
		] );

		/* Keywords pane */
		var kwInput = el( 'input', { type: 'text', placeholder: 'عبارت کلیدی را بنویسید و Enter بزنید', maxlength: '191' } );
		var kwWeight = ui.select( weightOptions(), 5, { 'aria-label': 'وزن' } );
		var kwList = el( 'div', { class: 'seopm-kw-list' } );
		var kwCount = el( 'span', { class: 'seopm-count' } );

		function addKeyword() {
			var text = kwInput.value.trim();
			if ( ! text ) {
				return;
			}
			var exists = keywords.some( function ( k ) {
				return k.keyword.toLowerCase() === text.toLowerCase();
			} );
			if ( exists ) {
				ui.toast( 'این کلمه کلیدی قبلاً اضافه شده است.', 'error' );
				return;
			}
			keywords.push( { keyword: text, weight: +kwWeight.value } );
			kwInput.value = '';
			kwInput.focus();
			drawKeywords();
		}
		kwInput.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Enter' ) {
				e.preventDefault();
				addKeyword();
			}
		} );

		function drawKeywords() {
			ui.clear( kwList );
			kwCount.textContent = J.faDigits( keywords.length );
			if ( ! keywords.length ) {
				kwList.appendChild( el( 'div', { class: 'seopm-muted seopm-kw-empty', text: 'هنوز کلمه کلیدی اضافه نشده است.' } ) );
				return;
			}
			keywords.slice().sort( function ( a, b ) {
				return b.weight - a.weight;
			} ).forEach( function ( k ) {
				var text = el( 'input', { type: 'text', value: k.keyword, class: 'seopm-kw-text', 'aria-label': 'عبارت کلیدی' } );
				text.addEventListener( 'change', function () {
					var v = text.value.trim();
					if ( v ) {
						k.keyword = v;
					} else {
						text.value = k.keyword;
					}
				} );
				var w = ui.select( weightOptions(), k.weight, { class: 'seopm-kw-weight', 'aria-label': 'وزن' } );
				w.addEventListener( 'change', function () {
					k.weight = +w.value;
					drawKeywords();
				} );
				kwList.appendChild( el( 'div', { class: 'seopm-kw-row' }, [
					text,
					el( 'div', { class: 'seopm-weight-meter', title: 'وزن ' + J.faDigits( k.weight ) }, el( 'span', { style: { width: ( k.weight * 10 ) + '%' } } ) ),
					w,
					el( 'button', { type: 'button', class: 'seopm-icon-btn seopm-danger-hover', 'aria-label': 'حذف ' + k.keyword, onclick: function () {
						keywords.splice( keywords.indexOf( k ), 1 );
						drawKeywords();
					} }, ui.icon( 'no-alt' ) )
				] ) );
			} );
		}
		drawKeywords();

		var kwPane = el( 'div', { class: 'seopm-kw-pane', hidden: true }, [
			el( 'div', { class: 'seopm-kw-add' }, [ kwInput, el( 'label', { class: 'seopm-inline-label' }, [ 'وزن', kwWeight ] ), ui.button( 'افزودن', 'ghost', addKeyword, 'plus-alt2' ) ] ),
			el( 'p', { class: 'seopm-muted seopm-small', text: 'وزن نشان‌دهنده اهمیت کلمه کلیدی است (۱ کمترین تا ۱۰ بیشترین). برای فعال‌سازی مقالات پیشنهادی استراتژیک، ثبت حداقل ۵ کلمه کلیدی با اولویت‌بندی الزامی است.' } ),
			kwList
		] );

		/* Prompts pane */
		var promptSuggestionsBrief = el( 'textarea', {
			rows: '5',
			class: 'seopm-prompt-textarea',
			placeholder: 'مثال: دستورالعمل استراتژی موضوعی، انتخاب عناوین جذاب بر اساس Search Intent، بررسی دقیق صفحات موجود در سایت‌مپ برای جلوگیری از هم‌پوشانی و قواعد تدوین بریف سئو...'
		} );
		promptSuggestionsBrief.value = biz ? ( biz.prompt_suggestions_brief || '' ) : '';

		var promptArticle = el( 'textarea', {
			rows: '5',
			class: 'seopm-prompt-textarea',
			placeholder: 'مثال: تو یک نویسنده ارشد سئو در حوزه ... هستی. مقاله را با لحن تخصصی اما قابل فهم، ساختار H2/H3، سوالات متداول و لینک‌سازی طبیعی به صفحه پیلار بنویس...'
		} );
		promptArticle.value = biz ? ( biz.prompt_article_writing || '' ) : '';

		var promptHtml = el( 'textarea', {
			rows: '5',
			class: 'seopm-prompt-textarea',
			placeholder: 'مثال: متن مقاله را به کد HTML تمیز و سئوپسند (فقط بدنه بدون تگ html و body) با استفاده از تگ‌های h2، h3، table، باکس نکات مهم و باکس CTA اختصاصی سایت تبدیل کن...'
		} );
		promptHtml.value = biz ? ( biz.prompt_html_conversion || '' ) : '';

		var promptImage = el( 'textarea', {
			rows: '4',
			class: 'seopm-prompt-textarea',
			placeholder: 'مثال: یک تصویر حرفه‌ای، مدرن و بدون متن با پالت رنگی برند، نورپردازی طبیعی و نسبت ابعاد 16:9 مناسب تصویر شاخص مقاله طراحی کن...'
		} );
		promptImage.value = biz ? ( biz.prompt_image_generation || '' ) : '';

		var promptSourcesExternal = el( 'textarea', {
			rows: '4',
			class: 'seopm-prompt-textarea',
			placeholder: 'مثال: فقط از منابع و مقالات معتبر علمی، دانشگاهی یا وب‌سایت‌های مرجع رسمی استفاده شود. ارجاع‌ها با انکرتکست نام منبع و به‌صورت nofollow noopener در تب جدید درج شوند...'
		} );
		promptSourcesExternal.value = biz ? ( biz.prompt_sources_external_links || '' ) : '';

		var promptInternal = el( 'textarea', {
			rows: '4',
			class: 'seopm-prompt-textarea',
			placeholder: 'مثال: استراتژی لینک‌سازی داخلی، اتصال به صفحات پیلار و لندینگ‌های خدمات هدف، رعایت انکرتکست‌های دقیق و عبارتی و درج حداقل ۳ تا ۵ لینک داخلی متنی در طول مقاله...'
		} );
		promptInternal.value = biz ? ( biz.prompt_internal_links || '' ) : '';

		var promptsCount = el( 'span', { class: 'seopm-count' } );
		function updatePromptsCount() {
			var filled = 0;
			if ( promptSuggestionsBrief.value.trim() ) {
				filled++;
			}
			if ( promptArticle.value.trim() ) {
				filled++;
			}
			if ( promptHtml.value.trim() ) {
				filled++;
			}
			if ( promptImage.value.trim() ) {
				filled++;
			}
			if ( promptSourcesExternal.value.trim() ) {
				filled++;
			}
			if ( promptInternal.value.trim() ) {
				filled++;
			}
			promptsCount.textContent = J.faDigits( filled ) + '/' + J.faDigits( 6 );
		}
		promptSuggestionsBrief.addEventListener( 'input', updatePromptsCount );
		promptArticle.addEventListener( 'input', updatePromptsCount );
		promptHtml.addEventListener( 'input', updatePromptsCount );
		promptImage.addEventListener( 'input', updatePromptsCount );
		promptSourcesExternal.addEventListener( 'input', updatePromptsCount );
		promptInternal.addEventListener( 'input', updatePromptsCount );
		updatePromptsCount();

		var promptsPane = el( 'div', { class: 'seopm-prompts-pane', hidden: true }, [
			el( 'div', { class: 'seopm-notice seopm-prompt-hint' }, [
				ui.icon( 'info' ),
				el( 'span', { text: 'پرامپت‌های اختصاصی این کسب‌وکار را اینجا وارد کنید تا در فرآیند تولید محتوا، تبدیل به کد HTML و تولید تصویر دقیقاً مطابق استاندارد و هویت برند این سایت عمل شود.' } )
			] ),
			el( 'div', { class: 'seopm-prompt-shortcodes-bar' }, [
				el( 'div', { class: 'seopm-prompt-shortcodes-title' }, [
					ui.icon( 'admin-generic' ),
					el( 'strong', { text: 'شورت‌کدهای هوشمند قابل استفاده در پرامپت‌ها (با کلیک روی هر مورد کپی می‌شود):' } )
				] ),
				el( 'div', { class: 'seopm-shortcodes-list' }, [
					createShortcodePill( '[basic_info]', 'اطلاعات پایه کسب‌وکار (بخش‌های ۱ تا ۳)' ),
					createShortcodePill( '[business_profile]', 'بخش ۱: مشخصات کسب‌وکار' ),
					createShortcodePill( '[content_goals]', 'بخش ۲: اهداف محتوا' ),
					createShortcodePill( '[target_audience]', 'بخش ۳: پرسونای مخاطب' ),
					createShortcodePill( '[gsc_data]', 'دیتای سرچ کنسول: کوئری‌های پرایمپرشن و فرصت‌های طلایی' ),
					createShortcodePill( '[serp_data]', 'آنالیز زنده نتایج صفحه اول گوگل و رقبا (Information Gain)' ),
					createShortcodePill( '[keywords]', 'لیست کلمات کلیدی هدف' ),
					createShortcodePill( '[brief_content]', 'بریف کامل سئو و استراتژی محتوا (عنوان، اسلاگ، کلمات LSI، سرفصل‌ها و نیت کاربر)' ),
					createShortcodePill( '[article_content]', 'متن کامل مقاله نگارش‌شده (جهت درج در پرامپت لینک‌سازی داخلی و تبدیل HTML)' ),
					createShortcodePill( '[article_title]', 'عنوان اختصاصی مقاله جاری' ),
					createShortcodePill( '[article_keyword]', 'کلمه کلیدی مقاله جاری' ),
					createShortcodePill( '[brand_color]', 'کد رنگ برند' )
				] )
			] ),
			el( 'div', { class: 'seopm-prompt-card' }, [
				el( 'label', { class: 'seopm-field' }, [
					el( 'span', { class: 'seopm-prompt-head' }, [
						ui.icon( 'lightbulb' ),
						document.createTextNode( '۱. پرامپت تولید عناوین پیشنهادی و بریف محتوا' )
					] ),
					el( 'small', { class: 'seopm-muted seopm-small', text: 'دستورالعمل استراتژی موضوعی (Topical Authority)، معماری تاپیک کلاسترها، زاویه دید عناوین و قواعد بریف سئو.' } ),
					promptSuggestionsBrief
				] )
			] ),
			el( 'div', { class: 'seopm-prompt-card' }, [
				el( 'label', { class: 'seopm-field' }, [
					el( 'span', { class: 'seopm-prompt-head' }, [
						ui.icon( 'edit-page' ),
						document.createTextNode( '۲. پرامپت نگارش مقاله' )
					] ),
					el( 'small', { class: 'seopm-muted seopm-small', text: 'دستورالعمل لحن برند، ساختار مقاله، تعداد کلمات، قواعد سئو محتوا و لینک‌سازی داخلی.' } ),
					el( 'div', { class: 'seopm-shortcodes-list seopm-shortcodes-inline-bar', style: { margin: '6px 0' } }, [
						createShortcodePill( '[brief_content]', 'بریف کامل سئو (شامل عنوان، اسلاگ، LSI، سرفصل‌ها و نیت)' ),
						createShortcodePill( '[article_title]', 'عنوان مقاله' ),
						createShortcodePill( '[article_keyword]', 'کلمه کلیدی' ),
						createShortcodePill( '[basic_info]', 'اطلاعات کسب‌وکار' )
					] ),
					el( 'p', { class: 'seopm-muted seopm-small', style: { margin: '2px 0 6px', fontSize: '11px', color: '#0284c7' }, text: 'نکته سئو: با قرار دادن شورت‌کد [brief_content] در این پرامپت، جزئیات کامل بریف مصوب استراتژیست (عناوین، اسلاگ، کلمات کلیدی فرعی/LSI و سرفصل‌های مصوب H2/H3) مستقیماً برای نگارش مقاله به هوش مصنوعی ارسال می‌شود.' } ),
					promptArticle
				] )
			] ),
			el( 'div', { class: 'seopm-prompt-card' }, [
				el( 'label', { class: 'seopm-field' }, [
					el( 'span', { class: 'seopm-prompt-head' }, [
						ui.icon( 'editor-code' ),
						document.createTextNode( '۳. پرامپت تبدیل مقاله به کد HTML' )
					] ),
					el( 'small', { class: 'seopm-muted seopm-small', text: 'قواعد تبدیل متن به HTML آماده انتشار (تگ‌ها، جدول‌ها، باکس‌های CTA و کلاس‌های CSS). تگ‌های HTML بدون حذف ذخیره می‌شوند.' } ),
					el( 'div', { class: 'seopm-shortcodes-list seopm-shortcodes-inline-bar', style: { margin: '6px 0' } }, [
						createShortcodePill( '[article_content]', 'متن کامل مقاله' ),
						createShortcodePill( '[article_title]', 'عنوان مقاله' ),
						createShortcodePill( '[brand_color]', 'رنگ برند' )
					] ),
					promptHtml
				] )
			] ),
			el( 'div', { class: 'seopm-prompt-card' }, [
				el( 'label', { class: 'seopm-field' }, [
					el( 'span', { class: 'seopm-prompt-head' }, [
						ui.icon( 'format-image' ),
						document.createTextNode( '۴. پرامپت تولید تصویر' )
					] ),
					el( 'small', { class: 'seopm-muted seopm-small', text: 'سبک بصری، رنگ‌بندی، نسبت ابعاد و جزئیات تولید تصویر شاخص و تصاویر داخل مقاله برای این کسب‌وکار.' } ),
					el( 'div', { class: 'seopm-shortcodes-list seopm-shortcodes-inline-bar', style: { margin: '6px 0' } }, [
						createShortcodePill( '[article_title]', 'عنوان اختصاصی مقاله' ),
						createShortcodePill( '[article_keyword]', 'کلمه کلیدی مقاله' ),
						createShortcodePill( '[article_headings]', 'هدینگ‌های مقاله' ),
						createShortcodePill( '[brand_color]', 'رنگ برند' )
					] ),
					el( 'p', { class: 'seopm-muted seopm-small', style: { margin: '2px 0 6px', fontSize: '11px', color: '#0d9488' }, text: 'نکته هوشمند: می‌توانید با شورت‌کد [article_title] عنوان مقاله را مستقیماً در پرامپت بگذارید. حتی در صورت عدم درج شورت‌کد، سیستم به‌طور خودکار سوژه عکس را بر اساس عنوان مقاله بازآفرینی کرده و با پالت رنگ و سبک هنری این پرامپت ترکیب می‌کند.' } ),
					promptImage
				] )
			] ),
			el( 'div', { class: 'seopm-prompt-card' }, [
				el( 'label', { class: 'seopm-field' }, [
					el( 'span', { class: 'seopm-prompt-head' }, [
						ui.icon( 'external' ),
						document.createTextNode( '۵. پرامپت منابع مورد استفاده جهت نگارش مقاله و لینک‌دهی خارجی' )
					] ),
					el( 'small', { class: 'seopm-muted seopm-small', text: 'دستورالعمل انتخاب منابع معتبر علمی/تخصصی، قواعد استناد، انکرتکست‌ها و استانداردهای لینک‌دهی خارجی.' } ),
					promptSourcesExternal
				] )
			] ),
			el( 'div', { class: 'seopm-prompt-card' }, [
				el( 'label', { class: 'seopm-field' }, [
					el( 'span', { class: 'seopm-prompt-head' }, [
						ui.icon( 'admin-links' ),
						document.createTextNode( '۶. پرامپت لینک‌دهی داخلی' )
					] ),
					el( 'small', { class: 'seopm-muted seopm-small', text: 'قواعد استراتژی لینک‌سازی داخلی، توزیع لینک‌ها به صفحات پیلار و لندینگ‌ها، تنوع انکرتکست‌ها و ارتباط موضوعی.' } ),
					el( 'div', { class: 'seopm-shortcodes-list seopm-shortcodes-inline-bar', style: { margin: '6px 0' } }, [
						createShortcodePill( '[article_content]', 'متن کامل مقاله ورودی جهت درج لینک‌ها' ),
						createShortcodePill( '[brief_content]', 'بریف کامل سئو و کلاستر مقاله' ),
						createShortcodePill( '[article_title]', 'عنوان مقاله' )
					] ),
					el( 'p', { class: 'seopm-muted seopm-small', style: { margin: '2px 0 6px', fontSize: '11px', color: '#059669' }, text: 'نکته استراتژیک: با شورت‌کد [article_content] متن کامل مقاله نگارش‌شده در پرامپت لینک‌سازی داخلی قرار می‌گیرد تا مدل هوش مصنوعی پیوندهای متنی را مستقیماً درون این متن جایگذاری کند.' } ),
					promptInternal
				] )
			] )
		] );

		/* WordPress Auto-Publish pane */
		var wpUser = el( 'input', { type: 'text', dir: 'ltr', autocomplete: 'off', placeholder: 'مثلاً: admin', value: biz ? ( biz.wp_username || '' ) : '' } );
		var wpPass = el( 'input', { type: 'password', dir: 'ltr', autocomplete: 'new-password', placeholder: ( biz && biz.wp_has_password ) ? 'رمز ذخیره شده است (برای تغییر رمز جدید وارد کنید)' : 'xxxx xxxx xxxx xxxx xxxx xxxx', value: '' } );
		var wpPassEye = el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-ghost seopm-btn-sm', title: 'نمایش/مخفی کردن رمز', onclick: function () {
			var show = wpPass.type === 'password';
			wpPass.type = show ? 'text' : 'password';
		} }, ui.icon( 'visibility' ) );
		var wpPublishTime = el( 'input', { type: 'time', dir: 'ltr', value: ( biz && biz.wp_publish_time ) ? biz.wp_publish_time : '21:00' } );
		var savedCatId = biz ? ( biz.wp_default_category || 0 ) : 0;
		var wpCategory = el( 'select', {} );
		function populateWpCategories( cats, selectedId ) {
			ui.clear( wpCategory );
			wpCategory.appendChild( el( 'option', { value: '0', text: 'دسته‌بندی پیش‌فرض وردپرس مقصد' } ) );
			var found = false;
			( cats || [] ).forEach( function ( c ) {
				var opt = el( 'option', { value: String( c.id ), text: c.name + ( c.count ? ' (' + J.faDigits( c.count ) + ')' : '' ) } );
				if ( +c.id === +selectedId ) {
					opt.selected = true;
					found = true;
				}
				wpCategory.appendChild( opt );
			} );
			if ( selectedId && ! found ) {
				var customOpt = el( 'option', { value: String( selectedId ), text: 'دسته انتخاب‌شده (شناسه ' + J.faDigits( selectedId ) + ')', selected: true } );
				wpCategory.appendChild( customOpt );
			}
		}
		populateWpCategories( [], savedCatId );

		var wpStatusBadge = el( 'span', { class: 'seopm-count', text: ( biz && biz.wp_connected ) ? '✓' : '—' } );
		var wpTestResult = el( 'div', { class: 'seopm-test-result', style: { marginTop: '10px' } } );
		var wpTestBtn = ui.button( 'تست اتصال و دریافت دسته‌بندی‌ها', 'ghost seopm-btn-sm', function () {
			var siteVal = website.value.trim();
			var userVal = wpUser.value.trim();
			var passVal = wpPass.value.trim();
			if ( ! siteVal ) {
				ui.toast( 'ابتدا آدرس وب‌سایت کسب‌وکار را در تب اطلاعات پایه وارد کنید.', 'error' );
				return;
			}
			if ( ! userVal || ( ! passVal && ! ( biz && biz.wp_has_password ) ) ) {
				ui.toast( 'نام کاربری وردپرس و رمز عبور برنامه را وارد کنید.', 'error' );
				return;
			}
			wpTestBtn.disabled = true;
			wpTestResult.className = 'seopm-test-result seopm-test-running';
			ui.clear( wpTestResult );
			wpTestResult.appendChild( el( 'span', { class: 'seopm-test-spinner' } ) );
			wpTestResult.appendChild( document.createTextNode( ' در حال بررسی اتصال به وردپرس مقصد...' ) );

			ui.api( '/businesses/' + ( biz ? biz.id : 0 ) + '/wp-test-connection', {
				method: 'POST',
				data: {
					website_url: siteVal,
					wp_username: userVal,
					wp_app_password: passVal
				},
				silent: true
			} ).then( function ( r ) {
				wpTestBtn.disabled = false;
				if ( r && r.success ) {
					wpTestResult.className = 'seopm-test-result seopm-test-success';
					wpTestResult.textContent = '✓ ' + ( r.message || 'اتصال با موفقیت برقرار شد.' );
					wpStatusBadge.textContent = '✓';
					if ( r.categories && r.categories.length ) {
						populateWpCategories( r.categories, +wpCategory.value || savedCatId );
					}
				} else {
					wpTestResult.className = 'seopm-test-result seopm-test-error';
					wpTestResult.textContent = '✕ ' + ( ( r && r.message ) || 'اتصال ناموفق بود.' );
				}
			} ).catch( function ( err ) {
				wpTestBtn.disabled = false;
				wpTestResult.className = 'seopm-test-result seopm-test-error';
				wpTestResult.textContent = '✕ ' + ( ( err && err.message ) || 'خطا در تست اتصال به سایت مقصد.' );
			} );
		}, 'cloud-upload' );

		var wpPane = el( 'div', { class: 'seopm-prompts-pane', hidden: true }, [
			el( 'div', { class: 'seopm-notice seopm-prompt-hint' }, [
				ui.icon( 'info' ),
				el( 'span', { text: 'برای ارسال و زمان‌بندی خودکار مقالات (عنوان، کد HTML، تصویر شاخص، اسلاگ و متادیتای Rank Math) روی سایت مقصد، در پیشخوان وردپرس آن سایت به مسیر «کاربران ← شناسنامه ← رمزهای عبور برنامه (Application Passwords)» بروید و یک رمز بسازید.' } )
			] ),
			el( 'div', { class: 'seopm-form-grid' }, [
				ui.field( 'نام کاربری وردپرس سایت مقصد', wpUser ),
				ui.field( 'ساعت پیش‌فرض انتشار مقالات (به وقت تهران)', wpPublishTime ),
				el( 'div', { class: 'seopm-field seopm-span-2' }, [
					el( 'span', { text: 'رمز عبور برنامه (Application Password)' } ),
					el( 'div', { class: 'seopm-key-input-wrap' }, [ wpPass, wpPassEye ] ),
					( biz && biz.wp_has_password ) ? el( 'small', { class: 'seopm-muted seopm-small', text: 'رمز قبلی با موفقیت ذخیره شده است (' + biz.wp_app_password + '). اگر نمی‌خواهید آن را تغییر دهید، این فیلد را خالی بگذارید.' } ) : null
				] ),
				ui.field( 'دسته‌بندی پیش‌فرض مقالات در سایت مقصد', wpCategory, 'seopm-span-2' )
			] ),
			el( 'div', { class: 'seopm-test-bar' }, [
				wpTestBtn,
				wpTestResult
			] )
		] );

		/* Tab 5: Telegram Client Review & Auto-Send */
		var tgChatId = el( 'input', { type: 'text', dir: 'ltr', value: biz ? ( biz.telegram_chat_id || '' ) : '', placeholder: 'مثلاً: 123456789' } );
		var tgUsername = el( 'input', { type: 'text', dir: 'ltr', value: biz ? ( biz.telegram_username || '' ) : '', placeholder: 'client_username' } );
		var tgNotifyCb = el( 'input', { type: 'checkbox' } );
		tgNotifyCb.checked = biz ? Boolean( biz.telegram_notify_enabled ) : true;
		var tgStatusBadge = el( 'span', { class: 'seopm-count', text: ( biz && biz.telegram_chat_id ) ? '✓' : '—' } );
		var tgTestResult = el( 'div', { class: 'seopm-test-result', style: { marginTop: '10px' } } );

		var tgTestBtn = ui.button( 'ارسال پیام تست به تلگرام این کسب‌وکار', 'ghost seopm-btn-sm', function () {
			var cid = tgChatId.value.trim();
			if ( ! cid ) {
				ui.toast( 'ابتدا شناسه چت (Chat ID) تلگرام را وارد کنید.', 'error' );
				return;
			}
			tgTestBtn.disabled = true;
			tgTestResult.className = 'seopm-test-result seopm-test-running';
			ui.clear( tgTestResult );
			tgTestResult.appendChild( el( 'span', { class: 'seopm-test-spinner' } ) );
			tgTestResult.appendChild( document.createTextNode( ' در حال ارسال پیام تست...' ) );

			ui.api( '/telegram/test-message', {
				method: 'POST',
				data: {
					chat_id: cid,
					business_name: name.value.trim()
				},
				silent: true
			} ).then( function ( r ) {
				tgTestBtn.disabled = false;
				tgTestResult.className = 'seopm-test-result seopm-test-success';
				tgTestResult.textContent = '✓ ' + ( ( r && r.message ) || 'پیام تست ارسال شد.' );
			} ).catch( function ( err ) {
				tgTestBtn.disabled = false;
				tgTestResult.className = 'seopm-test-result seopm-test-error';
				tgTestResult.textContent = '✕ ' + ( ( err && err.message ) || 'خطا در ارسال پیام تست.' );
			} );
		}, 'email-alt' );

		var tgFetchChatsBtn = ui.button( 'واکشی Chat ID از چت‌های اخیر ربات', 'ghost seopm-btn-sm', function () {
			tgFetchChatsBtn.disabled = true;
			ui.api( '/telegram/recent-chats', { silent: true } ).then( function ( res ) {
				tgFetchChatsBtn.disabled = false;
				var chats = ( res && res.chats ) ? res.chats : [];
				if ( ! chats.length ) {
					ui.toast( 'هیچ پیامی در ربات یافت نشد. به ربات پیام بدهید سپس امتحان کنید.', 'warning' );
					return;
				}
				var matched = chats.find( function ( c ) { return biz && c.matched_business_id === biz.id; } ) || chats[ 0 ];
				if ( matched ) {
					tgChatId.value = matched.chat_id;
					if ( matched.username && ! tgUsername.value ) {
						tgUsername.value = matched.username.replace( '@', '' );
					}
					tgStatusBadge.textContent = '✓';
					ui.toast( 'شناسه چت ' + matched.chat_id + ' (' + ( matched.title || matched.username ) + ') دریافت شد.', 'success' );
				}
			} ).catch( function ( err ) {
				tgFetchChatsBtn.disabled = false;
				ui.toast( ( err && err.message ) || 'خطا در واکشی چت‌ها.', 'error' );
			} );
		}, 'search' );

		var tgBotUname = ( C.telegram && C.telegram.bot_username ) ? C.telegram.bot_username : '';
		var tgDeepLink = ( biz && biz.id && tgBotUname ) ? ( 'https://t.me/' + tgBotUname + '?start=biz_' + biz.id ) : '';

		var tgPane = el( 'div', { class: 'seopm-prompts-pane', hidden: true }, [
			el( 'div', { class: 'seopm-notice seopm-prompt-hint' }, [
				ui.icon( 'info' ),
				el( 'span', { text: 'با وارد کردن شناسه چت تلگرام کارفرما، ۱ روز قبل از انتشار هر مقاله در تقویم، لینک پیش‌نمایش به تلگرام او ارسال می‌شود تا بتواند بدون نیاز به لاگین آن را مطالعه، تأیید یا اصلاحیه ثبت کند.' } )
			] ),
			el( 'div', { class: 'seopm-form-grid' }, [
				ui.field( 'شناسه چت تلگرام کارفرما (Chat ID) *', tgChatId ),
				ui.field( 'نام کاربری تلگرام کارفرما (بدون @)', tgUsername ),
				el( 'div', { class: 'seopm-field seopm-span-2' }, [
					el( 'label', { class: 'seopm-check', style: { fontWeight: '600' } }, [
						tgNotifyCb,
						el( 'span', { text: 'ارسال خودکار لینک پیش‌نمایش مقاله به این چت ۱ روز قبل از تاریخ انتشار' } )
					] )
				] ),
				tgDeepLink ? el( 'div', { class: 'seopm-field seopm-span-2' }, [
					el( 'span', { text: 'لینک اتصال مستقیم کارفرما به ربات (کافیست کارفرما روی این لینک کلیک کرده و دکمه Start را بزند):' } ),
					el( 'div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } }, [
						el( 'input', { type: 'text', readonly: true, dir: 'ltr', value: tgDeepLink, style: { fontFamily: 'monospace' } } ),
						ui.button( 'کپی لینک', 'ghost seopm-btn-sm', function () {
							if ( navigator.clipboard && navigator.clipboard.writeText ) {
								navigator.clipboard.writeText( tgDeepLink );
								ui.toast( 'لینک استارت تلگرام در کلیپ‌بورد کپی شد.', 'success' );
							}
						}, 'admin-page' )
					] )
				] ) : null
			] ),
			el( 'div', { class: 'seopm-test-bar', style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } }, [
				tgFetchChatsBtn,
				tgTestBtn,
				tgTestResult
			] )
		] );

		var tabInfo = el( 'button', { type: 'button', role: 'tab', class: 'is-active', 'aria-selected': 'true' }, [
			el( 'span', { text: 'اطلاعات پایه ' } ),
			createTabShortcode( '[basic_info]', 'شورت‌کد تجمیعی کل اطلاعات پایه (بخش‌های ۱ تا ۴)' )
		] );
		var tabKw = el( 'button', { type: 'button', role: 'tab', 'aria-selected': 'false' }, [
			el( 'span', { text: 'کلمات کلیدی ' } ),
			kwCount,
			createTabShortcode( '[keywords]', 'شورت‌کد لیست کلمات کلیدی هدف' )
		] );
		var tabPrompts = el( 'button', { type: 'button', role: 'tab', 'aria-selected': 'false' }, [ 'پرامپت‌های هوش مصنوعی ', promptsCount ] );
		var tabWp = el( 'button', { type: 'button', role: 'tab', 'aria-selected': 'false' }, [ 'انتشار خودکار وردپرس ', wpStatusBadge ] );
		var tabTg = el( 'button', { type: 'button', role: 'tab', 'aria-selected': 'false' }, [ 'تلگرام کارفرما ', tgStatusBadge ] );

		function switchTab( tab ) {
			var isInfo = tab === 'info';
			var isKw = tab === 'keywords';
			var isPrompts = tab === 'prompts';
			var isWp = tab === 'wp';
			var isTg = tab === 'telegram';

			tabInfo.classList.toggle( 'is-active', isInfo );
			tabKw.classList.toggle( 'is-active', isKw );
			tabPrompts.classList.toggle( 'is-active', isPrompts );
			tabWp.classList.toggle( 'is-active', isWp );
			tabTg.classList.toggle( 'is-active', isTg );

			tabInfo.setAttribute( 'aria-selected', String( isInfo ) );
			tabKw.setAttribute( 'aria-selected', String( isKw ) );
			tabPrompts.setAttribute( 'aria-selected', String( isPrompts ) );
			tabWp.setAttribute( 'aria-selected', String( isWp ) );
			tabTg.setAttribute( 'aria-selected', String( isTg ) );

			infoPane.hidden = ! isInfo;
			kwPane.hidden = ! isKw;
			promptsPane.hidden = ! isPrompts;
			wpPane.hidden = ! isWp;
			tgPane.hidden = ! isTg;

			if ( isKw ) {
				kwInput.focus();
			} else if ( isPrompts ) {
				promptArticle.focus();
			} else if ( isWp ) {
				wpUser.focus();
			} else if ( isTg ) {
				tgChatId.focus();
			} else {
				name.focus();
			}
		}
		tabInfo.addEventListener( 'click', function () { switchTab( 'info' ); } );
		tabKw.addEventListener( 'click', function () { switchTab( 'keywords' ); } );
		tabPrompts.addEventListener( 'click', function () { switchTab( 'prompts' ); } );
		tabWp.addEventListener( 'click', function () { switchTab( 'wp' ); } );
		tabTg.addEventListener( 'click', function () { switchTab( 'telegram' ); } );

		var m = ui.modal( {
			title: biz ? 'ویرایش کسب‌وکار' : 'کسب‌وکار جدید',
			size: 'lg',
			body: [ el( 'div', { class: 'seopm-tabs seopm-tabs-inline', role: 'tablist' }, [ tabInfo, tabKw, tabPrompts, tabWp, tabTg ] ), infoPane, kwPane, promptsPane, wpPane, tgPane, error ],
			footer: [
				ui.button( 'انصراف', 'ghost', function () {
					m.close();
				} ),
				ui.button( biz ? 'ذخیره تغییرات' : 'ایجاد کسب‌وکار', 'primary', save )
			]
		} );

		if ( $ && $.fn.wpColorPicker ) {
			$( color ).wpColorPicker();
		}

		if ( initialTab === 'keywords' || initialTab === 'prompts' || initialTab === 'wp' ) {
			switchTab( initialTab );
		}

		function save() {
			if ( kwInput.value.trim() ) {
				addKeyword();
			}
			var selectedGoals = [];
			GOAL_OPTIONS.forEach( function ( opt ) {
				if ( goalCheckboxes[ opt.key ] && goalCheckboxes[ opt.key ].checked ) {
					selectedGoals.push( opt.key );
				}
			} );

			var data = {
				name: name.value.trim(),
				website_url: website.value.trim(),
				sitemap_url: sitemap.value.trim(),
				color: colorValue,
				description: desc.value,
				industry_services: industryServices.value.trim(),
				target_location: targetLocation.value.trim(),
				focus_products_services: focusProductsServices.value.trim(),
				content_goals: selectedGoals,
				target_audience: targetAudience.value.trim(),
				prompt_suggestions_brief: promptSuggestionsBrief.value,
				prompt_article_writing: promptArticle.value,
				prompt_html_conversion: promptHtml.value,
				prompt_image_generation: promptImage.value,
				prompt_sources_external_links: promptSourcesExternal.value,
				prompt_internal_links: promptInternal.value,
				wp_username: wpUser.value.trim(),
				wp_publish_time: wpPublishTime.value || '21:00',
				wp_default_category: +wpCategory.value || 0,
				telegram_chat_id: tgChatId.value.trim(),
				telegram_username: tgUsername.value.trim().replace( /^@/, '' ),
				telegram_notify_enabled: tgNotifyCb.checked ? 1 : 0,
				keywords: keywords
			};
			if ( wpPass.value.trim() ) {
				data.wp_app_password = wpPass.value.trim();
			}
			if ( ! data.name ) {
				switchTab( 'info' );
				error.textContent = 'نام کسب‌وکار الزامی است.';
				error.hidden = false;
				return;
			}
			m.setBusy( true );
			ui.api( biz ? '/businesses/' + biz.id : '/businesses', { method: biz ? 'PUT' : 'POST', data: data, silent: true } ).then( function () {
				ui.toast( biz ? 'کسب‌وکار به‌روزرسانی شد.' : 'کسب‌وکار ایجاد شد.' );
				m.close();
				load();
			} ).catch( function ( err ) {
				m.setBusy( false );
				error.textContent = ( err && err.message ) || 'خطا در ذخیره';
				error.hidden = false;
			} );
		}
	}

	function weightOptions() {
		var out = [];
		for ( var i = 1; i <= 10; i++ ) {
			out.push( { value: i, label: J.faDigits( i ) } );
		}
		return out;
	}

	function removeBusiness( b ) {
		ui.api( '/businesses/' + b.id ).then( function ( full ) {
			var r = full.related;
			var keep = el( 'input', { type: 'checkbox' } );
			var extra = el( 'div', {}, [
				el( 'ul', { class: 'seopm-confirm-list' }, [
					el( 'li', { text: J.faDigits( r.tasks ) + ' تسک' } ),
					el( 'li', { text: J.faDigits( r.keywords ) + ' کلمه کلیدی' } ),
					el( 'li', { text: J.faDigits( r.reports ) + ' گزارش' } )
				] ),
				r.reports ? el( 'label', { class: 'seopm-check' }, [ keep, 'گزارش‌های آرشیوشده این کسب‌وکار نگه داشته شوند' ] ) : null
			] );
			ui.confirm( 'با حذف «' + b.name + '» موارد زیر هم حذف می‌شوند:', { title: 'حذف کسب‌وکار', confirmText: 'حذف کسب‌وکار', danger: true, extra: extra } ).then( function ( ok ) {
				if ( ! ok ) {
					return;
				}
				ui.api( '/businesses/' + b.id, { method: 'DELETE', query: { keep_reports: keep.checked ? 1 : 0 } } ).then( function () {
					ui.toast( 'کسب‌وکار حذف شد.' );
					load();
				} );
			} );
		} );
	}

	search.addEventListener( 'input', ui.debounce( render, 150 ) );
	document.querySelectorAll( '[data-action="new-business"]' ).forEach( function ( b ) {
		b.addEventListener( 'click', function () {
			openForm();
		} );
	} );

	var initPromise;
	if ( C.initialData ) {
		var init = C.initialData;
		C.initialData = null;
		populate( init );
		initPromise = Promise.resolve();
	} else {
		initPromise = load();
	}

	initPromise.then( function () {
		var params = new URLSearchParams( window.location.search );
		if ( params.get( 'new' ) ) {
			openForm();
		} else if ( params.get( 'edit' ) ) {
			openForm( +params.get( 'edit' ), params.get( 'tab' ) || '' );
		}
	} );
}( window, document, window.jQuery ) );

<?php
/**
 * Live SERP Analyzer & Competitor Intelligence Engine.
 *
 * Scrapes and analyzes live page 1 search engine results (organic competitors, titles, URLs, snippets)
 * and Google Autocomplete user suggestions for target keywords. Injects competitive intelligence
 * into AI prompts to enable Information Gain Optimization (covering content gaps, answering neglected
 * user questions, and outranking page 1 competitors).
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

class SERP_Analyzer {

	/**
	 * Transient cache prefix for keyword SERP data.
	 */
	const TRANSIENT_PREFIX = 'seopm_serp_';

	/**
	 * Cache TTL: 24 hours (86,400 seconds).
	 */
	const CACHE_TTL = 86400;

	/**
	 * Default organic results to scrape per keyword.
	 */
	const DEFAULT_LIMIT = 5;

	/**
	 * Maximum keywords to include in a cluster SERP digest.
	 */
	const MAX_KEYWORDS_DIGEST = 4;

	/**
	 * Fetch live SERP results and related search queries for a given keyword.
	 *
	 * Uses DuckDuckGo HTML as the primary resilient organic SERP scraper (no cookie gates or bot interstitials),
	 * decodes clean destination competitor URLs, parses meta snippets, and queries Google Autocomplete
	 * for real-time Persian search queries.
	 *
	 * @param string $keyword       Target keyword.
	 * @param int    $limit         Maximum organic results (1-10, default 5).
	 * @param bool   $force_refresh Bypass transient cache.
	 * @return array {
	 *     @type string $keyword Target keyword.
	 *     @type array  $results List of competitor results [{rank, title, url, domain, brand, snippet}].
	 *     @type array  $google_suggestions List of live Google search queries.
	 *     @type string $fetched_at Timestamp.
	 *     @type bool   $cached Whether result was served from cache.
	 * }
	 */
	public static function fetch_keyword_serp( $keyword, $limit = 5, $force_refresh = false ) {
		$keyword = trim( (string) $keyword );
		if ( '' === $keyword ) {
			return array(
				'keyword'            => '',
				'results'            => array(),
				'google_suggestions' => array(),
				'fetched_at'         => current_time( 'mysql' ),
				'cached'             => false,
			);
		}

		$limit     = max( 1, min( 10, (int) $limit ) );
		$cache_key = self::TRANSIENT_PREFIX . md5( mb_strtolower( $keyword ) );

		if ( ! $force_refresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && ! empty( $cached['results'] ) ) {
				$cached['cached'] = true;
				return $cached;
			}
		}

		$results            = array();
		$google_suggestions = array();

		// 1. Fetch Organic Page 1 Competitor Results via DuckDuckGo HTML
		$ddg_url  = 'https://html.duckduckgo.com/html/?q=' . rawurlencode( $keyword );
		$response = wp_remote_get(
			$ddg_url,
			array(
				'timeout'    => 5,
				'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
				'headers'    => array(
					'Accept-Language' => 'fa,en-US;q=0.9,en;q=0.8',
					'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				),
				'sslverify'  => false,
			)
		);

		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$html = wp_remote_retrieve_body( $response );
			if ( ! empty( $html ) ) {
				preg_match_all( '/<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/si', $html, $titles_matches, PREG_SET_ORDER );
				preg_match_all( '/<a[^>]+class="result__snippet"[^>]*>(.*?)<\/a>/si', $html, $snippets_matches, PREG_SET_ORDER );

				$count = min( $limit, count( $titles_matches ) );
				for ( $i = 0; $i < $count; $i++ ) {
					$raw_href  = $titles_matches[ $i ][ 1 ];
					$raw_title = $titles_matches[ $i ][ 2 ];

					$title = html_entity_decode( trim( wp_strip_all_tags( $raw_title ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );

					// Decode target URL from DDG redirect (//duckduckgo.com/l/?uddg=https%3A%2F%2F...)
					$clean_url = $raw_href;
					if ( preg_match( '/uddg=([^&]+)/i', $raw_href, $m ) ) {
						$clean_url = urldecode( $m[ 1 ] );
					}
					if ( 0 === strpos( $clean_url, '//' ) ) {
						$clean_url = 'https:' . $clean_url;
					}

					$snippet = '';
					if ( isset( $snippets_matches[ $i ][ 1 ] ) ) {
						$snippet = html_entity_decode( trim( wp_strip_all_tags( $snippets_matches[ $i ][ 1 ] ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
					}

					$host = wp_parse_url( $clean_url, PHP_URL_HOST );

					// Extract potential brand name from title (e.g. "عنوان مقاله | نام برند")
					$brand_name = '';
					if ( false !== strpos( $title, '|' ) ) {
						$parts      = explode( '|', $title );
						$brand_name = trim( end( $parts ) );
					} elseif ( false !== strpos( $title, '-' ) ) {
						$parts      = explode( '-', $title );
						$brand_name = trim( end( $parts ) );
					}

					$results[] = array(
						'rank'    => $i + 1,
						'title'   => $title,
						'url'     => $clean_url,
						'domain'  => $host ?: '',
						'brand'   => $brand_name,
						'snippet' => $snippet,
					);
				}
			}
		}

		// 2. Fetch Live Google Autocomplete Queries for Iran / Persian
		$sug_url  = 'https://suggestqueries.google.com/complete/search?client=firefox&hl=fa&gl=ir&q=' . rawurlencode( $keyword );
		$sug_resp = wp_remote_get(
			$sug_url,
			array(
				'timeout'    => 3,
				'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
				'sslverify'  => false,
			)
		);

		if ( ! is_wp_error( $sug_resp ) && 200 === (int) wp_remote_retrieve_response_code( $sug_resp ) ) {
			$sug_body = wp_remote_retrieve_body( $sug_resp );
			if ( ! empty( $sug_body ) ) {
				$sug_data = json_decode( $sug_body, true );
				if ( isset( $sug_data[ 1 ] ) && is_array( $sug_data[ 1 ] ) ) {
					foreach ( $sug_data[ 1 ] as $item ) {
						$s_clean = trim( (string) $item );
						if ( '' !== $s_clean && mb_strtolower( $s_clean ) !== mb_strtolower( $keyword ) ) {
							$google_suggestions[] = $s_clean;
						}
					}
					$google_suggestions = array_slice( $google_suggestions, 0, 8 );
				}
			}
		}

		$payload = array(
			'keyword'            => $keyword,
			'results'            => $results,
			'google_suggestions' => $google_suggestions,
			'fetched_at'         => current_time( 'mysql' ),
			'cached'             => false,
		);

		if ( ! empty( $results ) || ! empty( $google_suggestions ) ) {
			set_transient( $cache_key, $payload, self::CACHE_TTL );
		}

		return $payload;
	}

	/**
	 * Build formatted SERP intelligence text block for AI prompts.
	 *
	 * @param array $keywords      List of keywords or keyword objects.
	 * @param int   $limit_per_kw  Number of results per keyword.
	 * @param bool  $force_refresh Bypass cache.
	 * @return string Formatted Persian text block.
	 */
	public static function get_serp_digest( array $keywords, $limit_per_kw = 5, $force_refresh = false ) {
		if ( empty( $keywords ) ) {
			return '';
		}

		// Extract unique clean keyword strings
		$kw_list = array();
		foreach ( $keywords as $k ) {
			$word = is_array( $k ) ? trim( (string) ( $k['keyword'] ?? '' ) ) : trim( (string) $k );
			if ( '' !== $word && ! in_array( $word, $kw_list, true ) ) {
				$kw_list[] = $word;
			}
		}

		if ( empty( $kw_list ) ) {
			return '';
		}

		// Restrict to top keywords for prompt conciseness
		$kw_list = array_slice( $kw_list, 0, self::MAX_KEYWORDS_DIGEST );

		$sections = array();
		foreach ( $kw_list as $kw ) {
			$data = self::fetch_keyword_serp( $kw, $limit_per_kw, $force_refresh );
			$res  = $data['results'] ?? array();
			$sugs = $data['google_suggestions'] ?? array();

			if ( empty( $res ) && empty( $sugs ) ) {
				continue;
			}

			$kw_block   = array();
			$kw_block[] = "■ کلمه کلیدی: «{$kw}»";

			if ( ! empty( $res ) ) {
				$kw_block[] = '  • ۵ رقیب برتر صفحه اول گوگل (Organic Competitors):';
				foreach ( $res as $r ) {
					$rank    = $r['rank'] ?? 1;
					$title   = $r['title'] ?? '';
					$url     = $r['url'] ?? '';
					$domain  = ! empty( $r['domain'] ) ? " [دامنه: {$r['domain']}]" : '';
					$snippet = ! empty( $r['snippet'] ) ? '      خلاصه متای رقیب: ' . mb_substr( $r['snippet'], 0, 160 ) . '...' : '';

					$kw_block[] = "    {$rank}. {$title}{$domain}";
					if ( '' !== $url ) {
						$kw_block[] = "      URL: {$url}";
					}
					if ( '' !== $snippet ) {
						$kw_block[] = $snippet;
					}
				}
			}

			if ( ! empty( $sugs ) ) {
				$kw_block[] = '  • جستجوهای پرتکرار زنده کاربران در گوگل (Google Autocomplete / Related):';
				$kw_block[] = '    - ' . implode( ' | ', $sugs );
			}

			$sections[] = implode( "\n", $kw_block );
		}

		if ( empty( $sections ) ) {
			return '';
		}

		$header = "=== تحلیل زنده نتایج صفحه اول گوگل و رقبا (Live SERP Analysis & Information Gain) ===\n" .
			"نتایج زنده استخراج‌شده از صفحه اول برای کلمات کلیدی اصلی پروژه:\n\n" .
			implode( "\n\n", $sections ) . "\n\n" .
			"دستورالعمل حیاتی تمایز محتوایی و Information Gain Optimization:\n" .
			"۱. تحلیل خلاءهای رقبای صفحه اول: رقبای بالا را دقیق بررسی کن. تمام مقالات آن‌ها به موضوعات عمومی و کلیشه‌ای پرداخته‌اند. عناوین و بریف‌های پیشنهادی باید دقیقاً زوایا، سوالات کلیدی، ابهامات تخصصی یا نیازهای ناگفته‌ای را پوشش دهند که این رقبا به آن‌ها پاسخ نداده‌اند.\n" .
			"۲. پوشش کوئری‌های زنده کاربران: از عبارات جستجوی زنده کاربران (Google Autocomplete) در بالا برای پوشش قصد جستجوی واقعی و کشف ساب‌تاپیک‌های پرطرفدار استفاده نما.\n" .
			"۳. کسب امتیاز Information Gain: هوش مصنوعی باید محتوایی با ارزش افزوده اطلاعاتی واقعی پیشنهاد دهد تا وب‌سایت شانس بالایی برای جهش به رتبه ۱ گوگل و شکست دادن این رقبای قدیمی داشته باشد.";

		return $header;
	}

	/**
	 * Build SERP digest for a business based on its priority keywords.
	 *
	 * @param array|int $biz           Business data or business ID.
	 * @param bool      $force_refresh Bypass cache.
	 * @return string
	 */
	public static function get_serp_digest_for_business( $biz, $force_refresh = false ) {
		if ( is_numeric( $biz ) ) {
			$biz = Business::get( (int) $biz, true );
		}
		if ( ! is_array( $biz ) || empty( $biz['id'] ) ) {
			return '';
		}

		$keywords = array();
		if ( ! empty( $biz['keywords'] ) && is_array( $biz['keywords'] ) ) {
			$keywords = $biz['keywords'];
		} else {
			$keywords = Keyword::for_business( $biz['id'] );
		}

		if ( empty( $keywords ) ) {
			return '- هیچ کلمه کلیدی برای این کسب‌وکار جهت آنالیز زنده SERP ثبت نشده است.';
		}

		// Sort keywords by weight DESC
		usort(
			$keywords,
			static function ( $a, $b ) {
				$wa = is_array( $a ) ? ( $a['weight'] ?? 5 ) : 5;
				$wb = is_array( $b ) ? ( $b['weight'] ?? 5 ) : 5;
				return $wb <=> $wa;
			}
		);

		return self::get_serp_digest( $keywords, self::DEFAULT_LIMIT, $force_refresh );
	}

	/**
	 * Test live SERP connectivity for a keyword.
	 *
	 * @param string $keyword Target keyword.
	 * @return array Diagnostic info.
	 */
	public static function test_serp( $keyword = '' ) {
		$keyword = trim( (string) $keyword );
		if ( '' === $keyword ) {
			$keyword = 'فیزیوتراپی در منزل';
		}

		$start_time = microtime( true );
		$data       = self::fetch_keyword_serp( $keyword, 5, true );
		$latency_ms = (int) round( ( microtime( true ) - $start_time ) * 1000 );

		$results_count = count( $data['results'] ?? array() );
		$sugs_count    = count( $data['google_suggestions'] ?? array() );

		if ( $results_count > 0 || $sugs_count > 0 ) {
			return array(
				'success'            => true,
				'verified'           => true,
				'message'            => sprintf( 'آنالیز زنده SERP با موفقیت انجام شد (%d رقیب برتر صفحه اول و %d پرسش گوگل شناسایی شد).', $results_count, $sugs_count ),
				'keyword'            => $keyword,
				'results_count'      => $results_count,
				'suggestions_count'  => $sugs_count,
				'results'            => $data['results'],
				'google_suggestions' => $data['google_suggestions'],
				'latency_ms'         => $latency_ms,
			);
		}

		return array(
			'success'    => false,
			'verified'   => false,
			'message'    => 'امکان واکشی نتایج زنده SERP برای این کلمه کلیدی وجود نداشت.',
			'latency_ms' => $latency_ms,
		);
	}
}

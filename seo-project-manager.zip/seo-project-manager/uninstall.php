<?php
/**
 * Uninstall: removes data only when the administrator explicitly opted in.
 *
 * @package SEOPM
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$seopm_settings = get_option( 'seopm_settings' );
if ( ! is_array( $seopm_settings ) || empty( $seopm_settings['delete_on_uninstall'] ) ) {
	return;
}

global $wpdb;
foreach ( array( 'businesses', 'keywords', 'tasks', 'reports', 'report_versions' ) as $seopm_table ) {
	$wpdb->query( 'DROP TABLE IF EXISTS `' . esc_sql( $wpdb->prefix . 'seopm_' . $seopm_table ) . '`' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
}

delete_option( 'seopm_settings' );
delete_option( 'seopm_db_version' );

foreach ( wp_roles()->role_objects as $seopm_role ) {
	$seopm_role->remove_cap( 'seopm_manage' );
}
remove_role( 'seopm_manager' );

// Remove generated report files.
$seopm_uploads = wp_upload_dir( null, false );
$seopm_dir     = untrailingslashit( $seopm_uploads['basedir'] ) . '/seopm-reports';
if ( is_dir( $seopm_dir ) ) {
	$seopm_it = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $seopm_dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);
	foreach ( $seopm_it as $seopm_file ) {
		if ( $seopm_file->isDir() ) {
			rmdir( $seopm_file->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
		} else {
			unlink( $seopm_file->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
		}
	}
	rmdir( $seopm_dir ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
}

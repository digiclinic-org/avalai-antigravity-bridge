<?php
/**
 * Plugin Name:       SEO Project Manager
 * Plugin URI:        https://github.com/digiclinic-org/seo-task-manager
 * Description:       مدیریت پروژه‌های سئو: کسب‌وکارها، کلمات کلیدی، تسک‌ها، تقویم شمسی، داشبورد و گزارش‌های PDF حرفه‌ای برای کارفرمایان.
 * Version:           1.15.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            SEO Project Manager
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       seo-project-manager
 * Domain Path:       /languages
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;

define( 'SEOPM_VERSION', '1.15.0' );
define( 'SEOPM_FILE', __FILE__ );
define( 'SEOPM_PATH', plugin_dir_path( __FILE__ ) );
define( 'SEOPM_URL', plugin_dir_url( __FILE__ ) );

/**
 * PSR-4-like autoloader.
 * SEOPM\Report_Builder  -> includes/class-report-builder.php
 * SEOPM\Admin\Admin_Menu -> admin/class-admin-menu.php
 */
spl_autoload_register(
	static function ( $class ) {
		if ( 0 !== strpos( $class, 'SEOPM\\' ) ) {
			return;
		}
		$relative = substr( $class, 6 );
		$parts    = explode( '\\', $relative );
		$name     = array_pop( $parts );
		$dir      = $parts ? strtolower( implode( '/', $parts ) ) : 'includes';
		$file     = SEOPM_PATH . $dir . '/class-' . str_replace( '_', '-', strtolower( $name ) ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

register_activation_hook( __FILE__, array( 'SEOPM\\Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'SEOPM\\Deactivator', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'SEOPM\\Plugin', 'instance' ) );

<?php
/**
 * Dashboard data aggregation.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Dashboard.
 */
class Dashboard {

	/**
	 * All dashboard data in one call.
	 *
	 * @return array
	 */
	public static function data() {
		$today      = Jalali::today();
		$week_later = gmdate( 'Y-m-d', strtotime( $today . ' +7 days' ) );
		$businesses = Business::all();

		return array(
			'stats'      => array_merge( array( 'businesses' => count( $businesses ) ), Task::counts() ),
			'upcoming'   => Task::query(
				array(
					'status'   => 'open',
					'from'     => $today,
					'to'       => $week_later,
					'orderby'  => 'due_date',
					'per_page' => 8,
				),
				false
			)['items'],
			'overdue'    => Task::query(
				array(
					'status'   => 'overdue',
					'orderby'  => 'due_date',
					'per_page' => 8,
				),
				false
			)['items'],
			'recent'     => Task::query(
				array(
					'orderby'  => 'created_at',
					'order'    => 'DESC',
					'per_page' => 8,
				),
				false
			)['items'],
			'businesses' => $businesses,
			'today'      => $today,
		);
	}
}

<?php
/**
 * REST API routes (namespace seopm/v1).
 *
 * @package SEOPM
 */

namespace SEOPM;

use WP_REST_Request;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

/**
 * REST API controller.
 */
class Rest_Api {

	const NS = 'seopm/v1';

	/**
	 * Register a route with the shared permission callback.
	 *
	 * @param string $route   Route.
	 * @param array  $methods Map of method => [callback, args].
	 */
	private function route( $route, array $methods ) {
		$defs = array();
		foreach ( $methods as $method => $def ) {
			$defs[] = array(
				'methods'             => $method,
				'callback'            => array( $this, $def[0] ),
				'permission_callback' => array( Security::class, 'rest_permission' ),
				'args'                => $def[1] ?? array(),
			);
		}
		register_rest_route( self::NS, $route, $defs );
	}

	/**
	 * Common arg definitions.
	 *
	 * @return array
	 */
	private function id_arg() {
		return array(
			'id' => array(
				'type'              => 'integer',
				'required'          => true,
				'sanitize_callback' => 'absint',
			),
		);
	}

	/**
	 * Date arg.
	 *
	 * @param bool $required Required.
	 * @return array
	 */
	private function date_arg( $required = false ) {
		return array(
			'type'              => 'string',
			'required'          => $required,
			'validate_callback' => static function ( $v ) {
				return '' === $v || null !== Security::sanitize_date( $v );
			},
		);
	}

	/**
	 * Register routes.
	 */
	public function register_routes() {
		$id = $this->id_arg();

		$this->route(
			'/businesses',
			array(
				WP_REST_Server::READABLE  => array( 'list_businesses', array( 'search' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ) ) ),
				WP_REST_Server::CREATABLE => array( 'create_business' ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)',
			array(
				WP_REST_Server::READABLE  => array( 'get_business', $id ),
				WP_REST_Server::EDITABLE  => array( 'update_business', $id ),
				WP_REST_Server::DELETABLE => array( 'delete_business', $id + array( 'keep_reports' => array( 'type' => 'boolean', 'default' => false ) ) ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/site-report',
			array(
				WP_REST_Server::READABLE => array(
					'get_site_report',
					$id + array(
						'refresh' => array(
							'type'     => 'boolean',
							'default'  => false,
							'required' => false,
						),
					),
				),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/suggested-articles',
			array(
				WP_REST_Server::READABLE => array(
					'get_suggested_articles',
					$id + array(
						'refresh' => array(
							'type'     => 'boolean',
							'default'  => false,
							'required' => false,
						),
					),
				),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/suggested-articles/add-to-tasks',
			array(
				WP_REST_Server::CREATABLE => array( 'add_suggested_article_to_tasks', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/suggested-articles/replace',
			array(
				WP_REST_Server::CREATABLE => array( 'replace_suggested_article', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/draft',
			array(
				WP_REST_Server::READABLE  => array(
					'get_article_draft',
					$id + array(
						'article_key' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_key',
						),
					),
				),
				WP_REST_Server::CREATABLE => array( 'save_article_draft', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/generate',
			array(
				WP_REST_Server::CREATABLE => array( 'generate_article_content', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/convert-html',
			array(
				WP_REST_Server::CREATABLE => array( 'convert_article_to_html', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/generate-image',
			array(
				WP_REST_Server::CREATABLE => array( 'generate_article_image', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/upload-image',
			array(
				WP_REST_Server::CREATABLE => array( 'upload_article_image', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/publish-status',
			array(
				WP_REST_Server::READABLE => array(
					'get_article_publish_status',
					$id + array(
						'article_key' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_key',
						),
					),
				),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/publish',
			array(
				WP_REST_Server::CREATABLE => array( 'publish_article_to_wp', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/wp-test-connection',
			array(
				WP_REST_Server::CREATABLE => array( 'test_business_wp_connection', $id ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/test-sitemap',
			array(
				WP_REST_Server::CREATABLE => array( 'test_business_sitemap', $id ),
			)
		);
		$this->route(
			'/businesses/test-sitemap',
			array(
				WP_REST_Server::CREATABLE => array( 'test_business_sitemap', $can_manage ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/test-gsc',
			array(
				WP_REST_Server::CREATABLE => array( 'test_business_gsc', $id ),
			)
		);
		$this->route(
			'/businesses/test-gsc',
			array(
				WP_REST_Server::CREATABLE => array( 'test_business_gsc', $can_manage ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/gsc-performance',
			array(
				WP_REST_Server::READABLE  => array( 'get_business_gsc_performance', $id ),
				WP_REST_Server::CREATABLE => array( 'get_business_gsc_performance', $id ),
			)
		);
		$this->route(
			'/gsc/status',
			array(
				WP_REST_Server::READABLE => array( 'get_gsc_status', $can_manage ),
			)
		);
		$this->route(
			'/gsc/properties',
			array(
				WP_REST_Server::READABLE => array( 'get_gsc_properties', $can_manage ),
			)
		);
		$this->route(
			'/gsc/settings',
			array(
				WP_REST_Server::CREATABLE => array( 'save_gsc_settings', $can_manage ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/articles/send-telegram-preview',
			array(
				WP_REST_Server::CREATABLE => array( 'send_business_telegram_preview', $id ),
			)
		);
		$this->route(
			'/tasks/(?P<id>\d+)/send-telegram-preview',
			array(
				WP_REST_Server::CREATABLE => array( 'send_task_telegram_preview', $id ),
			)
		);
		$this->route(
			'/telegram/test-connection',
			array(
				WP_REST_Server::CREATABLE => array( 'test_telegram_connection' ),
			)
		);
		$this->route(
			'/telegram/test-message',
			array(
				WP_REST_Server::CREATABLE => array( 'send_telegram_test_message' ),
			)
		);
		$this->route(
			'/telegram/recent-chats',
			array(
				WP_REST_Server::READABLE => array( 'get_telegram_recent_chats' ),
			)
		);
		$this->route(
			'/telegram/run-daily-check',
			array(
				WP_REST_Server::CREATABLE => array( 'run_telegram_daily_check' ),
			)
		);
		register_rest_route(
			self::NS,
			'/public/review',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'submit_public_review' ),
				'permission_callback' => '__return_true',
			)
		);
		$this->route(
			'/ai/test-connection',
			array(
				WP_REST_Server::CREATABLE => array(
					'test_ai_connection',
					array(
						'provider' => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_key' ),
						'api_key'  => array( 'type' => 'string', 'required' => false ),
						'model'    => array( 'type' => 'string', 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
						'base_url' => array( 'type' => 'string', 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
					),
				),
			)
		);
		$this->route(
			'/ai/info',
			array(
				WP_REST_Server::READABLE => array( 'get_ai_info' ),
			)
		);
		$this->route(
			'/businesses/(?P<id>\d+)/keywords',
			array(
				WP_REST_Server::READABLE  => array( 'list_keywords', $id ),
				WP_REST_Server::CREATABLE => array( 'create_keyword', $id ),
			)
		);
		$this->route(
			'/keywords/(?P<id>\d+)',
			array(
				WP_REST_Server::EDITABLE  => array( 'update_keyword', $id ),
				WP_REST_Server::DELETABLE => array( 'delete_keyword', $id ),
			)
		);

		$task_filters = array(
			'business_ids' => array( 'sanitize_callback' => array( Security::class, 'id_list' ) ),
			'type'         => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_key' ),
			'status'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_key' ),
			'search'       => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
			'from'         => $this->date_arg(),
			'to'           => $this->date_arg(),
			'orderby'      => array( 'type' => 'string', 'enum' => array( 'due_date', 'created_at', 'updated_at', 'title', 'status' ), 'default' => 'due_date' ),
			'order'        => array( 'type' => 'string', 'enum' => array( 'asc', 'desc', 'ASC', 'DESC' ), 'default' => 'asc' ),
			'page'         => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
			'per_page'     => array( 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100 ),
		);
		$this->route(
			'/tasks',
			array(
				WP_REST_Server::READABLE  => array( 'list_tasks', $task_filters ),
				WP_REST_Server::CREATABLE => array( 'create_task' ),
			)
		);
		$this->route(
			'/tasks/bulk',
			array(
				WP_REST_Server::CREATABLE => array(
					'bulk_tasks',
					array(
						'ids'    => array( 'required' => true, 'sanitize_callback' => array( Security::class, 'id_list' ) ),
						'action' => array( 'type' => 'string', 'required' => true, 'enum' => array( 'delete', 'pending', 'in_progress', 'completed' ) ),
					),
				),
			)
		);
		$this->route(
			'/tasks/restore',
			array( WP_REST_Server::CREATABLE => array( 'restore_task', array( 'task' => array( 'type' => 'object', 'required' => true ) ) ) )
		);
		$this->route(
			'/tasks/(?P<id>\d+)',
			array(
				WP_REST_Server::READABLE  => array( 'get_task', $id ),
				WP_REST_Server::EDITABLE  => array( 'update_task', $id ),
				WP_REST_Server::DELETABLE => array( 'delete_task', $id ),
			)
		);
		$this->route(
			'/tasks/(?P<id>\d+)/status',
			array( 'PATCH, POST' => array( 'set_task_status', $id + array( 'status' => array( 'type' => 'string', 'required' => true, 'enum' => array_keys( Task::statuses() ) ) ) ) )
		);
		$this->route(
			'/tasks/(?P<id>\d+)/date',
			array( 'PATCH, POST' => array( 'set_task_date', $id + array( 'due_date' => $this->date_arg( true ) ) ) )
		);
		$this->route(
			'/tasks/(?P<id>\d+)/publish-status',
			array( WP_REST_Server::READABLE => array( 'get_task_publish_status', $id ) )
		);
		$this->route(
			'/tasks/(?P<id>\d+)/publish',
			array( WP_REST_Server::CREATABLE => array( 'publish_task_to_wp', $id ) )
		);
		$this->route(
			'/task-types',
			array(
				WP_REST_Server::READABLE  => array( 'list_task_types' ),
				WP_REST_Server::CREATABLE => array(
					'create_task_type',
					array(
						'label' => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
						'key'   => array( 'type' => 'string', 'required' => false, 'sanitize_callback' => 'sanitize_key' ),
					),
				),
			)
		);
		$this->route(
			'/task-types/(?P<key>[a-zA-Z0-9_\-]+)',
			array(
				WP_REST_Server::EDITABLE  => array(
					'update_task_type',
					array(
						'label' => array( 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
					),
				),
				WP_REST_Server::DELETABLE => array(
					'delete_task_type',
				),
			)
		);
		$this->route(
			'/task-types/(?P<key>[a-zA-Z0-9_\-]+)/delete',
			array(
				WP_REST_Server::CREATABLE => array(
					'delete_task_type',
				),
			)
		);

		$this->route(
			'/calendar/events',
			array(
				WP_REST_Server::READABLE => array(
					'calendar_events',
					array(
						'start'        => $this->date_arg( true ),
						'end'          => $this->date_arg( true ),
						'business_ids' => array( 'sanitize_callback' => array( Security::class, 'id_list' ) ),
					),
				),
			)
		);

		$this->route( '/dashboard', array( WP_REST_Server::READABLE => array( 'dashboard' ) ) );

		$this->route(
			'/reports',
			array(
				WP_REST_Server::READABLE  => array(
					'list_reports',
					array(
						'business_id' => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
						'jmonth'      => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
						'from'        => $this->date_arg(),
						'to'          => $this->date_arg(),
						'page'        => array( 'type' => 'integer', 'default' => 1, 'minimum' => 1 ),
						'per_page'    => array( 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100 ),
					),
				),
				WP_REST_Server::CREATABLE => array( 'create_report' ),
			)
		);
		$this->route( '/reports/preview', array( WP_REST_Server::READABLE => array( 'preview_report' ) ) );
		$this->route(
			'/reports/(?P<id>\d+)',
			array(
				WP_REST_Server::READABLE  => array( 'get_report', $id + array( 'version' => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ) ) ),
				WP_REST_Server::DELETABLE => array( 'delete_report', $id ),
			)
		);
		$this->route( '/reports/(?P<id>\d+)/summary', array( WP_REST_Server::EDITABLE => array( 'update_report_summary', $id ) ) );
		$this->route( '/reports/(?P<id>\d+)/regenerate', array( WP_REST_Server::CREATABLE => array( 'regenerate_report', $id ) ) );
		$this->route( '/reports/(?P<id>\d+)/pdf', array( WP_REST_Server::CREATABLE => array( 'regenerate_pdf', $id ) ) );

		/* Notes routes */
		$this->route(
			'/notes',
			array(
				WP_REST_Server::READABLE  => array( 'list_notes' ),
				WP_REST_Server::CREATABLE => array( 'create_note' ),
			)
		);
		$this->route(
			'/notes/(?P<id>\d+)',
			array(
				WP_REST_Server::READABLE  => array( 'get_note', $id ),
				WP_REST_Server::EDITABLE  => array( 'update_note', $id ),
				WP_REST_Server::DELETABLE => array( 'delete_note', $id ),
			)
		);
		$this->route(
			'/notes/(?P<id>\d+)/pin',
			array(
				WP_REST_Server::CREATABLE => array( 'toggle_pin_note', $id ),
			)
		);
	}

	/**
	 * Wrap result into a response.
	 *
	 * @param mixed $result Result or WP_Error.
	 * @param int   $status Success status.
	 * @return \WP_REST_Response|\WP_Error
	 */
	private function respond( $result, $status = 200 ) {
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( null === $result ) {
			return new \WP_Error( 'seopm_not_found', __( 'مورد درخواستی یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		return new \WP_REST_Response( $result, $status );
	}

	/**
	 * Paginated response with headers.
	 *
	 * @param array $result items/total/pages.
	 * @param array $extra  Extra body data.
	 * @return \WP_REST_Response
	 */
	private function paginated( array $result, array $extra = array() ) {
		$response = new \WP_REST_Response( array_merge( $result, $extra ) );
		$response->header( 'X-WP-Total', (string) $result['total'] );
		$response->header( 'X-WP-TotalPages', (string) $result['pages'] );
		return $response;
	}

	/* ------------------------- Businesses ------------------------- */

	/** @param WP_REST_Request $r Request. */
	public function list_businesses( WP_REST_Request $r ) {
		return $this->respond( Business::all( array( 'search' => $r['search'] ) ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function create_business( WP_REST_Request $r ) {
		return $this->respond( Business::create( (array) $r->get_json_params() ), 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function get_business( WP_REST_Request $r ) {
		$b = Business::get( $r['id'] );
		if ( $b ) {
			$b['related'] = Business::related_counts( $r['id'] );
		}
		return $this->respond( $b );
	}

	/** @param WP_REST_Request $r Request. */
	public function update_business( WP_REST_Request $r ) {
		return $this->respond( Business::update( $r['id'], (array) $r->get_json_params() ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function delete_business( WP_REST_Request $r ) {
		$res = Business::delete( $r['id'], (bool) $r['keep_reports'] );
		return $this->respond( is_wp_error( $res ) ? $res : array( 'deleted' => true ) );
	}

	/**
	 * Get site report (keywords, linked articles, and pages).
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_site_report( WP_REST_Request $r ) {
		$refresh = (bool) $r->get_param( 'refresh' );
		$report  = Site_Crawler::get_report( (int) $r['id'], $refresh );
		return $this->respond( $report );
	}

	/** @param WP_REST_Request $r Request. */
	public function get_suggested_articles( WP_REST_Request $r ) {
		$refresh  = (bool) $r->get_param( 'refresh' );
		$force_ai = (bool) $r->get_param( 'force_ai' );
		if ( $force_ai ) {
			$refresh = true;
		}
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'] );
		$data   = Content_Suggester::get_suggestions( $biz_id, $refresh, $force_ai );
		return $this->respond( $data );
	}

	/** @param WP_REST_Request $r Request. */
	public function add_suggested_article_to_tasks( WP_REST_Request $r ) {
		$params = (array) $r->get_json_params();
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$data   = Content_Suggester::add_to_tasks( $biz_id, $params );
		return $this->respond( $data, 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function replace_suggested_article( WP_REST_Request $r ) {
		$params = (array) $r->get_json_params();
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$data   = Content_Suggester::replace_scheduled_suggestion( $biz_id, $params );
		return $this->respond( $data );
	}

	/** @param WP_REST_Request $r Request. */
	public function get_article_draft( WP_REST_Request $r ) {
		$params  = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id  = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$art_key = sanitize_key( $params['article_key'] ?? $r['article_key'] ?? '' );
		$draft   = Article_Generator::get_draft( $biz_id, $art_key );
		return $this->respond(
			$draft ? $draft : array(
				'article_key'        => $art_key,
				'article_content'    => '',
				'article_html'       => '',
				'featured_image_url' => '',
				'images'             => array(),
				'images_count'       => 0,
				'has_article'        => false,
				'has_html'           => false,
				'has_image'          => false,
				'word_count'         => 0,
				'link_count'         => 0,
			)
		);
	}

	/** @param WP_REST_Request $r Request. */
	public function save_article_draft( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$key    = sanitize_key( $params['article_key'] ?? '' );
		$saved  = Article_Generator::save_draft( $biz_id, $key, $params );
		return $this->respond( $saved );
	}

	/** @param WP_REST_Request $r Request. */
	public function generate_article_content( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$res    = Article_Generator::generate_article( $biz_id, $params );
		return $this->respond( $res );
	}

	/** @param WP_REST_Request $r Request. */
	public function convert_article_to_html( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$res    = Article_Generator::convert_to_html( $biz_id, $params );
		return $this->respond( $res );
	}

	/** @param WP_REST_Request $r Request. */
	public function generate_article_image( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$res    = Article_Generator::generate_image( $biz_id, $params );
		return $this->respond( $res );
	}

	/** @param WP_REST_Request $r Request. */
	public function upload_article_image( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$res    = Article_Generator::upload_image( $biz_id, $params );
		return $this->respond( $res );
	}

	/** @param WP_REST_Request $r Request. */
	public function get_article_publish_status( WP_REST_Request $r ) {
		$params  = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id  = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$art_key = sanitize_key( $params['article_key'] ?? $r['article_key'] ?? '' );
		$res     = WP_Publisher::get_publish_status( $biz_id, $art_key, 0 );
		return $this->respond( $res );
	}

	/** @param WP_REST_Request $r Request. */
	public function publish_article_to_wp( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$res    = WP_Publisher::publish( $biz_id, $params );
		return $this->respond( $res );
	}

	/** @param WP_REST_Request $r Request. */
	public function test_business_wp_connection( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id = Article_Generator::resolve_business_id( (int) $r['id'], $params );
		$res    = WP_Publisher::test_connection( $biz_id, $params );
		return $this->respond( $res );
	}

	/**
	 * Test sitemap accessibility for a business.
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function test_business_sitemap( WP_REST_Request $r ) {
		$params      = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$sitemap_url = trim( (string) ( $params['sitemap_url'] ?? '' ) );
		$website_url = trim( (string) ( $params['website_url'] ?? '' ) );
		$biz_id      = (int) ( $r['id'] ?? 0 );

		if ( empty( $sitemap_url ) && $biz_id > 0 ) {
			$biz         = Business::get( $biz_id );
			$sitemap_url = $biz['sitemap_url'] ?? '';
			if ( empty( $website_url ) ) {
				$website_url = $biz['website_url'] ?? '';
			}
		}

		$res = Site_Crawler::test_sitemap( $sitemap_url, $website_url );
		return $this->respond( $res );
	}

	/**
	 * Test Google Search Console verification for a business website.
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function test_business_gsc( WP_REST_Request $r ) {
		$params      = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$website_url = trim( (string) ( $params['website_url'] ?? '' ) );
		$biz_id      = (int) ( $r['id'] ?? 0 );

		if ( empty( $website_url ) && $biz_id > 0 ) {
			$biz         = Business::get( $biz_id );
			$website_url = $biz['website_url'] ?? '';
		}

		$res = Site_Crawler::test_gsc( $website_url, $biz_id );
		return $this->respond( $res );
	}

	/**
	 * Get GSC performance for a business.
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function get_business_gsc_performance( WP_REST_Request $r ) {
		$biz_id = (int) ( $r['id'] ?? 0 );
		$biz    = Business::get( $biz_id );
		if ( ! $biz ) {
			return $this->error( 'not_found', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), 404 );
		}

		$params     = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$start_date = sanitize_text_field( $params['start_date'] ?? '' );
		$end_date   = sanitize_text_field( $params['end_date'] ?? '' );
		$row_limit  = min( 100, max( 5, (int) ( $params['row_limit'] ?? 25 ) ) );
		$dimension  = sanitize_text_field( $params['dimension'] ?? 'query' );

		if ( ! in_array( $dimension, array( 'query', 'page', 'device', 'country', 'date' ), true ) ) {
			$dimension = 'query';
		}

		$match = Google_Search_Console::match_property( $biz['website_url'] );
		if ( ! $match['found'] ) {
			return $this->respond(
				array(
					'success'               => false,
					'configured'            => Google_Search_Console::has_credentials(),
					'service_account_email' => Google_Search_Console::get_client_email(),
					'message'               => __( 'پراپرتی این کسب‌وکار در سرچ کنسول یافت نشد. لطفاً ایمیل سرویس اکانت را در سرچ کنسول اضافه کنید.', 'seo-project-manager' ),
				)
			);
		}

		$res = Google_Search_Console::query_performance(
			$match['property'],
			$start_date,
			$end_date,
			array( $dimension ),
			$row_limit
		);

		$res['property']              = $match['property'];
		$res['permission']            = $match['permission'];
		$res['service_account_email'] = Google_Search_Console::get_client_email();

		return $this->respond( $res );
	}

	/**
	 * Get Google Search Console integration status.
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function get_gsc_status( WP_REST_Request $r ) {
		$has_creds = Google_Search_Console::has_credentials();
		$email     = Google_Search_Console::get_client_email();
		$source    = Google_Search_Console::get_credential_source();
		$sites     = $has_creds ? Google_Search_Console::list_sites() : array();

		return $this->respond(
			array(
				'configured'       => $has_creds,
				'client_email'     => $email,
				'source'           => $source,
				'properties_count' => count( $sites ),
				'sites'            => $sites,
			)
		);
	}

	/**
	 * Get list of authorized GSC properties.
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function get_gsc_properties( WP_REST_Request $r ) {
		$refresh = (bool) ( $r->get_param( 'refresh' ) ?? false );
		$sites   = Google_Search_Console::list_sites( $refresh );
		return $this->respond( array( 'sites' => $sites, 'count' => count( $sites ) ) );
	}

	/**
	 * Save GSC settings (Service Account JSON).
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function save_gsc_settings( WP_REST_Request $r ) {
		$params = (array) $r->get_json_params();
		$json   = trim( (string) ( $params['service_account_json'] ?? '' ) );

		if ( empty( $json ) ) {
			delete_option( 'seopm_gsc_service_account_json' );
			delete_transient( 'seopm_gsc_sites_list' );
			return $this->respond(
				array(
					'success' => true,
					'message' => __( 'تنظیمات اختصاصی سرچ کنسول حذف گردید و در صورت وجود، از Easy MCP AI استفاده خواهد شد.', 'seo-project-manager' ),
				)
			);
		}

		$decoded = json_decode( $json, true );
		if ( ! is_array( $decoded ) || empty( $decoded['client_email'] ) || empty( $decoded['private_key'] ) ) {
			return $this->error( 'invalid_json', __( 'فایل یا متن JSON ارسالی معتبر نیست. لطفاً فایل معتبر Service Account گوگل را وارد فرمایید.', 'seo-project-manager' ), 400 );
		}

		update_option( 'seopm_gsc_service_account_json', $json );
		delete_transient( 'seopm_gsc_sites_list' );

		return $this->respond(
			array(
				'success'      => true,
				'client_email' => $decoded['client_email'],
				'message'      => sprintf( __( 'سرویس اکانت گوگل با موفقیت ذخیره شد (%s).', 'seo-project-manager' ), $decoded['client_email'] ),
			)
		);
	}

	/** @param WP_REST_Request $r Request. */
	public function get_task_publish_status( WP_REST_Request $r ) {
		$res = WP_Publisher::get_publish_status( 0, '', (int) $r['id'] );
		return $this->respond( $res );
	}

	/** @param WP_REST_Request $r Request. */
	public function publish_task_to_wp( WP_REST_Request $r ) {
		$params            = (array) $r->get_json_params();
		$params['task_id'] = (int) $r['id'];
		$res               = WP_Publisher::publish( 0, $params );
		return $this->respond( $res );
	}

	/**
	 * Test AI connection to a provider.
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function test_ai_connection( WP_REST_Request $r ) {
		$provider = sanitize_key( $r->get_param( 'provider' ) );
		$api_key  = trim( (string) $r->get_param( 'api_key' ) );
		$model    = sanitize_text_field( $r->get_param( 'model' ) );
		$base_url = trim( (string) $r->get_param( 'base_url' ) );

		if ( empty( $api_key ) || false !== strpos( $api_key, '****' ) || false !== strpos( $api_key, '...' ) ) {
			$saved = Settings::get( $provider . '_api_key' );
			if ( ! empty( $saved ) ) {
				$api_key = $saved;
			}
		}

		$res = AI_Client::test_connection( $provider, $api_key, $model, $base_url );
		return $this->respond( $res );
	}

	/**
	 * Get AI providers info and status.
	 *
	 * @param WP_REST_Request $r Request.
	 * @return \WP_REST_Response
	 */
	public function get_ai_info( WP_REST_Request $r ) {
		$providers = AI_Client::get_providers();
		$settings  = Settings::all();
		$active    = $settings['ai_active_provider'] ?? 'none';

		$out = array(
			'active_provider' => $active,
			'temperature'     => (float) ( $settings['ai_temperature'] ?? 0.7 ),
			'providers'       => array(),
		);

		foreach ( $providers as $pk => $pdata ) {
			$raw_key = $settings[ $pk . '_api_key' ] ?? '';
			$out['providers'][ $pk ] = array(
				'key'           => $pk,
				'name'          => $pdata['name'],
				'short_name'    => $pdata['short_name'],
				'color'         => $pdata['color'],
				'bg'            => $pdata['bg'],
				'has_key'       => ! empty( $raw_key ),
				'masked_key'    => Settings::mask_key( $raw_key ),
				'model'         => $settings[ $pk . '_model' ] ?? $pdata['default_model'],
				'models'        => $pdata['models'],
				'base_url'      => $settings[ $pk . '_base_url' ] ?? '',
				'portal_url'    => $pdata['portal_url'],
				'is_active'     => $active === $pk,
			);
		}

		return $this->respond( $out );
	}

	/** @param WP_REST_Request $r Request. */
	public function list_keywords( WP_REST_Request $r ) {
		return $this->respond( Keyword::for_business( $r['id'] ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function create_keyword( WP_REST_Request $r ) {
		return $this->respond( Keyword::create( $r['id'], (array) $r->get_json_params() ), 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function update_keyword( WP_REST_Request $r ) {
		return $this->respond( Keyword::update( $r['id'], (array) $r->get_json_params() ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function delete_keyword( WP_REST_Request $r ) {
		return $this->respond( Keyword::delete( $r['id'] ) ? array( 'deleted' => true ) : null );
	}

	/* ---------------------------- Tasks ---------------------------- */

	/** @param WP_REST_Request $r Request. */
	public function list_tasks( WP_REST_Request $r ) {
		$args = array(
			'business_ids' => $r['business_ids'],
			'type'         => $r['type'],
			'status'       => $r['status'],
			'search'       => $r['search'],
			'from'         => $r['from'],
			'to'           => $r['to'],
			'orderby'      => $r['orderby'],
			'order'        => $r['order'],
			'page'         => $r['page'],
			'per_page'     => $r['per_page'],
		);
		$counts = Task::counts( $args );
		$status = $args['status'] ?? '';
		if ( $status && isset( $counts[ $status ] ) ) {
			$total = (int) $counts[ $status ];
		} else {
			$total = (int) $counts['total'];
		}
		$per_page = max( 1, min( 500, (int) ( $args['per_page'] ?? 20 ) ) );
		$query    = Task::query( $args, false );
		$query['total'] = $total;
		$query['pages'] = (int) ceil( $total / $per_page );

		return $this->paginated( $query, array( 'counts' => $counts ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function create_task( WP_REST_Request $r ) {
		return $this->respond( Task::create( (array) $r->get_json_params() ), 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function get_task( WP_REST_Request $r ) {
		return $this->respond( Task::get( $r['id'] ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function update_task( WP_REST_Request $r ) {
		return $this->respond( Task::update( $r['id'], (array) $r->get_json_params() ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function delete_task( WP_REST_Request $r ) {
		$raw = Task::raw( $r['id'] );
		return $this->respond( $raw && Task::delete( $r['id'] ) ? array( 'deleted' => true, 'task' => $raw ) : null );
	}

	/** @param WP_REST_Request $r Request. */
	public function restore_task( WP_REST_Request $r ) {
		return $this->respond( Task::restore( (array) $r['task'] ), 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function set_task_status( WP_REST_Request $r ) {
		return $this->respond( Task::update( $r['id'], array( 'status' => $r['status'] ) ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function set_task_date( WP_REST_Request $r ) {
		return $this->respond( Task::update( $r['id'], array( 'due_date' => $r['due_date'] ) ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function bulk_tasks( WP_REST_Request $r ) {
		$done = 0;
		foreach ( $r['ids'] as $task_id ) {
			$res = 'delete' === $r['action'] ? Task::delete( $task_id ) : Task::update( $task_id, array( 'status' => $r['action'] ) );
			if ( $res && ! is_wp_error( $res ) ) {
				++$done;
			}
		}
		return $this->respond( array( 'affected' => $done ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function calendar_events( WP_REST_Request $r ) {
		return $this->respond( Calendar::events( $r['start'], $r['end'], (array) $r['business_ids'] ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function dashboard( WP_REST_Request $r ) {
		return $this->respond( Dashboard::data() );
	}

	/* --------------------------- Task Types --------------------------- */

	/** @param WP_REST_Request $r Request. */
	public function list_task_types( WP_REST_Request $r ) {
		$detailed = $r->get_param( 'detailed' );
		if ( $detailed ) {
			return $this->respond( Task::types_detailed() );
		}
		return $this->respond( Task::types() );
	}

	/** @param WP_REST_Request $r Request. */
	public function create_task_type( WP_REST_Request $r ) {
		$params = (array) $r->get_json_params();
		$label  = $params['label'] ?? '';
		$key    = $params['key'] ?? '';
		return $this->respond( Task::add_type( $label, $key ), 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function update_task_type( WP_REST_Request $r ) {
		$key    = $r['key'];
		$params = (array) $r->get_json_params();
		$label  = $params['label'] ?? '';
		return $this->respond( Task::update_type( $key, $label ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function delete_task_type( WP_REST_Request $r ) {
		$key   = $r['key'];
		$force = (bool) $r->get_param( 'force' );
		$res   = Task::delete_type( $key, $force );
		if ( is_wp_error( $res ) ) {
			return $this->respond( $res );
		}
		return $this->respond( array( 'deleted' => true, 'key' => $key ) );
	}

	/* --------------------------- Reports --------------------------- */

	/** @param WP_REST_Request $r Request. */
	public function list_reports( WP_REST_Request $r ) {
		return $this->paginated(
			Report::query(
				array(
					'business_id' => $r['business_id'],
					'jmonth'      => $r['jmonth'],
					'from'        => $r['from'],
					'to'          => $r['to'],
					'page'        => $r['page'],
					'per_page'    => $r['per_page'],
				)
			)
		);
	}

	/** @param WP_REST_Request $r Request. */
	public function preview_report( WP_REST_Request $r ) {
		$period = Report::resolve_period( $r->get_params() );
		if ( is_wp_error( $period ) ) {
			return $period;
		}
		list( $type, $start, $end ) = $period;
		return $this->respond(
			array(
				'start'         => $start,
				'end'           => $end,
				'count'         => Task::count_in_range( absint( $r['business_id'] ), $start, $end ),
				'default_title' => Report::default_title( $type, $start, $end ),
			)
		);
	}

	/**
	 * Strip server-only fields from a report response.
	 *
	 * @param mixed $report Report or error.
	 * @return mixed
	 */
	private function public_report( $report ) {
		if ( is_array( $report ) && isset( $report['snapshot']['branding']['logo_path'] ) ) {
			unset( $report['snapshot']['branding']['logo_path'] );
		}
		if ( is_array( $report ) && ! empty( $report['id'] ) ) {
			$report['download_url'] = Admin\Admin_Pages::download_url( $report['id'], $report['version_no'] );
		}
		return $report;
	}

	/** @param WP_REST_Request $r Request. */
	public function create_report( WP_REST_Request $r ) {
		return $this->respond( $this->public_report( Report::create( (array) $r->get_json_params() ) ), 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function get_report( WP_REST_Request $r ) {
		return $this->respond( $this->public_report( Report::get( $r['id'], $r['version'] ? (int) $r['version'] : null ) ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function delete_report( WP_REST_Request $r ) {
		return $this->respond( Report::delete( $r['id'] ) ? array( 'deleted' => true ) : null );
	}

	/** @param WP_REST_Request $r Request. */
	public function update_report_summary( WP_REST_Request $r ) {
		$p = (array) $r->get_json_params();
		return $this->respond( $this->public_report( Report::update_summary( $r['id'], $p['summary'] ?? '', $p['title'] ?? null ) ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function regenerate_report( WP_REST_Request $r ) {
		return $this->respond( $this->public_report( Report::regenerate( $r['id'] ) ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function regenerate_pdf( WP_REST_Request $r ) {
		$res = Report::generate_pdf( $r['id'] );
		return $this->respond( is_wp_error( $res ) ? $res : $this->public_report( Report::get( $r['id'] ) ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function test_telegram_connection( WP_REST_Request $r ) {
		return $this->respond( Telegram_Client::test_connection( (array) $r->get_json_params() ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function send_telegram_test_message( WP_REST_Request $r ) {
		return $this->respond( Telegram_Client::send_test_message( (array) $r->get_json_params() ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function get_telegram_recent_chats( WP_REST_Request $r ) {
		return $this->respond( Telegram_Client::get_recent_chats() );
	}

	/** @param WP_REST_Request $r Request. */
	public function run_telegram_daily_check( WP_REST_Request $r ) {
		return $this->respond( Telegram_Client::run_daily_pre_publish_notifications() );
	}

	/** @param WP_REST_Request $r Request. */
	public function send_business_telegram_preview( WP_REST_Request $r ) {
		$params      = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$biz_id      = Article_Generator::resolve_business_id( absint( $r['id'] ), $params );
		$article_key = sanitize_key( $params['article_key'] ?? '' );
		$task_id     = absint( $params['task_id'] ?? 0 );
		$force       = ! empty( $params['force'] );
		return $this->respond( Telegram_Client::send_article_preview( $biz_id, $article_key, $task_id, $force ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function send_task_telegram_preview( WP_REST_Request $r ) {
		$task_id = absint( $r['id'] );
		$task    = Task::get( $task_id );
		if ( ! $task ) {
			return $this->respond( new \WP_Error( 'seopm_task_not_found', __( 'تسک یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) ) );
		}
		$biz_id = absint( $task['business_id'] ?? 0 );
		return $this->respond( Telegram_Client::send_article_preview( $biz_id, '', $task_id, true ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function submit_public_review( WP_REST_Request $r ) {
		return $this->respond( Article_Preview::submit_feedback( (array) $r->get_json_params() ) );
	}

	/* ------------------------- Notes ------------------------- */

	/** @param WP_REST_Request $r Request. */
	public function list_notes( WP_REST_Request $r ) {
		$args = array(
			'business_id' => $r->get_param( 'business_id' ),
			'is_pinned'   => $r->get_param( 'is_pinned' ),
			'color'       => $r->get_param( 'color' ),
			'search'      => $r->get_param( 'search' ),
		);
		$notes = Note::all( $args );
		return $this->respond(
			array(
				'notes'  => $notes,
				'total'  => count( $notes ),
				'colors' => Note::colors(),
			)
		);
	}

	/** @param WP_REST_Request $r Request. */
	public function get_note( WP_REST_Request $r ) {
		$note = Note::get( (int) $r['id'] );
		if ( ! $note ) {
			return new \WP_Error( 'seopm_not_found', __( 'یادداشت یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		return $this->respond( $note );
	}

	/** @param WP_REST_Request $r Request. */
	public function create_note( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$note   = Note::create( $params );
		if ( is_wp_error( $note ) ) {
			return $note;
		}
		return $this->respond( $note, 201 );
	}

	/** @param WP_REST_Request $r Request. */
	public function update_note( WP_REST_Request $r ) {
		$params = array_merge( (array) $r->get_params(), (array) $r->get_json_params() );
		$note   = Note::update( (int) $r['id'], $params );
		if ( is_wp_error( $note ) ) {
			return $note;
		}
		return $this->respond( $note );
	}

	/** @param WP_REST_Request $r Request. */
	public function delete_note( WP_REST_Request $r ) {
		$res = Note::delete( (int) $r['id'] );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return $this->respond( array( 'success' => true ) );
	}

	/** @param WP_REST_Request $r Request. */
	public function toggle_pin_note( WP_REST_Request $r ) {
		$note = Note::toggle_pin( (int) $r['id'] );
		if ( is_wp_error( $note ) ) {
			return $note;
		}
		return $this->respond( $note );
	}
}

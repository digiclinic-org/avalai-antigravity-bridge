<?php
/**
 * Content Strategy & Article Suggester (Topic Cluster Architecture).
 *
 * Independently examines every keyword, generates evaluated candidate cluster articles,
 * scores each candidate using multi-criteria SEO opportunity scoring,
 * enforces exact proportional weight distribution (D'Hondt method),
 * and selects the top 10 highest-scoring articles across the site.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Content_Suggester class.
 */
class Content_Suggester {

	const TRANSIENT_PREFIX        = 'seopm_suggestions_';
	const TRANSIENT_EXPIRATION    = 43200; // 12 hours.
	const SCHEDULED_OPTION_PREFIX = 'seopm_scheduled_sugs_';

	const INTENT_INFORMATIONAL = 'Informational';
	const INTENT_COMMERCIAL    = 'Commercial Investigation';
	const INTENT_TRANSACTIONAL = 'Transactional';
	const INTENT_NAVIGATIONAL  = 'Navigational';

	/**
	 * Target number of high-quality suggested cluster articles per business batch.
	 */
	const TARGET_SUGGESTIONS = 10;

	/**
	 * Minimum target keywords required before suggestions can be generated.
	 */
	const MIN_REQUIRED_KEYWORDS = 5;

	/**
	 * Verify whether a business has fulfilled mandatory prerequisites for article suggestions:
	 * 1. Registered and valid Sitemap URL in business settings.
	 * 2. At least 5 target keywords registered with prioritization.
	 *
	 * @param int $business_id Business ID.
	 * @return array{ready:bool,has_sitemap:bool,sitemap_url:string,keyword_count:int,has_min_keywords:bool,min_keywords:int,missing:array,message:string}
	 */
	public static function check_suggestions_prerequisites( $business_id ) {
		$business_id = absint( $business_id );
		$biz         = $business_id ? Business::get( $business_id, true ) : null;
		if ( ! $biz ) {
			return array(
				'ready'            => false,
				'has_sitemap'      => false,
				'sitemap_url'      => '',
				'keyword_count'    => 0,
				'has_min_keywords' => false,
				'min_keywords'     => self::MIN_REQUIRED_KEYWORDS,
				'missing'          => array( 'business' ),
				'message'          => __( 'کسب‌وکار مورد نظر یافت نشد.', 'seo-project-manager' ),
			);
		}

		$raw_sitemap = trim( (string) ( $biz['sitemap_url'] ?? '' ) );
		$has_sitemap = ( '' !== $raw_sitemap && (bool) filter_var( $raw_sitemap, FILTER_VALIDATE_URL ) );
		$keywords    = is_array( $biz['keywords'] ?? null ) ? $biz['keywords'] : array();
		$kw_count    = count( $keywords );
		$has_kw      = ( $kw_count >= self::MIN_REQUIRED_KEYWORDS );

		$missing = array();
		if ( ! $has_sitemap ) {
			$missing[] = 'sitemap';
		}
		if ( ! $has_kw ) {
			$missing[] = 'keywords';
		}

		$ready = empty( $missing );
		$msg   = '';
		if ( ! $ready ) {
			if ( ! $has_sitemap && ! $has_kw ) {
				$msg = sprintf(
					/* translators: 1: keyword count, 2: minimum required keywords */
					__( 'ارائه مقالات پیشنهادی مشروط به ثبت «آدرس نقشه سایت (Sitemap URL)» و «حداقل %2$d کلمه کلیدی هدف» در تنظیمات کسب‌وکار است (هم‌اکنون %1$d کلمه کلیدی ثبت شده و آدرس نقشه سایت خالی است).', 'seo-project-manager' ),
					$kw_count,
					self::MIN_REQUIRED_KEYWORDS
				);
			} elseif ( ! $has_sitemap ) {
				$msg = __( 'برای کشف خلاء‌های محتوایی و جلوگیری قطعی از همنوع‌خواری (Cannibalization)، ثبت «آدرس نقشه سایت (Sitemap URL)» در تنظیمات این کسب‌وکار الزامی است.', 'seo-project-manager' );
			} else {
				$msg = sprintf(
					/* translators: 1: keyword count, 2: remaining keywords needed, 3: minimum required keywords */
					__( 'برای توزیع متناسب خوشه‌های محتوایی، ثبت حداقل %3$d کلمه کلیدی هدف در کسب‌وکار الزامی است (هم‌اکنون %1$d کلمه ثبت شده؛ لطفاً حداقل %2$d کلمه کلیدی دیگر اضافه کنید).', 'seo-project-manager' ),
					$kw_count,
					max( 1, self::MIN_REQUIRED_KEYWORDS - $kw_count ),
					self::MIN_REQUIRED_KEYWORDS
				);
			}
		}

		return array(
			'ready'            => $ready,
			'has_sitemap'      => $has_sitemap,
			'sitemap_url'      => $raw_sitemap,
			'keyword_count'    => $kw_count,
			'has_min_keywords' => $has_kw,
			'min_keywords'     => self::MIN_REQUIRED_KEYWORDS,
			'missing'          => $missing,
			'message'          => $msg,
		);
	}

	/**
	 * Get suggested articles for a business with caching.
	 *
	 * Automatically filters out any suggestions that have been scheduled in the calendar
	 * and replenishes from the bottom so the list stays fresh (up to 20 unscheduled items).
	 *
	 * @param int  $business_id Business ID.
	 * @param bool $refresh     Force refresh.
	 * @param bool $force_ai    Force AI generation.
	 * @return array
	 */
	public static function get_suggestions( $business_id, $refresh = false, $force_ai = false ) {
		$business_id = Article_Generator::resolve_business_id( $business_id );
		$cache_key   = self::TRANSIENT_PREFIX . $business_id;

		$prereq = self::check_suggestions_prerequisites( $business_id );
		if ( ! $prereq['ready'] ) {
			self::clear_cache( $business_id );
			$biz = Business::get( $business_id, false );
			return array(
				'business_id'        => $business_id,
				'business'           => $biz ? array(
					'id'          => $biz['id'],
					'name'        => $biz['name'],
					'color'       => $biz['color'],
					'sitemap_url' => $biz['sitemap_url'] ?? '',
				) : array(),
				'prerequisites'      => $prereq,
				'suggestions'        => array(),
				'total_suggestions'  => 0,
				'ai_enabled'         => false,
				'ai_generated'       => false,
				'prompts_configured' => self::prompts_status( $business_id ),
				'stats'              => array(
					'total_keywords'      => $prereq['keyword_count'],
					'total_posts_checked' => 0,
					'total_pages_checked' => 0,
					'sitemap_status'      => $prereq['has_sitemap'] ? 'valid' : 'missing',
				),
			);
		}

		if ( ! $refresh && ! $force_ai ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && ! empty( $cached['suggestions'] ) ) {
				$cached['suggestions']        = self::hydrate_suggestions_state( $business_id, $cached['suggestions'] );
				$cached                       = self::prune_and_replenish_cached( $business_id, $cached, false );
				$cached['prompts_configured'] = self::prompts_status( $business_id );
				$cached['prerequisites']      = $prereq;
				return $cached;
			}
		}

		$data = self::generate_suggestions( $business_id, $force_ai );
		$data['prerequisites'] = $prereq;
		if ( ! empty( $data['suggestions'] ) ) {
			$data['suggestions']        = self::hydrate_suggestions_state( $business_id, $data['suggestions'] );
			$data['prompts_configured'] = self::prompts_status( $business_id );
			set_transient( $cache_key, $data, self::TRANSIENT_EXPIRATION );
		}
		return $data;
	}

	/**
	 * Retrieve remembered scheduled/dismissed suggestion titles for a business.
	 *
	 * @param int $business_id Business ID.
	 * @return array<string>
	 */
	private static function get_scheduled_titles( $business_id ) {
		$saved = get_option( self::SCHEDULED_OPTION_PREFIX . absint( $business_id ), array() );
		return is_array( $saved ) ? array_values( array_filter( array_map( 'strval', $saved ) ) ) : array();
	}

	/**
	 * Remember a scheduled suggestion title so it does not reappear in the suggestions list.
	 *
	 * @param int    $business_id Business ID.
	 * @param string $title       Article title.
	 */
	private static function remember_scheduled_title( $business_id, $title ) {
		$business_id = absint( $business_id );
		$title       = trim( sanitize_text_field( (string) $title ) );
		if ( ! $business_id || '' === $title ) {
			return;
		}
		$list = self::get_scheduled_titles( $business_id );
		foreach ( $list as $existing ) {
			if ( self::is_similar_title( $existing, $title ) ) {
				return;
			}
		}
		$list[] = $title;
		if ( count( $list ) > 250 ) {
			$list = array_slice( $list, -250 );
		}
		update_option( self::SCHEDULED_OPTION_PREFIX . $business_id, $list, false );
	}

	/**
	 * Collect all excluded titles (existing calendar tasks + remembered scheduled titles).
	 *
	 * @param int   $business_id    Business ID.
	 * @param array $existing_tasks Optional preloaded tasks.
	 * @return array<string>
	 */
	private static function get_all_scheduled_titles( $business_id, ?array $existing_tasks = null ) {
		if ( null === $existing_tasks ) {
			$existing_tasks = self::get_existing_tasks( $business_id );
		}
		$titles = self::get_scheduled_titles( $business_id );
		foreach ( $existing_tasks as $t ) {
			if ( ! empty( $t['title'] ) ) {
				$titles[] = (string) $t['title'];
			}
		}
		return array_values( array_unique( array_filter( $titles ) ) );
	}

	/**
	 * Check whether a candidate title matches any excluded title or cannibalizes existing site content.
	 *
	 * @param string $title           Title to test.
	 * @param array  $excluded_titles List of titles to avoid.
	 * @param array  $posts           Crawled posts from sitemap.
	 * @param array  $pages           Crawled pages from sitemap.
	 * @param string $url_slug        Candidate slug.
	 * @return bool
	 */
	public static function is_title_excluded( $title, array $excluded_titles, array $posts = array(), array $pages = array(), $url_slug = '' ) {
		$title = trim( (string) $title );
		if ( '' === $title ) {
			return true;
		}
		foreach ( $excluded_titles as $ex ) {
			if ( '' !== trim( (string) $ex ) && self::is_similar_title( $title, (string) $ex ) ) {
				return true;
			}
		}

		// Cannibalization check against published site pages & posts.
		if ( ! empty( $posts ) || ! empty( $pages ) ) {
			$cannibal = self::detect_title_cannibalization( $title, $posts, $pages, $url_slug );
			if ( ! empty( $cannibal['conflict'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Deep semantic anti-cannibalization gatekeeper.
	 *
	 * Detects whether a candidate article title has semantic, pathology, or keyword overlap
	 * with existing pages/articles already published on the site.
	 *
	 * @param string $title    Candidate title.
	 * @param array  $posts    Crawled posts.
	 * @param array  $pages    Crawled pages.
	 * @param string $url_slug Candidate URL slug.
	 * @return array{conflict:bool,matched_title:string,matched_url:string,reason:string}
	 */
	public static function detect_title_cannibalization( $title, array $posts, array $pages = array(), $url_slug = '' ) {
		$title = trim( (string) $title );
		if ( '' === $title ) {
			return array(
				'conflict'      => false,
				'matched_title' => '',
				'matched_url'   => '',
				'reason'        => '',
			);
		}

		$body_patterns = array(
			'knee'      => '/(زانو|knee)/ui',
			'back'      => '/(کمر|ستون[\s\-‌]*فقرات|back|spine|lumbar)/ui',
			'neck'      => '/(گردن|مهره[\s\-‌]*گردن|neck|cervical)/ui',
			'hip'       => '/(لگن|ران|مفصل[\s\-‌]*ران|hip|pelvis)/ui',
			'shoulder'  => '/(شانه|کتف|shoulder)/ui',
			'arm_elbow' => '/(آرنج|دست|بازو|arm|elbow)/ui',
			'leg_foot'  => '/(پا|ساق|مچ[\s\-‌]*پا|leg|foot|ankle)/ui',
		);

		$pathology_patterns = array(
			'knee_sounds'        => '/(تق[\s\-‌]*تق|خرچ[\s\-‌]*خرچ|صدا[\s\-‌]*دادن|صدای|popping|clicking|crepitus|clicking\-popping)/ui',
			'knee_instability'   => '/(خالی[\s\-‌]*کردن|ناپایدار|بی[\s\-‌]*ثباتی|buckling|giving[\s\-‌]*way)/ui',
			'stairs_activity'    => '/(پله|stairs|climbing)/ui',
			'joint_replacement'  => '/(تعویض[\s\-‌]*مفصل|پروتز|آرتروپلاستی|replacement|arthroplasty)/ui',
			'bursitis_swelling'  => '/(بورسیت|ورم|تورم|آب[\s\-‌]*آوردن|bursitis|effusion|swelling)/ui',
			'ligament_meniscus'  => '/(رباط|صلیبی|منیسک|مینیسک|acl|meniscus|cruciate)/ui',
			'disc_herniation'    => '/(دیسک|فتق[\s\-‌]*دیسک|سیاتیک|sciatica|herniation|lumbar[\s\-‌]*disc)/ui',
			'stroke'             => '/(سکته|سکته[\s\-‌]*مغزی|stroke|hemiplegia)/ui',
			'parkinson'          => '/(پارکینسون|parkinson)/ui',
			'high_power_laser'   => '/(لیزر|laser)/ui',
			'walker_walking'     => '/(واکر|walker)/ui',
			'elderly_stiffness'  => '/(خشک[\s\-‌]*شدن|سفتی[\s\-‌]*پا|stiffness)/ui',
			'respiratory_covid'  => '/(تنفسی|کرونا|covid|breathing)/ui',
			'ms_balance'         => '/(ام[\s\-‌]*اس|ام‌اس|multiple[\s\-‌]*sclerosis)/ui',
			'frozen_shoulder'    => '/(شانه[\s\-‌]*منجمد|کپسولیت|frozen[\s\-‌]*shoulder)/ui',
			'elbow_contracture'  => '/(آرنج|صاف[\s\-‌]*نشدن|elbow)/ui',
		);

		$cand_text   = mb_strtolower( $title . ' ' . (string) $url_slug );
		$cand_bodies = array();
		foreach ( $body_patterns as $b_key => $b_pat ) {
			if ( preg_match( $b_pat, $cand_text ) ) {
				$cand_bodies[ $b_key ] = true;
			}
		}

		$cand_paths = array();
		foreach ( $pathology_patterns as $p_key => $p_pat ) {
			if ( preg_match( $p_pat, $cand_text ) ) {
				$cand_paths[ $p_key ] = true;
			}
		}

		$all_items = array_merge( $posts, $pages );
		foreach ( $all_items as $item ) {
			$item_title = trim( (string) ( $item['title'] ?? '' ) );
			$item_url   = trim( (string) ( $item['url'] ?? '' ) );
			if ( '' === $item_title && '' === $item_url ) {
				continue;
			}

			// Direct title similarity check (exact or substring).
			if ( self::is_similar_title( $title, $item_title ) ) {
				return array(
					'conflict'      => true,
					'matched_title' => $item_title,
					'matched_url'   => $item_url,
					'reason'        => 'تشابه عنوان مستقیم با مقاله موجود در نقشه سایت',
				);
			}

			$item_text   = mb_strtolower( $item_title . ' ' . $item_url );
			$item_bodies = array();
			foreach ( $body_patterns as $b_key => $b_pat ) {
				if ( preg_match( $b_pat, $item_text ) ) {
					$item_bodies[ $b_key ] = true;
				}
			}

			$item_paths = array();
			foreach ( $pathology_patterns as $p_key => $p_pat ) {
				if ( preg_match( $p_pat, $item_text ) ) {
					$item_paths[ $p_key ] = true;
				}
			}

			$shared_bodies = array_intersect_key( $cand_bodies, $item_bodies );
			$shared_paths  = array_intersect_key( $cand_paths, $item_paths );

			// Rule 1: Shared pathology on the same anatomical area (e.g. knee sounds/popping on knee).
			if ( ! empty( $shared_paths ) && ! empty( $shared_bodies ) ) {
				$p_names = implode( '، ', array_keys( $shared_paths ) );
				$b_names = implode( '، ', array_keys( $shared_bodies ) );
				return array(
					'conflict'      => true,
					'matched_title' => $item_title,
					'matched_url'   => $item_url,
					'reason'        => 'هم‌پوشانی پاتولوژی (' . $p_names . ') در اندام هدف (' . $b_names . ') با صفحه موجود در سایت',
				);
			}

			// Rule 2: Shared systemic condition/pathology (stroke, parkinson, laser, etc.).
			$systemic   = array(
				'stroke'            => true,
				'parkinson'         => true,
				'high_power_laser'  => true,
				'respiratory_covid' => true,
				'ms_balance'        => true,
			);
			$shared_sys = array_intersect_key( $shared_paths, $systemic );
			if ( ! empty( $shared_sys ) ) {
				return array(
					'conflict'      => true,
					'matched_title' => $item_title,
					'matched_url'   => $item_url,
					'reason'        => 'هم‌پوشانی بیماری تخصصی (' . implode( '، ', array_keys( $shared_sys ) ) . ') با مقاله موجود در سایت',
				);
			}
		}

		return array(
			'conflict'      => false,
			'matched_title' => '',
			'matched_url'   => '',
			'reason'        => '',
		);
	}

	/**
	 * Check whether per-business custom prompts are configured.
	 *
	 * @param int $business_id Business ID.
	 * @return array{article_writing:bool,html_conversion:bool,image_generation:bool}
	 */
	private static function prompts_status( $business_id ) {
		$biz = Business::get( $business_id, false );
		return array(
			'suggestions_brief'      => ! empty( trim( (string) ( $biz['prompt_suggestions_brief'] ?? '' ) ) ),
			'article_writing'        => ! empty( trim( (string) ( $biz['prompt_article_writing'] ?? '' ) ) ),
			'html_conversion'        => ! empty( trim( (string) ( $biz['prompt_html_conversion'] ?? '' ) ) ),
			'image_generation'       => ! empty( trim( (string) ( $biz['prompt_image_generation'] ?? '' ) ) ),
			'sources_external_links' => ! empty( trim( (string) ( $biz['prompt_sources_external_links'] ?? '' ) ) ),
			'internal_links'         => ! empty( trim( (string) ( $biz['prompt_internal_links'] ?? '' ) ) ),
		);
	}

	/**
	 * Clean an article slug by stripping /blog/ prefix and outer slashes.
	 *
	 * @param string $slug Raw slug.
	 * @return string
	 */
	public static function clean_slug( $slug ) {
		$slug = trim( (string) $slug );
		$slug = preg_replace( '#^/?blog/#i', '', $slug );
		$slug = trim( $slug, '/' );
		return $slug;
	}

	/**
	 * Clear suggestions cache.
	 *
	 * @param int $business_id Business ID.
	 */
	public static function clear_cache( $business_id ) {
		delete_transient( self::TRANSIENT_PREFIX . absint( $business_id ) );
	}

	/**
	 * Generate suggestions for a business.
	 *
	 * 1. Checks if AI Provider (Gemini / ChatGPT / DeepSeek / Claude) is active and configured.
	 * 2. If active, runs AI generation with comprehensive SEO Prompt.
	 * 3. Independently analyzes every keyword against sitemap and posts.
	 * 4. Generates candidate cluster articles across multiple strategic angles.
	 * 5. Scores every candidate with multi-criteria SEO opportunity score (0 - 100).
	 * 6. Allocates 10 slots using D'Hondt method ensuring exact proportional weight distribution.
	 * 7. Selects the top-scoring candidates per keyword and ranks the final 10 by score DESC.
	 *
	 * @param int  $business_id Business ID.
	 * @param bool $force_ai    Force AI generation.
	 * @return array
	 */
	public static function generate_suggestions( $business_id, $force_ai = false ) {
		$biz = Business::get( $business_id );
		if ( ! $biz ) {
			return array(
				'business_id'       => $business_id,
				'suggestions'       => array(),
				'total_suggestions' => 0,
				'stats'             => array(),
			);
		}

		$prereq = self::check_suggestions_prerequisites( $business_id );
		if ( ! $prereq['ready'] ) {
			return array(
				'business_id'        => $business_id,
				'business'           => array(
					'id'          => $biz['id'],
					'name'        => $biz['name'],
					'color'       => $biz['color'],
					'sitemap_url' => $biz['sitemap_url'] ?? '',
				),
				'prerequisites'      => $prereq,
				'suggestions'        => array(),
				'total_suggestions'  => 0,
				'ai_enabled'         => false,
				'ai_generated'       => false,
				'prompts_configured' => self::prompts_status( $business_id ),
				'stats'              => array(
					'total_keywords'      => $prereq['keyword_count'],
					'total_posts_checked' => 0,
					'total_pages_checked' => 0,
					'sitemap_status'      => $prereq['has_sitemap'] ? 'valid' : 'missing',
				),
			);
		}

		$keywords = $biz['keywords'] ?? array();

		// Crawl / fetch existing site content (posts & pages) via Site_Crawler (refreshed if force_ai is requested).
		$report = Site_Crawler::get_report( $business_id, $force_ai );
		$posts  = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['posts'] ) ) ? $report['posts'] : array();
		$pages  = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['pages'] ) ) ? $report['pages'] : array();

		// Step 1: D'Hondt proportional quota allocation for 10 slots based on keyword weights.
		// Guarantees weight 10 gets 2x the slots of weight 5 without largest-remainder paradoxes.
		$quotas = self::allocate_dhondt( $keywords, self::TARGET_SUGGESTIONS );

		// Step 2: Load existing task titles + remembered scheduled titles to exclude already-scheduled articles.
		$existing_tasks   = self::get_existing_tasks( $business_id );
		$scheduled_titles = self::get_all_scheduled_titles( $business_id, $existing_tasks );

		$ai_settings  = Settings::all();
		$active_ai    = $ai_settings['ai_active_provider'] ?? 'none';
		$ai_providers = AI_Client::get_providers();
		$has_ai_key   = 'none' !== $active_ai && ! empty( $ai_settings[ $active_ai . '_api_key' ] );

		$ai_generated  = false;
		$selected_pool = array();

		// Step 3: If AI provider is active and has an API key, run AI Generation via LLM!
		if ( $has_ai_key ) {
			$ai_suggestions = self::generate_with_ai( $business_id, $biz, $keywords, $posts, $pages, $quotas, $scheduled_titles );
			if ( is_array( $ai_suggestions ) && ! empty( $ai_suggestions ) ) {
				$ai_generated = true;
				foreach ( $ai_suggestions as $asug ) {
					$norm = self::normalize_ai_suggestion( $asug, $keywords, $pages, $posts, $biz, $existing_tasks );
					if ( $norm && ! self::is_title_excluded( $norm['best_title'], $scheduled_titles, $posts, $pages, $norm['url_slug'] ?? '' ) ) {
						$selected_pool[] = $norm;
					}
				}
			}
		}

		// Step 4: If AI didn't run or returned fewer than 10 items, run/fallback to Heuristic Engine!
		$all_candidates_count = count( $keywords ) * 3;
		if ( count( $selected_pool ) < self::TARGET_SUGGESTIONS ) {
			$all_candidates_count = 0;
			$candidates_by_kw     = array();

			foreach ( $keywords as $kw ) {
				$kw_id     = absint( $kw['id'] );
				$kw_text   = trim( $kw['keyword'] );
				$pillar    = self::find_target_pillar( $kw_text, $pages, $biz );
				$closest   = self::find_closest_content( $kw_text, $posts, $pages );

				$raw_candidates = self::generate_candidates_for_keyword( $kw, $pillar, $closest, $posts, $pages, $existing_tasks, $biz );
				$candidates     = array();
				foreach ( $raw_candidates as $rc ) {
					if ( ! self::is_title_excluded( $rc['best_title'], $scheduled_titles, $posts, $pages, $rc['url_slug'] ?? '' ) ) {
						$candidates[] = $rc;
					}
				}
				$all_candidates_count += count( $candidates );

				usort(
					$candidates,
					function ( $a, $b ) {
						return $b['score'] <=> $a['score'];
					}
				);

				$candidates_by_kw[ $kw_id ] = $candidates;
			}

			if ( ! $ai_generated ) {
				// Pure heuristic mode: select top-scoring candidates according to quotas
				$unselected_pool = array();
				foreach ( $keywords as $kw ) {
					$kw_id = absint( $kw['id'] );
					$quota = $quotas[ $kw_id ] ?? 0;
					$cands = $candidates_by_kw[ $kw_id ] ?? array();

					for ( $i = 0; $i < count( $cands ); $i++ ) {
						if ( $i < $quota ) {
							$selected_pool[] = $cands[ $i ];
						} else {
							$unselected_pool[] = $cands[ $i ];
						}
					}
				}

				if ( count( $selected_pool ) < self::TARGET_SUGGESTIONS && ! empty( $unselected_pool ) ) {
					usort(
						$unselected_pool,
						function ( $a, $b ) {
							return $b['score'] <=> $a['score'];
						}
					);
					$needed = self::TARGET_SUGGESTIONS - count( $selected_pool );
					for ( $j = 0; $j < $needed && $j < count( $unselected_pool ); $j++ ) {
						$selected_pool[] = $unselected_pool[ $j ];
					}
				}
			} else {
				// Hybrid mode: AI produced partial, backfill remaining to reach exactly 10
				$added_titles = array();
				foreach ( $selected_pool as $sp ) {
					$added_titles[] = mb_strtolower( $sp['best_title'] );
				}
				foreach ( $keywords as $kw ) {
					$kw_id = absint( $kw['id'] );
					$cands = $candidates_by_kw[ $kw_id ] ?? array();
					foreach ( $cands as $cand ) {
						if ( ! in_array( mb_strtolower( $cand['best_title'] ), $added_titles, true ) ) {
							$selected_pool[] = $cand;
							$added_titles[]  = mb_strtolower( $cand['best_title'] );
							if ( count( $selected_pool ) >= self::TARGET_SUGGESTIONS ) {
								break 2;
							}
						}
					}
				}
			}

			// If still fewer than 10 (because many base candidates are already scheduled), synthesize fresh ones.
			$safety_guard = 0;
			while ( count( $selected_pool ) < self::TARGET_SUGGESTIONS && $safety_guard < 25 ) {
				$safety_guard++;
				$pool_titles = array_merge(
					$scheduled_titles,
					array_map(
						static function ( $sp ) {
							return (string) ( $sp['best_title'] ?? '' );
						},
						$selected_pool
					)
				);
				$extra = self::pick_heuristic_replacement( $biz, $keywords, $posts, $pages, $existing_tasks, $pool_titles, '' );
				if ( ! $extra ) {
					break;
				}
				$selected_pool[] = $extra;
			}
		}

		// Step 5: Final Global Ranking: sort selected 10 articles by SCORE DESC.
		usort(
			$selected_pool,
			function ( $a, $b ) {
				if ( $b['score'] === $a['score'] ) {
					return ( $b['weight'] ?? 5 ) <=> ( $a['weight'] ?? 5 );
				}
				return $b['score'] <=> $a['score'];
			}
		);

		// Assign final 1-10 row indices.
		foreach ( $selected_pool as $idx => &$item ) {
			$item['id'] = $idx + 1;
		}
		unset( $item );

		return array(
			'business_id'                => $business_id,
			'business'                   => array(
				'id'          => $biz['id'],
				'name'        => $biz['name'],
				'color'       => $biz['color'],
				'sitemap_url' => $biz['sitemap_url'] ?? '',
			),
			'prerequisites'              => $prereq,
			'generated_at'               => current_time( 'mysql' ),
			'total_suggestions'          => count( $selected_pool ),
			'total_keywords_analyzed'    => count( $keywords ),
			'total_candidates_evaluated' => $all_candidates_count,
			'ai_provider'                => $active_ai,
			'ai_provider_name'           => 'none' !== $active_ai ? ( $ai_providers[ $active_ai ]['name'] ?? $active_ai ) : 'موتور محلی تحلیل سئو',
			'ai_enabled'                 => $has_ai_key,
			'ai_generated'               => $ai_generated,
			'suggestions'                => $selected_pool,
			'stats'                      => array(
				'total_keywords'      => count( $keywords ),
				'total_posts_checked' => count( $posts ),
				'total_pages_checked' => count( $pages ),
				'candidates_scanned'  => $all_candidates_count,
				'ai_provider'         => $active_ai,
				'ai_generated'        => $ai_generated,
				'method'              => $ai_generated ? ( 'تحلیل و تولید زنده با هوش مصنوعی ' . ( $ai_providers[ $active_ai ]['short_name'] ?? $active_ai ) . ' + فرمول سئو' ) : 'D\'Hondt Weighted Proportional Quota + Multi-Criteria SEO Scoring',
				'source'              => ( ! is_wp_error( $report ) && is_array( $report ) && isset( $report['stats']['source'] ) ) ? $report['stats']['source'] : 'wp_rest',
			),
		);
	}

	/**
	 * Rank existing site content by semantic and keyword relevance across all target keywords.
	 *
	 * Ensures that historical articles directly related to the target keywords are always
	 * prioritized and fed to the AI context and anti-cannibalization checks, even in large sites
	 * with hundreds or thousands of crawled URLs.
	 *
	 * @param array $items    List of posts or pages.
	 * @param array $keywords List of target keywords.
	 * @param int   $limit    Maximum items to return.
	 * @return array
	 */
	public static function prioritize_content_for_keywords( array $items, array $keywords, $limit = 70 ) {
		if ( empty( $items ) || empty( $keywords ) ) {
			return array_slice( $items, 0, $limit );
		}

		// Prepare keyword tokens and stems
		$kw_terms = array();
		foreach ( $keywords as $kw ) {
			$raw = is_array( $kw ) ? ( $kw['keyword'] ?? '' ) : (string) $kw;
			$raw = trim( mb_strtolower( $raw ) );
			if ( '' === $raw ) {
				continue;
			}
			$kw_terms[] = $raw;
			$words      = preg_split( '/[\s\-_\/]+/u', $raw );
			foreach ( $words as $w ) {
				$w = trim( $w );
				if ( mb_strlen( $w ) >= 3 ) {
					$kw_terms[] = $w;
				}
			}
		}
		$kw_terms = array_values( array_unique( $kw_terms ) );

		$scored = array();
		foreach ( $items as $idx => $item ) {
			$title = mb_strtolower( (string) ( $item['title'] ?? '' ) );
			$url   = urldecode( mb_strtolower( (string) ( $item['url'] ?? '' ) ) );
			$score = 0;

			foreach ( $kw_terms as $term ) {
				if ( mb_strpos( $title, $term ) !== false ) {
					$score += ( mb_strlen( $term ) > 7 ? 25 : 10 );
				}
				if ( mb_strpos( $url, $term ) !== false ) {
					$score += ( mb_strlen( $term ) > 7 ? 15 : 5 );
				}
			}

			$scored[] = array(
				'score' => $score,
				'idx'   => $idx,
				'item'  => $item,
			);
		}

		usort(
			$scored,
			function ( $a, $b ) {
				if ( $b['score'] === $a['score'] ) {
					return $a['idx'] <=> $b['idx'];
				}
				return $b['score'] <=> $a['score'];
			}
		);

		$result = array();
		foreach ( array_slice( $scored, 0, $limit ) as $s ) {
			$result[] = $s['item'];
		}

		return $result;
	}

	/**
	 * Attempt to generate suggestions via configured AI Provider (Gemini, ChatGPT, DeepSeek, Claude).
	 *
	 * @param int   $business_id Business ID.
	 * @param array $biz         Business data.
	 * @param array $keywords    List of keywords.
	 * @param array $posts       Crawled posts.
	 * @param array $pages       Crawled pages.
	 * @param array $quotas      Allocated quotas.
	 * @return array|null List of suggestions on success, null on failure.
	 */
	public static function generate_with_ai( $business_id, array $biz, array $keywords, array $posts, array $pages, array $quotas, array $excluded_titles = array() ) {
		$settings  = Settings::all();
		$active_ai = $settings['ai_active_provider'] ?? 'none';
		if ( 'none' === $active_ai ) {
			return null;
		}

		$api_key = $settings[ $active_ai . '_api_key' ] ?? '';
		if ( empty( $api_key ) ) {
			return null;
		}

		$sitemap_url = trim( (string) ( $biz['sitemap_url'] ?? ( $biz['website_url'] ? trailingslashit( $biz['website_url'] ) . 'sitemap_index.xml' : '' ) ) );

		// Prepare prioritized existing content summary from sitemap & crawler (semantic keyword relevance).
		$ranked_pages = self::prioritize_content_for_keywords( $pages, $keywords, 40 );
		$page_summary = array();
		foreach ( $ranked_pages as $p ) {
			if ( ! empty( $p['title'] ) && ! empty( $p['url'] ) ) {
				$page_summary[] = '- ' . $p['title'] . ' | URL: ' . $p['url'];
			}
		}

		$ranked_posts = self::prioritize_content_for_keywords( $posts, $keywords, 70 );
		$post_summary = array();
		foreach ( $ranked_posts as $p ) {
			if ( ! empty( $p['title'] ) && ! empty( $p['url'] ) ) {
				$post_summary[] = '- ' . $p['title'] . ' | URL: ' . $p['url'];
			}
		}

		$excluded_block = '';
		if ( ! empty( $excluded_titles ) ) {
			$sample         = array_slice( $excluded_titles, -40 );
			$excluded_block = "\nمقالاتی که قبلاً در تقویم ثبت شده‌اند (هرگز این عناوین یا مشابه آن‌ها را پیشنهاد نده):\n- " . implode( "\n- ", $sample ) . "\n";
		}

		// Filter only keywords that have at least 1 quota slot
		$target_keywords = array();
		foreach ( $keywords as $kw ) {
			$qid = absint( $kw['id'] );
			$q   = $quotas[ $qid ] ?? 0;
			if ( $q > 0 ) {
				$target_keywords[] = array(
					'keyword'     => $kw['keyword'],
					'weight'      => $kw['weight'],
					'slots_count' => $q,
				);
			}
		}

		$system_prompt = 'تو یک متخصص ارشد SEO، استراتژیست محتوا و متخصص معماری اطلاعات وب‌سایت هستی. وظیفه تو طراحی استراتژی تولید محتوای مقالات کلاستر با هدف افزایش ترافیک ارگانیک، پوشش کامل موضوعات (Topical Authority) و جلوگیری از تولید محتوای تکراری و هم‌نوع‌خواری کلمات کلیدی (Keyword Cannibalization) است. خروجی را فقط و فقط به‌صورت یک آبجکت JSON معتبر و بدون هیچ مقدمه یا توضیح اضافی ارسال کن.';

		$prompt_suggestions = trim( (string) ( $biz['prompt_suggestions_brief'] ?? '' ) );
		if ( '' !== $prompt_suggestions ) {
			$prompt_suggestions = Business::expand_shortcodes( $prompt_suggestions, $biz );
			$system_prompt     .= "\n\n=== پرامپت و دستورالعمل اختصاصی این کسب‌وکار جهت تولید عناوین پیشنهادی و بریف محتوا ===\n" . $prompt_suggestions;
		}

		$biz_details = array();
		$biz_details[] = '- نام کسب‌وکار: ' . ( $biz['name'] ?? '' );
		$biz_details[] = '- آدرس سایت: ' . ( $biz['website_url'] ?? $biz['website'] ?? '' );
		$biz_details[] = '- آدرس نقشه سایت (Sitemap URL): ' . ( $sitemap_url ?: '—' );
		if ( ! empty( $biz['industry_services'] ) ) {
			$biz_details[] = '- حوزه فعالیت و خدمات یا محصولات اصلی: ' . $biz['industry_services'];
		}
		if ( ! empty( $biz['target_location'] ) ) {
			$biz_details[] = '- شهر یا کشور هدف (محدوده جغرافیایی): ' . $biz['target_location'];
		}
		if ( ! empty( $biz['focus_products_services'] ) ) {
			$biz_details[] = '- خدمات یا محصولاتی که اولویت تمرکز هستند: ' . $biz['focus_products_services'];
		}
		if ( ! empty( $biz['content_goals'] ) && is_array( $biz['content_goals'] ) ) {
			$goal_labels = array(
				'traffic_google'  => 'جذب ورودی ارگانیک از گوگل',
				'leads_calls'     => 'دریافت تماس، مشاوره یا درخواست خدمات (Lead Generation)',
				'sales'           => 'فروش مستقیم محصول یا خدمت',
				'brand_awareness' => 'افزایش آگاهی از برند و اعتبار تخصصی',
				'rank_support'    => 'حمایت از رتبه و قدرت سئو صفحات خدمات یا دسته‌بندی‌ها',
			);
			$active_goals = array();
			foreach ( $biz['content_goals'] as $gk ) {
				if ( isset( $goal_labels[ $gk ] ) ) {
					$active_goals[] = $goal_labels[ $gk ];
				}
			}
			if ( ! empty( $active_goals ) ) {
				$biz_details[] = '- اولویت‌ها و اهداف استراتژیک تولید محتوا: ' . implode( ' | ', $active_goals );
			}
		}
		if ( ! empty( $biz['target_audience'] ) ) {
			$biz_details[] = '- ویژگی‌های مخاطب هدف و دغدغه‌های آن‌ها: ' . $biz['target_audience'];
		}
		$biz_details[] = '- زبان محتوا: فارسی';
		$biz_details[] = '- بازار هدف: ایران';

		$user_prompt = "لطفاً برای وب‌سایت زیر، بر اساس کلمات کلیدی، سهمیه مشخص‌شده و با تحلیل کامل و دقیق نقشه سایت (Sitemap)، ۱۰ عنوان مقاله کلاستر استراتژیک با بریف سئو تولید کن.\n\n" .
			"اطلاعات وب‌سایت:\n" .
			implode( "\n", $biz_details ) . "\n\n" .
			"کلمات کلیدی هدف و تعداد مقالات مورد نیاز برای هر کلمه (مجموعاً ۱۰ مقاله با تمرکز عمیق و بالاترین کیفیت):\n" .
			wp_json_encode( $target_keywords, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . "\n\n" .
			"=== نقشه سایت و ساختار محتوایی موجود در وب‌سایت (Sitemap) ===\n" .
			( ! empty( $sitemap_url ) ? "آدرس نقشه سایت: {$sitemap_url}\n\n" : '' ) .
			( ! empty( $page_summary ) ? "صفحات لندینگ، پیلارها و خدمات اصلی استخراج‌شده از نقشه سایت:\n" . implode( "\n", $page_summary ) . "\n\n" : '' ) .
			( ! empty( $post_summary ) ? "مقالات و مطالب وبلاگ استخراج‌شده از نقشه سایت (مرتب‌شده بر اساس ارتباط موضوعی با کلمات کلیدی جهت جلوگیری از همنوع‌خواری):\n" . implode( "\n", $post_summary ) . "\n\n" : '' ) .
			$excluded_block . "\n" .
			( '' !== $prompt_suggestions ? "=== دستورالعمل اختصاصی کسب‌وکار برای تولید عناوین و بریف محتوا (اولویت اول و قطعی) ===\n{$prompt_suggestions}\n\n" : '' ) .
			"دستورالعمل‌های حیاتی تولید عناوین استراتژیک، هدف جستجو (Search Intent) و معماری تاپیک کلاستر:\n" .
			"۱. عنوان‌سازی واقعی و مبتنی بر قصد دقیق کاربر (Search Intent): از عناوین آکادمیک، کلیشه‌ای، دانشنامه‌ای یا مبهم مطلقاً خودداری کن. عناوین باید به سوالات واقعی بیماران/مشتریان، ابهامات قبل از سفارش خدمات، شفافیت هزینه و بیمه، زمان بهبودی، مقایسه روش‌های درمانی و نکات تصمیم‌گیری پاسخ دهند تا بیشترین ترافیک ارگانیک و نرخ کلیک (High CTR) را به همراه داشته باشند.\n" .
			"۲. ضد همنوع‌خواری ۱۰۰٪ (Zero Cannibalization): تمامی مقالات و صفحات موجود در نقشه سایت بالا را موشکافانه تحلیل کن. مطلقاً هیچ عنوانی نباید تکراری، هم‌پوشان یا رقیب مقالات و لندینگ‌های موجود در نقشه سایت باشد.\n" .
			"۳. عناوین کلاستر نه لندینگ: عناوین نباید عنوان لندینگ خدمات یا صفحه اصلی باشند؛ بلکه باید مقالات کلاستر کاربردی (بررسی علائم، آموزش، مراقبت‌ها، سوالات، اشتباهات رایج، راهنمای هزینه) باشند که به پیلار اصلی لینک می‌دهند.\n" .
			"۴. استراتژی لینک‌سازی به پیلار (Forward Link): فقط و فقط ۱ لینک متنی متمرکز در بدنه مقاله به پیلار (target_pillar_url) با primary_anchor یا انکر توصیفی مشخص کن؛ اکیداً از تکرار چندباره لینک به یک پیلار یکسان در متن مقاله خودداری کن تا قانون First Link رعایت شده و از اتلاف اعتبار پیج‌رنک جلوگیری گردد. در صورت نیاز تنها یک لینک در باکس CTA انتهایی پیشنهاد بده.\n" .
			"۵. راهنمای لینک معکوس از پیلار به کلاستر (Backward Link: reverse_link_guide): مشخص کن پس از انتشار این مقاله کلاستر، در کدام بخش از صفحه پیلار باید چه پاراگرافی با چه انکرتکستی اضافه شود تا به این مقاله کلاستر لینک بدهد و چرخه دوطرفه پیلار-کلاستر تکمیل گردد.\n" .
			"۶. پیشنهاد لینک هم‌خوشه (Inter-Cluster / sister_cluster_link): مشخص کن این مقاله کلاستر به کدام مقاله هم‌خوشه دیگر در سایت پیوند افقی داده شود تا مسیر خوانش کاربر و اعتبار خوشه‌ای تقویت شود.\n" .
			"۷. برای هر مقاله، ۳ عنوان جذاب فارسی و اسلاگ کوتاه انگلیسی بدون تداخل ارائه بده.\n" .
			"۸. خروجی باید یک شیء JSON با کلید \"suggestions\" شامل آرایه‌ای از اشیاء با ساختار زیر باشد:\n" .
			"{\n" .
			'  "suggestions": [\n' .
			"    {\n" .
			'      "keyword": "فیزیوتراپی در منزل",\n' .
			'      "weight": 10,\n' .
			'      "search_intent": "Commercial Investigation",\n' .
			'      "search_intent_fa": "بررسی تجاری",\n' .
			'      "user_core_need": "نیاز بیمار به دریافت خدمات فیزیوتراپی تخصصی در منزل",\n' .
			'      "best_title": "فیزیوتراپی در منزل برای چه بیمارانی ضروری است؟",\n' .
			'      "best_title_reason": "عنوان دقیق، متناسب با Search Intent و دارای بالاترین نرخ کلیک",\n' .
			'      "titles": ["عنوان ۱", "عنوان ۲", "عنوان ۳"],\n' .
			'      "url_slug": "home-physiotherapy-indications",\n' .
			'      "decision": "create_new",\n' .
			'      "decision_label": "تولید مقاله جدید توصیه می‌شود",\n' .
			'      "decision_reason": "عدم وجود مقاله رقیب در سایت و خلاء محتوایی کامل",\n' .
			'      "cannibalization_risk": "کم",\n' .
			'      "pillar": {\n' .
			'        "target_pillar_title": "خدمات فیزیوتراپی در منزل",\n' .
			'        "target_pillar_url": "https://tehranhomecare.org/services/physiotherapy/",\n' .
			'        "pillar_role": "لندینگ خدمات تجاری",\n' .
			'        "primary_anchor": "فیزیوتراپی در منزل",\n' .
			'        "secondary_anchors": ["فیزیوتراپیست در منزل", "خدمات فیزیوتراپی"],\n' .
			'        "placement_strategy": {\n' .
			'          "main_link": "لینک متنی اصلی در بدنه مقاله روی انکرتکست دقیق یا توصیفی.",\n' .
			'          "cta_link": "باکس دعوت به اقدام (CTA) در انتهای مقاله جهت تماس و ثبت درخواست خدمت."\n' .
			"        },\n" .
			'        "reverse_link_guide": "در صفحه پیلار خدمات، در بخش معرفی درمان‌ها یک پاراگراف کوتاه با انکر «راهنمای فیزیوتراپی بعد از تعویض مفصل» به این مقاله کلاستر لینک داده شود."\n' .
			"      },\n" .
			'      "sister_cluster_link": {\n' .
			'        "target_topic": "مراقبت‌های لازم بعد از فیزیوتراپی زانو در منزل",\n' .
			'        "anchor_text": "مراقبت‌های بعد از فیزیوتراپی",\n' .
			'        "rationale": "هدایت کاربر به مقاله مکمل جهت افزایش ماندگاری در سایت و تکمیل زنجیره راهنمایی بیمار."\n' .
			"      }\n" .
			"    }\n" .
			"  ]\n" .
			"}";

		$ai_res = AI_Client::generate( $user_prompt, $system_prompt, array( 'timeout' => 50 ) );
		if ( ! $ai_res['success'] || empty( $ai_res['text'] ) ) {
			return null;
		}

		$parsed = AI_Client::parse_json( $ai_res['text'] );
		if ( ! is_array( $parsed ) || empty( $parsed['suggestions'] ) || ! is_array( $parsed['suggestions'] ) ) {
			return null;
		}

		return $parsed['suggestions'];
	}

	/**
	 * Normalize and score an AI-generated suggestion.
	 *
	 * @param array $item           Raw AI suggestion item.
	 * @param array $keywords       List of business keywords.
	 * @param array $pages          Crawled pages.
	 * @param array $posts          Crawled posts.
	 * @param array $biz            Business data.
	 * @param array $existing_tasks Existing task titles.
	 * @return array|null
	 */
	public static function normalize_ai_suggestion( array $item, array $keywords, array $pages, array $posts, array $biz, array $existing_tasks ) {
		$kw_text = trim( $item['keyword'] ?? '' );
		if ( empty( $kw_text ) ) {
			return null;
		}

		// Find keyword weight
		$weight = 5;
		$kw_obj = null;
		foreach ( $keywords as $k ) {
			if ( mb_strtolower( trim( $k['keyword'] ) ) === mb_strtolower( $kw_text ) ) {
				$weight = absint( $k['weight'] ?? 5 );
				$kw_obj = $k;
				break;
			}
		}
		if ( ! $kw_obj ) {
			$kw_obj = array( 'keyword' => $kw_text, 'weight' => $weight );
		}

		$pillar  = ( ! empty( $item['pillar'] ) && is_array( $item['pillar'] ) && ! empty( $item['pillar']['target_pillar_title'] ) ) ? $item['pillar'] : self::find_target_pillar( $kw_text, $pages, $biz );
		$closest = self::find_closest_content( $kw_text, $posts, $pages );

		$titles = isset( $item['titles'] ) && is_array( $item['titles'] ) ? array_map( 'sanitize_text_field', $item['titles'] ) : array();
		$best_title = sanitize_text_field( $item['best_title'] ?? ( $titles[0] ?? $kw_text ) );
		if ( ! in_array( $best_title, $titles, true ) ) {
			array_unshift( $titles, $best_title );
		}

		$reverse_link_guide = '';
		if ( ! empty( $item['pillar']['reverse_link_guide'] ) ) {
			$reverse_link_guide = sanitize_text_field( $item['pillar']['reverse_link_guide'] );
		} elseif ( ! empty( $item['reverse_link_guide'] ) ) {
			$reverse_link_guide = sanitize_text_field( $item['reverse_link_guide'] );
		} else {
			$p_title            = $pillar['title'] ?? $pillar['target_pillar_title'] ?? 'اصلی';
			$reverse_link_guide = 'پس از انتشار این مقاله، به صفحه پیلار «' . $p_title . '» مراجعه کرده و در بخش مرتبط، با انکرتکست «' . $best_title . '» به این مقاله کلاستر لینک دهید تا چرخه لینک‌دهی دوطرفه پیلار-کلاستر برقرار گردد.';
		}
		if ( is_array( $pillar ) ) {
			$pillar['reverse_link_guide'] = $reverse_link_guide;
		}

		$sister_raw  = isset( $item['sister_cluster_link'] ) && is_array( $item['sister_cluster_link'] ) ? $item['sister_cluster_link'] : array();
		$sister_link = array(
			'target_topic' => sanitize_text_field( $sister_raw['target_topic'] ?? ( 'مقاله مکمل پیرامون ' . $kw_text ) ),
			'anchor_text'  => sanitize_text_field( $sister_raw['anchor_text'] ?? ( 'راهنمای تکمیلی ' . $kw_text ) ),
			'rationale'    => sanitize_text_field( $sister_raw['rationale'] ?? 'ارتباط موضوعی افقی با مقالات کلاستر هم‌خانواده جهت تقویت ساختار خوشه‌ای سایت.' ),
		);

		$intent    = sanitize_text_field( $item['search_intent'] ?? 'Commercial Investigation' );
		$intent_fa = sanitize_text_field( $item['search_intent_fa'] ?? 'بررسی تجاری' );
		$slug      = sanitize_title( $item['url_slug'] ?? sanitize_title_with_dashes( $best_title ) );

		// Calculate transparent SEO Score
		$cluster_dummy = array(
			'angle'         => 'ai_generated',
			'search_intent' => $intent,
		);
		$scoring = self::calculate_score( $kw_obj, $cluster_dummy, $pillar, $closest );

		$task_added = false;
		$task_id    = 0;
		if ( isset( $existing_tasks[ mb_strtolower( $best_title ) ] ) ) {
			$task_added = true;
			$task_id    = $existing_tasks[ mb_strtolower( $best_title ) ];
		}

		$cannibal_check = self::detect_title_cannibalization( $best_title, $posts, $pages, $slug );
		$is_cannibal    = ! empty( $cannibal_check['conflict'] );

		$decision        = $is_cannibal ? 'cannibalization_conflict' : sanitize_key( $item['decision'] ?? 'create_new' );
		$decision_label  = $is_cannibal ? 'خطر هم‌پوشانی با مقاله موجود' : sanitize_text_field( $item['decision_label'] ?? 'تولید مقاله جدید توصیه می‌شود' );
		$decision_reason = $is_cannibal ? ( 'تداخل اینتنت با مقاله منتشرشده: ' . $cannibal_check['matched_title'] ) : sanitize_text_field( $item['decision_reason'] ?? 'عدم وجود مقاله رقیب در سایت، ارزش بالای جذب لید و خلاء محتوایی کامل.' );
		$c_risk          = $is_cannibal ? ( 'بسیار بالا (تداخل مستقیم با: ' . $cannibal_check['matched_title'] . ')' ) : 'صفر (تأییدشده توسط نقشه سایت)';

		return array(
			'keyword'              => $kw_text,
			'weight'               => $weight,
			'score'                => $scoring['total'],
			'score_breakdown'      => $scoring['breakdown'],
			'angle'                => 'ai_custom',
			'angle_label'          => 'هوش مصنوعی (' . ( $scoring['total'] >= 90 ? 'اولویت طلایی' : 'اولویت بالا' ) . ')',
			'search_intent'        => $intent,
			'search_intent_fa'     => $intent_fa,
			'user_core_need'       => sanitize_text_field( $item['user_core_need'] ?? ( 'پاسخ به سوالات، بررسی علائم و نیازهای درمانی کاربر در رابطه با ' . $kw_text ) ),
			'best_title'           => $best_title,
			'best_title_reason'    => sanitize_text_field( $item['best_title_reason'] ?? 'عنوان دقیق، جذاب، متناسب با Search Intent و دارای بالاترین پتانسیل کلیک و تبدیل.' ),
			'titles'               => array_slice( $titles, 0, 3 ),
			'url_slug'             => $slug,
			'decision'             => $decision,
			'decision_label'       => $decision_label,
			'decision_reason'      => $decision_reason,
			'cannibalization_risk' => $c_risk,
			'cannibalization_info' => $cannibal_check,
			'audit'                => array(
				'total_urls_checked'     => count( $pages ) + count( $posts ),
				'matched_existing_count' => count( $closest ),
				'closest_pages'          => $closest,
			),
			'pillar'               => $pillar,
			'sister_cluster_link'  => $sister_link,
			'task_added'           => $task_added,
			'task_id'              => $task_id,
		);
	}

	/**
	 * D'Hondt (Jefferson) method for exact proportional slot allocation.
	 *
	 * Eliminates the largest remainder paradox. Ensures that a keyword with
	 * weight 10 gets exactly 2x the slots of weight 5.
	 *
	 * @param array $keywords    List of keywords with id and weight.
	 * @param int   $total_slots Number of slots (default 10).
	 * @return array [keyword_id => slot_count]
	 */
	public static function allocate_dhondt( array $keywords, $total_slots = self::TARGET_SUGGESTIONS ) {
		$slots = array();
		foreach ( $keywords as $k ) {
			$slots[ absint( $k['id'] ) ] = 0;
		}

		for ( $round = 0; $round < $total_slots; $round++ ) {
			$best_id       = null;
			$best_quotient = -1.0;

			foreach ( $keywords as $k ) {
				$kid = absint( $k['id'] );
				$w   = max( 1, absint( $k['weight'] ?? 5 ) );
				$s   = $slots[ $kid ];

				// D'Hondt quotient: Weight / (s + 1)
				$quotient = (float) $w / (float) ( $s + 1 );

				if ( $quotient > $best_quotient ) {
					$best_quotient = $quotient;
					$best_id       = $kid;
				}
			}

			if ( null !== $best_id ) {
				$slots[ $best_id ]++;
			}
		}

		return $slots;
	}

	/**
	 * Calculate multi-criteria SEO opportunity score (0 - 100).
	 *
	 * Evaluates:
	 * 1. Keyword weight importance (max 40 pts)
	 * 2. Content gap / topical novelty (max 25 pts)
	 * 3. Pillar synergy & link strength (max 20 pts)
	 * 4. Search intent & lead conversion (max 15 pts)
	 *
	 * @param array $kw      Keyword data.
	 * @param array $cluster Cluster template.
	 * @param array $pillar  Pillar page.
	 * @param array $closest Closest crawled posts.
	 * @return array [total, breakdown]
	 */
	public static function calculate_score( array $kw, array $cluster, array $pillar, array $closest ) {
		$weight = max( 1, min( 10, absint( $kw['weight'] ?? 5 ) ) );

		// 1. Keyword Weight factor (max 40 pts).
		$weight_score = (int) round( ( $weight / 10 ) * 40 );

		// 2. Content Gap & Topical Novelty (max 25 pts).
		$has_conflict = false;
		$has_partial  = false;
		foreach ( $closest as $cp ) {
			if ( ( $cp['score'] ?? 0 ) >= 10 && ( $cp['type'] ?? '' ) === 'مقاله کلاستر' ) {
				$has_conflict = true;
				break;
			} elseif ( ( $cp['score'] ?? 0 ) >= 6 ) {
				$has_partial = true;
			}
		}

		if ( $has_conflict ) {
			$gap_score = 10;
		} elseif ( $has_partial ) {
			$gap_score = 18;
		} else {
			$gap_score = 25; // Complete topical gap (highest value).
		}

		// 3. Pillar Synergy & internal link strength (max 20 pts).
		if ( ! empty( $pillar['is_subpillar'] ) ) {
			$pillar_score = 20; // Dedicated sub-pillar landing page exists.
		} elseif ( ! empty( $pillar['url'] ) ) {
			$pillar_score = 15; // Main pillar page exists.
		} else {
			$pillar_score = 10;
		}

		// 4. Intent & conversion value (max 15 pts).
		$intent = $cluster['intent'] ?? self::INTENT_INFORMATIONAL;
		if ( self::INTENT_COMMERCIAL === $intent ) {
			$intent_score = 15; // Commercial evaluation & comparison.
		} elseif ( 'symptoms' === ( $cluster['angle_type'] ?? '' ) || 'timeline' === ( $cluster['angle_type'] ?? '' ) ) {
			$intent_score = 14; // Urgent patient questions & golden time.
		} elseif ( 'risks' === ( $cluster['angle_type'] ?? '' ) ) {
			$intent_score = 13;
		} else {
			$intent_score = 12;
		}

		$total = $weight_score + $gap_score + $pillar_score + $intent_score;
		$total = max( 50, min( 100, $total ) );

		return array(
			'total'     => $total,
			'breakdown' => array(
				'weight_score' => $weight_score,
				'gap_score'    => $gap_score,
				'pillar_score' => $pillar_score,
				'intent_score' => $intent_score,
			),
		);
	}

	/**
	 * Find the target Pillar (Service Landing Page) for a keyword.
	 *
	 * In Topic Cluster architecture, each cluster article must link back to its Pillar.
	 *
	 * @param string $keyword Keyword text.
	 * @param array  $pages   Site pages.
	 * @param array  $biz     Business data.
	 * @return array
	 */
	public static function find_target_pillar( $keyword, array $pages, array $biz = array() ) {
		$clean_kw = preg_replace( '/[\s\-_]+/', ' ', mb_strtolower( trim( $keyword ) ) );
		$tokens   = array_filter(
			explode( ' ', $clean_kw ),
			function ( $t ) {
				return mb_strlen( trim( $t ) ) > 2 && ! in_array( $t, array( 'های', 'برای', 'در', 'با', 'از' ), true );
			}
		);

		$best_page    = null;
		$best_score   = 0;
		$service_page = null;

		foreach ( $pages as $p ) {
			$title   = $p['title'] ?? '';
			$url     = $p['url'] ?? '';
			$l_title = mb_strtolower( $title );
			$l_url   = mb_strtolower( $url );

			// Identify any generic services landing page.
			if ( mb_strpos( $l_url, 'service' ) !== false || mb_strpos( $l_title, 'خدمات' ) !== false ) {
				if ( ! $service_page ) {
					$service_page = $p;
				}
			}

			$score = 0;
			foreach ( $tokens as $t ) {
				if ( mb_strpos( $l_title, $t ) !== false ) {
					$score += 4;
				}
				if ( mb_strpos( $l_url, $t ) !== false ) {
					$score += 2;
				}
			}

			if ( $score > $best_score ) {
				$best_score = $score;
				$best_page  = $p;
			}
		}

		if ( $best_score >= 4 && $best_page ) {
			return array(
				'title'           => $best_page['title'],
				'url'             => $best_page['url'],
				'is_subpillar'    => true,
				'role'            => 'صفحه پیلار فرعی خدمات (Sub-Pillar Landing Page)',
				'exact_anchor'    => $keyword,
				'fallback_anchor' => 'خدمات ' . $keyword,
			);
		}

		if ( $service_page ) {
			return array(
				'title'           => $service_page['title'],
				'url'             => $service_page['url'],
				'is_subpillar'    => false,
				'role'            => 'صفحه اصلی خدمات (Main Services Page)',
				'exact_anchor'    => $keyword,
				'fallback_anchor' => $service_page['title'],
			);
		}

		$site_url = trim( $biz['website_url'] ?? home_url( '/' ) );
		$biz_name = trim( $biz['name'] ?? get_bloginfo( 'name' ) );
		return array(
			'title'           => $biz_name ? ( $biz_name . ' - صفحه اصلی' ) : 'صفحه اصلی سایت',
			'url'             => rtrim( $site_url, '/' ) . '/',
			'is_subpillar'    => false,
			'role'            => 'صفحه پیلار اصلی سایت (Main Pillar Landing Page)',
			'exact_anchor'    => $keyword,
			'fallback_anchor' => $biz_name ?: $keyword,
		);
	}

	/**
	 * Find closest existing content for cannibalization audit.
	 *
	 * @param string $keyword Keyword.
	 * @param array  $posts   Posts.
	 * @param array  $pages   Pages.
	 * @return array
	 */
	private static function find_closest_content( $keyword, array $posts, array $pages ) {
		$matches   = array();
		$kw_tokens = preg_split( '/[\s\-_]+/', mb_strtolower( $keyword ) );
		$kw_tokens = array_filter(
			$kw_tokens,
			function ( $t ) {
				return mb_strlen( $t ) > 2 && ! in_array( $t, array( 'در', 'به', 'با', 'از', 'برای', 'های' ), true );
			}
		);

		$all_items = array_merge(
			array_map(
				function ( $p ) {
					$p['item_type'] = 'post';
					return $p;
				},
				$posts
			),
			array_map(
				function ( $pg ) {
					$pg['item_type'] = 'page';
					return $pg;
				},
				$pages
			)
		);

		foreach ( $all_items as $item ) {
			$title = mb_strtolower( $item['title'] ?? '' );
			$url   = mb_strtolower( $item['url'] ?? '' );
			$score = 0;

			foreach ( $kw_tokens as $t ) {
				if ( mb_strpos( $title, $t ) !== false ) {
					$score += 3;
				}
				if ( mb_strpos( $url, $t ) !== false ) {
					$score += 2;
				}
			}

			if ( mb_strpos( $title, mb_strtolower( $keyword ) ) !== false ) {
				$score += 5;
			}

			if ( $score >= 3 ) {
				$is_service_page = ( $item['item_type'] === 'page' ) || ( mb_strpos( $url, 'service' ) !== false ) || ( mb_strpos( $title, 'خدمات' ) !== false );
				$matches[]       = array(
					'url'           => $item['url'],
					'title'         => $item['title'],
					'type'          => $item['item_type'] === 'page' ? 'برگه پیلار' : 'مقاله کلاستر',
					'relevance'     => $score >= 8 ? 'بالا' : 'متوسط',
					'intent'        => $is_service_page ? 'Transactional (خدماتی/پیلار)' : 'Informational (اطلاعاتی)',
					'conflict_risk' => $is_service_page ? 'صفر (این مقاله کلاستر حامی پیلار است و به آن لینک می‌دهد)' : ( $score >= 10 ? 'متوسط (نیاز به تفکیک زاویه)' : 'کم (محتوای مکمل)' ),
					'score'         => $score,
				);
			}
		}

		usort(
			$matches,
			function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		return $matches;
	}

	/**
	 * Generate evaluated candidates for a specific keyword.
	 *
	 * @param array $kw             Keyword data.
	 * @param array $pillar         Target pillar.
	 * @param array $closest        Closest content.
	 * @param array $posts          Site posts.
	 * @param array $pages          Site pages.
	 * @param array $existing_tasks Existing tasks.
	 * @param array $biz            Business data.
	 * @return array List of candidate suggestions.
	 */
	private static function generate_candidates_for_keyword( array $kw, array $pillar, array $closest, array $posts, array $pages, array $existing_tasks, array $biz ) {
		$kw_text       = trim( $kw['keyword'] );
		$weight        = absint( $kw['weight'] ?? 5 );
		$profile       = self::get_keyword_profile( $kw_text, $biz );
		$clusters      = $profile['clusters'];
		$candidates    = array();
		$total_checked = count( $posts ) + count( $pages );

		foreach ( $clusters as $c_idx => $c ) {
			$score_data = self::calculate_score( $kw, $c, $pillar, $closest );
			$best_title = $c['titles'][0];
			$slug       = self::generate_cluster_slug( $profile['slug_base'], $c['angle_type'], $c_idx );

			// Check cannibalization against published site content.
			$cannibal = self::detect_title_cannibalization( $best_title, $posts, $pages, $slug );
			if ( $cannibal['conflict'] ) {
				// Try alternate titles from the cluster.
				$resolved = false;
				for ( $alt_i = 1; $alt_i < count( $c['titles'] ); $alt_i++ ) {
					$alt_t    = $c['titles'][ $alt_i ];
					$alt_s    = $slug . '-v' . ( $alt_i + 1 );
					$alt_conf = self::detect_title_cannibalization( $alt_t, $posts, $pages, $alt_s );
					if ( ! $alt_conf['conflict'] ) {
						$best_title = $alt_t;
						$slug       = $alt_s;
						$resolved   = true;
						break;
					}
				}
				if ( ! $resolved ) {
					continue; // Entire cluster angle conflicts with existing content in sitemap, drop it!
				}
			}

			// Check if already in tasks.
			$task_added = false;
			$task_id    = null;
			foreach ( $existing_tasks as $t ) {
				if ( self::is_similar_title( $t['title'], $best_title ) || mb_strpos( $t['description'] ?? '', $best_title ) !== false ) {
					$task_added = true;
					$task_id    = absint( $t['id'] );
					break;
				}
			}

			$biz_name = trim( $biz['name'] ?? '' );
			$pillar_linking = array(
				'target_pillar_title' => $pillar['title'],
				'target_pillar_url'   => $pillar['url'],
				'pillar_role'         => $pillar['role'],
				'primary_anchor'      => $pillar['exact_anchor'],
				'secondary_anchors'   => $c['anchors'],
				'placement_strategy'  => array(
					'main_link' => 'لینک متنی اصلی (پاراگراف دوم یا میانی): اتصال انکرتکست «' . $pillar['exact_anchor'] . '» برای هدایت مستقیم به صفحه خدمات تخصصی و انتقال اعتبار تاپیک کلاستر (فقط ۱ لینک متنی در بدنه مقاله).',
					'cta_link'  => 'باکس دعوت به اقدام (پایان مقاله): دکمه یا باکس تماس (CTA) جهت دریافت مشاوره تخصصی یا سفارش خدمات ' . ( $biz_name ? esc_html( $biz_name ) : '' ) . '.',
				),
				'reverse_link_guide'  => 'پس از انتشار این مقاله، به صفحه پیلار «' . $pillar['title'] . '» مراجعه کرده و در بخش مرتبط، با انکرتکست «' . ( $c['anchors'][0] ?? $best_title ) . '» به این مقاله کلاستر جدید لینک دهید تا چرخه دوطرفه تکمیل شود.',
				'seo_goal'            => 'تزریق اتوریتی موضوعی (Topical Authority) به لندینگ سرویس، پاسخ کامل به نیت کاربر در کلاستر و صفر کردن ریسک Cannibalization.',
			);

			$candidates[] = array(
				'id'                   => 0, // Assigned after final ranking.
				'keyword_id'           => absint( $kw['id'] ),
				'keyword'              => $kw_text,
				'weight'               => $weight,
				'score'                => $score_data['total'],
				'score_breakdown'      => $score_data['breakdown'],
				'best_title'           => $best_title,
				'titles'               => $c['titles'],
				'best_title_reason'    => $c['best_title_reason'],
				'search_intent'        => $c['intent'],
				'search_intent_fa'     => $c['intent_fa'],
				'decision'             => 'recommended_new',
				'decision_label'       => 'تولید مقاله کلاستر جدید (حمایت از پیلار)',
				'decision_reason'      => 'ایجاد محتوای کلاستر تخصصی با نیت باریک برای پوشش اعتبار موضوعی (Topical Authority) و هدایت هدفمند کاربر به صفحه پیلار «' . $pillar['title'] . '» بدون تداخل محتوایی.',
				'user_core_need'       => $c['user_core_need'],
				'url_slug'             => $slug,
				'cannibalization_risk' => 'صفر (تحلیل نقشه سایت تأیید کرد هیچ مقاله رقیبی با این موضوع در وب‌سایت منتشر نشده است)',
				'angle_label'          => $c['angle_label'],
				'task_added'           => $task_added,
				'task_id'              => $task_id,
				'pillar'               => $pillar_linking,
				'sister_cluster_link'  => array(
					'target_topic' => 'مقاله کلاستر مکمل در حوزه ' . $kw_text,
					'anchor_text'  => $c['anchors'][1] ?? ( 'نکات تکمیلی ' . $kw_text ),
					'rationale'    => 'پیوند افقی دو مقاله کلاستر هم‌خانواده جهت افزایش میانگین زمان حضور کاربر در سایت و تثبیت Topical Authority.',
				),
				'audit'                => array(
					'total_urls_checked'     => $total_checked,
					'matched_existing_count' => count( $closest ),
					'closest_pages'          => array_slice( $closest, 0, 4 ),
				),
			);
		}

		return $candidates;
	}

	/**
	 * Get topic profiles and cluster options.
	 *
	 * Every profile provides 3 distinct high-value cluster angles.
	 *
	 * @param string $keyword Keyword.
	 * @param array  $biz     Business data.
	 * @return array
	 */
	private static function get_keyword_profile( $keyword, array $biz = array() ) {
		$kw       = $keyword;
		$biz_name = mb_strtolower( trim( $biz['name'] ?? '' ) );
		$biz_url  = mb_strtolower( trim( $biz['website_url'] ?? '' ) );

		// Only apply specialized clinical/home-physiotherapy profiles if the business domain explicitly matches physiotherapy.
		// All other businesses (e.g. DigiClinic, agencies, ecommerce, software) always use the dynamic cluster generator.
		$is_physio = ( mb_strpos( $biz_name, 'فیزیوتراپی' ) !== false || mb_strpos( $biz_name, 'هوم کر' ) !== false || mb_strpos( $biz_url, 'tehranhomecare' ) !== false );
		if ( ! $is_physio ) {
			return self::build_dynamic_keyword_profile( $keyword, $biz );
		}

		$profiles = array(
			'elbow'            => array(
				'matches'   => array( 'آرنج' ),
				'slug_base' => 'elbow-pain-physiotherapy',
				'clusters'  => array(
					array(
						'titles'            => array(
							'آرنج تنیس‌بازان و گلف‌بازان؛ چه زمانی به فیزیوتراپی نیاز است و چطور در خانه درمان می‌شود؟',
							'علت تیر کشیدن آرنج تا انگشتان؛ راهکارهای تسکین درد و فیزیوتراپی در منزل',
							'درمان خشکی مفصل آرنج بعد از باز کردن گچ با تمرینات توانبخشی خانگی',
						),
						'angle_label'       => 'عارضه‌یابی و تشخیص تنیس البو',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی / عارضه‌یابی (Informational)',
						'user_core_need'    => 'بیمار دچار سوزش و درد شدید در مفصل آرنج است و می‌خواهد بداند عارضه تنیس البو چگونه با فیزیوتراپی در خانه درمان می‌شود.',
						'best_title_reason' => 'پاسخ مستقیم به شایع‌ترین شکایت بالینی درد آرنج و ایجاد پیوند قوی به لندینگ خدمات.',
						'anchors'           => array( 'فیزیوتراپی آرنج در منزل', 'خدمات فیزیوتراپی تخصصی آرنج' ),
					),
					array(
						'titles'            => array(
							'۵ حرکت کششی و تقویتی برای رفع خشکی و گرفتگی آرنج در خانه',
							'تمرینات بازتوانی بعد از جراحی و شکستگی آرنج؛ چه کارهایی نباید انجام دهیم؟',
							'چند جلسه فیزیوتراپی برای درمان کامل درد آرنج لازم است؟',
						),
						'angle_label'       => 'حرکات اصلاحی و تمرینات خانگی',
						'angle_type'        => 'exercises',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'آموزشی و خودمراقبتی (Informational)',
						'user_core_need'    => 'یافتن تمرینات ایمن حرکتی بین جلسات فیزیوتراپی جهت تسریع بازگشت دامنه حرکتی مفصل آرنج.',
						'best_title_reason' => 'عناوین تمرینی لیست‌محور بیشترین نرخ ذخیره و اشتراک‌گذاری را در بین بیماران دارند.',
						'anchors'           => array( 'فیزیوتراپی آرنج در منزل', 'فیزیوتراپ مجرب در منزل' ),
					),
					array(
						'titles'            => array(
							'علت درد شدید و تیرکشنده پشت آرنج؛ گیر افتادگی عصب اولنار چیست؟',
							'مراقبت‌های لازم بعد از گچ‌گیری آرنج برای جلوگیری از چسبندگی تاندون‌ها',
							'هزینه و تعداد جلسات فیزیوتراپی آرنج در منزل در سال جاری',
						),
						'angle_label'       => 'درگیری عصب اولنار و پیشگیری از چسبندگی',
						'angle_type'        => 'risks',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی تخصصی (Informational)',
						'user_core_need'    => 'تشخیص خواب‌رفتگی انگشتان کوچک ناشی از تحت فشار قرار گرفتن عصب در آرنج.',
						'best_title_reason' => 'بررسی گیر افتادگی عصب اولنار برای بیمارانی که گزگز دست دارند.',
						'anchors'           => array( 'فیزیوتراپی آرنج در منزل', 'فیزیوتراپیست در خانه' ),
					),
				),
			),
			'laser'            => array(
				'matches'   => array( 'لیزر', 'لیزر پرتوان' ),
				'slug_base' => 'high-power-laser-therapy',
				'clusters'  => array(
					array(
						'titles'            => array(
							'تفاوت لیزر پرتوان با روش‌های سنتی فیزیوتراپی؛ کدام‌یک درد مزمن را سریع‌تر متوقف می‌کند؟',
							'لیزر پرتوان برای چه دردهایی معجزه می‌کند؟ موارد منع و ایمنی درمان در منزل',
							'آیا لیزر پرتوان در فیزیوتراپی درد دارد؟ بررسی عوارض، تعداد جلسات و اثربخشی',
						),
						'angle_label'       => 'مقایسه تکنولوژی و انتخاب روش درمان',
						'angle_type'        => 'comparison',
						'intent'            => self::INTENT_COMMERCIAL,
						'intent_fa'         => 'بررسی تجاری و مقایسه‌ای (Commercial Investigation)',
						'user_core_need'    => 'بیمار می‌خواهد بداند آیا پرداخت هزینه برای لیزر پرتوان در منزل اثر سریع‌تری نسبت به فیزیوتراپی عادی دارد.',
						'best_title_reason' => 'مقایسه شفاف قبل از خرید خدمت که شک و تردیدهای بیمار را رفع می‌کند.',
						'anchors'           => array( 'فیزیوتراپی با لیزر پرتوان در منزل', 'لیزر درمانی پرتوان در منزل' ),
					),
					array(
						'titles'            => array(
							'لیزر پرتوان برای چه بیماری‌هایی ممنوع است؟ بررسی موارد منع مصرف و خطرات احتمالی',
							'چند جلسه لیزر پرتوان برای درمان دیسک کمر و زانو درد نیاز است؟',
							'تجهیزات پرتابل لیزر درمانی در منزل؛ آیا اثربخشی دستگاه‌های خانگی با کلینیک برابر است؟',
						),
						'angle_label'       => 'موارد منع مصرف، ایمنی و تعداد جلسات',
						'angle_type'        => 'risks',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی ایمنی (Informational)',
						'user_core_need'    => 'بیمار نگران سوختگی پوست یا عوارض جانبی اشعه لیزر پرتوان در فضای خانه است.',
						'best_title_reason' => 'پاسخ به سوالات ایمنی بیمار و جلب اعتماد کامل به تخصص فیزیوتراپیست اعزامی.',
						'anchors'           => array( 'فیزیوتراپی با لیزر پرتوان در منزل', 'لیزر پرتوان در منزل' ),
					),
				),
			),
			'post_surgery'     => array(
				'matches'   => array( 'بعد از عمل', 'عمل جراحی', 'جراحی' ),
				'slug_base' => 'post-surgery-rehab',
				'clusters'  => array(
					array(
						'titles'            => array(
							'چند روز بعد از عمل جراحی باید فیزیوتراپی در منزل را شروع کرد؟ (جدول زمان‌بندی طلایی)',
							'عوارض خطرناک تاخیر در فیزیوتراپی بعد از جراحی؛ پیشگیری از چسبندگی و لخته شدن خون',
							'چگونه فضای خانه را برای بیمار بعد از ترخیص از بیمارستان و انجام فیزیوتراپی آماده کنیم؟',
						),
						'angle_label'       => 'پروتکل طلایی زمان‌بندی بعد از جراحی',
						'angle_type'        => 'timeline',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی اورژانسی (Informational)',
						'user_core_need'    => 'همراهان بیمار بعد از ترخیص سردرگم هستند که دقیقاً چه زمانی باید فیزیوتراپ به خانه بیاید تا مفصل خشک نشود.',
						'best_title_reason' => 'استفاده از عبارت جدول زمان‌بندی طلایی که اضطراب خانواده بیمار را برطرف می‌سازد.',
						'anchors'           => array( 'فیزیوتراپی بعد از عمل جراحی در منزل', 'توانبخشی بعد از عمل در خانه' ),
					),
					array(
						'titles'            => array(
							'کارهای ممنوع در هفته اول بعد از جراحی ارتوپدی که روند جوش خوردن را خراب می‌کند',
							'روش اصولی راه رفتن با واکر و عصا در منزل بعد از جراحی پا و لگن',
							'علائم هشداردهنده عفونت و آمبولی در دوره نقاهت جراحی پس از ترخیص',
						),
						'angle_label'       => 'کارهای ممنوع و راهنمای راه رفتن با واکر',
						'angle_type'        => 'risks',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'مراقبتی و پیشگیرانه (Informational)',
						'user_core_need'    => 'جلوگیری از رفتارهای اشتباه حرکتی در روزهای اول پس از جراحی.',
						'best_title_reason' => 'چک‌لیست کارهای ممنوع بعد از جراحی بیشترین میزان اشتراک‌گذاری بین همراهان بیمار را دارد.',
						'anchors'           => array( 'فیزیوتراپی بعد از عمل جراحی در منزل', 'مراقبت‌های بعد از عمل در منزل' ),
					),
				),
			),
			'ms'               => array(
				'matches'   => array( 'ام‌اس', 'ام اس' ),
				'slug_base' => 'multiple-sclerosis-physio',
				'clusters'  => array(
					array(
						'titles'            => array(
							'تکنیک‌های فیزیوتراپی در منزل برای کنترل اسپاسم و گرفتگی شدید عضلات در بیماران ام‌اس',
							'چگونه خستگی مفرط (Fatigue) بیماران ام‌اس را با فیزیوتراپی مدیریت کنیم؟',
							'تمرینات تعادلی ایمن در خانه برای جلوگیری از زمین خوردن مبتلایان به MS',
						),
						'angle_label'       => 'مدیریت اسپاسم و سفتی عضلانی ام‌اس',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی تخصصی (Informational)',
						'user_core_need'    => 'بیمار مبتلا به ام‌اس از خشکی و سفت شدن شبانه پاها رنج می‌برد و به دنبال تمرینات اختصاصی کاهش اسپاسم است.',
						'best_title_reason' => 'تمرکز بر حل اصلی‌ترین معضل بیماران ام‌اس با رویکرد توانبخشی ملایم در منزل.',
						'anchors'           => array( 'فیزیوتراپی بیماران ام‌اس در منزل', 'توانبخشی بیماران ام اس در منزل' ),
					),
					array(
						'titles'            => array(
							'تمرینات تعادلی و هماهنگی عصبی-عضلانی برای حفظ استقلال حرکتی در ام‌اس',
							'آیا ورزش سنگین برای بیمار ام‌اس خطر دارد؟ حد مجاز خستگی در فیزیوتراپی',
							'نقش فیزیوتراپیست خانگی در جلوگیری از تحلیل رفتن قوای عضلانی بیماران MS',
						),
						'angle_label'       => 'حفظ تعادل حرکتی و جلوگیری از تحلیل توان',
						'angle_type'        => 'exercises',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'آموزشی و خودمراقبتی (Informational)',
						'user_core_need'    => 'حفظ توانایی راه رفتن مستقل و جلوگیری از زمین خوردن‌های مکرر در منزل.',
						'best_title_reason' => 'تمرینات تعادلی کلید استقلال حرکتی بیماران ام‌اس است.',
						'anchors'           => array( 'فیزیوتراپی بیماران ام‌اس در منزل', 'فیزیوتراپی در منزل' ),
					),
				),
			),
			'parkinson'        => array(
				'matches'   => array( 'پارکینسون' ),
				'slug_base' => 'parkinsons-home-physio',
				'clusters'  => array(
					array(
						'titles'            => array(
							'راهکارهای فیزیوتراپی برای غلبه بر قفل شدن پا (Freezing) و حفظ تعادل در بیماران پارکینسون',
							'بهترین تمرینات روزانه در منزل برای کاهش لرزش و بهبود راه رفتن در پارکینسون',
							'چک‌لیست ایمن‌سازی چیدمان خانه برای پیشگیری از زمین خوردن سالمند مبتلا به پارکینسون',
						),
						'angle_label'       => 'غلبه بر فریزینگ و حفظ تعادل حرکتی',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی تخصصی (Informational)',
						'user_core_need'    => 'جلوگیری از قفل شدن ناگهانی پا هنگام راه رفتن و پیشگیری از سقوط‌های خطرناک در خانه.',
						'best_title_reason' => 'اشاره به اصطلاح بالینی Freezing که دغدغه روزمره بیماران و پزشکان معالج است.',
						'anchors'           => array( 'فیزیوتراپی بیماران پارکینسون در منزل', 'فیزیوتراپی تخصصی پارکینسون' ),
					),
					array(
						'titles'            => array(
							'تکنیک‌های ریتمیک و شمارش برای شروع راه رفتن در بیماران پارکینسون در خانه',
							'ورزش‌های کششی و تنفسی روزانه برای کاهش خشکی مفاصل و لرزش دست',
							'تجهیزات و وسایل کمکی مناسب برای حرکت ایمن بیماران پارکینسون در منزل',
						),
						'angle_label'       => 'تکنیک‌های ریتمیک و تمرینات روزانه ضد لرزش',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'آموزشی و مهارتی (Informational)',
						'user_core_need'    => 'کاهش لرزش دست‌ها موقع غذا خوردن و اصلاح الگوی راه رفتن با نشانه‌های صوتی و بینایی.',
						'best_title_reason' => 'تکنیک‌های ریتمیک از جدیدترین متدهای اثبات‌شده نوروریهاب در پارکینسون هستند.',
						'anchors'           => array( 'فیزیوتراپی بیماران پارکینسون در منزل', 'توانبخشی پارکینسون در منزل' ),
					),
				),
			),
			'hip_replacement'  => array(
				'matches'   => array( 'تعویض مفصل ران', 'تعویض مفصل لگن', 'مفصل ران' ),
				'slug_base' => 'hip-replacement-recovery',
				'clusters'  => array(
					array(
						'titles'            => array(
							'چه کارهایی بعد از جراحی تعویض مفصل ران ممنوع است؟ (راهنمای نشستن، خوابیدن و توالت)',
							'برنامه فیزیوتراپی هفته اول تا ششم بعد از تعویض مفصل ران در منزل',
							'چه زمانی بعد از جراحی مفصل ران می‌توان واکر را کنار گذاشت و مستقل راه رفت؟',
						),
						'angle_label'       => 'کارهای ممنوع و پیشگیری از دررفتگی پروتز',
						'angle_type'        => 'risks',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'مراقبتی و پیشگیرانه (Informational)',
						'user_core_need'    => 'آموزش زوایای مجاز حرکتی تا پروتز تازه کار گذاشته شده ران دچار دررفتگی و عارضه نشود.',
						'best_title_reason' => 'پاسخ به بزرگترین ترس بیمار پس از تعویض مفصل لگن درباره نحوه خوابیدن و نشستن.',
						'anchors'           => array( 'فیزیوتراپی تعویض مفصل ران در منزل', 'فیزیوتراپی مفصل ران در منزل' ),
					),
					array(
						'titles'            => array(
							'چند هفته استراحت مطلق بعد از عمل تعویض مفصل لگن لازم است؟ تفاوت استراحت با بی تحرکی',
							'تمرینات ایمن تقویت عضلات گلوتئال و ران در تخت خواب پس از جراحی تعویض مفصل',
							'علائم شل شدن پروتز یا عفونت مفصل ران؛ چه نشانه‌هایی را باید جدی گرفت؟',
						),
						'angle_label'       => 'طول دوره استراحت و تمرینات تقویتی در تخت',
						'angle_type'        => 'timeline',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی توانبخشی (Informational)',
						'user_core_need'    => 'آگاهی از مرز بین استراحت ایمن و بی‌تحرکی خطرناک که موجب لخته خون می‌شود.',
						'best_title_reason' => 'تعیین دقیق طول دوره نقاهت و اطمینان از سلامت پروتز ران.',
						'anchors'           => array( 'فیزیوتراپی تعویض مفصل ران در منزل', 'فیزیوتراپی در منزل' ),
					),
				),
			),
			'knee_replacement' => array(
				'matches'   => array( 'تعویض مفصل زانو' ),
				'slug_base' => 'knee-replacement-stiffness',
				'clusters'  => array(
					array(
						'titles'            => array(
							'چرا زانو بعد از تعویض مفصل داغ می‌شود یا کامل خم نمی‌شود؟ علت و راهکارهای فیزیوتراپی',
							'جدول زمان‌بندی زاویه خم شدن زانو در هفته‌های ۱ تا ۶ بعد از عمل پروتز زانو',
							'ورزش‌های بعد از تعویض مفصل زانو در منزل؛ چند بار در روز باید تمرین کرد؟',
						),
						'angle_label'       => 'علت داغی زانو و زاویه خم شدن',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی / رفع ابهام (Informational)',
						'user_core_need'    => 'بیمار نگران احساس حرارت و خشکی زانو است و نیاز به دانستن زاویه نرمال خم شدن دارد.',
						'best_title_reason' => 'رفع نگرانی‌های بعد از عمل بیمار و ترغیب به ادامه منظم جلسات فیزیوتراپی.',
						'anchors'           => array( 'فیزیوتراپی تعویض مفصل زانو در منزل', 'فیزیوتراپی زانو در منزل' ),
					),
					array(
						'titles'            => array(
							'خم نشدن زانو تا زاویه ۹۰ درجه بعد از تعویض مفصل؛ زمان طلایی مانیپولاسیون چه موقع است؟',
							'استفاده از یخ، کیسه آب گرم و دستگاه CPM در توانبخشی خانگی پروتز زانو',
							'چگونه ورم و سفتی صبحگاهی زانو را پس از جراحی تعویض مفصل برطرف کنیم؟',
						),
						'angle_label'       => 'زمان طلایی رفع خشکی زانو و دستگاه CPM',
						'angle_type'        => 'timeline',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'تخصصی و بازتوانی (Informational)',
						'user_core_need'    => 'جلوگیری از چسبندگی بافت‌های اطراف پروتز زانو و دستیابی به دامنه حرکتی کامل.',
						'best_title_reason' => 'تمرکز بر زمان طلایی زاویه ۹۰ درجه که برای نشستن روی صندلی حیاتی است.',
						'anchors'           => array( 'فیزیوتراپی تعویض مفصل زانو در منزل', 'فیزیوتراپی زانو در خانه' ),
					),
				),
			),
			'respiratory'      => array(
				'matches'   => array( 'تنفسی' ),
				'slug_base' => 'chest-physiotherapy-techniques',
				'clusters'  => array(
					array(
						'titles'            => array(
							'تکنیک‌های فیزیوتراپی تنفسی در منزل برای تخلیه خلط و افزایش ظرفیت ریه (آموزش گام‌به‌گام)',
							'فیزیوتراپی تنفسی برای چه بیمارانی حیاتی است؟ (بیماران بستری، جراحی قفسه سینه و سالمندان)',
							'علائم کمبود اکسیژن در بیماران ریوی و نقش فیزیوتراپیست تنفسی در منزل',
						),
						'angle_label'       => 'تخلیه ترشحات ریه و تنفس موثر',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'آموزشی و مهارتی (Informational)',
						'user_core_need'    => 'تخلیه خلط سینه و باز شدن مجاری تنفسی در بیماران با افت سطح اکسیژن در خانه.',
						'best_title_reason' => 'رویکرد عملی برای پاکسازی ریه بدون نیاز به اعزام بیمار بدحال به بیمارستان.',
						'anchors'           => array( 'فیزیوتراپی تنفسی در منزل', 'فیزیوتراپی ریه در منزل' ),
					),
				),
			),
			'general_home'     => array(
				'matches'   => array( 'فیزیوتراپی در منزل' ),
				'slug_base' => 'home-vs-clinic-physiotherapy',
				'clusters'  => array(
					array(
						'titles'            => array(
							'فیزیوتراپی در منزل یا کلینیک؟ مقایسه هزینه، کیفیت درمان و سرعت بهبودی بیماران',
							'آیا بیمه تکمیلی هزینه فیزیوتراپی در منزل را پرداخت می‌کند؟ (مدارک و شرایط بازپرداخت)',
							'۵ نکته حیاتی که قبل از ورود فیزیوتراپیست به خانه باید بررسی کنید (احراز صلاحیت و بهداشت)',
						),
						'angle_label'       => 'مقایسه خانه با کلینیک و تصمیم‌گیری',
						'angle_type'        => 'comparison',
						'intent'            => self::INTENT_COMMERCIAL,
						'intent_fa'         => 'بررسی تجاری و مقایسه‌ای (Commercial Investigation)',
						'user_core_need'    => 'بررسی مزایای درمان خانگی در برابر زحمت و خطرات جابجایی بیمار با ویلچر یا آمبولانس.',
						'best_title_reason' => 'عالی‌ترین عنوان برای قیف تبدیل کاربران سرگردان به مشتریان تماس تلفنی.',
						'anchors'           => array( 'فیزیوتراپی در منزل تهران', 'خدمات فیزیوتراپی در منزل' ),
					),
					array(
						'titles'            => array(
							'مدارک و شرایط دریافت هزینه فیزیوتراپی در منزل از بیمه تکمیلی (راهنمای جامع سال جاری)',
							'چگونه اتاق و فضای خانه را برای جلسه فیزیوتراپی آماده کنیم؟ (چک‌لیست تجهیزات ضروری)',
							'تجهیزات مدرن قابل حمل که فیزیوتراپیست همراه خود به منزل بیمار می‌آورد',
						),
						'angle_label'       => 'بیمه تکمیلی و چک‌لیست آماده‌سازی خانه',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_COMMERCIAL,
						'intent_fa'         => 'کاربردی و مالی (Commercial Investigation)',
						'user_core_need'    => 'دریافت خسارت از بیمه تکمیلی و آمادگی کامل فضای خانه قبل از حضور درمانگر.',
						'best_title_reason' => 'مسائل مالی و بیمه تکمیلی دغدغه بیش از ۸۰٪ متقاضیان خدمات در منزل است.',
						'anchors'           => array( 'فیزیوتراپی در منزل تهران', 'فیزیوتراپی در منزل' ),
					),
				),
			),
			'lumbar_disc'      => array(
				'matches'   => array( 'دیسک کمر', 'ستون فقرات' ),
				'slug_base' => 'sciatica-lumbar-disc-pain',
				'clusters'  => array(
					array(
						'titles'            => array(
							'علت تیر کشیدن درد دیسک کمر به پا (سیاتیک) چیست و فیزیوتراپی در منزل چگونه آن را آرام می‌کند؟',
							'پیاده‌روی برای دیسک کمر مفید است یا مضر؟ نحوه صحیح راه رفتن در دوره درمان',
							'پوزیشن‌های مجاز خوابیدن و استراحت برای بیماران دیسک کمر حاد (همراه تصویر)',
						),
						'angle_label'       => 'درد تیرکشنده سیاتیک و تسکین عصب',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی و تسکین درد (Informational)',
						'user_core_need'    => 'بیمار نمی‌تواند راه برود یا بنشیند و به دنبال درک علت انتشار درد به باسن و ران پاست.',
						'best_title_reason' => 'درد سیاتیک پرتکرارترین کلمه همراه دیسک کمر در سرچ کاربران ایرانی است.',
						'anchors'           => array( 'فیزیوتراپی دیسک کمر در منزل', 'فیزیوتراپی ستون فقرات و کمر در منزل' ),
					),
					array(
						'titles'            => array(
							'پیاده‌روی برای دیسک کمر حاد؛ چه زمانی کمک‌کننده است و چه زمانی درد را بدتر می‌کند؟',
							'حرکات کششی و تمرینات مکنزی برای کاهش فشار روی ریشه عصب دیسک کمر در خانه',
							'کارهای روزمره ممنوع برای افراد مبتلا به بیرون‌زدگی دیسک کمر (نشستن، خم شدن و بلند کردن اشیاء)',
						),
						'angle_label'       => 'پیاده‌روی و تمرینات مکنزی دیسک کمر',
						'angle_type'        => 'exercises',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'آموزشی و خودمراقبتی (Informational)',
						'user_core_need'    => 'یافتن حرکات تسکین‌دهنده بین جلسات فیزیوتراپی جهت بازگشت به کار و فعالیت روزمره.',
						'best_title_reason' => 'پیاده‌روی برای دیسک کمر سوال اول هر بیمار پس از شروع کمردرد است.',
						'anchors'           => array( 'فیزیوتراپی دیسک کمر در منزل', 'درمان دیسک کمر در منزل' ),
					),
				),
			),
			'knee'             => array(
				'matches'   => array( 'زانو' ),
				'slug_base' => 'knee-swelling-bursitis-effusion',
				'clusters'  => array(
					array(
						'titles'            => array(
							'ورم و آب آوردن زانو (بورسیت)؛ علت چیست و چه زمانی فیزیوتراپی به تخلیه التهاب کمک می‌کند؟',
							'تمرینات تقویتی عضله چهارسر ران در خانه برای کاهش ساییدگی و درد آرتروز زانو',
							'تفاوت درد رباط صلیبی با منیسک زانو؛ راهنمای توانبخشی و فیزیوتراپی در خانه',
						),
						'angle_label'       => 'ورم و آب آوردن زانو (بورسیت مفصل)',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'نشانه‌شناسی و عارضه‌یابی (Informational)',
						'user_core_need'    => 'بیمار دچار تورم، احساس سنگینی و آب آوردن زانو شده و به دنبال روش‌های کاهش التهاب و توانبخشی است.',
						'best_title_reason' => 'پاسخ به خلاء محتوایی مهم درباره ورم و افیوژن زانو که در مقالات سایت پوشش داده نشده است.',
						'anchors'           => array( 'فیزیوتراپی زانو در منزل', 'خدمات فیزیوتراپی زانو در خانه' ),
					),
					array(
						'titles'            => array(
							'۵ تمرین ایزومتریک بدون نیاز به وزنه برای درمان آرتروز زانو و کاهش ساییدگی مفصل در خانه',
							'تاندونیت کشکک زانو (زانوی پرش‌کاران)؛ علائم، تفاوت با ساییدگی و تمرینات خانگی',
							'تزریق ژل زانو یا فیزیوتراپی؟ مقایسه ماندگاری اثر درمان بر درد مفاصل',
						),
						'angle_label'       => 'تمرینات بدون وزنه آرتروز و تاندونیت کشکک',
						'angle_type'        => 'exercises',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'آموزشی و خودمراقبتی (Informational)',
						'user_core_need'    => 'تقویت عضلات حامی زانو بدون ایجاد فشار مضاعف روی غضروف ساییده‌شده.',
						'best_title_reason' => 'پوشش خلاء موضوعی پیرامون تاندونیت کشکک و تمرینات ایزومتریک آرتروز.',
						'anchors'           => array( 'فیزیوتراپی زانو در منزل', 'فیزیوتراپ متخصص زانو در منزل' ),
					),
				),
			),
			'elderly'          => array(
				'matches'   => array( 'سالمند', 'سالمندان' ),
				'slug_base' => 'elderly-weakness-mobility-care',
				'clusters'  => array(
					array(
						'titles'            => array(
							'علت ضعف شدید پا و ناتوانی در بلند شدن از صندلی در سالمندان؛ راهکارهای توانبخشی در منزل',
							'چگونه از تحلیل رفتن عضلات سالمند زمین‌گیر در خانه جلوگیری کنیم؟ (تمرینات در تخت)',
							'علت و درمان ترس سالمندان از راه رفتن بعد از یک بار زمین خوردن',
						),
						'angle_label'       => 'تقویت عضلات پا و جلوگیری از تحلیل حرکتی',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی مراقبتی (Informational)',
						'user_core_need'    => 'فرزندان سالمند می‌خواهند بدانند چطور پدر یا مادر کم‌توانشان دوباره بتوانند بدون واکر بلند شوند.',
						'best_title_reason' => 'ارائه راهکار عملی برای ناتوانی در بلند شدن از صندلی که دغدغه تمام خانواده‌هاست.',
						'anchors'           => array( 'فیزیوتراپی سالمند در منزل', 'توانبخشی سالمندان در منزل' ),
					),
				),
			),
			'cardiac'          => array(
				'matches'   => array( 'سکته قلبی', 'قلبی' ),
				'slug_base' => 'cardiac-rehab-exercise-safety',
				'clusters'  => array(
					array(
						'titles'            => array(
							'مراحل بازتوانی قلبی و فیزیوتراپی در منزل پس از سکته قلبی؛ علائم خطر هنگام ورزش چیست؟',
							'چند هفته بعد از آنژیوپلاستی یا عمل قلب باز می‌توان ورزش‌های سبک را شروع کرد؟',
							'تنظیم ضربان قلب ایمن هنگام فعالیت بدنی در بیماران قلبی در خانه',
						),
						'angle_label'       => 'ورزش ایمن و کنترل ضربان قلب پس از سکته',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی ایمنی (Informational)',
						'user_core_need'    => 'بیمار قلبی از حرکت می‌ترسد و نیاز به اطمینان خاطر در مورد سطح مجاز فعالیت بدنی دارد.',
						'best_title_reason' => 'پوشش ترس بیماران و تعیین حد مجاز ضربان قلب برای شروع مجدد زندگی عادی.',
						'anchors'           => array( 'فیزیوتراپی سکته قلبی در منزل', 'بازتوانی قلبی در منزل' ),
					),
				),
			),
			'stroke'           => array(
				'matches'   => array( 'سکته مغزی' ),
				'slug_base' => 'stroke-golden-time-physio',
				'clusters'  => array(
					array(
						'titles'            => array(
							'زمان طلایی (Golden Time) فیزیوتراپی بعد از سکته مغزی؛ چرا هر روز تاخیر به ضرر بیمار است؟',
							'بهترین تمرینات خانگی برای بازگرداندن حرکت به دست و انگشتان فلج‌شده بعد از سکته مغزی',
							'چگونه با اسپاسم و سفت شدن شدید عضلات بیمار سکته مغزی مقابله کنیم؟',
						),
						'angle_label'       => 'زمان طلایی بازتوانی و شروع زودهنگام',
						'angle_type'        => 'timeline',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی استراتژیک (Informational)',
						'user_core_need'    => 'خانواده بیمار سکته مغزی می‌خواهند بدانند چقدر فرصت برای احیای نورون‌های مغزی و حرکت دست و پا دارند.',
						'best_title_reason' => 'تاکید بر گلدن تایم (زمان طلایی) محرک قوی اقدام فوری برای استخدام فیزیوتراپیست است.',
						'anchors'           => array( 'فیزیوتراپی سکته مغزی در منزل', 'توانبخشی سکته مغزی در منزل' ),
					),
					array(
						'titles'            => array(
							'بهترین تمرینات خانگی برای بازگرداندن حرکت به دست و انگشتان فلج‌شده بعد از سکته',
							'چگونه بیمار سکته مغزی را بعد از ماه‌ها بی‌تحرکی دوباره راه بیندازیم؟ (مراحل گام‌به‌گام)',
							'جلوگیری از زخم بستر و افتادگی شانه در سمت فلج‌شده بیمار سکته مغزی',
						),
						'angle_label'       => 'بازتوانی دست و پا و شروع مجدد راه رفتن',
						'angle_type'        => 'exercises',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'توانبخشی تخصصی (Informational)',
						'user_core_need'    => 'بازگرداندن حرکت به انگشتان دست و توانایی ایستادن و راه رفتن مستقل.',
						'best_title_reason' => 'تمرکز بر سخت‌ترین بخش بازتوانی (دست و انگشتان فلج) که جستجوی زیادی دارد.',
						'anchors'           => array( 'فیزیوتراپی سکته مغزی در منزل', 'فیزیوتراپیست سکته مغزی در منزل' ),
					),
				),
			),
			'shoulder'         => array(
				'matches'   => array( 'شانه' ),
				'slug_base' => 'frozen-shoulder-night-pain',
				'clusters'  => array(
					array(
						'titles'            => array(
							'شانه منجمد (یخ‌زده) چیست و فیزیوتراپی در منزل چقدر طول می‌کشد تا دست کامل بالا بیاید؟',
							'علت درد شدید شانه هنگام خوابیدن به پهلو و راهکارهای تسکین آن در خانه',
							'تمرینات کششی با چوب و طناب برای باز کردن گرفتگی مفصل شانه',
						),
						'angle_label'       => 'شانه منجمد و درد شبانه خوابیدن',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی درمانی (Informational)',
						'user_core_need'    => 'بیمار شب‌ها از درد بیدار می‌شود و نمی‌تواند دستش را برای لباس پوشیدن بالا ببرد.',
						'best_title_reason' => 'شانه منجمد شایع‌ترین اختلال غیرترومایی مفصل شانه در سنین بالای ۴۰ سال است.',
						'anchors'           => array( 'فیزیوتراپی شانه در منزل', 'فیزیوتراپی تخصصی شانه در منزل' ),
					),
				),
			),
			'fracture'         => array(
				'matches'   => array( 'شکستگی' ),
				'slug_base' => 'cast-removal-bone-stiffness',
				'clusters'  => array(
					array(
						'titles'            => array(
							'مراقبت‌ها و فیزیوتراپی بعد از باز کردن گچ یا آتل؛ چطور ورم و خشکی استخوان را از بین ببریم؟',
							'چه زمانی بعد از جراحی شکستگی و گذاشتن پلاتین می‌توان وزن روی پا انداخت؟',
							'علت درد استخوان در محل جوش‌خوردگی شکستگی هنگام تغییر هوا چیست؟',
						),
						'angle_label'       => 'مراقبت‌های بعد از باز کردن گچ و آتل',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی بازتوانی (Informational)',
						'user_core_need'    => 'بیمار بعد از باز کردن گچ با پایی لاغر، ورم کرده و بدون تحرک مواجه شده و راهنمایی می‌خواهد.',
						'best_title_reason' => 'حل دلهره بیمار در همان روز باز کردن گچ و تسریع جوش خوردن استخوان.',
						'anchors'           => array( 'فیزیوتراپی شکستگی در منزل', 'توانبخشی بعد از شکستگی در منزل' ),
					),
				),
			),
			'facial_stroke'    => array(
				'matches'   => array( 'صورت پس از سکته', 'فلج صورت', 'صورت' ),
				'slug_base' => 'facial-palsy-stroke-exercises',
				'clusters'  => array(
					array(
						'titles'            => array(
							'تمرینات فیزیوتراپی و ماساژ صورت برای رفع افتادگی دهان و بستن کامل چشم بعد از سکته',
							'تفاوت فلج بل (عصب صورت) با فلج صورت ناشی از سکته مغزی چیست؟',
							'چند جلسه فیزیوتراپی برای قرینه شدن مجدد لبخند و صحبت کردن واضح لازم است؟',
						),
						'angle_label'       => 'تمرینات بازتوانی عضلات صورت و قرینگی لبخند',
						'angle_type'        => 'exercises',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی توانبخشی (Informational)',
						'user_core_need'    => 'رفع افتادگی گوشه دهان، بهبود تلفظ کلمات و توانایی پلک زدن طبیعی.',
						'best_title_reason' => 'تمرکز بر نگرانی شدید بیمار درباره زیبایی چهره و برقراری ارتباط با دیگران.',
						'anchors'           => array( 'فیزیوتراپی صورت پس از سکته در منزل', 'فیزیوتراپی فلج بل در منزل' ),
					),
				),
			),
			'spinal_cord'      => array(
				'matches'   => array( 'ضایعات نخاعی', 'نخاع' ),
				'slug_base' => 'spinal-cord-injury-home-care',
				'clusters'  => array(
					array(
						'titles'            => array(
							'پروتکل‌های پیشگیری از زخم بستر و حفظ دامنه حرکتی در بیماران ضایعه نخاعی در خانه',
							'تجهیزات ضروری فیزیوتراپی و کاردرمانی در منزل برای بیماران نخاعی',
							'روش‌های صحیح جابجایی بیمار نخاعی از تخت به ویلچر بدون آسیب به مهره‌ها',
						),
						'angle_label'       => 'پیشگیری از زخم بستر و حفظ دامنه حرکتی',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی حیاتی (Informational)',
						'user_core_need'    => 'آموزش مراقبین برای پیشگیری از زخم بستر درجه ۳ و تحلیل غیرقابل برگشت عضلات.',
						'best_title_reason' => 'پیشگیری از زخم بستر مرگبارترین و هزینه‌برترین چالش بیماران ضایعه نخاعی است.',
						'anchors'           => array( 'فیزیوتراپی ضایعات نخاعی در منزل', 'توانبخشی بیماران نخاعی در منزل' ),
					),
				),
			),
			'jaw'              => array(
				'matches'   => array( 'فک' ),
				'slug_base' => 'tmj-jaw-clicking-physiotherapy',
				'clusters'  => array(
					array(
						'titles'            => array(
							'علت صدای تق تق، قفل شدن یا درد مفصل فک (TMJ) هنگام جویدن غذا و روش‌های درمان خانگی',
							'آیا دندان قروچه باعث اختلال مفصل فک می‌شود؟ تمرینات آرام‌سازی عضلات گیجگاهی',
							'تکنیک‌های منوال‌تراپی و فیزیوتراپی فک در منزل برای باز شدن کامل دهان',
						),
						'angle_label'       => 'اختلال مفصل فک (TMJ) و صدای تق‌تق',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'نشانه‌شناسی و آگاهی‌بخشی (Informational)',
						'user_core_need'    => 'بیمار هنگام غذا خوردن احساس درد و صدا در فک دارد و سردردهای مبهم می‌گیرد.',
						'best_title_reason' => 'آگاهی‌بخشی درباره وجود تخصص فیزیوتراپی فک که اغلب مردم از آن بی‌خبرند.',
						'anchors'           => array( 'فیزیوتراپی فک در منزل', 'فیزیوتراپی مفصل فک در خانه' ),
					),
				),
			),
			'pelvic_floor'     => array(
				'matches'   => array( 'کف لگن' ),
				'slug_base' => 'pelvic-floor-incontinence-kegel',
				'clusters'  => array(
					array(
						'titles'            => array(
							'درمان بی‌اختیاری ادرار ناشی از استرس و خنده با تمرینات تخصصی فیزیوتراپی کف لگن در منزل',
							'تمرینات کگل (Kegel) را چگونه درست انجام دهیم؟ اشتباهاتی که مشکل را بدتر می‌کند',
							'فیزیوتراپی کف لگن برای چه کسانی ضروری است؟ (پس از زایمان، جراحی پروستات و افتادگی مثانه)',
						),
						'angle_label'       => 'بی‌اختیاری ادرار و تمرینات کگل',
						'angle_type'        => 'care',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'تخصصی و حریم خصوصی (Informational)',
						'user_core_need'    => 'درمان ترشح غیرارادی ادرار با تقویت اسفنکتر در حریم امن و بدون استرس خانه.',
						'best_title_reason' => 'تاکید بر حریم خصوصی که بزرگترین مانع بیماران برای مراجعه به مراکز است.',
						'anchors'           => array( 'فیزیوتراپی کف لگن در منزل', 'فیزیوتراپی کف لگن در خانه' ),
					),
				),
			),
			'neck'             => array(
				'matches'   => array( 'گردن' ),
				'slug_base' => 'cervical-disc-arm-numbness',
				'clusters'  => array(
					array(
						'titles'            => array(
							'علت تیر کشیدن درد گردن به شانه و خواب رفتن دست‌ها چیست؟ (تشخیص درگیری دیسک و عصب)',
							'بهترین بالش و نحوه خوابیدن برای بیماران مبتلا به دیسک و آرتروز گردن',
							'۵ تمرین ایزومتریک خانگی برای تقویت عضلات ضعیف گردن ناشی از کار با گوشی و کامپیوتر',
						),
						'angle_label'       => 'خواب‌رفتگی دست و تیر کشیدن گردن',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'اطلاعاتی تشخیصی (Informational)',
						'user_core_need'    => 'بیمار از خواب‌رفتگی شبانه دست‌ها به ستوه آمده و به دنبال درمان ریشه‌ای دیسک گردن است.',
						'best_title_reason' => 'خواب رفتن دست‌ها علامتی نگران‌کننده برای بیماران است که جستجوی ارگانیک بالایی دارد.',
						'anchors'           => array( 'فیزیوتراپی گردن در منزل', 'فیزیوتراپی تخصصی گردن در منزل' ),
					),
				),
			),
			'pelvis'           => array(
				'matches'   => array( 'لگن' ),
				'slug_base' => 'pelvic-hip-joint-pain-causes',
				'clusters'  => array(
					array(
						'titles'            => array(
							'تفاوت درد مفصل لگن با درد سیاتیک و دیسک کمر؛ چطور منشأ درد را تشخیص دهیم؟',
							'علت درد استخوان لگن هنگام راه رفتن یا بالا رفتن از پله‌ها در میانسالان',
							'تمرینات ایمن فیزیوتراپی برای تسکین بورسیت و التهاب مفصل لگن در خانه',
						),
						'angle_label'       => 'تمایز درد مفصل لگن از دیسک کمر',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'تشخیصی و تمایزی (Informational)',
						'user_core_need'    => 'بیمار نمی‌داند درد پهلو و کشاله ران مربوط به کمر است یا مفصل لگن؛ نیاز به تشخیص دارد.',
						'best_title_reason' => 'تمایز تشخیصی شفاف قبل از شروع جلسات فیزیوتراپی.',
						'anchors'           => array( 'فیزیوتراپی لگن در منزل', 'فیزیوتراپی مفصل لگن در خانه' ),
					),
				),
			),
			'ankle'            => array(
				'matches'   => array( 'مچ پا', 'خار پاشنه', 'پاشنه' ),
				'slug_base' => 'heel-spur-morning-pain',
				'clusters'  => array(
					array(
						'titles'            => array(
							'چرا صبح‌ها هنگام اولین قدم پاشنه پا تیر می‌کشد؟ درمان خار پاشنه با فیزیوتراپی در منزل',
							'تمرینات کششی فاشیای کف پا و بطری یخ برای رفع التهاب و درد پاشنه پا',
							'فیزیوتراپی پیچ‌خوردگی مچ پا بعد از باز کردن آتل؛ پیشگیری از لق شدن همیشگی مفصل',
						),
						'angle_label'       => 'درد صبحگاهی پاشنه و کشش فاشیا',
						'angle_type'        => 'symptoms',
						'intent'            => self::INTENT_INFORMATIONAL,
						'intent_fa'         => 'نشانه‌شناسی و تسکین درد (Informational)',
						'user_core_need'    => 'خلاصی از درد شدید اولین قدم صبحگاهی و راه‌حل قطعی درمان خار پاشنه بدون جراحی.',
						'best_title_reason' => 'همذات‌پنداری عمیق با شکایت بالینی «درد اولین قدم صبح».',
						'anchors'           => array( 'فیزیوتراپی مچ پا یا خار پاشنه در منزل', 'درمان خار پاشنه در منزل' ),
					),
				),
			),
		);

		foreach ( $profiles as $prof ) {
			foreach ( $prof['matches'] as $m ) {
				if ( mb_strpos( $kw, $m ) !== false ) {
					return $prof;
				}
			}
		}

		return self::build_dynamic_keyword_profile( $keyword, $biz );
	}

	/**
	 * Build dynamic, niche-agnostic SEO cluster profiles for any keyword and business.
	 *
	 * @param string $keyword Target keyword.
	 * @param array  $biz     Business data.
	 * @return array
	 */
	private static function build_dynamic_keyword_profile( $keyword, array $biz = array() ) {
		$kw        = trim( $keyword );
		$biz_name  = trim( $biz['name'] ?? '' );
		$slug_base = sanitize_title( self::generate_english_slug_from_keyword( $kw ) );
		if ( empty( $slug_base ) || 'article' === $slug_base ) {
			$slug_base = 'guide-' . substr( md5( $kw ), 0, 8 );
		}

		return array(
			'matches'   => array( $kw ),
			'slug_base' => $slug_base,
			'clusters'  => array(
				// Cluster 1: Commercial Investigation & Decision Making
				array(
					'titles'            => array(
						'راهنمای جامع انتخاب ' . $kw . '؛ بررسی هزینه‌ها، کیفیت و معیارها',
						'هزینه و تعرفه ' . $kw . ' در سال جاری (راهنمای جامع قیمت‌گذاری و عوامل موثر)',
						'۵ نکته حیاتی که قبل از سفارش و دریافت خدمات ' . $kw . ' باید بررسی کنید',
					),
					'angle_label'       => 'بررسی تجاری و راهنمای تصمیم‌گیری',
					'angle_type'        => 'commercial-decision',
					'intent'            => self::INTENT_COMMERCIAL,
					'intent_fa'         => 'بررسی تجاری و مقایسه‌ای (Commercial Investigation)',
					'user_core_need'    => 'کاربر قصد خرید، سفارش یا دریافت خدمات «' . $kw . '» را دارد و به دنبال استعلام هزینه، معیار انتخاب متخصص و شفافیت خدمات است.',
					'best_title_reason' => 'عالی‌ترین زاویه برای تبدیل جستجوگران با نیت تجاری به لید و تماس تلفنی برای ' . ( $biz_name ?: 'کسب‌وکار' ) . '.',
					'anchors'           => array( $kw, 'خدمات ' . $kw, 'بهترین ' . $kw ),
				),
				// Cluster 2: Educational & Fundamentals (Informational)
				array(
					'titles'            => array(
						$kw . ' چیست و چگونه به رشد کسب‌وکار شما کمک می‌کند؟ (صفر تا صد)',
						'مهم‌ترین مزایا، چالش‌ها و روندهای روز در حوزه ' . $kw,
						'آموزش گام‌به‌گام و نحوه اجرای اصولی ' . $kw . ' به زبان ساده',
					),
					'angle_label'       => 'آموزش جامع و راهکارهای اصولی',
					'angle_type'        => 'informational-guide',
					'intent'            => self::INTENT_INFORMATIONAL,
					'intent_fa'         => 'آموزشی و تخصصی (Informational)',
					'user_core_need'    => 'درک عمیق مفاهیم، مزیت‌ها و مراحل اجرای «' . $kw . '» جهت حل چالش‌ها و تصمیم‌گیری آگاهانه.',
					'best_title_reason' => 'کسب رتبه در کلمات کلیدی آموزشی با حجم جستجوی بالا و ایجاد اعتبار تخصصی (Topical Authority).',
					'anchors'           => array( $kw, 'آموزش ' . $kw ),
				),
				// Cluster 3: Mistakes, Checklist & Advanced Strategy
				array(
					'titles'            => array(
						'اشتباهات رایج در ' . $kw . ' و راهکارهای پیشگیری از آن‌ها',
						'چک‌لیست ارزیابی و استانداردهای ضروری در ' . $kw . ' (راهنمای عملی)',
						'مقایسه روش‌های مختلف اجرای ' . $kw . '؛ کدام گزینه برای شما مناسب‌تر است؟',
					),
					'angle_label'       => 'چک‌لیست عملیاتی و پیشگیری از اشتباهات',
					'angle_type'        => 'checklist-strategy',
					'intent'            => self::INTENT_INFORMATIONAL,
					'intent_fa'         => 'کاربردی و استراتژیک (Informational)',
					'user_core_need'    => 'جلوگیری از اتلاف هزینه و زمان در اجرای «' . $kw . '» با استفاده از چک‌لیست معتبر.',
					'best_title_reason' => 'عناوین چک‌لیستی و اشتباهات رایج بالاترین نرخ ذخیره، ارجاع و کلیک ارگانیک را دارند.',
					'anchors'           => array( $kw, 'استراتژی ' . $kw ),
				),
			),
		);
	}

	/**
	 * Map Persian domain keywords to clean English slug bases.
	 *
	 * @param string $keyword Keyword in Persian.
	 * @return string
	 */
	private static function generate_english_slug_from_keyword( $keyword ) {
		$kw = mb_strtolower( trim( $keyword ) );
		$dictionary = array(
			'سلامت دیجیتال'         => 'digital-health',
			'تحلیل داده های سلامت'   => 'health-data-analytics',
			'تحلیل داده سلامت'      => 'health-data-analytics',
			'سئو سایت پزشکی'         => 'medical-seo',
			'سئو سایت کلینیک'        => 'clinic-seo',
			'سئو پزشکی'             => 'medical-seo',
			'طراحی سایت پزشکی'       => 'medical-web-design',
			'طراحی سایت دندانپزشکی'   => 'dental-web-design',
			'طراحی سایت کلینیک'      => 'clinic-web-design',
			'طراحی سایت'            => 'web-design',
			'طراحی نرم افزار'        => 'software-development',
			'نرم افزار سلامت'       => 'health-software',
			'فیزیوتراپی در منزل'     => 'home-physiotherapy',
			'فیزیوتراپی'            => 'physiotherapy',
			'دیسک کمر'              => 'lumbar-disc',
			'ستون فقرات'            => 'spine-health',
		);

		foreach ( $dictionary as $phrase => $slug ) {
			if ( mb_strpos( $kw, $phrase ) !== false ) {
				return $slug;
			}
		}

		$slug = sanitize_title_with_dashes( $keyword );
		if ( empty( $slug ) || preg_match( '/^[%0-9\-]+$/', $slug ) ) {
			$slug = 'guide-' . substr( md5( $keyword ), 0, 8 );
		}
		return $slug;
	}

	/**
	 * Generate clean English URL slug for cluster post (without /blog/ prefix).
	 *
	 * @param string $slug_base  Base slug.
	 * @param string $angle_type Angle type.
	 * @param int    $index      Variation index.
	 * @return string
	 */
	private static function generate_cluster_slug( $slug_base, $angle_type, $index = 0 ) {
		$clean_base = preg_replace( '/[^a-z0-9\-]/', '', strtolower( $slug_base ) );
		$suffix     = ( $index > 0 ) ? '-' . $angle_type : '';
		return trim( $clean_base . $suffix, '-' );
	}

	/**
	 * Get existing tasks for business to mark task_added status.
	 *
	 * @param int $business_id Business ID.
	 * @return array
	 */
	private static function get_existing_tasks( $business_id ) {
		global $wpdb;
		$table = Database::table( 'tasks' );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, title, description, status, due_date FROM {$table} WHERE business_id = %d", $business_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Hydrate suggestions with clean slugs, live task status, and saved article/HTML draft flags.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $suggestions Suggestions.
	 * @return array
	 */
	private static function hydrate_suggestions_state( $business_id, array $suggestions ) {
		$existing = self::get_existing_tasks( $business_id );
		$drafts   = Article_Generator::get_drafts_map( $business_id );

		foreach ( $suggestions as &$sug ) {
			$bt                 = $sug['best_title'] ?? '';
			$sug['business_id'] = (int) $business_id;
			$sug['url_slug']    = self::clean_slug( $sug['url_slug'] ?? '' );
			$key                = Article_Generator::make_key( $bt );
			$sug['article_key']          = $key;
			$sug['has_article']          = ! empty( $drafts[ $key ]['has_article'] );
			$sug['has_html']             = ! empty( $drafts[ $key ]['has_html'] );
			$sug['has_image']            = ! empty( $drafts[ $key ]['has_image'] );
			$sug['images_count']         = (int) ( $drafts[ $key ]['images_count'] ?? 0 );
			$sug['has_in_content_image'] = ! empty( $drafts[ $key ]['has_in_content_image'] );
			$sug['remote_post_id']   = (int) ( $drafts[ $key ]['remote_post_id'] ?? 0 );
			$sug['remote_post_url']  = (string) ( $drafts[ $key ]['remote_post_url'] ?? '' );
			$sug['remote_status']    = (string) ( $drafts[ $key ]['remote_status'] ?? '' );
			$sug['scheduled_for']    = $drafts[ $key ]['scheduled_for'] ?? null;
			$sug['draft_updated_at'] = $drafts[ $key ]['updated_at'] ?? '';

			$sug['task_added'] = false;
			$sug['task_id']    = null;
			foreach ( $existing as $t ) {
				if ( self::is_similar_title( $t['title'], $bt ) ) {
					$sug['task_added'] = true;
					$sug['task_id']    = absint( $t['id'] );
					break;
				}
			}
		}
		unset( $sug );
		return $suggestions;
	}

	/**
	 * Title similarity check (guarded against empty or overly short substring false positives).
	 *
	 * @param string $t1 Title 1.
	 * @param string $t2 Title 2.
	 * @return bool
	 */
	private static function is_similar_title( $t1, $t2 ) {
		$t1 = preg_replace( '/[\s\-_،؛,؟?\.]+/u', '', mb_strtolower( trim( (string) $t1 ) ) );
		$t2 = preg_replace( '/[\s\-_،؛,؟?\.]+/u', '', mb_strtolower( trim( (string) $t2 ) ) );
		if ( '' === $t1 || '' === $t2 ) {
			return false;
		}
		if ( $t1 === $t2 ) {
			return true;
		}
		$min_len = min( mb_strlen( $t1 ), mb_strlen( $t2 ) );
		if ( $min_len < 12 ) {
			return false;
		}
		return false !== mb_strpos( $t1, $t2 ) || false !== mb_strpos( $t2, $t1 );
	}

	/**
	 * Prune any cached suggestions that are already scheduled in the calendar and backfill
	 * replacements at the bottom so the list stays fresh (up to 10 unscheduled items).
	 *
	 * @param int   $business_id Business ID.
	 * @param array $cached      Cached payload.
	 * @param bool  $allow_ai    Whether to call AI for backfill (false for fast cache reads).
	 * @return array
	 */
	private static function prune_and_replenish_cached( $business_id, array $cached, $allow_ai = false ) {
		$suggestions = isset( $cached['suggestions'] ) && is_array( $cached['suggestions'] ) ? $cached['suggestions'] : array();
		if ( empty( $suggestions ) ) {
			return $cached;
		}

		$existing_tasks   = self::get_existing_tasks( $business_id );
		$scheduled_titles = self::get_all_scheduled_titles( $business_id, $existing_tasks );

		$report = Site_Crawler::get_report( $business_id );
		$posts  = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['posts'] ) ) ? $report['posts'] : array();
		$pages  = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['pages'] ) ) ? $report['pages'] : array();

		$kept    = array();
		$removed = array();
		foreach ( $suggestions as $sug ) {
			$bt   = (string) ( $sug['best_title'] ?? '' );
			$slug = (string) ( $sug['url_slug'] ?? '' );
			if ( ! empty( $sug['task_added'] ) || self::is_title_excluded( $bt, $scheduled_titles, $posts, $pages, $slug ) ) {
				$removed[] = $sug;
			} else {
				$kept[] = $sug;
			}
		}

		if ( empty( $removed ) ) {
			return $cached;
		}

		$biz = Business::get( $business_id );
		if ( ! $biz || empty( $biz['keywords'] ) ) {
			$cached['suggestions']       = array_values( $kept );
			$cached['total_suggestions'] = count( $kept );
			return $cached;
		}

		$keywords = $biz['keywords'];

		$target_count = self::TARGET_SUGGESTIONS;
		$idx_rem      = 0;
		$guard        = 0;
		while ( count( $kept ) < $target_count && $guard < 25 ) {
			$guard++;
			$preferred_kw    = isset( $removed[ $idx_rem ]['keyword'] ) ? (string) $removed[ $idx_rem ]['keyword'] : '';
			$idx_rem++;
			$excluded_titles = array_merge(
				$scheduled_titles,
				array_map(
					static function ( $item ) {
						return (string) ( $item['best_title'] ?? '' );
					},
					$kept
				)
			);
			$excluded_slugs  = array_map(
				static function ( $item ) {
					return self::clean_slug( $item['url_slug'] ?? '' );
				},
				$kept
			);

			$replacement = self::build_single_replacement( $business_id, $biz, $keywords, $posts, $pages, $existing_tasks, $excluded_titles, $excluded_slugs, $preferred_kw, $allow_ai );
			if ( ! $replacement ) {
				break;
			}
			$kept[] = $replacement;
		}

		foreach ( $kept as $i => &$item ) {
			$item['id'] = $i + 1;
			unset( $item['is_new_replacement'] );
		}
		unset( $item );

		$kept                        = self::hydrate_suggestions_state( $business_id, $kept );
		$cached['suggestions']       = $kept;
		$cached['total_suggestions'] = count( $kept );
		set_transient( self::TRANSIENT_PREFIX . $business_id, $cached, self::TRANSIENT_EXPIRATION );

		return $cached;
	}

	/**
	 * Remove a scheduled suggestion from the cached list and append 1 brand-new suggestion at the bottom.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $params      { title, article_key, keyword }.
	 * @return array|\WP_Error
	 */
	public static function replace_scheduled_suggestion( $business_id, array $params = array() ) {
		$business_id = Article_Generator::resolve_business_id( $business_id, $params );
		$biz         = $business_id ? Business::get( $business_id ) : null;
		if ( ! $biz ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$biz         = Business::get( $business_id );
			}
		}
		if ( ! $biz ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$prereq = self::check_suggestions_prerequisites( $business_id );
		if ( ! $prereq['ready'] ) {
			return new \WP_Error( 'seopm_prerequisites_missing', $prereq['message'], array( 'status' => 400 ) );
		}

		$removed_title   = trim( sanitize_text_field( $params['title'] ?? $params['best_title'] ?? '' ) );
		$removed_key     = sanitize_key( $params['article_key'] ?? '' );
		$removed_keyword = trim( sanitize_text_field( $params['keyword'] ?? '' ) );

		if ( '' !== $removed_title ) {
			self::remember_scheduled_title( $business_id, $removed_title );
		}
		if ( '' !== $removed_key ) {
			Article_Generator::delete_draft( $business_id, $removed_key );
		} elseif ( '' !== $removed_title ) {
			Article_Generator::delete_draft( $business_id, Article_Generator::make_key( $removed_title ) );
		}

		$cache_key = self::TRANSIENT_PREFIX . $business_id;
		$cached    = get_transient( $cache_key );
		if ( ! is_array( $cached ) || empty( $cached['suggestions'] ) ) {
			$cached = self::get_suggestions( $business_id, false, false );
		}

		$suggestions      = isset( $cached['suggestions'] ) && is_array( $cached['suggestions'] ) ? $cached['suggestions'] : array();
		$existing_tasks   = self::get_existing_tasks( $business_id );
		$scheduled_titles = self::get_all_scheduled_titles( $business_id, $existing_tasks );
		if ( '' !== $removed_title ) {
			$scheduled_titles[] = $removed_title;
		}

		$keywords = $biz['keywords'] ?? array();
		$report   = Site_Crawler::get_report( $business_id );
		$posts    = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['posts'] ) ) ? $report['posts'] : array();
		$pages    = ( ! is_wp_error( $report ) && is_array( $report ) && ! empty( $report['pages'] ) ) ? $report['pages'] : array();

		$kept = array();
		foreach ( $suggestions as $sug ) {
			$bt   = (string) ( $sug['best_title'] ?? '' );
			$slug = (string) ( $sug['url_slug'] ?? '' );
			$key  = ! empty( $sug['article_key'] ) ? sanitize_key( $sug['article_key'] ) : Article_Generator::make_key( $bt );

			$is_target = ( '' !== $removed_key && $key === $removed_key )
				|| ( '' !== $removed_title && self::is_similar_title( $bt, $removed_title ) )
				|| self::is_title_excluded( $bt, $scheduled_titles, $posts, $pages, $slug );

			if ( $is_target ) {
				if ( '' === $removed_keyword && ! empty( $sug['keyword'] ) ) {
					$removed_keyword = (string) $sug['keyword'];
				}
				if ( '' !== $bt ) {
					self::remember_scheduled_title( $business_id, $bt );
					$scheduled_titles[] = $bt;
				}
				continue;
			}
			$kept[] = $sug;
		}

		$excluded_titles = array_values(
			array_unique(
				array_merge(
					$scheduled_titles,
					array_map(
						static function ( $item ) {
							return (string) ( $item['best_title'] ?? '' );
						},
						$kept
					)
				)
			)
		);
		$excluded_slugs  = array_values(
			array_unique(
				array_filter(
					array_map(
						static function ( $item ) {
							return self::clean_slug( $item['url_slug'] ?? '' );
						},
						$kept
					)
				)
			)
		);

		$used_ai     = false;
		$replacement = null;
		if ( ! empty( $keywords ) ) {
			$replacement = self::build_single_replacement(
				$business_id,
				$biz,
				$keywords,
				$posts,
				$pages,
				$existing_tasks,
				$excluded_titles,
				$excluded_slugs,
				$removed_keyword,
				true,
				$used_ai
			);
			if ( $replacement ) {
				$kept[] = $replacement;
			}
		}

		// Re-number sequentially and hydrate draft/slug/task states.
		$kept = self::hydrate_suggestions_state( $business_id, $kept );
		foreach ( $kept as $idx => &$item ) {
			$item['id'] = $idx + 1;
			unset( $item['is_new_replacement'] );
		}
		unset( $item );

		// Save updated list into transient WITHOUT the ephemeral highlight flag.
		$cached['suggestions']       = $kept;
		$cached['total_suggestions'] = count( $kept );
		set_transient( $cache_key, $cached, self::TRANSIENT_EXPIRATION );

		// Prepare response payload with ephemeral is_new_replacement flag on the newly appended last item.
		$response_list = $kept;
		$final_rep     = null;
		if ( $replacement && ! empty( $response_list ) ) {
			$last_idx                                      = count( $response_list ) - 1;
			$response_list[ $last_idx ]['is_new_replacement'] = true;
			$final_rep                                     = $response_list[ $last_idx ];
		}

		return array(
			'success'           => true,
			'removed_title'     => $removed_title,
			'replacement'       => $final_rep,
			'suggestions'       => $response_list,
			'total_suggestions' => count( $response_list ),
			'ai_generated'      => $used_ai,
		);
	}

	/**
	 * Build a single unique replacement suggestion (tries active AI provider first, falls back to heuristic engine).
	 *
	 * @param int    $business_id      Business ID.
	 * @param array  $biz              Business data.
	 * @param array  $keywords         Business keywords.
	 * @param array  $posts            Crawled posts.
	 * @param array  $pages            Crawled pages.
	 * @param array  $existing_tasks   Existing tasks.
	 * @param array  $excluded_titles  Titles to avoid.
	 * @param array  $excluded_slugs   Slugs to avoid.
	 * @param string $preferred_kw     Preferred keyword text (e.g. of the removed suggestion).
	 * @param bool   $allow_ai         Whether to try AI provider.
	 * @param bool   $used_ai          Output flag: true if generated via AI.
	 * @return array|null
	 */
	private static function build_single_replacement( $business_id, array $biz, array $keywords, array $posts, array $pages, array $existing_tasks, array $excluded_titles, array $excluded_slugs, $preferred_kw = '', $allow_ai = true, &$used_ai = false ) {
		$used_ai = false;

		// Pick target keyword: prefer the removed item's keyword to preserve D'Hondt weight balance.
		$target_kw = null;
		if ( '' !== trim( $preferred_kw ) ) {
			foreach ( $keywords as $kw ) {
				if ( mb_strtolower( trim( $kw['keyword'] ) ) === mb_strtolower( trim( $preferred_kw ) ) ) {
					$target_kw = $kw;
					break;
				}
			}
		}
		if ( ! $target_kw && ! empty( $keywords ) ) {
			$sorted_kws = $keywords;
			usort(
				$sorted_kws,
				static function ( $a, $b ) {
					return absint( $b['weight'] ?? 5 ) <=> absint( $a['weight'] ?? 5 );
				}
			);
			$target_kw = $sorted_kws[0];
		}

		if ( $allow_ai && $target_kw ) {
			$ai_item = self::generate_single_with_ai( $business_id, $biz, $target_kw, $keywords, $posts, $pages, $excluded_titles, $excluded_slugs );
			if ( is_array( $ai_item ) ) {
				$norm = self::normalize_ai_suggestion( $ai_item, $keywords, $pages, $posts, $biz, $existing_tasks );
				if ( $norm && ! self::is_title_excluded( $norm['best_title'], $excluded_titles, $posts, $pages, $norm['url_slug'] ?? '' ) ) {
					$norm['url_slug'] = self::ensure_unique_slug( self::clean_slug( $norm['url_slug'] ?? '' ), $excluded_slugs );
					$used_ai          = true;
					return $norm;
				}
			}
		}

		$rep = self::pick_heuristic_replacement( $biz, $keywords, $posts, $pages, $existing_tasks, $excluded_titles, $preferred_kw );
		if ( $rep ) {
			$rep['url_slug'] = self::ensure_unique_slug( self::clean_slug( $rep['url_slug'] ?? '' ), $excluded_slugs );
		}
		return $rep;
	}

	/**
	 * Ensure a slug is not duplicated among existing suggestions.
	 *
	 * @param string $slug           Candidate slug.
	 * @param array  $excluded_slugs Slugs already in use.
	 * @return string
	 */
	private static function ensure_unique_slug( $slug, array $excluded_slugs ) {
		$slug = self::clean_slug( $slug );
		if ( '' === $slug ) {
			$slug = 'cluster-article-' . wp_rand( 100, 999 );
		}
		if ( ! in_array( $slug, $excluded_slugs, true ) ) {
			return $slug;
		}
		for ( $n = 2; $n <= 20; $n++ ) {
			$try = $slug . '-' . $n;
			if ( ! in_array( $try, $excluded_slugs, true ) ) {
				return $try;
			}
		}
		return $slug . '-' . wp_rand( 100, 999 );
	}

	/**
	 * Generate a single brand-new cluster article suggestion via the active AI provider.
	 *
	 * @param int   $business_id     Business ID.
	 * @param array $biz             Business data.
	 * @param array $target_kw       Target keyword object.
	 * @param array $keywords        All business keywords.
	 * @param array $posts           Crawled posts.
	 * @param array $pages           Crawled pages.
	 * @param array $excluded_titles Titles that must not be repeated.
	 * @param array $excluded_slugs  Slugs that must not be repeated.
	 * @return array|null
	 */
	private static function generate_single_with_ai( $business_id, array $biz, array $target_kw, array $keywords, array $posts, array $pages, array $excluded_titles, array $excluded_slugs ) {
		$settings  = Settings::all();
		$active_ai = $settings['ai_active_provider'] ?? 'none';
		if ( 'none' === $active_ai || empty( $settings[ $active_ai . '_api_key' ] ) ) {
			return null;
		}

		$pillar = self::find_target_pillar( $target_kw['keyword'], $pages, $biz );

		$sitemap_url = trim( (string) ( $biz['sitemap_url'] ?? ( $biz['website_url'] ? trailingslashit( $biz['website_url'] ) . 'sitemap_index.xml' : '' ) ) );

		$ranked_pages = self::prioritize_content_for_keywords( $pages, array( $target_kw ), 35 );
		$page_summary = array();
		foreach ( $ranked_pages as $p ) {
			if ( ! empty( $p['title'] ) && ! empty( $p['url'] ) ) {
				$page_summary[] = '- ' . $p['title'] . ' | URL: ' . $p['url'];
			}
		}

		$ranked_posts = self::prioritize_content_for_keywords( $posts, array( $target_kw ), 50 );
		$post_summary = array();
		foreach ( $ranked_posts as $p ) {
			if ( ! empty( $p['title'] ) && ! empty( $p['url'] ) ) {
				$post_summary[] = '- ' . $p['title'] . ' | URL: ' . $p['url'];
			}
		}

		$excluded_sample = array_slice( array_values( array_unique( $excluded_titles ) ), -50 );
		$other_kws       = array_slice(
			array_map(
				static function ( $k ) {
					return $k['keyword'] . ' (وزن ' . absint( $k['weight'] ?? 5 ) . ')';
				},
				$keywords
			),
			0,
			15
		);

		$system_prompt = 'تو یک متخصص ارشد SEO، استراتژیست محتوای کلاستر و متخصص پیشگیری از Cannibalization فارسی هستی. دقیقاً یک پیشنهاد مقاله کلاستر جدید، غیرتکراری، متناسب با نقشه سایت و باارزش را فقط و فقط به‌صورت یک آبجکت JSON معتبر و بدون هیچ توضیح اضافه خروجی بده.';

		$single_biz_details = array();
		$single_biz_details[] = '- نام کسب‌وکار: ' . ( $biz['name'] ?? '' );
		$single_biz_details[] = '- وب‌سایت: ' . ( $biz['website_url'] ?? '' );
		$single_biz_details[] = '- آدرس نقشه سایت (Sitemap URL): ' . ( $sitemap_url ?: '—' );
		if ( ! empty( $biz['industry_services'] ) ) {
			$single_biz_details[] = '- حوزه فعالیت و خدمات یا محصولات اصلی: ' . $biz['industry_services'];
		}
		if ( ! empty( $biz['target_location'] ) ) {
			$single_biz_details[] = '- شهر یا کشور هدف (محدوده جغرافیایی): ' . $biz['target_location'];
		}
		if ( ! empty( $biz['focus_products_services'] ) ) {
			$single_biz_details[] = '- خدمات یا محصولاتی که اولویت تمرکز هستند: ' . $biz['focus_products_services'];
		}
		if ( ! empty( $biz['target_audience'] ) ) {
			$single_biz_details[] = '- ویژگی‌های مخاطب هدف و دغدغه‌های آن‌ها: ' . $biz['target_audience'];
		}

		$user_prompt = "یک مقاله کلاستر جدید برای جایگزینی در لیست مقالات پیشنهادی وب‌سایت زیر تولید کن.\n\n" .
			"اطلاعات کسب‌وکار:\n" .
			implode( "\n", $single_biz_details ) . "\n" .
			"- کلمه کلیدی اولویت‌دار این جایگزین: " . $target_kw['keyword'] . " (وزن: " . absint( $target_kw['weight'] ?? 5 ) . ")\n" .
			"- صفحه پیلار مرتبط در نقشه سایت: " . ( $pillar['title'] ?? '' ) . ' | ' . ( $pillar['url'] ?? '' ) . "\n" .
			"- سایر کلمات کلیدی پروژه: " . implode( '، ', $other_kws ) . "\n\n" .
			"=== نقشه سایت و ساختار صفحات موجود وب‌سایت (Sitemap) ===\n" .
			( ! empty( $page_summary ) ? "صفحات لندینگ و پیلارها از نقشه سایت:\n" . implode( "\n", $page_summary ) . "\n\n" : '' ) .
			( ! empty( $post_summary ) ? "مقالات منتشرشده وبلاگ از نقشه سایت:\n" . implode( "\n", $post_summary ) . "\n\n" : '' ) .
			"عناوین فعلی لیست و مقالات قبلاً ثبت‌شده در تقویم (مطلقاً تکراری یا مشابه این‌ها نباشد):\n- " .
			implode( "\n- ", $excluded_sample ) . "\n\n" .
			"دستورالعمل حیاتی تحلیل نقشه سایت:\n" .
			"عنوان جدید نباید با هیچ‌یک از مقالات یا صفحات موجود در نقشه سایت بالا تکراری، هم‌پوشان یا رقیب باشد (Cannibalization Zero). زاویه‌ای بکر با ارزش اطلاعاتی بالا پیشنهاد بده.\n\n" .
			"خروجی دقیقاً یک شیء JSON با ساختار زیر باشد (فقط ۱ مقاله):\n" .
			"{\n" .
			'  "keyword": "' . $target_kw['keyword'] . '",' . "\n" .
			'  "weight": ' . absint( $target_kw['weight'] ?? 5 ) . ",\n" .
			'  "search_intent": "Informational یا Commercial Investigation",' . "\n" .
			'  "search_intent_fa": "اطلاعاتی یا بررسی تجاری",' . "\n" .
			'  "user_core_need": "نیاز دقیق کاربر",' . "\n" .
			'  "best_title": "یک عنوان جدید، تخصصی، جذاب و غیرتکراری فارسی",' . "\n" .
			'  "best_title_reason": "دلیل انتخاب این عنوان",' . "\n" .
			'  "titles": ["عنوان ۱", "عنوان ۲", "عنوان ۳"],' . "\n" .
			'  "url_slug": "short-clean-english-slug",' . "\n" .
			'  "decision": "create_new",' . "\n" .
			'  "decision_label": "تولید مقاله کلاستر جدید توصیه می‌شود",' . "\n" .
			'  "decision_reason": "پوشش خلاء موضوعی و تقویت صفحه پیلار",' . "\n" .
			'  "cannibalization_risk": "کم",' . "\n" .
			'  "pillar": {' . "\n" .
			'    "target_pillar_title": "' . ( $pillar['title'] ?? $target_kw['keyword'] ) . '",' . "\n" .
			'    "target_pillar_url": "' . ( $pillar['url'] ?? ( $biz['website_url'] ?? '' ) ) . '",' . "\n" .
			'    "pillar_role": "لندینگ خدمات تجاری",' . "\n" .
			'    "primary_anchor": "' . ( $pillar['exact_anchor'] ?? $target_kw['keyword'] ) . '",' . "\n" .
			'    "secondary_anchors": ["انکر توصیفی ۱", "انکر توصیفی ۲"],' . "\n" .
			'    "placement_strategy": {' . "\n" .
			'      "main_link": "لینک متنی اصلی در بدنه مقاله روی انکرتکست دقیق یا توصیفی.",' . "\n" .
			'      "cta_link": "باکس دعوت به اقدام (CTA) در انتهای مقاله جهت تماس و ثبت درخواست خدمت."' . "\n" .
			"    }\n" .
			"  }\n" .
			"}";

		$ai_res = AI_Client::generate(
			$user_prompt,
			$system_prompt,
			array(
				'max_tokens' => 1800,
				'timeout'    => 45,
			)
		);
		if ( empty( $ai_res['success'] ) || empty( $ai_res['text'] ) ) {
			return null;
		}

		$parsed = AI_Client::parse_json( $ai_res['text'] );
		if ( ! is_array( $parsed ) ) {
			return null;
		}
		if ( isset( $parsed['suggestions'][0] ) && is_array( $parsed['suggestions'][0] ) ) {
			return $parsed['suggestions'][0];
		}
		if ( isset( $parsed['suggestion'] ) && is_array( $parsed['suggestion'] ) ) {
			return $parsed['suggestion'];
		}
		if ( ! empty( $parsed['best_title'] ) ) {
			return $parsed;
		}
		return null;
	}

	/**
	 * Pick a fresh, non-duplicate heuristic replacement suggestion.
	 *
	 * @param array  $biz             Business data.
	 * @param array  $keywords        Business keywords.
	 * @param array  $posts           Crawled posts.
	 * @param array  $pages           Crawled pages.
	 * @param array  $existing_tasks  Existing tasks.
	 * @param array  $excluded_titles Titles to avoid.
	 * @param string $preferred_kw    Preferred keyword text.
	 * @return array|null
	 */
	private static function pick_heuristic_replacement( array $biz, array $keywords, array $posts, array $pages, array $existing_tasks, array $excluded_titles, $preferred_kw = '' ) {
		if ( empty( $keywords ) ) {
			return null;
		}

		// Order keywords: preferred keyword first, then remaining by weight DESC.
		$ordered = $keywords;
		usort(
			$ordered,
			static function ( $a, $b ) use ( $preferred_kw ) {
				$a_pref = '' !== $preferred_kw && mb_strtolower( trim( $a['keyword'] ) ) === mb_strtolower( trim( $preferred_kw ) );
				$b_pref = '' !== $preferred_kw && mb_strtolower( trim( $b['keyword'] ) ) === mb_strtolower( trim( $preferred_kw ) );
				if ( $a_pref !== $b_pref ) {
					return $a_pref ? -1 : 1;
				}
				return absint( $b['weight'] ?? 5 ) <=> absint( $a['weight'] ?? 5 );
			}
		);

		// Pass 1: Try unused primary candidate titles across ordered keywords.
		$all_candidates = array();
		foreach ( $ordered as $kw ) {
			$kw_text = trim( $kw['keyword'] );
			$pillar  = self::find_target_pillar( $kw_text, $pages, $biz );
			$closest = self::find_closest_content( $kw_text, $posts, $pages );
			$cands   = self::generate_candidates_for_keyword( $kw, $pillar, $closest, $posts, $pages, $existing_tasks, $biz );
			foreach ( $cands as $c ) {
				$all_candidates[] = $c;
				if ( ! self::is_title_excluded( $c['best_title'], $excluded_titles, $posts, $pages, $c['url_slug'] ?? '' ) ) {
					return $c;
				}
			}
		}

		// Pass 2: Promote unused alternate titles (titles[1], titles[2]) from existing cluster candidates.
		foreach ( $all_candidates as $c ) {
			$alts = isset( $c['titles'] ) && is_array( $c['titles'] ) ? $c['titles'] : array();
			foreach ( $alts as $idx => $alt_title ) {
				if ( 0 === $idx ) {
					continue;
				}
				$alt_slug = self::clean_slug( ( $c['url_slug'] ?? 'article' ) . '-v' . ( $idx + 1 ) );
				if ( ! self::is_title_excluded( $alt_title, $excluded_titles, $posts, $pages, $alt_slug ) ) {
					$promoted               = $c;
					$promoted['best_title'] = $alt_title;
					$promoted['url_slug']   = $alt_slug;
					$promoted['task_added'] = false;
					$promoted['task_id']    = null;
					return $promoted;
				}
			}
		}

		// Pass 3: Synthesize a fresh strategic cluster angle for the top keyword so replacement never fails.
		$top_kw   = $ordered[0];
		$kw_text  = trim( $top_kw['keyword'] );
		$pillar   = self::find_target_pillar( $kw_text, $pages, $biz );
		$closest  = self::find_closest_content( $kw_text, $posts, $pages );
		$angles   = array(
			array( 'title' => 'اشتباهات پرهزینه و باورهای غلط درباره ' . $kw_text . ' که روند بهبودی را کند می‌کند', 'slug' => 'common-mistakes', 'label' => 'اشتباهات رایج و باورهای غلط', 'intent' => self::INTENT_INFORMATIONAL, 'intent_fa' => 'آگاهی‌بخشی و اصلاح باور غلط (Informational)' ),
			array( 'title' => 'چند جلسه ' . $kw_text . ' لازم است؟ جدول زمان‌بندی بهبودی و عوامل مؤثر بر نتیجه', 'slug' => 'sessions-timeline', 'label' => 'تعداد جلسات و زمان‌بندی بهبودی', 'intent' => self::INTENT_COMMERCIAL, 'intent_fa' => 'بررسی تجاری و تصمیم‌گیری (Commercial)' ),
			array( 'title' => 'چک‌لیست آماده‌سازی پیش از شروع ' . $kw_text . ' و نکاتی که باید بدانید', 'slug' => 'preparation-checklist', 'label' => 'چک‌لیست آماده‌سازی بیمار', 'intent' => self::INTENT_INFORMATIONAL, 'intent_fa' => 'راهنمای کاربردی (Informational)' ),
			array( 'title' => 'مقایسه روش‌های مختلف ' . $kw_text . '؛ کدام پروتکل برای شرایط شما مناسب‌تر است؟', 'slug' => 'methods-comparison', 'label' => 'مقایسه روش‌ها و پروتکل‌ها', 'intent' => self::INTENT_COMMERCIAL, 'intent_fa' => 'مقایسه‌ای و تصمیم‌گیری (Commercial)' ),
			array( 'title' => 'علائم هشداردهنده پس از ' . $kw_text . '؛ چه زمانی باید با متخصص تماس بگیرید؟', 'slug' => 'warning-signs', 'label' => 'علائم خطر و مراقبت ایمن', 'intent' => self::INTENT_INFORMATIONAL, 'intent_fa' => 'نشانه‌شناسی و ایمنی (Informational)' ),
		);

		foreach ( $angles as $ang ) {
			if ( ! self::is_title_excluded( $ang['title'], $excluded_titles, $posts, $pages, $ang['slug'] ?? '' ) ) {
				$score_data = self::calculate_score( $top_kw, array( 'intent' => $ang['intent'], 'angle_type' => 'care' ), $pillar, $closest );
				return array(
					'id'                   => 0,
					'keyword_id'           => absint( $top_kw['id'] ?? 0 ),
					'keyword'              => $kw_text,
					'weight'               => absint( $top_kw['weight'] ?? 5 ),
					'score'                => $score_data['total'],
					'score_breakdown'      => $score_data['breakdown'],
					'best_title'           => $ang['title'],
					'titles'               => array( $ang['title'] ),
					'best_title_reason'    => 'زاویه کلاستر تکمیلی برای پوشش خلاء موضوعی و تقویت صفحه پیلار هدف.',
					'search_intent'        => $ang['intent'],
					'search_intent_fa'     => $ang['intent_fa'],
					'decision'             => 'recommended_new',
					'decision_label'       => 'تولید مقاله کلاستر جدید (حمایت از پیلار)',
					'decision_reason'      => 'تکمیل پوشش موضوعی (Topical Authority) برای کلیدواژه «' . $kw_text . '» بدون هم‌پوشانی با مقالات قبلی.',
					'user_core_need'       => 'پاسخ دقیق، علمی و کاربردی به دغدغه‌های واقعی کاربر درباره ' . $kw_text,
					'url_slug'             => sanitize_title( $ang['slug'] . '-' . absint( $top_kw['id'] ?? 1 ) ),
					'cannibalization_risk' => 'کم',
					'angle_label'          => $ang['label'],
					'task_added'           => false,
					'task_id'              => null,
					'pillar'               => array(
						'target_pillar_title' => $pillar['title'],
						'target_pillar_url'   => $pillar['url'],
						'pillar_role'         => $pillar['role'],
						'primary_anchor'      => $pillar['exact_anchor'],
						'secondary_anchors'   => array( $kw_text ),
						'placement_strategy'  => array(
							'intro_link' => 'لینک اول در مقدمه روی انکرتکست دقیق «' . $pillar['exact_anchor'] . '».',
							'body_link'  => 'لینک دوم در بدنه مقاله روی انکر توصیفی.',
							'cta_link'   => 'لینک سوم به‌صورت طبیعی در بخش نتیجه‌گیری.',
						),
						'reverse_link_guide'  => 'پس از انتشار، در صفحه پیلار «' . $pillar['title'] . '» یک پاراگراف معرفی به این مقاله با انکر «' . $ang['title'] . '» اضافه شود.',
					),
					'sister_cluster_link'  => array(
						'target_topic' => 'مقاله کلاستر مکمل پیرامون ' . $kw_text,
						'anchor_text'  => 'راهنمای تکمیلی ' . $kw_text,
						'rationale'    => 'پیوند افقی دو مقاله هم‌خانواده جهت تقویت تاپیک کلاستر.',
					),
					'audit'                => array(
						'total_urls_checked'     => count( $posts ) + count( $pages ),
						'matched_existing_count' => count( $closest ),
						'closest_pages'          => array_slice( $closest, 0, 4 ),
					),
				);
			}
		}

		return null;
	}

	/**
	 * Add suggested article directly to task calendar, remove it from suggestions, and append a replacement.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $params      Task data (title, due_date, description, etc.).
	 * @return array|\WP_Error
	 */
	public static function add_to_tasks( $business_id, array $params ) {
		$business_id = Article_Generator::resolve_business_id( $business_id, $params );
		if ( ! $business_id || ! Business::exists( $business_id ) ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'کسب‌وکار معتبر نیست.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$prereq = self::check_suggestions_prerequisites( $business_id );
		if ( ! $prereq['ready'] ) {
			return new \WP_Error( 'seopm_prerequisites_missing', $prereq['message'], array( 'status' => 400 ) );
		}

		$title = sanitize_text_field( $params['title'] ?? '' );
		if ( empty( $title ) ) {
			return new \WP_Error( 'seopm_missing_title', __( 'عنوان مقاله الزامی است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$task_type = sanitize_key( $params['task_type'] ?? 'article_writing' );
		if ( ! isset( Task::types()[ $task_type ] ) ) {
			$task_type = 'article_writing';
		}

		// Gregorian ISO due date (Y-m-d).
		$due_date = Security::sanitize_date( $params['due_date'] ?? '' );
		if ( empty( $due_date ) ) {
			try {
				$due_date = ( new \DateTimeImmutable( '+7 days', wp_timezone() ) )->format( 'Y-m-d' );
			} catch ( \Exception $e ) {
				$due_date = gmdate( 'Y-m-d', strtotime( '+7 days' ) );
			}
		}

		$desc = sanitize_textarea_field( $params['description'] ?? '' );
		if ( empty( $desc ) ) {
			$desc = 'تولید محتوای مقاله کلاستر بر اساس استراتژی سئو و لینک‌سازی به صفحه پیلار اصلی خدمات.';
		}

		$created = Task::create(
			array(
				'title'       => $title,
				'business_id' => $business_id,
				'task_type'   => $task_type,
				'due_date'    => $due_date,
				'description' => $desc,
				'status'      => 'pending',
			)
		);

		if ( is_wp_error( $created ) ) {
			return $created;
		}

		$replaced = self::replace_scheduled_suggestion(
			$business_id,
			array(
				'title'       => $title,
				'article_key' => sanitize_key( $params['article_key'] ?? '' ),
				'keyword'     => sanitize_text_field( $params['keyword'] ?? '' ),
			)
		);

		return array(
			'success'     => true,
			'task'        => $created,
			'replacement' => ! is_wp_error( $replaced ) ? ( $replaced['replacement'] ?? null ) : null,
			'suggestions' => ! is_wp_error( $replaced ) ? ( $replaced['suggestions'] ?? null ) : null,
			'message'     => __( 'مقاله در تقویم ثبت و از لیست حذف شد؛ یک عنوان جدید به انتهای لیست اضافه گردید.', 'seo-project-manager' ),
		);
	}
}

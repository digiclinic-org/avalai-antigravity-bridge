<?php
/**
 * Plugin bootstrap.
 *
 * @package SEOPM
 */

namespace SEOPM;

use SEOPM\Admin\Admin_Menu;
use SEOPM\Admin\Admin_Pages;

defined( 'ABSPATH' ) || exit;

/**
 * Main plugin class (singleton).
 */
final class Plugin {

	/**
	 * Instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		load_plugin_textdomain( 'seo-project-manager', false, dirname( plugin_basename( SEOPM_FILE ) ) . '/languages' );

		Database::maybe_upgrade();

		add_action( 'rest_api_init', array( new Rest_Api(), 'register_routes' ) );
		add_action( 'template_redirect', array( 'SEOPM\\Article_Preview', 'maybe_render' ), 1 );
		add_action( 'init', array( 'SEOPM\\Telegram_Client', 'ensure_cron' ) );
		add_action( Telegram_Client::CRON_HOOK, array( 'SEOPM\\Telegram_Client', 'run_daily_pre_publish_notifications' ) );

		if ( is_admin() ) {
			$pages = new Admin_Pages();
			( new Admin_Menu( $pages ) )->init();
			$pages->init();
		}
	}
}

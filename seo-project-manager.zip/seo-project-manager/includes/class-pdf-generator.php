<?php
/**
 * PDF generation (mPDF) and secure file storage.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * PDF generator.
 */
class Pdf_Generator {

	const DIR = 'seopm-reports';

	/**
	 * Storage base directory (no trailing slash).
	 *
	 * @return string
	 */
	public static function base_dir() {
		$uploads = wp_upload_dir( null, false );
		return untrailingslashit( $uploads['basedir'] ) . '/' . self::DIR;
	}

	/**
	 * Create storage directory and block direct web access.
	 *
	 * @return bool
	 */
	public static function ensure_storage() {
		$base = self::base_dir();
		if ( ! wp_mkdir_p( $base . '/tmp' ) ) {
			return false;
		}
		$files = array(
			'.htaccess'  => "# Deny direct access to SEO Project Manager reports\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tOrder deny,allow\n\tDeny from all\n</IfModule>\n",
			'index.php'  => "<?php\n// Silence is golden.\n",
			'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
		);
		foreach ( $files as $name => $content ) {
			if ( ! file_exists( $base . '/' . $name ) ) {
				file_put_contents( $base . '/' . $name, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			}
		}
		return true;
	}

	/**
	 * Resolve a stored relative path to an absolute path inside the storage dir.
	 * Prevents path traversal.
	 *
	 * @param string $relative Relative path.
	 * @return string|null
	 */
	public static function absolute( $relative ) {
		if ( ! is_string( $relative ) || '' === $relative || false !== strpos( $relative, '..' ) ) {
			return null;
		}
		$base = realpath( self::base_dir() );
		$full = realpath( self::base_dir() . '/' . ltrim( $relative, '/' ) );
		if ( ! $base || ! $full || 0 !== strpos( $full, $base . DIRECTORY_SEPARATOR ) || ! is_file( $full ) ) {
			return null;
		}
		return $full;
	}

	/**
	 * Whether a stored file exists.
	 *
	 * @param string $relative Relative path.
	 * @return bool
	 */
	public static function exists( $relative ) {
		return null !== self::absolute( $relative );
	}

	/**
	 * Delete a stored file.
	 *
	 * @param string $relative Relative path.
	 */
	public static function delete_file( $relative ) {
		$abs = self::absolute( (string) $relative );
		if ( $abs ) {
			wp_delete_file( $abs );
		}
	}

	/**
	 * Load mPDF.
	 *
	 * @return bool
	 */
	private static function load_library() {
		if ( ! class_exists( '\Mpdf\Mpdf' ) && file_exists( SEOPM_PATH . 'vendor/autoload.php' ) ) {
			require_once SEOPM_PATH . 'vendor/autoload.php';
		}
		return class_exists( '\Mpdf\Mpdf' );
	}

	/**
	 * Generate a PDF from a frozen snapshot.
	 *
	 * @param int         $report_id  Report ID.
	 * @param int         $version_no Version.
	 * @param array       $snapshot   Snapshot.
	 * @param string      $summary    Manager summary (HTML).
	 * @param string|null $old_path   Previous file to replace.
	 * @return string|\WP_Error Relative path.
	 */
	public static function generate( $report_id, $version_no, array $snapshot, $summary, $old_path = null ) {
		if ( ! self::load_library() ) {
			return new \WP_Error( 'seopm_pdf_library', __( 'کتابخانه تولید PDF یافت نشد.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}
		if ( empty( $snapshot['business'] ) ) {
			return new \WP_Error( 'seopm_pdf_snapshot', __( 'داده‌های گزارش ناقص است.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}
		if ( ! self::ensure_storage() ) {
			return new \WP_Error( 'seopm_pdf_storage', __( 'پوشه ذخیره گزارش‌ها قابل ایجاد نیست.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}

		wp_raise_memory_limit( 'admin' );
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		$fonts = Settings::pdf_fonts();
		$font  = $snapshot['branding']['pdf_font'] ?? 'xbriyaz';
		$font  = isset( $fonts[ $font ] ) ? $font : 'xbriyaz';

		$year     = gmdate( 'Y' );
		$relative = $year . '/report-' . (int) $report_id . '-v' . (int) $version_no . '-' . wp_generate_password( 24, false, false ) . '.pdf';
		$absolute = self::base_dir() . '/' . $relative;
		wp_mkdir_p( dirname( $absolute ) );

		try {
			$mpdf = new \Mpdf\Mpdf(
				array(
					'mode'                => 'utf-8',
					'format'              => 'A4',
					'default_font'        => $font,
					'default_font_size'   => 10,
					'directionality'      => 'rtl',
					'margin_top'          => 26,
					'margin_bottom'       => 20,
					'margin_left'         => 15,
					'margin_right'        => 15,
					'margin_header'       => 8,
					'margin_footer'       => 8,
					'tempDir'             => self::base_dir() . '/tmp',
					'defaultPageNumStyle' => 'persian',
				)
			);
			$mpdf->use_kwt = true;
			$mpdf->SetTitle( (string) ( $snapshot['title'] ?? '' ) );
			$mpdf->SetAuthor( (string) ( $snapshot['branding']['agency_name'] ?? '' ) );
			$mpdf->SetCreator( 'SEO Project Manager' );
			$mpdf->WriteHTML( self::render_html( $snapshot, $summary, $font ) );
			$mpdf->Output( $absolute, \Mpdf\Output\Destination::FILE );
		} catch ( \Throwable $e ) {
			if ( file_exists( $absolute ) ) {
				wp_delete_file( $absolute );
			}
			return new \WP_Error( 'seopm_pdf_failed', __( 'تولید PDF با خطا مواجه شد: ', 'seo-project-manager' ) . $e->getMessage(), array( 'status' => 500 ) );
		}

		if ( $old_path && $old_path !== $relative ) {
			self::delete_file( $old_path );
		}
		return $relative;
	}

	/**
	 * Render report HTML for mPDF.
	 *
	 * @param array  $snapshot Snapshot.
	 * @param string $summary  Summary HTML.
	 * @param string $font     Font family key.
	 * @return string
	 */
	public static function render_html( array $snapshot, $summary, $font = 'xbriyaz' ) {
		$view = self::view_model( $snapshot, $summary );
		$view['font'] = $font;
		ob_start();
		include SEOPM_PATH . 'templates/pdf/report-template.php';
		return (string) ob_get_clean();
	}

	/**
	 * Prepare template variables (shared by PDF and screen view).
	 *
	 * @param array  $snapshot Snapshot.
	 * @param string $summary  Summary.
	 * @return array
	 */
	public static function view_model( array $snapshot, $summary ) {
		$branding = $snapshot['branding'] ?? array();
		$business = $snapshot['business'] ?? array();
		$accent   = ! empty( $branding['use_business_color'] ) || empty( $branding['report_color'] )
			? ( $business['color'] ?? '#4f46e5' )
			: $branding['report_color'];
		$accent   = Security::sanitize_color( $accent );
		$tasks    = $snapshot['tasks'] ?? array();

		$grouped = array();
		foreach ( $tasks as $task ) {
			$grouped[ $task['task_type'] ][] = $task;
		}

		$remaining = array_values(
			array_filter(
				$tasks,
				static function ( $t ) {
					return 'completed' !== $t['status'] && empty( $t['overdue'] );
				}
			)
		);
		$overdue   = array_values(
			array_filter(
				$tasks,
				static function ( $t ) {
					return ! empty( $t['overdue'] );
				}
			)
		);
		$completed = array_values(
			array_filter(
				$tasks,
				static function ( $t ) {
					return 'completed' === $t['status'];
				}
			)
		);

		$logo = '';
		if ( ! empty( $branding['logo_path'] ) && file_exists( $branding['logo_path'] ) ) {
			$logo = $branding['logo_path'];
		} elseif ( ! empty( $branding['logo_url'] ) ) {
			$logo = $branding['logo_url'];
		}

		return array(
			'snapshot'  => $snapshot,
			'branding'  => $branding,
			'business'  => $business,
			'stats'     => $snapshot['stats'] ?? array(),
			'by_type'   => $snapshot['by_type'] ?? array(),
			'labels'    => $snapshot['labels'] ?? array( 'types' => Task::types(), 'statuses' => Task::statuses() ),
			'trend'     => $snapshot['trend'] ?? array( 'labels' => array(), 'values' => array() ),
			'tasks'     => $tasks,
			'grouped'   => $grouped,
			'remaining' => $remaining,
			'overdue'   => $overdue,
			'completed' => $completed,
			'summary'   => (string) $summary,
			'accent'    => $accent,
			'theme'     => $branding['report_theme'] ?? 'light',
			'logo'      => $logo,
			'default_logo' => SEOPM_PATH . 'assets/images/logo-default.svg',
		);
	}

	/**
	 * Safe download file name.
	 *
	 * @param array $report Report (from Report::get()).
	 * @return string
	 */
	public static function download_name( array $report ) {
		$name = sanitize_file_name( $report['title'] );
		if ( '' === $name || '.pdf' === $name ) {
			$name = 'report-' . $report['id'];
		}
		return $name . '-v' . $report['version_no'] . '.pdf';
	}

	/**
	 * Stream a PDF to the browser and exit.
	 *
	 * @param string $absolute Absolute path (already validated).
	 * @param string $filename Download name.
	 */
	public static function stream( $absolute, $filename, $fallback = 'report.pdf' ) {
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $fallback ) . '"; filename*=UTF-8\'\'' . rawurlencode( $filename ) );
		header( 'Content-Length: ' . filesize( $absolute ) );
		header( 'X-Content-Type-Options: nosniff' );
		readfile( $absolute ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}
}

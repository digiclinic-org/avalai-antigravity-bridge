<?php
/**
 * Deactivation routines. User data is never removed here.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Deactivator.
 */
class Deactivator {

	/**
	 * Plugin deactivation.
	 */
	public static function deactivate() {
		// Intentionally keeps all tables, options, capabilities and report files.
		wp_clear_scheduled_hook( Telegram_Client::CRON_HOOK );
		flush_rewrite_rules( false );
	}
}

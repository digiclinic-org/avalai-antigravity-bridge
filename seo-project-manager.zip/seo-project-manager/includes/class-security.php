<?php
/**
 * Security helpers: capability checks and sanitizers.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Security.
 */
class Security {

	const CAP = 'seopm_manage';

	/**
	 * Whether the current user can use the plugin.
	 *
	 * @return bool
	 */
	public static function can_manage() {
		return current_user_can( self::CAP );
	}

	/**
	 * REST permission callback.
	 *
	 * @return true|\WP_Error
	 */
	public static function rest_permission() {
		if ( self::can_manage() ) {
			return true;
		}
		return new \WP_Error(
			'seopm_forbidden',
			__( 'شما مجوز دسترسی به این بخش را ندارید.', 'seo-project-manager' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Validate and normalize a Y-m-d date.
	 *
	 * @param mixed $value Raw value.
	 * @return string|null
	 */
	public static function sanitize_date( $value ) {
		if ( ! is_string( $value ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $value, $m ) ) {
			return null;
		}
		if ( ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return null;
		}
		return $value;
	}

	/**
	 * Sanitize a hex color, falling back to a default.
	 *
	 * @param mixed  $value   Raw value.
	 * @param string $default Default color.
	 * @return string
	 */
	public static function sanitize_color( $value, $default = '#4f46e5' ) {
		$color = is_string( $value ) ? sanitize_hex_color( $value ) : null;
		if ( ! $color ) {
			return $default;
		}
		if ( 4 === strlen( $color ) ) {
			$color = '#' . $color[1] . $color[1] . $color[2] . $color[2] . $color[3] . $color[3];
		}
		return strtolower( $color );
	}

	/**
	 * Sanitize an optional URL (empty string allowed).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_url( $value ) {
		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return '';
		}
		$value = trim( $value );
		if ( ! preg_match( '#^https?://#i', $value ) ) {
			$value = 'https://' . $value;
		}
		return esc_url_raw( $value, array( 'http', 'https' ) );
	}

	/**
	 * Parse a list of positive integer IDs from array or comma string.
	 *
	 * @param mixed $value Raw value.
	 * @return int[]
	 */
	public static function id_list( $value ) {
		if ( is_string( $value ) ) {
			$value = '' === $value ? array() : explode( ',', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		return array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );
	}
}

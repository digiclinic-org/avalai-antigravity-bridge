<?php
/**
 * Remote WordPress Publisher (Scheduled 21:00 publishing + Featured Image upload + Rank Math SEO sync).
 *
 * Strictly requires: Title + Clean Slug + Generated HTML + Featured Image before sending.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * WP_Publisher service.
 */
class WP_Publisher {

	/**
	 * Build Basic Auth header for WordPress Application Passwords.
	 *
	 * @param string $username WordPress username.
	 * @param string $password Application password (spaces are safe to strip or keep).
	 * @return string
	 */
	private static function auth_header( $username, $password ) {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		return 'Basic ' . base64_encode( trim( (string) $username ) . ':' . trim( (string) $password ) );
	}

	/**
	 * Normalize target site base URL to REST root (https://site.tld/wp-json).
	 *
	 * @param string $site_url Website URL.
	 * @return string
	 */
	private static function rest_root( $site_url ) {
		$url = untrailingslashit( trim( (string) $site_url ) );
		if ( '' === $url ) {
			return '';
		}
		if ( ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . $url;
		}
		$url = preg_replace( '#/wp-json(?:/.*)?$#i', '', $url );
		return untrailingslashit( $url ) . '/wp-json';
	}

	/**
	 * Test WordPress REST API + Application Password connection and fetch categories & Rank Math status.
	 *
	 * @param int   $business_id Business ID (0 allowed if testing unsaved business).
	 * @param array $override    Optional unsaved credentials { website_url, wp_username, wp_app_password }.
	 * @return array|\WP_Error
	 */
	public static function test_connection( $business_id = 0, array $override = array() ) {
		$creds = $business_id ? Business::get_wp_credentials( $business_id ) : array();
		if ( ! is_array( $creds ) ) {
			$creds = array();
		}

		$site_url = trim( (string) ( $override['website_url'] ?? $creds['website_url'] ?? '' ) );
		$username = trim( (string) ( $override['wp_username'] ?? $creds['wp_username'] ?? '' ) );
		$password = trim( (string) ( $override['wp_app_password'] ?? '' ) );
		if ( '' === $password || false !== strpos( $password, '****' ) || false !== strpos( $password, '...' ) ) {
			$password = trim( (string) ( $creds['wp_app_password'] ?? '' ) );
		}

		if ( '' === $site_url ) {
			return new \WP_Error( 'seopm_wp_no_url', __( 'آدرس وب‌سایت کسب‌وکار وارد نشده است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		if ( '' === $username || '' === $password ) {
			return new \WP_Error( 'seopm_wp_no_creds', __( 'نام کاربری وردپرس و رمز عبور برنامه (Application Password) را وارد کنید.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$root    = self::rest_root( $site_url );
		$headers = array(
			'Authorization' => self::auth_header( $username, $password ),
			'Accept'        => 'application/json',
		);

		$start = microtime( true );
		// Use /wp/v2/types/post?context=edit instead of /wp/v2/users/me because many hardened
		// WordPress hosts block /wp/v2/users* to prevent username enumeration.
		// WordPress core enforces edit_posts capability for context=edit on post types.
		$res   = wp_remote_get(
			$root . '/wp/v2/types/post?context=edit',
			array(
				'timeout' => 25,
				'headers' => $headers,
			)
		);
		$ms    = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( is_wp_error( $res ) ) {
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطا در اتصال به سایت مقصد: %s', 'seo-project-manager' ), $res->get_error_message() ),
			);
		}

		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( $code < 200 || $code >= 300 || ! is_array( $body ) || empty( $body['capabilities'] ) ) {
			$err = is_array( $body ) && ! empty( $body['message'] ) ? $body['message'] : ( 'HTTP ' . $code );
			return array(
				'success' => false,
				'message' => sprintf( __( 'احراز هویت در وردپرس مقصد ناموفق بود (%1$d): %2$s', 'seo-project-manager' ), $code, $err ),
			);
		}

		// Optionally fetch display name if /wp/v2/users/me is not blocked by host security rules.
		$user_label = $username;
		$me_res     = wp_remote_get(
			$root . '/wp/v2/users/me',
			array(
				'timeout' => 10,
				'headers' => $headers,
			)
		);
		if ( ! is_wp_error( $me_res ) && 200 === wp_remote_retrieve_response_code( $me_res ) ) {
			$me_body = json_decode( wp_remote_retrieve_body( $me_res ), true );
			if ( is_array( $me_body ) && ! empty( $me_body['name'] ) ) {
				$user_label = (string) $me_body['name'];
			}
		}

		// Fetch post categories for default category dropdown.
		$categories = array();
		$cat_res    = wp_remote_get(
			$root . '/wp/v2/categories?per_page=100&orderby=count&order=desc',
			array(
				'timeout' => 20,
				'headers' => $headers,
			)
		);
		if ( ! is_wp_error( $cat_res ) && wp_remote_retrieve_response_code( $cat_res ) === 200 ) {
			$cat_data = json_decode( wp_remote_retrieve_body( $cat_res ), true );
			if ( is_array( $cat_data ) ) {
				foreach ( $cat_data as $c ) {
					if ( ! empty( $c['id'] ) && isset( $c['name'] ) ) {
						$categories[] = array(
							'id'    => (int) $c['id'],
							'name'  => html_entity_decode( (string) $c['name'], ENT_QUOTES, 'UTF-8' ),
							'count' => (int) ( $c['count'] ?? 0 ),
						);
					}
				}
			}
		}

		// Check Rank Math REST namespace availability.
		$rank_math_ready = false;
		$rm_res          = wp_remote_get(
			$root . '/rankmath/v1',
			array(
				'timeout' => 15,
				'headers' => $headers,
			)
		);
		if ( ! is_wp_error( $rm_res ) && wp_remote_retrieve_response_code( $rm_res ) === 200 ) {
			$rank_math_ready = true;
		}

		return array(
			'success'         => true,
			'latency_ms'      => $ms,
			'user_name'       => $user_label,
			'site_url'        => untrailingslashit( $site_url ),
			'rank_math_ready' => $rank_math_ready,
			'categories'      => $categories,
			'message'         => sprintf(
				/* translators: 1: user display name, 2: rank math status, 3: latency ms */
				__( 'اتصال به وردپرس مقصد با کاربر «%1$s» برقرار شد (%2$s · %3$d میلی‌ثانیه).', 'seo-project-manager' ),
				$user_label,
				$rank_math_ready ? 'Rank Math فعال است' : 'بدون Rank Math REST',
				$ms
			),
		);
	}

	/**
	 * Build a clean SEO meta description fallback from article content or HTML.
	 *
	 * @param array $draft Draft row.
	 * @return string
	 */
	private static function default_seo_description( array $draft ) {
		if ( ! empty( $draft['seo_description'] ) ) {
			return trim( (string) $draft['seo_description'] );
		}
		$source = ! empty( $draft['article_content'] ) ? $draft['article_content'] : ( $draft['article_html'] ?? '' );
		$plain  = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $source ) ) );
		// Strip leading "خلاصه مقاله" label if present.
		$plain  = preg_replace( '/^خلاصه\s+مقاله\s*[:：\-]?\s*/u', '', $plain );
		if ( mb_strlen( $plain ) > 158 ) {
			$plain = mb_substr( $plain, 0, 155 );
			$space = mb_strrpos( $plain, ' ' );
			if ( false !== $space && $space > 100 ) {
				$plain = mb_substr( $plain, 0, $space );
			}
			$plain .= '…';
		}
		return $plain;
	}

	/**
	 * Evaluate strict 4-item readiness for publishing an article to the business's WordPress site.
	 *
	 * Mandatory items: Title, Clean Slug, Generated HTML Code, Featured Image.
	 *
	 * @param int    $business_id Business ID.
	 * @param string $article_key Article key (optional if task_id is provided).
	 * @param int    $task_id     Calendar task ID (optional).
	 * @return array|\WP_Error
	 */
	public static function get_publish_status( $business_id = 0, $article_key = '', $task_id = 0 ) {
		$task = $task_id ? Task::get( absint( $task_id ) ) : null;
		if ( $task_id && ! $task ) {
			return new \WP_Error( 'seopm_task_not_found', __( 'تسک یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		if ( $task ) {
			$business_id = (int) $task['business_id'];
			if ( '' === $article_key ) {
				$article_key = ! empty( $task['article_key'] ) ? (string) $task['article_key'] : Article_Generator::make_key( $task['title'] );
			}
		}

		$business_id = Article_Generator::resolve_business_id( $business_id );
		$creds       = Business::get_wp_credentials( $business_id );
		if ( ! $creds ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$creds       = Business::get_wp_credentials( $business_id );
			}
		}
		if ( ! $creds ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$article_key = sanitize_key( $article_key );
		$draft       = '' !== $article_key ? Article_Generator::get_draft( $business_id, $article_key ) : null;

		if ( ! $task && '' !== $article_key ) {
			$task = Task::find_by_article( $business_id, $article_key, $draft['title'] ?? '' );
		}

		$title      = trim( (string) ( $draft['title'] ?? ( $task['title'] ?? '' ) ) );
		$slug       = Content_Suggester::clean_slug( $draft['url_slug'] ?? '' );
		$html       = trim( (string) ( $draft['article_html'] ?? '' ) );
		$image_url  = trim( (string) ( $draft['featured_image_url'] ?? '' ) );
		$keyword    = trim( (string) ( $draft['keyword'] ?? '' ) );
		$seo_title  = trim( (string) ( $draft['seo_title'] ?? '' ) ) ?: $title;
		$seo_desc   = $draft ? self::default_seo_description( $draft ) : '';

		$has_title = '' !== $title;
		$has_slug  = '' !== $slug;
		$has_html  = '' !== trim( wp_strip_all_tags( $html ) );
		$has_image = '' !== $image_url;
		$wp_ready  = '' !== $creds['website_url'] && '' !== $creds['wp_username'] && '' !== $creds['wp_app_password'];

		$missing = array();
		if ( ! $has_title ) {
			$missing[] = 'عنوان مقاله';
		}
		if ( ! $has_slug ) {
			$missing[] = 'اسلاگ (Slug) مقاله';
		}
		if ( ! $has_html ) {
			$missing[] = 'کد HTML تولیدشده مقاله';
		}
		if ( ! $has_image ) {
			$missing[] = 'تصویر شاخص تولیدشده مقاله';
		}

		$due_date     = $task ? (string) $task['due_date'] : Jalali::today();
		$publish_time = $creds['wp_publish_time'];

		return array(
			'business_id'       => $business_id,
			'business_name'     => $creds['name'],
			'website_url'       => $creds['website_url'],
			'article_key'       => $article_key,
			'task_id'           => $task ? (int) $task['id'] : 0,
			'due_date'          => $due_date,
			'publish_time'      => $publish_time,
			'default_category'  => (int) $creds['wp_default_category'],
			'ready'             => empty( $missing ) && $wp_ready,
			'content_ready'     => empty( $missing ),
			'wp_connected'      => $wp_ready,
			'missing'           => $missing,
			'checks'            => array(
				'title' => $has_title,
				'slug'  => $has_slug,
				'html'  => $has_html,
				'image' => $has_image,
			),
			'preview'           => array(
				'title'              => $title,
				'url_slug'           => $slug,
				'keyword'            => $keyword,
				'seo_title'          => $seo_title,
				'seo_description'    => $seo_desc,
				'featured_image_url' => $image_url,
				'images'             => is_array( $draft['images'] ?? null ) ? $draft['images'] : array(),
				'images_count'       => is_array( $draft['images'] ?? null ) ? count( $draft['images'] ) : 0,
				'has_article'        => ! empty( $draft['has_article'] ),
				'has_html'           => $has_html,
				'has_image'          => $has_image,
			),
			'remote'            => array(
				'post_id'       => (int) ( $draft['remote_post_id'] ?? ( $task['remote_post_id'] ?? 0 ) ),
				'post_url'      => (string) ( $draft['remote_post_url'] ?? ( $task['remote_post_url'] ?? '' ) ),
				'status'        => (string) ( $draft['remote_status'] ?? ( $task['remote_status'] ?? '' ) ),
				'scheduled_for' => $draft['scheduled_for'] ?? ( $task['scheduled_for'] ?? null ),
			),
		);
	}

	/**
	 * Publish / schedule an article to the business's WordPress site at 21:00 on its calendar date.
	 *
	 * Enforces strict completeness gate: refuses if Title, Slug, HTML Code, or Featured Image is missing.
	 * Uploads featured image to remote WP Media Library, creates/updates the scheduled post (status: future),
	 * and syncs Rank Math SEO metadata (focus keyword, SEO title, meta description).
	 *
	 * @param int   $business_id Business ID.
	 * @param array $params      { task_id, article_key, due_date, publish_time, category_id, seo_title, seo_description, keyword, url_slug, title }.
	 * @return array|\WP_Error
	 */
	public static function publish( $business_id, array $params = array() ) {
		$business_id = Article_Generator::resolve_business_id( $business_id, $params );
		$task_id     = absint( $params['task_id'] ?? 0 );
		$article_key = sanitize_key( $params['article_key'] ?? '' );

		// Save any updated slug / SEO metadata sent from UI before validating.
		if ( '' !== $article_key && absint( $business_id ) > 0 ) {
			$pre_save = array();
			if ( ! empty( $params['title'] ) ) {
				$pre_save['title'] = sanitize_text_field( $params['title'] );
			}
			if ( ! empty( $params['url_slug'] ) ) {
				$pre_save['url_slug'] = Content_Suggester::clean_slug( $params['url_slug'] );
			}
			if ( array_key_exists( 'keyword', $params ) && '' !== trim( (string) $params['keyword'] ) ) {
				$pre_save['keyword'] = sanitize_text_field( $params['keyword'] );
			}
			if ( array_key_exists( 'seo_title', $params ) ) {
				$pre_save['seo_title'] = sanitize_text_field( $params['seo_title'] );
			}
			if ( array_key_exists( 'seo_description', $params ) ) {
				$pre_save['seo_description'] = sanitize_textarea_field( $params['seo_description'] );
			}
			if ( ! empty( $pre_save ) ) {
				Article_Generator::save_draft( absint( $business_id ), $article_key, $pre_save );
			}
		}

		$status = self::get_publish_status( $business_id, $article_key, $task_id );
		if ( is_wp_error( $status ) ) {
			return $status;
		}

		// STRICT GATE: Refuse if ANY of the 4 required components is missing!
		if ( ! $status['content_ready'] ) {
			return new \WP_Error(
				'seopm_publish_incomplete',
				sprintf(
					/* translators: %s: comma-separated list of missing items */
					__( 'ارسال به سایت انجام نشد! موارد زیر هنوز تولید یا تکمیل نشده‌اند: %s', 'seo-project-manager' ),
					implode( '، ', $status['missing'] )
				),
				array(
					'status'  => 400,
					'missing' => $status['missing'],
				)
			);
		}

		if ( ! $status['wp_connected'] ) {
			return new \WP_Error(
				'seopm_wp_not_configured',
				__( 'اطلاعات اتصال وردپرس (نام کاربری و رمز عبور برنامه) برای این کسب‌وکار ثبت نشده است. لطفاً در بخش «کسب‌وکارها ← ویرایش ← انتشار خودکار وردپرس» آن را تنظیم کنید.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$business_id = (int) $status['business_id'];
		$article_key = (string) $status['article_key'];
		$creds       = Business::get_wp_credentials( $business_id );
		$draft       = Article_Generator::get_draft( $business_id, $article_key );
		$task        = $status['task_id'] ? Task::get( (int) $status['task_id'] ) : null;

		$title      = trim( (string) $status['preview']['title'] );
		$slug       = Content_Suggester::clean_slug( $status['preview']['url_slug'] );
		$html_body  = trim( (string) ( $draft['article_html'] ?? '' ) );
		$image_url  = trim( (string) $status['preview']['featured_image_url'] );
		$image_id   = (int) ( $draft['featured_image_id'] ?? 0 );
		$keyword    = trim( (string) ( $params['keyword'] ?? $status['preview']['keyword'] ?? '' ) );
		$seo_title  = trim( (string) ( $params['seo_title'] ?? $status['preview']['seo_title'] ?? $title ) );
		$seo_desc   = trim( (string) ( $params['seo_description'] ?? $status['preview']['seo_description'] ?? '' ) );

		// Determine scheduled date (calendar task due_date or provided due_date).
		$due_date = Security::sanitize_date( $params['due_date'] ?? '' );
		if ( ! $due_date ) {
			$due_date = $task ? (string) $task['due_date'] : Jalali::today();
		}

		$publish_time = trim( (string) ( $params['publish_time'] ?? $creds['wp_publish_time'] ?? '21:00' ) );
		if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $publish_time ) ) {
			$publish_time = '21:00';
		}

		$category_id = isset( $params['category_id'] ) ? absint( $params['category_id'] ) : (int) $creds['wp_default_category'];

		// Calculate exact local (Tehran / site timezone) and UTC schedule timestamps.
		$tz             = wp_timezone();
		$scheduled_sql  = $due_date . ' ' . $publish_time . ':00';
		$dt_local       = new \DateTimeImmutable( $scheduled_sql, $tz );
		$dt_utc         = $dt_local->setTimezone( new \DateTimeZone( 'UTC' ) );
		$now_local      = new \DateTimeImmutable( 'now', $tz );
		$is_future      = $dt_local->getTimestamp() > ( $now_local->getTimestamp() + 60 );
		$wp_post_status = $is_future ? 'future' : 'publish';

		$root    = self::rest_root( $creds['website_url'] );
		$headers = array(
			'Authorization' => self::auth_header( $creds['wp_username'], $creds['wp_app_password'] ),
			'Accept'        => 'application/json',
		);

		// Step 1: Upload Featured Image to Remote WordPress Media Library.
		$remote_featured = self::upload_remote_media( $root, $headers, $image_url, $image_id, $slug, $title, $keyword );
		if ( is_wp_error( $remote_featured ) ) {
			return $remote_featured;
		}
		$remote_media_id = (int) $remote_featured['id'];

		// Step 1b: Upload any image(s) ticked as "in-content" (تصویر میان‌متنی) to the target WordPress Media Library
		//          and inject them full-size right before the next <h2> so nothing hotlinks digiclinic.org.
		$draft_images          = ( ! empty( $draft['images'] ) && is_array( $draft['images'] ) ) ? $draft['images'] : array();
		$remote_in_content     = array();
		$in_content_index      = 0;
		foreach ( $draft_images as $dim ) {
			if ( empty( $dim['is_in_content'] ) || empty( $dim['url'] ) ) {
				continue;
			}
			$in_content_index++;
			// If the exact same image is ALSO selected as featured, reuse its already-uploaded remote URL.
			if ( $dim['url'] === $image_url && ! empty( $remote_featured['url'] ) ) {
				$remote_in_content[] = array(
					'url' => $remote_featured['url'],
					'alt' => $title ?: $keyword,
				);
				continue;
			}
			$up_in = self::upload_remote_media(
				$root,
				$headers,
				(string) $dim['url'],
				absint( $dim['attachment_id'] ?? 0 ),
				$slug . '-section-' . $in_content_index,
				$title,
				$keyword
			);
			if ( ! is_wp_error( $up_in ) && ! empty( $up_in['url'] ) ) {
				$remote_in_content[] = array(
					'url' => $up_in['url'],
					'alt' => $title ?: $keyword,
				);
			}
		}
		$html_body = Article_Generator::inject_in_content_images( $html_body, $remote_in_content, $title ?: $keyword );

		// Step 2: Create or update the post on Remote WordPress.
		$remote_post_id = (int) ( $draft['remote_post_id'] ?? ( $task['remote_post_id'] ?? 0 ) );
		$post_endpoint  = $remote_post_id > 0
			? ( $root . '/wp/v2/posts/' . $remote_post_id )
			: ( $root . '/wp/v2/posts' );

		$post_payload = array(
			'title'          => $title,
			'slug'           => $slug,
			'content'        => $html_body,
			'status'         => $wp_post_status,
			'date'           => $dt_local->format( 'Y-m-d\TH:i:s' ),
			'date_gmt'       => $dt_utc->format( 'Y-m-d\TH:i:s' ),
			'featured_media' => (int) $remote_media_id,
		);
		if ( $category_id > 0 ) {
			$post_payload['categories'] = array( $category_id );
		}

		$post_res = wp_remote_post(
			$post_endpoint,
			array(
				'timeout' => 45,
				'headers' => array_merge( $headers, array( 'Content-Type' => 'application/json; charset=utf-8' ) ),
				'body'    => wp_json_encode( $post_payload ),
			)
		);

		if ( is_wp_error( $post_res ) ) {
			return new \WP_Error(
				'seopm_wp_post_failed',
				sprintf( __( 'خطا در ارسال مقاله به سایت مقصد: %s', 'seo-project-manager' ), $post_res->get_error_message() ),
				array( 'status' => 502 )
			);
		}

		$p_code = wp_remote_retrieve_response_code( $post_res );
		$p_body = json_decode( wp_remote_retrieve_body( $post_res ), true );

		// If an old remote_post_id was deleted on target site (404), retry as a fresh POST.
		if ( $remote_post_id > 0 && 404 === $p_code ) {
			$post_res = wp_remote_post(
				$root . '/wp/v2/posts',
				array(
					'timeout' => 45,
					'headers' => array_merge( $headers, array( 'Content-Type' => 'application/json; charset=utf-8' ) ),
					'body'    => wp_json_encode( $post_payload ),
				)
			);
			if ( ! is_wp_error( $post_res ) ) {
				$p_code = wp_remote_retrieve_response_code( $post_res );
				$p_body = json_decode( wp_remote_retrieve_body( $post_res ), true );
			}
		}

		if ( $p_code < 200 || $p_code >= 300 || ! is_array( $p_body ) || empty( $p_body['id'] ) ) {
			$err_msg = is_array( $p_body ) && ! empty( $p_body['message'] ) ? $p_body['message'] : ( 'HTTP ' . $p_code );
			return new \WP_Error(
				'seopm_wp_post_error',
				sprintf( __( 'خطا در ثبت مقاله در وردپرس مقصد (%1$d): %2$s', 'seo-project-manager' ), $p_code, $err_msg ),
				array( 'status' => 502 )
			);
		}

		$new_post_id  = (int) $p_body['id'];
		$new_post_url = esc_url_raw( (string) ( $p_body['link'] ?? '' ) );
		$actual_stat  = sanitize_key( (string) ( $p_body['status'] ?? $wp_post_status ) );

		// Step 3: Push Rank Math SEO metadata via /wp-json/rankmath/v1/updateMeta.
		$rank_math_synced = self::sync_rank_math_meta( $root, $headers, $new_post_id, $keyword, $seo_title, $seo_desc );

		// Step 4: Save remote publish tracking on the draft.
		Article_Generator::save_draft(
			$business_id,
			$article_key,
			array(
				'title'           => $title,
				'url_slug'        => $slug,
				'keyword'         => $keyword,
				'seo_title'       => $seo_title,
				'seo_description' => $seo_desc,
				'remote_post_id'  => $new_post_id,
				'remote_post_url' => $new_post_url,
				'remote_status'   => $actual_stat,
				'scheduled_for'   => $scheduled_sql,
				'published_at'    => Database::now(),
			)
		);

		// Step 5: Link/create or update the calendar task for this article.
		if ( ! $task ) {
			$created_task = Task::create(
				array(
					'title'       => $title,
					'business_id' => $business_id,
					'task_type'   => 'article_writing',
					'due_date'    => $due_date,
					'description' => '',
					'article_key' => $article_key,
					'status'      => 'publish' === $actual_stat ? 'completed' : 'in_progress',
				)
			);
			if ( ! is_wp_error( $created_task ) && ! empty( $created_task['id'] ) ) {
				$task = $created_task;
				// Also remove from suggested articles and replenish at bottom.
				Content_Suggester::replace_scheduled_suggestion(
					$business_id,
					array(
						'title'       => $title,
						'article_key' => $article_key,
						'keyword'     => $keyword,
					)
				);
			}
		}

		if ( $task && ! empty( $task['id'] ) ) {
			$task = Task::update_remote_publish(
				(int) $task['id'],
				array(
					'article_key'     => $article_key,
					'remote_post_id'  => $new_post_id,
					'remote_post_url' => $new_post_url,
					'remote_status'   => $actual_stat,
					'scheduled_for'   => $scheduled_sql,
					'status'          => 'publish' === $actual_stat ? 'completed' : 'in_progress',
				)
			);
		}

		$jalali_date = Jalali::format( $due_date, 'long' );
		$msg         = 'future' === $actual_stat
			? sprintf(
				/* translators: 1: Jalali date, 2: HH:MM time, 3: site name */
				__( 'مقاله با موفقیت برای انتشار در تاریخ %1$s ساعت %2$s در سایت «%3$s» زمان‌بندی شد.', 'seo-project-manager' ),
				$jalali_date,
				Jalali::fa_digits( $publish_time ),
				$creds['name']
			)
			: sprintf(
				/* translators: %s: site name */
				__( 'مقاله با موفقیت در سایت «%s» منتشر شد.', 'seo-project-manager' ),
				$creds['name']
			);

		if ( $rank_math_synced ) {
			$msg .= ' ' . __( '(تنظیمات سئوی Rank Math نیز ثبت شد)', 'seo-project-manager' );
		}

		return array(
			'success'          => true,
			'remote_post_id'   => $new_post_id,
			'remote_post_url'  => $new_post_url,
			'remote_edit_url'  => untrailingslashit( $creds['website_url'] ) . '/wp-admin/post.php?post=' . $new_post_id . '&action=edit',
			'remote_status'    => $actual_stat,
			'remote_media_id'  => (int) $remote_media_id,
			'scheduled_for'    => $scheduled_sql,
			'rank_math_synced' => $rank_math_synced,
			'task'             => $task,
			'message'          => $msg,
		);
	}

	/**
	 * Upload the draft's featured image to the remote WordPress site's media library.
	 *
	 * @param string $root      Remote REST root.
	 * @param array  $headers   Auth headers.
	 * @param string $image_url Local/remote image URL.
	 * @param int    $image_id  Local attachment ID (optional).
	 * @param string $slug      Article slug.
	 * @param string $title     Article title.
	 * @param string $keyword   Article focus keyword.
	 * @return int|\WP_Error Remote attachment ID.
	 */
	private static function upload_remote_media( $root, array $headers, $image_url, $image_id, $slug, $title, $keyword ) {
		$bytes = '';
		$mime  = 'image/png';
		$ext   = 'png';

		if ( $image_id > 0 ) {
			$local_path = get_attached_file( $image_id );
			if ( is_string( $local_path ) && '' !== $local_path && is_readable( $local_path ) ) {
				$bytes     = file_get_contents( $local_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$file_type = wp_check_filetype( $local_path );
				if ( ! empty( $file_type['type'] ) ) {
					$mime = $file_type['type'];
				}
				if ( ! empty( $file_type['ext'] ) ) {
					$ext = $file_type['ext'];
				}
			}
		}

		if ( ! is_string( $bytes ) || '' === $bytes ) {
			$dl = wp_remote_get( $image_url, array( 'timeout' => 30 ) );
			if ( is_wp_error( $dl ) || wp_remote_retrieve_response_code( $dl ) < 200 || wp_remote_retrieve_response_code( $dl ) >= 300 ) {
				return new \WP_Error( 'seopm_media_read_failed', __( 'خواندن فایل تصویر شاخص مقاله برای ارسال به سایت مقصد ناموفق بود.', 'seo-project-manager' ), array( 'status' => 502 ) );
			}
			$bytes = wp_remote_retrieve_body( $dl );
			$ct    = wp_remote_retrieve_header( $dl, 'content-type' );
			if ( is_string( $ct ) && 0 === strpos( $ct, 'image/' ) ) {
				$mime = trim( explode( ';', $ct )[0] );
			}
			$path_ext = strtolower( (string) pathinfo( (string) wp_parse_url( $image_url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
			if ( in_array( $path_ext, array( 'png', 'jpg', 'jpeg', 'webp', 'gif' ), true ) ) {
				$ext = 'jpeg' === $path_ext ? 'jpg' : $path_ext;
			}
		}

		if ( ! is_string( $bytes ) || '' === $bytes ) {
			return new \WP_Error( 'seopm_media_empty', __( 'فایل تصویر شاخص خالی است و امکان ارسال به سایت مقصد وجود ندارد.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$safe_slug = sanitize_file_name( $slug ?: 'featured-image' );
		$filename  = $safe_slug . '.' . $ext;

		$up_res = wp_remote_post(
			$root . '/wp/v2/media',
			array(
				'timeout' => 60,
				'headers' => array_merge(
					$headers,
					array(
						'Content-Type'        => $mime,
						'Content-Disposition' => 'attachment; filename="' . $filename . '"',
					)
				),
				'body'    => $bytes,
			)
		);

		if ( is_wp_error( $up_res ) ) {
			return new \WP_Error(
				'seopm_remote_media_failed',
				sprintf( __( 'خطا در آپلود تصویر شاخص به سایت مقصد: %s', 'seo-project-manager' ), $up_res->get_error_message() ),
				array( 'status' => 502 )
			);
		}

		$m_code = wp_remote_retrieve_response_code( $up_res );
		$m_body = json_decode( wp_remote_retrieve_body( $up_res ), true );

		if ( $m_code < 200 || $m_code >= 300 || ! is_array( $m_body ) || empty( $m_body['id'] ) ) {
			$err_msg = is_array( $m_body ) && ! empty( $m_body['message'] ) ? $m_body['message'] : ( 'HTTP ' . $m_code );
			return new \WP_Error(
				'seopm_remote_media_error',
				sprintf( __( 'آپلود تصویر شاخص در وردپرس مقصد ناموفق بود (%1$d): %2$s', 'seo-project-manager' ), $m_code, $err_msg ),
				array( 'status' => 502 )
			);
		}

		$remote_media_id = (int) $m_body['id'];
		$alt_text        = trim( $title ?: $keyword );

		// Set SEO alt_text and title on the uploaded remote media item.
		if ( '' !== $alt_text ) {
			wp_remote_post(
				$root . '/wp/v2/media/' . $remote_media_id,
				array(
					'timeout' => 20,
					'headers' => array_merge( $headers, array( 'Content-Type' => 'application/json; charset=utf-8' ) ),
					'body'    => wp_json_encode(
						array(
							'title'    => $alt_text,
							'alt_text' => $alt_text,
						)
					),
				)
			);
		}

		return array(
			'id'  => $remote_media_id,
			'url' => esc_url_raw( (string) ( $m_body['source_url'] ?? '' ) ),
		);
	}

	/**
	 * Sync Rank Math SEO metadata on the remote WordPress site via /wp-json/rankmath/v1/updateMeta.
	 *
	 * @param string $root      Remote REST root.
	 * @param array  $headers   Auth headers.
	 * @param int    $post_id   Remote post ID.
	 * @param string $keyword   Focus keyword.
	 * @param string $seo_title SEO title.
	 * @param string $seo_desc  Meta description.
	 * @return bool True if Rank Math accepted the update.
	 */
	private static function sync_rank_math_meta( $root, array $headers, $post_id, $keyword, $seo_title, $seo_desc ) {
		$meta = array();
		if ( '' !== trim( (string) $keyword ) ) {
			$meta['rank_math_focus_keyword'] = trim( (string) $keyword );
		}
		if ( '' !== trim( (string) $seo_title ) ) {
			$meta['rank_math_title'] = trim( (string) $seo_title );
		}
		if ( '' !== trim( (string) $seo_desc ) ) {
			$meta['rank_math_description'] = trim( (string) $seo_desc );
		}
		if ( empty( $meta ) ) {
			return false;
		}

		$res = wp_remote_post(
			$root . '/rankmath/v1/updateMeta',
			array(
				'timeout' => 25,
				'headers' => array_merge( $headers, array( 'Content-Type' => 'application/json; charset=utf-8' ) ),
				'body'    => wp_json_encode(
					array(
						'objectType' => 'post',
						'objectID'   => (int) $post_id,
						'meta'       => $meta,
					)
				),
			)
		);

		if ( is_wp_error( $res ) ) {
			return false;
		}
		$code = wp_remote_retrieve_response_code( $res );
		return $code >= 200 && $code < 300;
	}
}

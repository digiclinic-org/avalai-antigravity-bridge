<?php
/**
 * Builds immutable report snapshots from real data.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Report snapshot builder.
 */
class Report_Builder {

	const SCHEMA = 1;

	/**
	 * Build snapshot.
	 *
	 * @param array  $business    Business (formatted).
	 * @param string $start       Y-m-d.
	 * @param string $end         Y-m-d.
	 * @param string $report_type monthly|custom.
	 * @param string $title       Title.
	 * @return array
	 */
	public static function build( array $business, $start, $end, $report_type, $title ) {
		$today    = Jalali::today();
		$types    = Task::types();
		$statuses = Task::statuses();
		$rows     = Task::in_range( $business['id'], $start, $end );

		$stats   = array(
			'total'       => 0,
			'completed'   => 0,
			'in_progress' => 0,
			'pending'     => 0,
			'overdue'     => 0,
		);
		$by_type = array();
		foreach ( $types as $key => $label ) {
			$by_type[ $key ] = array(
				'label'       => $label,
				'total'       => 0,
				'completed'   => 0,
				'in_progress' => 0,
				'pending'     => 0,
				'overdue'     => 0,
			);
		}

		$tasks = array();
		foreach ( $rows as $row ) {
			$status  = isset( $statuses[ $row['status'] ] ) ? $row['status'] : 'pending';
			$overdue = 'completed' !== $status && $row['due_date'] < $today;
			$type    = $row['task_type'];
			if ( ! isset( $by_type[ $type ] ) ) {
				$by_type[ $type ] = array(
					'label'       => $type,
					'total'       => 0,
					'completed'   => 0,
					'in_progress' => 0,
					'pending'     => 0,
					'overdue'     => 0,
				);
			}

			++$stats['total'];
			++$stats[ $status ];
			++$by_type[ $type ]['total'];
			++$by_type[ $type ][ $status ];
			if ( $overdue ) {
				++$stats['overdue'];
				++$by_type[ $type ]['overdue'];
			}

			$tasks[] = array(
				'id'           => (int) $row['id'],
				'title'        => $row['title'],
				'task_type'    => $type,
				'due_date'     => $row['due_date'],
				'status'       => $status,
				'overdue'      => $overdue,
				'completed_on' => $row['completed_at'] ? get_date_from_gmt( $row['completed_at'], 'Y-m-d' ) : null,
				'description'  => (string) $row['description'],
			);
		}
		$stats['completion'] = Task::rate( $stats['completed'], $stats['total'] );

		foreach ( $by_type as &$bt ) {
			$bt['completion'] = Task::rate( $bt['completed'], $bt['total'] );
		}
		unset( $bt );

		$snapshot = array(
			'schema'       => self::SCHEMA,
			'generated_at' => Database::now(),
			'today'        => $today,
			'title'        => $title,
			'report_type'  => $report_type,
			'period'       => array(
				'start' => $start,
				'end'   => $end,
			),
			'business'     => array(
				'id'          => (int) $business['id'],
				'name'        => $business['name'],
				'website_url' => $business['website_url'],
				'color'       => $business['color'],
			),
			'labels'       => array(
				'types'    => $types,
				'statuses' => $statuses,
			),
			'stats'        => $stats,
			'by_type'      => $by_type,
			'tasks'        => $tasks,
			'trend'        => self::trend( $tasks, $start, $end ),
			'branding'     => Settings::branding(),
		);

		/**
		 * Filter the snapshot before it is frozen (add-ons may append data).
		 *
		 * @param array $snapshot Snapshot.
		 * @param array $business Business.
		 */
		return apply_filters( 'seopm_report_snapshot', $snapshot, $business );
	}

	/**
	 * Completion trend: completed tasks per day (<= 31 days) or per 7-day bucket.
	 *
	 * @param array  $tasks Snapshot tasks.
	 * @param string $start Y-m-d.
	 * @param string $end   Y-m-d.
	 * @return array{granularity:string,labels:string[],values:int[]}
	 */
	public static function trend( array $tasks, $start, $end ) {
		$start_ts = strtotime( $start . ' 00:00:00 UTC' );
		$end_ts   = strtotime( $end . ' 00:00:00 UTC' );
		$days     = (int) round( ( $end_ts - $start_ts ) / DAY_IN_SECONDS ) + 1;
		$step     = $days <= 31 ? 1 : 7;

		$labels  = array();
		$buckets = array();
		for ( $ts = $start_ts; $ts <= $end_ts; $ts += $step * DAY_IN_SECONDS ) {
			$p        = Jalali::parts( gmdate( 'Y-m-d', $ts ) );
			$labels[] = Jalali::fa_digits( sprintf( '%02d/%02d', $p[1], $p[2] ) );
			$buckets[] = 0;
		}

		foreach ( $tasks as $task ) {
			if ( empty( $task['completed_on'] ) ) {
				continue;
			}
			$ts = strtotime( $task['completed_on'] . ' 00:00:00 UTC' );
			if ( $ts < $start_ts || $ts > $end_ts ) {
				continue;
			}
			$index = (int) floor( ( $ts - $start_ts ) / ( $step * DAY_IN_SECONDS ) );
			if ( isset( $buckets[ $index ] ) ) {
				++$buckets[ $index ];
			}
		}

		return array(
			'granularity' => 1 === $step ? 'day' : 'week',
			'labels'      => $labels,
			'values'      => $buckets,
		);
	}
}

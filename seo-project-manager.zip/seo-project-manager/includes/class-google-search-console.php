<?php
/**
 * Google Search Console Client & Integration Service.
 *
 * Handles Google Cloud Service Account OAuth2 JWT token generation,
 * property verification, and Search Analytics queries for businesses.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

class Google_Search_Console {

	const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
	const GSC_API_BASE   = 'https://www.googleapis.com/webmasters/v3';
	const SCOPE          = 'https://www.googleapis.com/auth/webmasters.readonly';

	/**
	 * Retrieve Google Service Account credentials.
	 * Checks SEOPM settings first, then falls back to Easy MCP AI credentials.
	 *
	 * @return array|null Parsed credentials or null if not configured.
	 */
	public static function get_credentials() {
		$raw = get_option( 'seopm_gsc_service_account_json', '' );
		if ( empty( $raw ) ) {
			$raw = get_option( 'easy_mcp_ai_gsc_service_account_json', '' );
		}

		if ( empty( $raw ) ) {
			return null;
		}

		$data = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
		if ( ! is_array( $data ) || empty( $data['client_email'] ) || empty( $data['private_key'] ) ) {
			return null;
		}

		return $data;
	}

	/**
	 * Check if a valid Google Service Account is configured.
	 *
	 * @return bool
	 */
	public static function has_credentials() {
		return null !== self::get_credentials();
	}

	/**
	 * Get the configured Service Account email.
	 *
	 * @return string Email address or empty string.
	 */
	public static function get_client_email() {
		$creds = self::get_credentials();
		return $creds['client_email'] ?? '';
	}

	/**
	 * Get the credential source ('seopm' or 'easy_mcp_ai').
	 *
	 * @return string|null
	 */
	public static function get_credential_source() {
		$raw_seopm = get_option( 'seopm_gsc_service_account_json', '' );
		if ( ! empty( $raw_seopm ) ) {
			return 'seopm';
		}
		$raw_mcp = get_option( 'easy_mcp_ai_gsc_service_account_json', '' );
		if ( ! empty( $raw_mcp ) ) {
			return 'easy_mcp_ai';
		}
		return null;
	}

	/**
	 * Generate an OAuth2 access token via JWT Bearer assertion using pure PHP OpenSSL.
	 *
	 * @param bool $force_refresh Whether to bypass transient cache.
	 * @return string|\WP_Error Access token string or WP_Error.
	 */
	public static function get_access_token( $force_refresh = false ) {
		$creds = self::get_credentials();
		if ( ! $creds ) {
			return new \WP_Error( 'no_credentials', __( 'کلید سرویس اکانت گوگل سرچ کنسول یافت نشد.', 'seo-project-manager' ) );
		}

		$cache_key = 'seopm_gsc_token_' . md5( $creds['client_email'] );
		if ( ! $force_refresh ) {
			$cached = get_transient( $cache_key );
			if ( ! empty( $cached ) && is_string( $cached ) ) {
				return $cached;
			}
		}

		if ( ! function_exists( 'openssl_sign' ) ) {
			return new \WP_Error( 'no_openssl', __( 'ماژول OpenSSL در هاست فعال نیست.', 'seo-project-manager' ) );
		}

		$now     = time();
		$header  = self::base64_url_encode( (string) wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
		$claim   = self::base64_url_encode( (string) wp_json_encode(
			array(
				'iss'   => $creds['client_email'],
				'scope' => self::SCOPE,
				'aud'   => self::TOKEN_ENDPOINT,
				'exp'   => $now + 3600,
				'iat'   => $now,
			)
		) );

		$to_sign = $header . '.' . $claim;
		$signature = '';
		$pkey    = openssl_pkey_get_private( $creds['private_key'] );
		if ( ! $pkey ) {
			return new \WP_Error( 'invalid_private_key', __( 'کلید خصوصی سرویس اکانت گوگل معتبر نیست.', 'seo-project-manager' ) );
		}

		$signed = openssl_sign( $to_sign, $signature, $pkey, OPENSSL_ALGO_SHA256 );
		if ( ! $signed ) {
			return new \WP_Error( 'signing_failed', __( 'امضای توکن JWT با کلید اختصاصی شکست خورد.', 'seo-project-manager' ) );
		}

		$jwt = $to_sign . '.' . self::base64_url_encode( $signature );

		$res = wp_remote_post(
			self::TOKEN_ENDPOINT,
			array(
				'timeout'   => 15,
				'sslverify' => false,
				'headers'   => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
				'body'      => array(
					'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
					'assertion'  => $jwt,
				),
			)
		);

		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( 200 !== $code || empty( $body['access_token'] ) ) {
			$err_msg = $body['error_description'] ?? ( $body['error'] ?? 'HTTP ' . $code );
			return new \WP_Error( 'oauth_error', sprintf( __( 'خطای دریافت توکن گوگل: %s', 'seo-project-manager' ), $err_msg ) );
		}

		$token = (string) $body['access_token'];
		set_transient( $cache_key, $token, 3300 ); // Cache for 55 minutes.

		return $token;
	}

	/**
	 * List all sites accessible by this Google Service Account.
	 *
	 * @param bool $refresh Force refresh from Google API.
	 * @return array List of properties with siteUrl and permissionLevel.
	 */
	public static function list_sites( $refresh = false ) {
		$cache_key = 'seopm_gsc_sites_list';
		if ( ! $refresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && ! empty( $cached ) ) {
				return $cached;
			}
		}

		$token = self::get_access_token();
		if ( is_wp_error( $token ) ) {
			// Fallback to Easy MCP AI sites cache if available.
			$mcp_cache = get_option( 'easy_mcp_ai_gsc_sites_cache', array() );
			if ( is_array( $mcp_cache ) && ! empty( $mcp_cache ) ) {
				$formatted = array();
				foreach ( $mcp_cache as $item ) {
					$site_url    = is_array( $item ) ? ( $item['siteUrl'] ?? '' ) : (string) $item;
					$permission = is_array( $item ) ? ( $item['permissionLevel'] ?? 'siteFullUser' ) : 'siteFullUser';
					if ( ! empty( $site_url ) ) {
						$formatted[] = array(
							'siteUrl'         => $site_url,
							'permissionLevel' => $permission,
						);
					}
				}
				return $formatted;
			}
			return array();
		}

		$res = wp_remote_get(
			self::GSC_API_BASE . '/sites',
			array(
				'timeout'   => 15,
				'sslverify' => false,
				'headers'   => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/json',
				),
			)
		);

		if ( is_wp_error( $res ) ) {
			return array();
		}

		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( 200 !== $code || ! isset( $body['siteEntry'] ) || ! is_array( $body['siteEntry'] ) ) {
			return array();
		}

		$sites = array();
		foreach ( $body['siteEntry'] as $entry ) {
			if ( ! empty( $entry['siteUrl'] ) ) {
				$sites[] = array(
					'siteUrl'         => (string) $entry['siteUrl'],
					'permissionLevel' => (string) ( $entry['permissionLevel'] ?? 'siteFullUser' ),
				);
			}
		}

		set_transient( $cache_key, $sites, 43200 ); // Cache for 12 hours.
		return $sites;
	}

	/**
	 * Match a business website URL to an authorized Search Console property.
	 *
	 * @param string $website_url Website URL or domain.
	 * @return array Matching result: [ 'found' => bool, 'property' => string, 'permission' => string ]
	 */
	public static function match_property( $website_url ) {
		$clean = trim( (string) $website_url );
		if ( empty( $clean ) ) {
			return array( 'found' => false );
		}

		$host = wp_parse_url( ( ! preg_match( '#^https?://#i', $clean ) ? 'https://' : '' ) . $clean, PHP_URL_HOST );
		if ( empty( $host ) ) {
			$host = strtolower( trim( $clean, '/' ) );
		}
		$host = preg_replace( '#^www\.#i', '', strtolower( $host ) );

		$sites = self::list_sites();
		if ( empty( $sites ) ) {
			// Also check directly in raw Easy MCP cache if needed.
			$raw_cache = get_option( 'easy_mcp_ai_gsc_sites_cache', array() );
			if ( is_array( $raw_cache ) ) {
				foreach ( $raw_cache as $prop ) {
					$prop_url = is_array( $prop ) ? ( $prop['siteUrl'] ?? '' ) : (string) $prop;
					$sites[]  = array(
						'siteUrl'         => $prop_url,
						'permissionLevel' => 'siteFullUser',
					);
				}
			}
		}

		$candidates = array(
			'sc-domain:' . $host,
			'https://' . $host . '/',
			'http://' . $host . '/',
			'https://www.' . $host . '/',
			'http://www.' . $host . '/',
			'https://' . $host,
			'http://' . $host,
		);

		foreach ( $sites as $site ) {
			$site_url = strtolower( trim( (string) ( $site['siteUrl'] ?? '' ) ) );
			foreach ( $candidates as $cand ) {
				if ( $site_url === strtolower( $cand ) || rtrim( $site_url, '/' ) === rtrim( strtolower( $cand ), '/' ) ) {
					return array(
						'found'      => true,
						'property'   => $site['siteUrl'],
						'permission' => $site['permissionLevel'] ?? 'siteFullUser',
					);
				}
			}
		}

		return array( 'found' => false );
	}

	/**
	 * Query Google Search Console performance / analytics data.
	 *
	 * @param string $property Search Console property (e.g. sc-domain:example.com or https://example.com/).
	 * @param string $start_date YYYY-MM-DD. Defaults to 28 days ago.
	 * @param string $end_date   YYYY-MM-DD. Defaults to 2 days ago.
	 * @param array  $dimensions Dimensions to group by: 'query', 'page', 'device', 'country', 'date'.
	 * @param int    $row_limit  Max rows to return (up to 25000).
	 * @return array Results array with success, rows, totals or error.
	 */
	public static function query_performance( $property, $start_date = '', $end_date = '', $dimensions = array( 'query' ), $row_limit = 25 ) {
		$token = self::get_access_token();
		if ( is_wp_error( $token ) ) {
			return array(
				'success' => false,
				'message' => $token->get_error_message(),
			);
		}

		if ( empty( $end_date ) ) {
			$end_date = gmdate( 'Y-m-d', strtotime( '-2 days' ) );
		}
		if ( empty( $start_date ) ) {
			$start_date = gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		}

		$endpoint = self::GSC_API_BASE . '/sites/' . rawurlencode( $property ) . '/searchAnalytics/query';

		$body_payload = array(
			'startDate'  => $start_date,
			'endDate'    => $end_date,
			'dimensions' => (array) $dimensions,
			'rowLimit'   => (int) $row_limit,
		);

		$res = wp_remote_post(
			$endpoint,
			array(
				'timeout'   => 20,
				'sslverify' => false,
				'headers'   => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'      => (string) wp_json_encode( $body_payload ),
			)
		);

		if ( is_wp_error( $res ) ) {
			return array(
				'success' => false,
				'message' => $res->get_error_message(),
			);
		}

		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( 200 !== $code ) {
			$msg = $body['error']['message'] ?? ( 'HTTP ' . $code );
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای سرچ کنسول گوگل: %s', 'seo-project-manager' ), $msg ),
			);
		}

		$rows         = array();
		$total_clicks = 0;
		$total_imp    = 0;

		if ( isset( $body['rows'] ) && is_array( $body['rows'] ) ) {
			foreach ( $body['rows'] as $r ) {
				$clicks = (int) ( $r['clicks'] ?? 0 );
				$imp    = (int) ( $r['impressions'] ?? 0 );
				$ctr    = (float) ( $r['ctr'] ?? 0 );
				$pos    = (float) ( $r['position'] ?? 0 );
				$keys   = (array) ( $r['keys'] ?? array() );

				$total_clicks += $clicks;
				$total_imp    += $imp;

				$rows[] = array(
					'keys'        => $keys,
					'query'       => $keys[0] ?? '',
					'clicks'      => $clicks,
					'impressions' => $imp,
					'ctr'         => round( $ctr * 100, 2 ),
					'position'    => round( $pos, 1 ),
				);
			}
		}

		$avg_ctr = $total_imp > 0 ? round( ( $total_clicks / $total_imp ) * 100, 2 ) : 0;

		return array(
			'success'    => true,
			'property'   => $property,
			'start_date' => $start_date,
			'end_date'   => $end_date,
			'count'      => count( $rows ),
			'rows'       => $rows,
			'totals'     => array(
				'clicks'      => $total_clicks,
				'impressions' => $total_imp,
				'ctr'         => $avg_ctr,
			),
		);
	}

	/**
	 * Live verification test for a business website against Google Search Console API.
	 *
	 * @param string $website_url Website URL.
	 * @param int    $business_id Business ID.
	 * @return array Test result details.
	 */
	public static function test_connection( $website_url, $business_id = 0 ) {
		$start_time = microtime( true );

		if ( empty( $website_url ) && $business_id > 0 ) {
			$biz         = Business::get( $business_id );
			$website_url = $biz['website_url'] ?? '';
		}

		if ( empty( $website_url ) ) {
			return array(
				'success' => false,
				'message' => __( 'آدرس وب‌سایت وارد نشده است.', 'seo-project-manager' ),
			);
		}

		$has_creds = self::has_credentials();
		$email     = self::get_client_email();

		if ( ! $has_creds ) {
			return array(
				'success'    => false,
				'configured' => false,
				'message'    => __( 'سرویس اکانت گوگل سرچ کنسول هنوز تنظیم نشده است. می‌توانید فایل JSON سرویس اکانت گوگل را در تنظیمات افزونه ثبت کنید.', 'seo-project-manager' ),
			);
		}

		$matched = self::match_property( $website_url );
		$latency_ms = (int) round( ( microtime( true ) - $start_time ) * 1000 );

		if ( $matched['found'] ) {
			$property = $matched['property'];
			$perf     = self::query_performance( $property, '', '', array( 'query' ), 5 );
			$perf_ok  = ! empty( $perf['success'] );
			$clicks   = $perf['totals']['clicks'] ?? 0;
			$imp      = $perf['totals']['impressions'] ?? 0;

			$perm_labels = array(
				'siteFullUser'       => __( 'کاربر کامل (Full)', 'seo-project-manager' ),
				'siteOwner'          => __( 'مالک تأیید شده (Owner)', 'seo-project-manager' ),
				'siteRestrictedUser' => __( 'کاربر محدود (Restricted)', 'seo-project-manager' ),
			);
			$perm_text = $perm_labels[ $matched['permission'] ] ?? $matched['permission'];

			$detail_msg = $perf_ok
				? sprintf( __( 'تعداد %s ایمپرشن و %s کلیک در ۲۸ روز گذشته ثبت شده است.', 'seo-project-manager' ), number_format_i18n( $imp ), number_format_i18n( $clicks ) )
				: __( 'دسترسی API برقرار است.', 'seo-project-manager' );

			return array(
				'success'               => true,
				'verified'              => true,
				'method'                => 'gsc_service_account_api',
				'property'              => $property,
				'permission'            => $matched['permission'],
				'permission_label'      => $perm_text,
				'service_account_email' => $email,
				'credential_source'     => self::get_credential_source(),
				'latency_ms'            => $latency_ms,
				'clicks_28d'            => $clicks,
				'impressions_28d'       => $imp,
				'message'               => sprintf(
					__( 'اتصال زنده به دیتای گوگل سرچ کنسول برقرار است (پراپرتی متصل: %s | سطح دسترسی: %s). %s', 'seo-project-manager' ),
					$property,
					$perm_text,
					$detail_msg
				),
			);
		}

		// Service account is configured, but this domain is not yet shared with it in GSC.
		return array(
			'success'               => true,
			'verified'              => false,
			'has_service_account'   => true,
			'service_account_email' => $email,
			'credential_source'     => self::get_credential_source(),
			'latency_ms'            => $latency_ms,
			'message'               => sprintf(
				__( 'سرویس اکانت گوگل فعال است، اما این دامنه هنوز در سرچ کنسول به آن متصل نشده است. کافی است در سرچ کنسول، ایمیل زیر را به عنوان کاربر (User) اضافه فرمایید:\n%s', 'seo-project-manager' ),
				$email
			),
		);
	}

	/**
	 * Safe base64 URL encoding for JWT.
	 *
	 * @param string $data Raw data.
	 * @return string Base64 URL encoded string.
	 */
	private static function base64_url_encode( $data ) {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}
}

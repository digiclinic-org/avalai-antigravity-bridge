<?php
/**
 * AI Provider Client for Gemini, OpenAI/ChatGPT, DeepSeek, and Anthropic Claude.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * AI Client.
 */
class AI_Client {

	/**
	 * Supported providers list.
	 *
	 * @return array
	 */
	public static function get_providers() {
		return array(
			'avalai'   => array(
				'name'          => __( 'اول‌ای‌آی (AvalAI - بدون تحریم)', 'seo-project-manager' ),
				'short_name'    => 'AvalAI',
				'color'         => '#7c3aed',
				'bg'            => '#f5f3ff',
				'icon'          => 'cloud',
				'default_url'   => 'https://api.avalai.ir/v1',
				'portal_url'    => 'https://chat.avalai.ir/platform/api-keys',
				'models'        => array(
					'gemini-2.5-flash'           => 'Gemini 2.5 Flash (سریع، باکیفیت و بسیار اقتصادی - پیشنهادی)',
					'gemini-2.5-pro'             => 'Gemini 2.5 Pro (قدرتمند در استراتژی سئو و نگارش فارسی)',
					'gemini-2.0-flash'           => 'Gemini 2.0 Flash (سریع و سبک)',
					'gpt-4o'                     => 'GPT-4o (پرچمدار چندمنظوره OpenAI)',
					'gpt-4o-mini'                => 'GPT-4o Mini (سریع و مقرون‌به‌صرفه)',
					'gpt-4.1'                    => 'GPT-4.1 (دقیق برای کد HTML و ساختار سئو)',
					'claude-sonnet-4-20250514'   => 'Claude Sonnet 4 (قلم حرفه‌ای و نگارش طبیعی فارسی)',
					'claude-3-7-sonnet-20250219' => 'Claude 3.7 Sonnet (تحلیل عمیق محتوا)',
					'claude-3-5-sonnet-20241022' => 'Claude 3.5 Sonnet (پایدار و دقیق)',
					'deepseek-chat'              => 'DeepSeek-V3 (اقتصادی و قوی در فارسی)',
					'deepseek-reasoner'          => 'DeepSeek-R1 (استدلال عمیق)',
				),
				'default_model' => 'gemini-2.5-flash',
			),
			'gemini'   => array(
				'name'        => __( 'گوگل جمنای (Google Gemini)', 'seo-project-manager' ),
				'short_name'  => 'Gemini',
				'color'       => '#1a73e8',
				'bg'          => '#e8f0fe',
				'icon'        => 'google',
				'default_url' => 'https://generativelanguage.googleapis.com/v1beta',
				'portal_url'  => 'https://aistudio.google.com/app/apikey',
				'models'      => array(
					'gemini-2.5-flash' => 'Gemini 2.5 Flash (جدید، سریع و پیشنهادی)',
					'gemini-2.5-pro'   => 'Gemini 2.5 Pro (قدرتمند با درک عمیق سئو)',
					'gemini-2.0-flash' => 'Gemini 2.0 Flash (سریع و اقتصادی)',
					'gemini-1.5-flash' => 'Gemini 1.5 Flash (قدیمی)',
					'gemini-1.5-pro'   => 'Gemini 1.5 Pro (قدیمی)',
				),
				'default_model' => 'gemini-2.5-flash',
			),
			'openai'   => array(
				'name'        => __( 'چت جی‌پی‌تی (OpenAI / ChatGPT)', 'seo-project-manager' ),
				'short_name'  => 'ChatGPT',
				'color'       => '#10a37f',
				'bg'          => '#e6f7f2',
				'icon'        => 'admin-generic',
				'default_url' => 'https://api.openai.com/v1',
				'portal_url'  => 'https://platform.openai.com/api-keys',
				'models'      => array(
					'gpt-4o-mini'    => 'GPT-4o Mini (سریع و اقتصادی - پیشنهادی)',
					'gpt-4o'         => 'GPT-4o (پرچمدار و چندمنظوره)',
					'gpt-3.5-turbo'  => 'GPT-3.5 Turbo (پایه)',
				),
				'default_model' => 'gpt-4o-mini',
			),
			'deepseek' => array(
				'name'        => __( 'دیپ‌سیک (DeepSeek)', 'seo-project-manager' ),
				'short_name'  => 'DeepSeek',
				'color'       => '#0891b2',
				'bg'          => '#ecfeff',
				'icon'        => 'superhero',
				'default_url' => 'https://api.deepseek.com',
				'portal_url'  => 'https://platform.deepseek.com/api_keys',
				'models'      => array(
					'deepseek-chat'     => 'DeepSeek-V3 (سریع و فوق‌العاده در درک و نگارش فارسی)',
					'deepseek-reasoner' => 'DeepSeek-R1 (استدلال سئو و معماری عمیق محتوا)',
				),
				'default_model' => 'deepseek-chat',
			),
			'claude'   => array(
				'name'        => __( 'آنت‌روپیک کلود (Anthropic Claude)', 'seo-project-manager' ),
				'short_name'  => 'Claude',
				'color'       => '#d97706',
				'bg'          => '#fef3c7',
				'icon'        => 'edit-page',
				'default_url' => 'https://api.anthropic.com/v1',
				'portal_url'  => 'https://console.anthropic.com/settings/keys',
				'models'      => array(
					'claude-3-5-sonnet-20241022' => 'Claude 3.5 Sonnet (بهترین تفکر تحلیلی و نگارش سئو)',
					'claude-3-5-haiku-20241022'  => 'Claude 3.5 Haiku (فوق‌العاده سریع و سبک)',
					'claude-3-opus-20240229'     => 'Claude 3 Opus (عمیق و جامع)',
				),
				'default_model' => 'claude-3-5-sonnet-20241022',
			),
		);
	}

	/**
	 * Test connection to an AI provider.
	 *
	 * @param string $provider Provider key.
	 * @param string $api_key  API Key.
	 * @param string $model    Model name.
	 * @param string $base_url Custom base URL (optional).
	 * @return array
	 */
	public static function test_connection( $provider, $api_key, $model = '', $base_url = '' ) {
		$providers = self::get_providers();
		if ( ! isset( $providers[ $provider ] ) ) {
			return array(
				'success' => false,
				'message' => __( 'ارائه‌دهنده نامعتبر است.', 'seo-project-manager' ),
			);
		}

		$p_info = $providers[ $provider ];
		$model  = $model ? sanitize_text_field( $model ) : $p_info['default_model'];
		$api_key = trim( (string) $api_key );

		if ( empty( $api_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'کلید API وارد نشده است.', 'seo-project-manager' ),
			);
		}

		$test_prompt = 'این یک تست اتصال از سمت افزونه مدیریت سئو است. لطفاً فقط یک کلمه پاسخ بده: OK';
		$start_time  = microtime( true );

		$result = self::call_raw( $provider, $api_key, $model, $base_url, $test_prompt, '', array( 'max_tokens' => 1024 ) );

		$latency = round( ( microtime( true ) - $start_time ) * 1000 );

		if ( ! $result['success'] ) {
			return array(
				'success'    => false,
				'latency_ms' => $latency,
				'provider'   => $provider,
				'model'      => $model,
				'message'    => $result['message'],
			);
		}

		return array(
			'success'    => true,
			'latency_ms' => $latency,
			'provider'   => $provider,
			'model'      => $model,
			'reply'      => trim( $result['text'] ),
			'message'    => sprintf(
				/* translators: 1: Provider name, 2: Model name, 3: Latency ms */
				__( 'اتصال به %1$s با مدل %2$s با موفقیت برقرار شد (زمان پاسخ: %3$d میلی‌ثانیه).', 'seo-project-manager' ),
				$p_info['short_name'],
				$model,
				$latency
			),
		);
	}

	/**
	 * Generate completion with active or specified provider.
	 *
	 * @param string $prompt             Prompt text.
	 * @param string $system_instruction System instruction / role.
	 * @param array  $options            Additional options.
	 * @return array
	 */
	public static function generate( $prompt, $system_instruction = '', array $options = array() ) {
		$settings = Settings::all();
		$provider = $options['provider'] ?? $settings['ai_active_provider'] ?? 'none';

		if ( 'none' === $provider || empty( $provider ) ) {
			return array(
				'success' => false,
				'message' => __( 'هیچ ارائه‌دهنده هوش مصنوعی فعالی انتخاب نشده است.', 'seo-project-manager' ),
			);
		}

		$providers = self::get_providers();
		if ( ! isset( $providers[ $provider ] ) ) {
			return array(
				'success' => false,
				'message' => __( 'ارائه‌دهنده انتخاب‌شده نامعتبر است.', 'seo-project-manager' ),
			);
		}

		$api_key  = $options['api_key'] ?? $settings[ $provider . '_api_key' ] ?? '';
		$model    = $options['model'] ?? '';
		if ( '' === $model && 'avalai' === $provider && ! empty( $settings['avalai_custom_model'] ) ) {
			$model = trim( (string) $settings['avalai_custom_model'] );
		}
		if ( '' === $model ) {
			$model = $settings[ $provider . '_model' ] ?? $providers[ $provider ]['default_model'];
		}
		$base_url = $options['base_url'] ?? $settings[ $provider . '_base_url' ] ?? '';

		if ( empty( $api_key ) ) {
			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: %s: Provider name */
					__( 'کلید API برای %s ثبت نشده است. لطفاً به صفحه تنظیمات مراجعه کنید.', 'seo-project-manager' ),
					$providers[ $provider ]['short_name']
				),
			);
		}

		return self::call_raw( $provider, $api_key, $model, $base_url, $prompt, $system_instruction, $options );
	}

	/**
	 * Low-level dispatch to provider endpoint.
	 *
	 * @param string $provider           Provider key.
	 * @param string $api_key            API Key.
	 * @param string $model              Model name.
	 * @param string $base_url           Base URL.
	 * @param string $prompt             Prompt.
	 * @param string $system_instruction System prompt.
	 * @param array  $options            Options.
	 * @return array
	 */
	private static function call_raw( $provider, $api_key, $model, $base_url, $prompt, $system_instruction = '', array $options = array() ) {
		$timeout     = isset( $options['timeout'] ) ? absint( $options['timeout'] ) : 45;
		$temperature = isset( $options['temperature'] ) ? floatval( $options['temperature'] ) : 0.7;

		switch ( $provider ) {
			case 'avalai':
				return self::call_openai_compatible( 'https://api.avalai.ir/v1', $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options );

			case 'gemini':
				return self::call_gemini( $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options );

			case 'openai':
				return self::call_openai_compatible( 'https://api.openai.com/v1', $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options );

			case 'deepseek':
				return self::call_openai_compatible( 'https://api.deepseek.com', $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options );

			case 'claude':
				return self::call_claude( $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options );

			default:
				return array(
					'success' => false,
					'message' => __( 'ارائه‌دهنده پشتیبانی نمی‌شود.', 'seo-project-manager' ),
				);
		}
	}

	/**
	 * Call Google Gemini API.
	 */
	private static function call_gemini( $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options ) {
		$root = ! empty( $base_url ) ? untrailingslashit( $base_url ) : 'https://generativelanguage.googleapis.com/v1beta';
		$url  = $root . '/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $api_key );

		$body = array(
			'contents' => array(
				array(
					'role'  => 'user',
					'parts' => array(
						array( 'text' => $prompt ),
					),
				),
			),
			'generationConfig' => array(
				'temperature'     => $temperature,
				'maxOutputTokens' => isset( $options['max_tokens'] ) ? absint( $options['max_tokens'] ) : 4096,
			),
		);

		if ( ! empty( $system_instruction ) ) {
			$body['systemInstruction'] = array(
				'parts' => array(
					array( 'text' => $system_instruction ),
				),
			);
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Content-Type' => 'application/json; charset=utf-8',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای اتصال به جمنای: %s', 'seo-project-manager' ), $response->get_error_message() ),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( $code < 200 || $code >= 300 ) {
			$err_msg = self::extract_error( $code, $raw, $data );
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای Gemini API (%1$d): %2$s', 'seo-project-manager' ), $code, $err_msg ),
			);
		}

		$candidate = $data['candidates'][0] ?? null;
		if ( ! $candidate || empty( $candidate['content']['parts'][0]['text'] ) ) {
			return array(
				'success' => false,
				'message' => __( 'پاسخ نامعتبر یا خالی از جمنای دریافت شد.', 'seo-project-manager' ),
			);
		}

		return array(
			'success' => true,
			'text'    => $candidate['content']['parts'][0]['text'],
			'raw'     => $data,
		);
	}

	/**
	 * Call OpenAI-compatible API (OpenAI and DeepSeek).
	 */
	private static function call_openai_compatible( $default_root, $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options ) {
		$root = ! empty( $base_url ) ? untrailingslashit( trim( $base_url ) ) : $default_root;

		// Normalize bare avalai.org / avalai.ir domains to api.avalai.{org|ir}/v1.
		if ( preg_match( '#^https?://(?:www\.)?avalai\.(ir|org)$#i', $root, $am ) ) {
			$root = 'https://api.avalai.' . strtolower( $am[1] ) . '/v1';
		} elseif ( preg_match( '#^https?://api\.avalai\.(ir|org)$#i', $root, $am ) ) {
			$root = 'https://api.avalai.' . strtolower( $am[1] ) . '/v1';
		}

		// If base URL doesn't have /chat/completions, append it cleanly.
		if ( false !== strpos( $root, '/chat/completions' ) ) {
			$url = $root;
		} else {
			$url = rtrim( $root, '/' ) . '/chat/completions';
		}

		$messages = array();
		if ( ! empty( $system_instruction ) ) {
			$messages[] = array(
				'role'    => 'system',
				'content' => $system_instruction,
			);
		}
		$messages[] = array(
			'role'    => 'user',
			'content' => $prompt,
		);

		$body = array(
			'model'       => $model,
			'messages'    => $messages,
			'temperature' => $temperature,
		);

		if ( isset( $options['max_tokens'] ) ) {
			$body['max_tokens'] = absint( $options['max_tokens'] );
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Content-Type'  => 'application/json; charset=utf-8',
					'Authorization' => 'Bearer ' . $api_key,
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای اتصال: %s', 'seo-project-manager' ), $response->get_error_message() ),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( $code < 200 || $code >= 300 ) {
			$err_msg = self::extract_error( $code, $raw, $data );
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای API (%1$d): %2$s', 'seo-project-manager' ), $code, $err_msg ),
			);
		}

		$msg   = $data['choices'][0]['message'] ?? array();
		$reply = is_array( $msg ) ? ( $msg['content'] ?? '' ) : '';
		if ( '' === trim( (string) $reply ) && is_array( $msg ) && ! empty( $msg['reasoning_content'] ) ) {
			$reply = (string) $msg['reasoning_content'];
		}
		if ( '' === trim( (string) $reply ) ) {
			return array(
				'success' => false,
				'message' => __( 'پاسخ نامعتبر یا خالی از سرور دریافت شد.', 'seo-project-manager' ),
			);
		}

		return array(
			'success' => true,
			'text'    => $reply,
			'raw'     => $data,
		);
	}

	/**
	 * Call Anthropic Claude API.
	 */
	private static function call_claude( $api_key, $model, $base_url, $prompt, $system_instruction, $temperature, $timeout, $options ) {
		$root = ! empty( $base_url ) ? untrailingslashit( $base_url ) : 'https://api.anthropic.com/v1';
		$url  = rtrim( $root, '/' ) . '/messages';

		$max_tokens = isset( $options['max_tokens'] ) ? absint( $options['max_tokens'] ) : 4096;
		if ( 0 === strpos( $model, 'claude-3-opus' ) && $max_tokens > 4096 ) {
			$max_tokens = 4096;
		}

		$body = array(
			'model'      => $model,
			'max_tokens' => $max_tokens,
			'messages'   => array(
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
		);

		if ( ! empty( $system_instruction ) ) {
			$body['system'] = $system_instruction;
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Content-Type'      => 'application/json; charset=utf-8',
					'x-api-key'         => $api_key,
					'anthropic-version' => '2023-06-01',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای اتصال به کلود: %s', 'seo-project-manager' ), $response->get_error_message() ),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( $code < 200 || $code >= 300 ) {
			$err_msg = self::extract_error( $code, $raw, $data );
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای Claude API (%1$d): %2$s', 'seo-project-manager' ), $code, $err_msg ),
			);
		}

		$reply = $data['content'][0]['text'] ?? '';
		if ( '' === $reply ) {
			return array(
				'success' => false,
				'message' => __( 'پاسخ نامعتبر یا خالی از کلود دریافت شد.', 'seo-project-manager' ),
			);
		}

		return array(
			'success' => true,
			'text'    => $reply,
			'raw'     => $data,
		);
	}

	/**
	 * Extract human-readable error from API response.
	 *
	 * @param int         $code HTTP status code.
	 * @param string      $raw  Raw body string.
	 * @param array|null  $data Decoded JSON body.
	 * @return string
	 */
	private static function extract_error( $code, $raw, $data ) {
		if ( is_array( $data ) ) {
			if ( ! empty( $data['error']['message'] ) ) {
				return $data['error']['message'];
			}
			if ( ! empty( $data['error'] ) && is_string( $data['error'] ) ) {
				return $data['error'];
			}
			if ( ! empty( $data['message'] ) ) {
				return $data['message'];
			}
		}
		if ( ! empty( $raw ) ) {
			$clean = trim( wp_strip_all_tags( $raw ) );
			if ( ! empty( $clean ) ) {
				return substr( $clean, 0, 300 );
			}
		}
		return 'HTTP ' . $code;
	}

	/**
	 * Generate a featured image via the active (or fallback image-capable) AI provider.
	 *
	 * Supports AvalAI (OpenAI-compatible /v1/images/generations), OpenAI, and Google Gemini Imagen.
	 *
	 * @param string $prompt  Image generation prompt.
	 * @param array  $options { model, size, timeout, provider }.
	 * @return array{success:bool,b64?:string,url?:string,mime?:string,model?:string,provider?:string,message?:string}
	 */
	public static function generate_image( $prompt, array $options = array() ) {
		$prompt = trim( (string) $prompt );
		if ( '' === $prompt ) {
			return array(
				'success' => false,
				'message' => __( 'پرامپت تولید تصویر خالی است.', 'seo-project-manager' ),
			);
		}

		$settings = Settings::all();
		$provider = sanitize_key( $options['provider'] ?? ( $settings['ai_active_provider'] ?? 'none' ) );
		$capable  = array( 'avalai', 'openai', 'gemini' );

		if ( ! in_array( $provider, $capable, true ) || empty( $settings[ $provider . '_api_key' ] ) ) {
			$fallback = '';
			foreach ( $capable as $cand ) {
				if ( ! empty( $settings[ $cand . '_api_key' ] ) ) {
					$fallback = $cand;
					break;
				}
			}
			if ( '' === $fallback ) {
				return array(
					'success' => false,
					'message' => __( 'برای تولید تصویر با هوش مصنوعی، باید کلید API یکی از سرویس‌های AvalAI، OpenAI یا Gemini ثبت شده باشد (یا تصویر را به‌صورت دستی آپلود کنید).', 'seo-project-manager' ),
				);
			}
			$provider = $fallback;
		}

		$api_key  = trim( (string) ( $settings[ $provider . '_api_key' ] ?? '' ) );
		$base_url = trim( (string) ( $settings[ $provider . '_base_url' ] ?? '' ) );
		$timeout  = isset( $options['timeout'] ) ? absint( $options['timeout'] ) : 90;
		$size     = sanitize_text_field( $options['size'] ?? '1536x1024' );

		if ( 'gemini' === $provider ) {
			$model = sanitize_text_field( $options['model'] ?? 'imagen-3.0-generate-002' );
			$root  = '' !== $base_url ? untrailingslashit( $base_url ) : 'https://generativelanguage.googleapis.com/v1beta';
			$url   = $root . '/models/' . rawurlencode( $model ) . ':predict?key=' . rawurlencode( $api_key );
			$body  = array(
				'instances'  => array(
					array( 'prompt' => $prompt ),
				),
				'parameters' => array(
					'sampleCount' => 1,
					'aspectRatio' => '16:9',
				),
			);
			$response = wp_remote_post(
				$url,
				array(
					'timeout' => $timeout,
					'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
					'body'    => wp_json_encode( $body ),
				)
			);
			if ( is_wp_error( $response ) ) {
				return array(
					'success' => false,
					'message' => sprintf( __( 'خطای اتصال در تولید تصویر جمنای: %s', 'seo-project-manager' ), $response->get_error_message() ),
				);
			}
			$code = wp_remote_retrieve_response_code( $response );
			$raw  = wp_remote_retrieve_body( $response );
			$data = json_decode( $raw, true );
			if ( $code < 200 || $code >= 300 ) {
				return array(
					'success' => false,
					'message' => sprintf( __( 'خطای تولید تصویر جمنای (%1$d): %2$s', 'seo-project-manager' ), $code, self::extract_error( $code, $raw, $data ) ),
				);
			}
			$b64  = $data['predictions'][0]['bytesBase64Encoded'] ?? '';
			$mime = $data['predictions'][0]['mimeType'] ?? 'image/png';
			if ( '' === $b64 ) {
				return array(
					'success' => false,
					'message' => __( 'پاسخ تصویر از جمنای خالی بود.', 'seo-project-manager' ),
				);
			}
			return array(
				'success'  => true,
				'b64'      => $b64,
				'mime'     => $mime,
				'model'    => $model,
				'provider' => $provider,
			);
		}

		// AvalAI or OpenAI: OpenAI-compatible /v1/images/generations endpoint.
		$default_root = ( 'avalai' === $provider ) ? 'https://api.avalai.ir/v1' : 'https://api.openai.com/v1';
		$root         = '' !== $base_url ? untrailingslashit( $base_url ) : $default_root;
		if ( preg_match( '#^https?://(?:www\.)?avalai\.(ir|org)$#i', $root, $am ) ) {
			$root = 'https://api.avalai.' . strtolower( $am[1] ) . '/v1';
		} elseif ( preg_match( '#^https?://api\.avalai\.(ir|org)$#i', $root, $am ) ) {
			$root = 'https://api.avalai.' . strtolower( $am[1] ) . '/v1';
		}
		$root = preg_replace( '#/chat/completions$#i', '', $root );
		$url  = ( false !== strpos( $root, '/images/generations' ) ) ? $root : ( $root . '/images/generations' );

		$model = trim( sanitize_text_field( $options['model'] ?? '' ) );
		// Replace deprecated models (gpt-image-1, dall-e-3) with AvalAI's active frontier models.
		if ( '' === $model || in_array( $model, array( 'gpt-image-1', 'dall-e-3' ), true ) ) {
			$model = ( 'avalai' === $provider ) ? 'gemini-2.5-flash-image' : 'gpt-image-2.5-flare';
		}

		// Adapt allowed size per model.
		if ( in_array( $model, array( 'gemini-2.5-flash-image', 'gpt-image-2.5-flare', 'gpt-image-2.6-flare' ), true ) ) {
			if ( '1536x1024' !== $size && '1024x1024' !== $size && '1792x1024' !== $size ) {
				$size = '1536x1024';
			}
		} elseif ( 'dall-e-3' === $model && '1536x1024' === $size ) {
			$size = '1792x1024';
		}

		$body = array(
			'model'           => $model,
			'prompt'          => $prompt,
			'n'               => 1,
			'size'            => $size,
			'response_format' => 'b64_json',
		);
		if ( 'dall-e-3' === $model ) {
			$body['quality'] = 'standard';
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Content-Type'  => 'application/json; charset=utf-8',
					'Authorization' => 'Bearer ' . $api_key,
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای اتصال به سرویس تولید تصویر: %s', 'seo-project-manager' ), $response->get_error_message() ),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		// Fallback: If requested model returned 404 (deprecated), auto-retry with gemini-2.5-flash-image on AvalAI.
		if ( ( 404 === $code || 400 === $code ) && 'avalai' === $provider && 'gemini-2.5-flash-image' !== $model ) {
			$body['model']    = 'gemini-2.5-flash-image';
			$retry_res        = wp_remote_post(
				$url,
				array(
					'timeout' => $timeout,
					'headers' => array(
						'Content-Type'  => 'application/json; charset=utf-8',
						'Authorization' => 'Bearer ' . $api_key,
					),
					'body'    => wp_json_encode( $body ),
				)
			);
			if ( ! is_wp_error( $retry_res ) && wp_remote_retrieve_response_code( $retry_res ) === 200 ) {
				$code     = 200;
				$raw      = wp_remote_retrieve_body( $retry_res );
				$data     = json_decode( $raw, true );
				$model    = 'gemini-2.5-flash-image';
			}
		}

		if ( $code < 200 || $code >= 300 ) {
			$err_msg = self::extract_error( $code, $raw, $data );
			return array(
				'success' => false,
				'message' => sprintf( __( 'خطای تولید تصویر (%1$d): %2$s', 'seo-project-manager' ), $code, $err_msg ),
			);
		}

		$first = $data['data'][0] ?? array();
		if ( ! empty( $first['b64_json'] ) ) {
			return array(
				'success'  => true,
				'b64'      => (string) $first['b64_json'],
				'mime'     => 'image/png',
				'model'    => $model,
				'provider' => $provider,
			);
		}
		if ( ! empty( $first['url'] ) ) {
			return array(
				'success'  => true,
				'url'      => (string) $first['url'],
				'mime'     => 'image/png',
				'model'    => $model,
				'provider' => $provider,
			);
		}

		return array(
			'success' => false,
			'message' => __( 'پاسخ معتبری از سرویس تولید تصویر دریافت نشد.', 'seo-project-manager' ),
		);
	}

	/**
	 * Clean and parse JSON from an LLM response string.
	 *
	 * @param string $text LLM output text.
	 * @return mixed Array on success, null on failure.
	 */
	public static function parse_json( $text ) {
		$text = trim( (string) $text );
		// Strip markdown code fences if present
		if ( preg_match( '/```(?:json)?\s*([\s\S]*?)\s*```/i', $text, $matches ) ) {
			$text = trim( $matches[1] );
		}
		$decoded = json_decode( $text, true );
		return is_array( $decoded ) ? $decoded : null;
	}
}

<?php
/**
 * Jalali (Persian / Shamsi) calendar conversion.
 * Algorithm ported from jalaali-js (MIT, Behrang Noruzi Niya).
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Jalali date utilities.
 */
class Jalali {

	const MONTHS = array( 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' );

	/**
	 * Weekday names indexed by PHP 'w' (0 = Sunday).
	 */
	const WEEKDAYS = array( 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه' );

	const BREAKS = array( -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178 );

	/**
	 * Truncating integer division.
	 *
	 * @param int $a A.
	 * @param int $b B.
	 * @return int
	 */
	private static function div( $a, $b ) {
		return intdiv( $a, $b );
	}

	/**
	 * Truncating modulo.
	 *
	 * @param int $a A.
	 * @param int $b B.
	 * @return int
	 */
	private static function mod( $a, $b ) {
		return $a - intdiv( $a, $b ) * $b;
	}

	/**
	 * Jalali calendar year info.
	 *
	 * @param int $jy Jalali year.
	 * @return array{leap:int,gy:int,march:int}
	 */
	private static function jal_cal( $jy ) {
		$breaks = self::BREAKS;
		$bl     = count( $breaks );
		$gy     = $jy + 621;
		$leap_j = -14;
		$jp     = $breaks[0];
		$jump   = 0;

		for ( $i = 1; $i < $bl; $i++ ) {
			$jm   = $breaks[ $i ];
			$jump = $jm - $jp;
			if ( $jy < $jm ) {
				break;
			}
			$leap_j = $leap_j + self::div( $jump, 33 ) * 8 + self::div( self::mod( $jump, 33 ), 4 );
			$jp     = $jm;
		}
		$n      = $jy - $jp;
		$leap_j = $leap_j + self::div( $n, 33 ) * 8 + self::div( self::mod( $n, 33 ) + 3, 4 );
		if ( 4 === self::mod( $jump, 33 ) && 4 === $jump - $n ) {
			++$leap_j;
		}
		$leap_g = self::div( $gy, 4 ) - self::div( ( self::div( $gy, 100 ) + 1 ) * 3, 4 ) - 150;
		$march  = 20 + $leap_j - $leap_g;

		if ( $jump - $n < 6 ) {
			$n = $n - $jump + self::div( $jump + 4, 33 ) * 33;
		}
		$leap = self::mod( self::mod( $n + 1, 33 ) - 1, 4 );
		if ( -1 === $leap ) {
			$leap = 4;
		}
		return array(
			'leap'  => $leap,
			'gy'    => $gy,
			'march' => $march,
		);
	}

	/**
	 * Gregorian to Julian Day Number.
	 *
	 * @param int $gy Year.
	 * @param int $gm Month.
	 * @param int $gd Day.
	 * @return int
	 */
	private static function g2d( $gy, $gm, $gd ) {
		$d = self::div( ( $gy + self::div( $gm - 8, 6 ) + 100100 ) * 1461, 4 )
			+ self::div( 153 * self::mod( $gm + 9, 12 ) + 2, 5 )
			+ $gd - 34840408;
		return $d - self::div( self::div( $gy + 100100 + self::div( $gm - 8, 6 ), 100 ) * 3, 4 ) + 752;
	}

	/**
	 * Julian Day Number to Gregorian.
	 *
	 * @param int $jdn JDN.
	 * @return int[] [y, m, d]
	 */
	private static function d2g( $jdn ) {
		$j  = 4 * $jdn + 139361631;
		$j  = $j + self::div( self::div( 4 * $jdn + 183187720, 146097 ) * 3, 4 ) * 4 - 3908;
		$i  = self::div( self::mod( $j, 1461 ), 4 ) * 5 + 308;
		$gd = self::div( self::mod( $i, 153 ), 5 ) + 1;
		$gm = self::mod( self::div( $i, 153 ), 12 ) + 1;
		$gy = self::div( $j, 1461 ) - 100100 + self::div( 8 - $gm, 6 );
		return array( $gy, $gm, $gd );
	}

	/**
	 * Gregorian to Jalali.
	 *
	 * @param int $gy Year.
	 * @param int $gm Month.
	 * @param int $gd Day.
	 * @return int[] [jy, jm, jd]
	 */
	public static function to_jalali( $gy, $gm, $gd ) {
		$jdn = self::g2d( (int) $gy, (int) $gm, (int) $gd );
		list( $gy2 ) = self::d2g( $jdn );
		$jy  = $gy2 - 621;
		$r   = self::jal_cal( $jy );
		$k   = $jdn - self::g2d( $gy2, 3, $r['march'] );

		if ( $k >= 0 ) {
			if ( $k <= 185 ) {
				return array( $jy, 1 + self::div( $k, 31 ), self::mod( $k, 31 ) + 1 );
			}
			$k -= 186;
		} else {
			--$jy;
			$k += 179;
			if ( 1 === $r['leap'] ) {
				++$k;
			}
		}
		return array( $jy, 7 + self::div( $k, 30 ), self::mod( $k, 30 ) + 1 );
	}

	/**
	 * Jalali to Gregorian.
	 *
	 * @param int $jy Year.
	 * @param int $jm Month.
	 * @param int $jd Day.
	 * @return int[] [gy, gm, gd]
	 */
	public static function to_gregorian( $jy, $jm, $jd ) {
		$jy  = (int) $jy;
		$jm  = (int) $jm;
		$r   = self::jal_cal( $jy );
		$jdn = self::g2d( $r['gy'], 3, $r['march'] ) + ( $jm - 1 ) * 31 - self::div( $jm, 7 ) * ( $jm - 7 ) + (int) $jd - 1;
		return self::d2g( $jdn );
	}

	/**
	 * Whether a Jalali year is leap.
	 *
	 * @param int $jy Year.
	 * @return bool
	 */
	public static function is_leap( $jy ) {
		return 0 === self::jal_cal( (int) $jy )['leap'];
	}

	/**
	 * Days in a Jalali month.
	 *
	 * @param int $jy Year.
	 * @param int $jm Month.
	 * @return int
	 */
	public static function month_length( $jy, $jm ) {
		if ( $jm <= 6 ) {
			return 31;
		}
		if ( $jm <= 11 ) {
			return 30;
		}
		return self::is_leap( $jy ) ? 30 : 29;
	}

	/**
	 * Gregorian Y-m-d range (inclusive) for a Jalali month.
	 *
	 * @param int $jy Year.
	 * @param int $jm Month.
	 * @return string[] [start, end]
	 */
	public static function month_range( $jy, $jm ) {
		$s = self::to_gregorian( $jy, $jm, 1 );
		$e = self::to_gregorian( $jy, $jm, self::month_length( $jy, $jm ) );
		return array( sprintf( '%04d-%02d-%02d', $s[0], $s[1], $s[2] ), sprintf( '%04d-%02d-%02d', $e[0], $e[1], $e[2] ) );
	}

	/**
	 * Convert a Y-m-d (or Y-m-d H:i:s) string into Jalali parts.
	 *
	 * @param string $date Gregorian date.
	 * @return int[]|null
	 */
	public static function parts( $date ) {
		if ( ! is_string( $date ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})/', $date, $m ) ) {
			return null;
		}
		return self::to_jalali( (int) $m[1], (int) $m[2], (int) $m[3] );
	}

	/**
	 * Format a Gregorian date as Jalali.
	 *
	 * @param string $date   Gregorian Y-m-d.
	 * @param string $format 'numeric' (1405/08/24) | 'long' (24 آبان 1405) | 'month' (آبان 1405).
	 * @param bool   $fa     Use Persian digits.
	 * @return string
	 */
	public static function format( $date, $format = 'numeric', $fa = true ) {
		$p = self::parts( $date );
		if ( ! $p ) {
			return '';
		}
		switch ( $format ) {
			case 'long':
				$out = $p[2] . ' ' . self::MONTHS[ $p[1] - 1 ] . ' ' . $p[0];
				break;
			case 'month':
				$out = self::MONTHS[ $p[1] - 1 ] . ' ' . $p[0];
				break;
			default:
				$out = sprintf( '%04d/%02d/%02d', $p[0], $p[1], $p[2] );
		}
		return $fa ? self::fa_digits( $out ) : $out;
	}

	/**
	 * Format a UTC MySQL datetime as local Jalali date + time.
	 *
	 * @param string $utc  UTC datetime.
	 * @param bool   $time Include H:i.
	 * @return string
	 */
	public static function format_utc( $utc, $time = true ) {
		if ( empty( $utc ) ) {
			return '';
		}
		try {
			$dt    = new \DateTimeImmutable( (string) $utc, new \DateTimeZone( 'UTC' ) );
			$local = $dt->setTimezone( wp_timezone() )->format( 'Y-m-d H:i' );
		} catch ( \Exception $e ) {
			$local = get_date_from_gmt( $utc, 'Y-m-d H:i' );
		}
		$out = self::format( substr( $local, 0, 10 ) );
		if ( $time ) {
			$out .= ' - ' . self::fa_digits( substr( $local, 11, 5 ) );
		}
		return $out;
	}

	/**
	 * Convert Latin digits to Persian digits.
	 *
	 * @param string|int|float $value Value.
	 * @return string
	 */
	public static function fa_digits( $value ) {
		return strtr( (string) $value, array( '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹', '%' => '٪' ) );
	}

	/**
	 * Today's Gregorian ISO date in the site timezone (Y-m-d).
	 *
	 * Uses DateTimeImmutable directly instead of wp_date() so Persian date
	 * plugins (e.g. WP-Parsidate / WP-Jalali) cannot corrupt the ISO string.
	 *
	 * @return string
	 */
	public static function today() {
		try {
			return ( new \DateTimeImmutable( 'now', wp_timezone() ) )->format( 'Y-m-d' );
		} catch ( \Exception $e ) {
			return gmdate( 'Y-m-d' );
		}
	}
}

<?php
/**
 * Reports with versioned snapshots.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Report repository.
 */
class Report {

	/**
	 * Report types.
	 *
	 * @return array
	 */
	public static function types() {
		return array(
			'monthly' => __( 'ماهانه', 'seo-project-manager' ),
			'custom'  => __( 'بازه دلخواه', 'seo-project-manager' ),
		);
	}

	/**
	 * Archive list.
	 *
	 * @param array $args business_id, jmonth (YYYY-MM jalali), from, to, page, per_page.
	 * @return array{items:array,total:int,pages:int}
	 */
	public static function query( array $args = array() ) {
		global $wpdb;
		$r = Database::table( 'reports' );
		$v = Database::table( 'report_versions' );
		$b = Database::table( 'businesses' );

		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['business_id'] ) ) {
			$where[]  = 'r.business_id = %d';
			$params[] = absint( $args['business_id'] );
		}
		if ( ! empty( $args['jmonth'] ) && preg_match( '/^(\d{4})-(\d{1,2})$/', $args['jmonth'], $m ) && (int) $m[2] >= 1 && (int) $m[2] <= 12 ) {
			list( $ms, $me ) = Jalali::month_range( (int) $m[1], (int) $m[2] );
			$where[]         = 'r.start_date <= %s AND r.end_date >= %s';
			$params[]        = $me;
			$params[]        = $ms;
		}
		$from = Security::sanitize_date( $args['from'] ?? '' );
		$to   = Security::sanitize_date( $args['to'] ?? '' );
		if ( $from ) {
			$where[]  = 'r.end_date >= %s';
			$params[] = $from;
		}
		if ( $to ) {
			$where[]  = 'r.start_date <= %s';
			$params[] = $to;
		}
		$where    = implode( ' AND ', $where );
		$per_page = max( 1, min( 100, (int) ( $args['per_page'] ?? 20 ) ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$count_sql = "SELECT COUNT(*) FROM {$r} r WHERE {$where}";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );
		$rows      = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT r.id, r.business_id, r.title, r.report_type, r.start_date, r.end_date, r.status, r.pdf_path, r.created_at, r.updated_at,
					b.name AS business_name, b.color AS business_color,
					(SELECT MAX(version_no) FROM {$v} vv WHERE vv.report_id = r.id) AS versions,
					(SELECT version_no FROM {$v} cv WHERE cv.id = r.current_version_id) AS current_version
				FROM {$r} r LEFT JOIN {$b} b ON b.id = r.business_id
				WHERE {$where} ORDER BY r.created_at DESC, r.id DESC LIMIT %d OFFSET %d",
				array_merge( $params, array( $per_page, ( $page - 1 ) * $per_page ) )
			),
			ARRAY_A
		);
		// phpcs:enable

		$items = array();
		foreach ( (array) $rows as $row ) {
			if ( null === $row['business_name'] ) {
				// Business deleted but report kept: fall back to the snapshot.
				$snap                  = self::current_snapshot( (int) $row['id'] );
				$row['business_name']  = $snap['business']['name'] ?? '—';
				$row['business_color'] = $snap['business']['color'] ?? '#64748b';
			}
			$items[] = self::format_row( $row );
		}
		return array(
			'items' => $items,
			'total' => $total,
			'pages' => (int) ceil( $total / $per_page ),
		);
	}

	/**
	 * Format archive row.
	 *
	 * @param array $row Row.
	 * @return array
	 */
	private static function format_row( array $row ) {
		$types = self::types();
		return array(
			'id'               => (int) $row['id'],
			'business_id'      => (int) $row['business_id'],
			'business_name'    => $row['business_name'],
			'business_color'   => $row['business_color'],
			'title'            => $row['title'],
			'report_type'      => $row['report_type'],
			'report_type_label' => $types[ $row['report_type'] ] ?? $row['report_type'],
			'start_date'       => $row['start_date'],
			'end_date'         => $row['end_date'],
			'status'           => $row['status'],
			'has_pdf'          => ! empty( $row['pdf_path'] ),
			'versions'         => (int) ( $row['versions'] ?? 1 ),
			'current_version'  => (int) ( $row['current_version'] ?? 1 ),
			'created_at'       => $row['created_at'],
			'updated_at'       => $row['updated_at'],
		);
	}

	/**
	 * Raw report row.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function row( $id ) {
		global $wpdb;
		$r = Database::table( 'reports' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$r} WHERE id = %d", $id ), ARRAY_A ) ?: null; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Version row.
	 *
	 * @param int      $report_id Report ID.
	 * @param int|null $version   Version number (null = current).
	 * @return array|null
	 */
	public static function version( $report_id, $version = null ) {
		global $wpdb;
		$v = Database::table( 'report_versions' );
		if ( null === $version ) {
			$report = self::row( $report_id );
			if ( ! $report || ! $report['current_version_id'] ) {
				return null;
			}
			return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$v} WHERE id = %d", $report['current_version_id'] ), ARRAY_A ) ?: null; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$v} WHERE report_id = %d AND version_no = %d", $report_id, $version ), ARRAY_A ) ?: null; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Decoded current snapshot.
	 *
	 * @param int $id Report ID.
	 * @return array
	 */
	private static function current_snapshot( $id ) {
		$row  = self::row( $id );
		$data = $row ? json_decode( (string) $row['snapshot_data'], true ) : null;
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Full report (for viewer / API).
	 *
	 * @param int      $id      Report ID.
	 * @param int|null $version Version number or null for current.
	 * @return array|null
	 */
	public static function get( $id, $version = null ) {
		global $wpdb;
		$row = self::row( $id );
		if ( ! $row ) {
			return null;
		}
		$ver = self::version( $id, $version );
		if ( ! $ver ) {
			return null;
		}
		$v        = Database::table( 'report_versions' );
		$versions = $wpdb->get_results( $wpdb->prepare( "SELECT id, version_no, pdf_path, created_at FROM {$v} WHERE report_id = %d ORDER BY version_no DESC", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$snapshot = json_decode( $ver['snapshot_data'], true );

		return array(
			'id'              => (int) $row['id'],
			'business_id'     => (int) $row['business_id'],
			'title'           => $row['title'],
			'report_type'     => $row['report_type'],
			'start_date'      => $row['start_date'],
			'end_date'        => $row['end_date'],
			'status'          => $row['status'],
			'created_at'      => $row['created_at'],
			'updated_at'      => $row['updated_at'],
			'version_no'      => (int) $ver['version_no'],
			'is_current'      => (int) $ver['id'] === (int) $row['current_version_id'],
			'summary'         => (string) $ver['summary'],
			'has_pdf'         => ! empty( $ver['pdf_path'] ) && Pdf_Generator::exists( $ver['pdf_path'] ),
			'version_created' => $ver['created_at'],
			'snapshot'        => is_array( $snapshot ) ? $snapshot : array(),
			'versions'        => array_map(
				static function ( $x ) {
					return array(
						'version_no' => (int) $x['version_no'],
						'has_pdf'    => ! empty( $x['pdf_path'] ),
						'created_at' => $x['created_at'],
					);
				},
				(array) $versions
			),
		);
	}

	/**
	 * Resolve and validate period from input.
	 *
	 * @param array $data Input.
	 * @return array|\WP_Error [type, start, end]
	 */
	public static function resolve_period( array $data ) {
		$type = ( $data['report_type'] ?? 'monthly' ) === 'custom' ? 'custom' : 'monthly';
		if ( 'monthly' === $type ) {
			$jy = (int) ( $data['jyear'] ?? 0 );
			$jm = (int) ( $data['jmonth'] ?? 0 );
			if ( $jy < 1300 || $jy > 1500 || $jm < 1 || $jm > 12 ) {
				return new \WP_Error( 'seopm_report_month', __( 'ماه گزارش نامعتبر است.', 'seo-project-manager' ), array( 'status' => 400 ) );
			}
			list( $start, $end ) = Jalali::month_range( $jy, $jm );
		} else {
			$start = Security::sanitize_date( $data['start_date'] ?? '' );
			$end   = Security::sanitize_date( $data['end_date'] ?? '' );
			if ( ! $start || ! $end ) {
				return new \WP_Error( 'seopm_report_dates', __( 'تاریخ شروع و پایان را مشخص کنید.', 'seo-project-manager' ), array( 'status' => 400 ) );
			}
			if ( $start > $end ) {
				return new \WP_Error( 'seopm_report_range', __( 'تاریخ شروع نمی‌تواند بعد از تاریخ پایان باشد.', 'seo-project-manager' ), array( 'status' => 400 ) );
			}
			if ( ( strtotime( $end ) - strtotime( $start ) ) / DAY_IN_SECONDS > 731 ) {
				return new \WP_Error( 'seopm_report_range', __( 'بازه گزارش حداکثر دو سال می‌تواند باشد.', 'seo-project-manager' ), array( 'status' => 400 ) );
			}
		}
		return array( $type, $start, $end );
	}

	/**
	 * Default title for a period.
	 *
	 * @param string $type  Type.
	 * @param string $start Start.
	 * @param string $end   End.
	 * @return string
	 */
	public static function default_title( $type, $start, $end ) {
		if ( 'monthly' === $type ) {
			/* translators: %s: Jalali month and year. */
			return sprintf( __( 'گزارش عملکرد سئو %s', 'seo-project-manager' ), Jalali::format( $start, 'month' ) );
		}
		/* translators: 1: start date, 2: end date. */
		return sprintf( __( 'گزارش عملکرد سئو از %1$s تا %2$s', 'seo-project-manager' ), Jalali::format( $start ), Jalali::format( $end ) );
	}

	/**
	 * Create report (version 1) and generate its PDF.
	 *
	 * @param array $data business_id, report_type, jyear, jmonth, start_date, end_date, title, summary.
	 * @return array|\WP_Error
	 */
	public static function create( array $data ) {
		global $wpdb;
		$business = Business::get( absint( $data['business_id'] ?? 0 ), false );
		if ( ! $business ) {
			return new \WP_Error( 'seopm_report_business', __( 'کسب‌وکار را انتخاب کنید.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		$period = self::resolve_period( $data );
		if ( is_wp_error( $period ) ) {
			return $period;
		}
		list( $type, $start, $end ) = $period;

		$title   = trim( sanitize_text_field( $data['title'] ?? '' ) );
		$title   = '' === $title ? self::default_title( $type, $start, $end ) : mb_substr( $title, 0, 255 );
		$summary = wp_kses_post( $data['summary'] ?? '' );
		$now     = Database::now();

		$ok = $wpdb->insert(
			Database::table( 'reports' ),
			array(
				'business_id' => $business['id'],
				'title'       => $title,
				'report_type' => $type,
				'start_date'  => $start,
				'end_date'    => $end,
				'summary'     => $summary,
				'status'      => 'draft',
				'created_by'  => get_current_user_id(),
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
		if ( ! $ok ) {
			return new \WP_Error( 'seopm_db_error', __( 'خطا در ذخیره گزارش.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}
		$id = (int) $wpdb->insert_id;

		$snapshot = Report_Builder::build( $business, $start, $end, $type, $title );
		self::add_version( $id, $snapshot, $summary );
		self::generate_pdf( $id );

		do_action( 'seopm_report_created', $id );
		return self::get( $id );
	}

	/**
	 * Insert a new version and make it current.
	 *
	 * @param int    $report_id Report ID.
	 * @param array  $snapshot  Snapshot.
	 * @param string $summary   Summary.
	 * @return int Version row ID.
	 */
	private static function add_version( $report_id, array $snapshot, $summary ) {
		global $wpdb;
		$v    = Database::table( 'report_versions' );
		$next = 1 + (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(version_no) FROM {$v} WHERE report_id = %d", $report_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$json = wp_json_encode( $snapshot, JSON_UNESCAPED_UNICODE );
		$now  = Database::now();
		$wpdb->insert(
			$v,
			array(
				'report_id'     => $report_id,
				'version_no'    => $next,
				'snapshot_data' => $json,
				'summary'       => $summary,
				'created_by'    => get_current_user_id(),
				'created_at'    => $now,
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s' )
		);
		$version_id = (int) $wpdb->insert_id;
		$wpdb->update(
			Database::table( 'reports' ),
			array(
				'current_version_id' => $version_id,
				'snapshot_data'      => $json,
				'summary'            => $summary,
				'pdf_path'           => null,
				'status'             => 'draft',
				'updated_at'         => $now,
			),
			array( 'id' => $report_id ),
			array( '%d', '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
		return $version_id;
	}

	/**
	 * (Re)generate the PDF of the current version from its frozen snapshot.
	 *
	 * @param int $id Report ID.
	 * @return true|\WP_Error
	 */
	public static function generate_pdf( $id ) {
		global $wpdb;
		$report  = self::row( $id );
		$version = self::version( $id );
		if ( ! $report || ! $version ) {
			return new \WP_Error( 'seopm_report_not_found', __( 'گزارش یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$snapshot = json_decode( $version['snapshot_data'], true );
		$path     = Pdf_Generator::generate( (int) $id, (int) $version['version_no'], is_array( $snapshot ) ? $snapshot : array(), (string) $version['summary'], $version['pdf_path'] );
		$now      = Database::now();

		if ( is_wp_error( $path ) ) {
			$wpdb->update( Database::table( 'reports' ), array( 'status' => 'failed', 'updated_at' => $now ), array( 'id' => $id ), array( '%s', '%s' ), array( '%d' ) );
			return $path;
		}
		$wpdb->update( Database::table( 'report_versions' ), array( 'pdf_path' => $path ), array( 'id' => $version['id'] ), array( '%s' ), array( '%d' ) );
		$wpdb->update(
			Database::table( 'reports' ),
			array(
				'pdf_path'   => $path,
				'status'     => 'generated',
				'updated_at' => $now,
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s' ),
			array( '%d' )
		);
		return true;
	}

	/**
	 * Update the manager summary of the current version and rebuild its PDF.
	 * The snapshot itself is not touched.
	 *
	 * @param int    $id      Report ID.
	 * @param string $summary Summary HTML.
	 * @param string $title   Optional new title.
	 * @return array|\WP_Error
	 */
	public static function update_summary( $id, $summary, $title = null ) {
		global $wpdb;
		$version = self::version( $id );
		if ( ! $version ) {
			return new \WP_Error( 'seopm_report_not_found', __( 'گزارش یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$summary = wp_kses_post( (string) $summary );
		$wpdb->update( Database::table( 'report_versions' ), array( 'summary' => $summary ), array( 'id' => $version['id'] ), array( '%s' ), array( '%d' ) );

		$fields = array(
			'summary'    => $summary,
			'updated_at' => Database::now(),
		);
		if ( null !== $title && '' !== trim( (string) $title ) ) {
			$fields['title'] = mb_substr( sanitize_text_field( $title ), 0, 255 );
			$snapshot        = json_decode( $version['snapshot_data'], true );
			if ( is_array( $snapshot ) ) {
				$snapshot['title'] = $fields['title'];
				$json              = wp_json_encode( $snapshot, JSON_UNESCAPED_UNICODE );
				$wpdb->update( Database::table( 'report_versions' ), array( 'snapshot_data' => $json ), array( 'id' => $version['id'] ), array( '%s' ), array( '%d' ) );
				$fields['snapshot_data'] = $json;
			}
		}
		$wpdb->update( Database::table( 'reports' ), $fields, array( 'id' => $id ), null, array( '%d' ) );

		$pdf = self::generate_pdf( $id );
		if ( is_wp_error( $pdf ) ) {
			return $pdf;
		}
		return self::get( $id );
	}

	/**
	 * Create a new version with current data (previous versions are kept).
	 *
	 * @param int $id Report ID.
	 * @return array|\WP_Error
	 */
	public static function regenerate( $id ) {
		$report = self::row( $id );
		if ( ! $report ) {
			return new \WP_Error( 'seopm_report_not_found', __( 'گزارش یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$business = Business::get( (int) $report['business_id'], false );
		if ( ! $business ) {
			return new \WP_Error( 'seopm_report_business_gone', __( 'کسب‌وکار این گزارش حذف شده است؛ تولید نسخه جدید ممکن نیست.', 'seo-project-manager' ), array( 'status' => 409 ) );
		}
		$snapshot = Report_Builder::build( $business, $report['start_date'], $report['end_date'], $report['report_type'], $report['title'] );
		self::add_version( $id, $snapshot, (string) $report['summary'] );
		$pdf = self::generate_pdf( $id );
		if ( is_wp_error( $pdf ) ) {
			return $pdf;
		}
		do_action( 'seopm_report_regenerated', $id );
		return self::get( $id );
	}

	/**
	 * Report IDs of a business.
	 *
	 * @param int $business_id Business ID.
	 * @return int[]
	 */
	public static function ids_for_business( $business_id ) {
		global $wpdb;
		$r = Database::table( 'reports' );
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$r} WHERE business_id = %d", $business_id ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Delete report, all versions and PDF files.
	 *
	 * @param int $id Report ID.
	 * @return bool
	 */
	public static function delete( $id ) {
		global $wpdb;
		$v     = Database::table( 'report_versions' );
		$paths = (array) $wpdb->get_col( $wpdb->prepare( "SELECT pdf_path FROM {$v} WHERE report_id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( $paths as $path ) {
			Pdf_Generator::delete_file( $path );
		}
		$wpdb->delete( $v, array( 'report_id' => $id ), array( '%d' ) );
		$ok = (bool) $wpdb->delete( Database::table( 'reports' ), array( 'id' => $id ), array( '%d' ) );
		if ( $ok ) {
			do_action( 'seopm_report_deleted', $id );
		}
		return $ok;
	}

	/**
	 * Absolute PDF path for a version, validated to live in the storage dir.
	 *
	 * @param int      $id      Report ID.
	 * @param int|null $version Version or null for current.
	 * @return string|null
	 */
	public static function pdf_file( $id, $version = null ) {
		$ver = self::version( $id, $version );
		if ( ! $ver || empty( $ver['pdf_path'] ) ) {
			return null;
		}
		return Pdf_Generator::absolute( $ver['pdf_path'] );
	}
}

<?php
/**
 * Notes model and repository.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Note entity and CRUD operations.
 */
class Note {

	/**
	 * Available note color themes.
	 *
	 * @return array<string, array{label: string, bg: string, border: string, text: string}>
	 */
	public static function colors() {
		return array(
			'default' => array(
				'label'  => __( 'پیش‌فرض (سفید)', 'seo-project-manager' ),
				'bg'     => '#ffffff',
				'border' => '#e2e8f0',
				'text'   => '#1e293b',
			),
			'amber'   => array(
				'label'  => __( 'کهربایی / زرد', 'seo-project-manager' ),
				'bg'     => '#fffbeb',
				'border' => '#fde68a',
				'text'   => '#92400e',
			),
			'emerald' => array(
				'label'  => __( 'سبز ملایم', 'seo-project-manager' ),
				'bg'     => '#ecfdf5',
				'border' => '#a7f3d0',
				'text'   => '#065f46',
			),
			'sky'     => array(
				'label'  => __( 'آبی آسمانی', 'seo-project-manager' ),
				'bg'     => '#f0f9ff',
				'border' => '#bae6fd',
				'text'   => '#0369a1',
			),
			'indigo'  => array(
				'label'  => __( 'نیلی / بنفش', 'seo-project-manager' ),
				'bg'     => '#eef2ff',
				'border' => '#c7d2fe',
				'text'   => '#3730a3',
			),
			'rose'    => array(
				'label'  => __( 'صورتی / رز', 'seo-project-manager' ),
				'bg'     => '#fff1f2',
				'border' => '#fecdd3',
				'text'   => '#9f1239',
			),
			'purple'  => array(
				'label'  => __( 'ارغوانی', 'seo-project-manager' ),
				'bg'     => '#faf5ff',
				'border' => '#e9d5ff',
				'text'   => '#6b21a8',
			),
			'teal'    => array(
				'label'  => __( 'فیروزه‌ای', 'seo-project-manager' ),
				'bg'     => '#f0fdfa',
				'border' => '#99f6e4',
				'text'   => '#115e59',
			),
		);
	}

	/**
	 * Retrieve all notes with optional filtering.
	 *
	 * @param array $args Query filters.
	 * @return array List of formatted notes.
	 */
	public static function all( array $args = array() ) {
		global $wpdb;
		$n = Database::table( 'notes' );
		$b = Database::table( 'businesses' );

		$where  = array( '1=1' );
		$params = array();

		// Filter by business: positive ID for specific biz, '0' or 0 for general notes only.
		if ( isset( $args['business_id'] ) && '' !== $args['business_id'] && 'all' !== $args['business_id'] ) {
			$where[]  = 'n.business_id = %d';
			$params[] = absint( $args['business_id'] );
		}

		// Filter by pinned state.
		if ( isset( $args['is_pinned'] ) && '' !== $args['is_pinned'] ) {
			$where[]  = 'n.is_pinned = %d';
			$params[] = empty( $args['is_pinned'] ) ? 0 : 1;
		}

		// Filter by color.
		if ( ! empty( $args['color'] ) && isset( self::colors()[ $args['color'] ] ) ) {
			$where[]  = 'n.color = %s';
			$params[] = $args['color'];
		}

		// Search across title, content, and tags.
		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( trim( $args['search'] ) ) . '%';
			$where[]  = '(n.title LIKE %s OR n.content LIKE %s OR n.tags LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$where_clause = implode( ' AND ', $where );
		$sql          = "SELECT n.*, b.name AS business_name, b.color AS business_color
			FROM {$n} n
			LEFT JOIN {$b} b ON n.business_id = b.id
			WHERE {$where_clause}
			ORDER BY n.is_pinned DESC, n.updated_at DESC, n.id DESC";

		if ( ! empty( $params ) ) {
			$sql = $wpdb->prepare( $sql, $params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map( array( __CLASS__, 'format_row' ), $rows );
	}

	/**
	 * Retrieve a single note by ID.
	 *
	 * @param int $id Note ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$n = Database::table( 'notes' );
		$b = Database::table( 'businesses' );

		$sql = $wpdb->prepare(
			"SELECT n.*, b.name AS business_name, b.color AS business_color
			FROM {$n} n
			LEFT JOIN {$b} b ON n.business_id = b.id
			WHERE n.id = %d LIMIT 1",
			absint( $id )
		);

		$row = $wpdb->get_row( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $row ? self::format_row( $row ) : null;
	}

	/**
	 * Sanitize and clean note input data.
	 *
	 * @param array $data Raw input data.
	 * @return array|\WP_Error
	 */
	private static function clean( array $data ) {
		$title   = sanitize_text_field( $data['title'] ?? '' );
		$content = wp_kses_post( $data['content'] ?? '' );

		if ( empty( $title ) && empty( $content ) ) {
			return new \WP_Error( 'seopm_invalid_note', __( 'عنوان یا متن یادداشت نمی‌تواند خالی باشد.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$colors = self::colors();
		$color  = sanitize_key( $data['color'] ?? 'default' );
		if ( ! isset( $colors[ $color ] ) ) {
			$color = 'default';
		}

		$biz_id = isset( $data['business_id'] ) ? absint( $data['business_id'] ) : 0;
		if ( $biz_id > 0 && ! Business::exists( $biz_id ) ) {
			$biz_id = 0; // Fallback to general note if referenced business doesn't exist.
		}

		$tags = sanitize_text_field( $data['tags'] ?? '' );

		return array(
			'business_id' => $biz_id,
			'title'       => mb_substr( $title, 0, 255 ),
			'content'     => $content,
			'color'       => $color,
			'is_pinned'   => empty( $data['is_pinned'] ) ? 0 : 1,
			'tags'        => mb_substr( $tags, 0, 255 ),
		);
	}

	/**
	 * Create a new note.
	 *
	 * @param array $data Input data.
	 * @return array|\WP_Error Created note or error.
	 */
	public static function create( array $data ) {
		global $wpdb;
		$clean = self::clean( $data );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}

		$now                 = Database::now();
		$user_id             = get_current_user_id();
		$clean['created_by'] = $user_id ? absint( $user_id ) : 1;
		$clean['created_at'] = $now;
		$clean['updated_at'] = $now;

		$table = Database::table( 'notes' );
		$ok    = $wpdb->insert(
			$table,
			$clean,
			array( '%d', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' )
		);

		if ( ! $ok ) {
			// Auto-heal table if not created yet
			Database::install();
			$ok = $wpdb->insert(
				$table,
				$clean,
				array( '%d', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' )
			);
		}

		if ( ! $ok ) {
			return new \WP_Error( 'seopm_db_error', $wpdb->last_error ?: __( 'خطا در ثبت یادداشت در پایگاه داده.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}

		$id = $wpdb->insert_id;
		do_action( 'seopm_note_created', $id );
		return self::get( $id );
	}

	/**
	 * Update an existing note.
	 *
	 * @param int   $id   Note ID.
	 * @param array $data Input data.
	 * @return array|\WP_Error Updated note or error.
	 */
	public static function update( $id, array $data ) {
		global $wpdb;
		$existing = self::get( $id );
		if ( ! $existing ) {
			return new \WP_Error( 'seopm_not_found', __( 'یادداشت مورد نظر یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$merged = array_merge( $existing, $data );
		$clean  = self::clean( $merged );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}

		$clean['updated_at'] = Database::now();

		$ok = $wpdb->update(
			Database::table( 'notes' ),
			$clean,
			array( 'id' => absint( $id ) ),
			array( '%d', '%s', '%s', '%s', '%d', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $ok ) {
			return new \WP_Error( 'seopm_db_error', __( 'خطا در ویرایش یادداشت.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}

		do_action( 'seopm_note_updated', $id );
		return self::get( $id );
	}

	/**
	 * Toggle the pinned status of a note.
	 *
	 * @param int $id Note ID.
	 * @return array|\WP_Error Updated note or error.
	 */
	public static function toggle_pin( $id ) {
		global $wpdb;
		$existing = self::get( $id );
		if ( ! $existing ) {
			return new \WP_Error( 'seopm_not_found', __( 'یادداشت مورد نظر یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$new_pinned = $existing['is_pinned'] ? 0 : 1;
		$now        = Database::now();

		$wpdb->update(
			Database::table( 'notes' ),
			array(
				'is_pinned'  => $new_pinned,
				'updated_at' => $now,
			),
			array( 'id' => absint( $id ) ),
			array( '%d', '%s' ),
			array( '%d' )
		);

		do_action( 'seopm_note_pinned', $id, $new_pinned );
		return self::get( $id );
	}

	/**
	 * Delete a note.
	 *
	 * @param int $id Note ID.
	 * @return bool|\WP_Error
	 */
	public static function delete( $id ) {
		global $wpdb;
		$existing = self::get( $id );
		if ( ! $existing ) {
			return new \WP_Error( 'seopm_not_found', __( 'یادداشت مورد نظر یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$ok = $wpdb->delete(
			Database::table( 'notes' ),
			array( 'id' => absint( $id ) ),
			array( '%d' )
		);

		if ( ! $ok ) {
			return new \WP_Error( 'seopm_db_error', __( 'خطا در حذف یادداشت.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}

		do_action( 'seopm_note_deleted', $id );
		return true;
	}

	/**
	 * Format a database row into a structured output array.
	 *
	 * @param array $row Raw DB row.
	 * @return array
	 */
	public static function format_row( array $row ) {
		$id          = absint( $row['id'] );
		$business_id = absint( $row['business_id'] ?? 0 );
		$is_pinned   = (bool) ( $row['is_pinned'] ?? false );
		$color_key   = $row['color'] ?? 'default';
		$colors      = self::colors();
		$color_meta  = $colors[ $color_key ] ?? $colors['default'];

		// Authorship.
		$user_id   = absint( $row['created_by'] ?? 0 );
		$user_name = '';
		if ( $user_id ) {
			$user = get_userdata( $user_id );
			if ( $user ) {
				$user_name = $user->display_name;
			}
		}

		// Tags array.
		$tags_raw = (string) ( $row['tags'] ?? '' );
		$tags     = array_values( array_filter( array_map( 'trim', explode( ',', $tags_raw ) ) ) );

		// Jalali date formats.
		$created_at = $row['created_at'] ?? '';
		$updated_at = $row['updated_at'] ?? '';

		$created_jalali = '';
		$updated_jalali = '';
		if ( $created_at ) {
			$created_date   = substr( $created_at, 0, 10 );
			$created_time   = substr( $created_at, 11, 5 );
			$created_jalali = Jalali::format( $created_date, 'numeric', false ) . ' ' . $created_time;
		}
		if ( $updated_at ) {
			$updated_date   = substr( $updated_at, 0, 10 );
			$updated_time   = substr( $updated_at, 11, 5 );
			$updated_jalali = Jalali::format( $updated_date, 'numeric', false ) . ' ' . $updated_time;
		}

		return array(
			'id'                => $id,
			'business_id'       => $business_id,
			'business_name'     => $business_id ? ( $row['business_name'] ?? __( 'کسب‌وکار نامشخص', 'seo-project-manager' ) ) : __( 'یادداشت عمومی (همه پروژه‌ها)', 'seo-project-manager' ),
			'business_color'    => $row['business_color'] ?? '#64748b',
			'title'             => $row['title'] ?? '',
			'content'           => $row['content'] ?? '',
			'color'             => $color_key,
			'color_meta'        => $color_meta,
			'is_pinned'         => $is_pinned,
			'tags'              => $tags,
			'tags_raw'          => $tags_raw,
			'created_by'        => $user_id,
			'author_name'       => $user_name,
			'created_at'        => $created_at,
			'created_at_jalali' => $created_jalali,
			'updated_at'        => $updated_at,
			'updated_at_jalali' => $updated_jalali,
		);
	}
}

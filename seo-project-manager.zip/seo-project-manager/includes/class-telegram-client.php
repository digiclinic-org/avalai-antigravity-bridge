<?php
/**
 * Telegram Bot API client (direct + Cloudflare Worker reverse-proxy support)
 * and automatic day-before-publish client review notifications.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Telegram client & review scheduler.
 */
class Telegram_Client {

	const CRON_HOOK        = 'seopm_telegram_daily_review';
	const DEFAULT_API_BASE = 'https://api.telegram.org';

	/**
	 * Ensure hourly WP-Cron event is scheduled.
	 */
	public static function ensure_cron() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 120, 'hourly', self::CRON_HOOK );
		}
	}

	/**
	 * Resolve active Telegram credentials with optional unsaved overrides (e.g. from test buttons).
	 *
	 * @param array $overrides Optional overrides.
	 * @return array
	 */
	public static function get_config( array $overrides = array() ) {
		$s = Settings::all();

		$token = trim( (string) ( $overrides['bot_token'] ?? '' ) );
		if ( '' === $token || false !== strpos( $token, '****' ) || false !== strpos( $token, '...' ) ) {
			$token = trim( (string) ( $s['telegram_bot_token'] ?? '' ) );
		}

		$proxy = array_key_exists( 'proxy_url', $overrides )
			? untrailingslashit( trim( (string) $overrides['proxy_url'] ) )
			: untrailingslashit( trim( (string) ( $s['telegram_proxy_url'] ?? '' ) ) );

		$secret = trim( (string) ( $overrides['proxy_secret'] ?? '' ) );
		if ( '' === $secret || false !== strpos( $secret, '****' ) || false !== strpos( $secret, '...' ) ) {
			$secret = trim( (string) ( $s['telegram_proxy_secret'] ?? '' ) );
		}

		return array(
			'bot_token'     => $token,
			'bot_username'  => ltrim( trim( (string) ( $s['telegram_bot_username'] ?? '' ) ), '@' ),
			'proxy_url'     => $proxy,
			'proxy_secret'  => $secret,
			'admin_chat_id' => trim( (string) ( $s['telegram_admin_chat_id'] ?? '' ) ),
			'auto_enabled'  => ! empty( $s['telegram_auto_enabled'] ),
			'send_hour'     => (string) ( $s['telegram_send_hour'] ?? '10:00' ),
		);
	}

	/**
	 * Whether Telegram bot token is configured.
	 *
	 * @return bool
	 */
	public static function is_configured() {
		$cfg = self::get_config();
		return '' !== $cfg['bot_token'];
	}

	/**
	 * Call any Telegram Bot API method via Cloudflare Worker proxy (if configured) or directly.
	 *
	 * @param string $method    Telegram method (e.g. getMe, sendMessage, getUpdates).
	 * @param array  $params    JSON body parameters.
	 * @param array  $overrides Optional unsaved credentials.
	 * @return array|\WP_Error
	 */
	public static function api_request( $method, array $params = array(), array $overrides = array() ) {
		$cfg = self::get_config( $overrides );
		if ( '' === $cfg['bot_token'] ) {
			return new \WP_Error(
				'seopm_tg_no_token',
				__( 'توکن ربات تلگرام (Bot Token) در تنظیمات وارد نشده است.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$base      = '' !== $cfg['proxy_url'] ? $cfg['proxy_url'] : self::DEFAULT_API_BASE;
		$via_proxy = '' !== $cfg['proxy_url'];
		$endpoint  = untrailingslashit( $base ) . '/bot' . rawurlencode( $cfg['bot_token'] ) . '/' . ltrim( (string) $method, '/' );

		$headers = array(
			'Content-Type' => 'application/json; charset=utf-8',
			'Accept'       => 'application/json',
		);
		if ( $via_proxy && '' !== $cfg['proxy_secret'] ) {
			$headers['X-TG-Proxy-Secret'] = $cfg['proxy_secret'];
		}

		$args = array(
			'timeout'   => 20,
			'headers'   => $headers,
			'sslverify' => true,
		);
		if ( ! empty( $params ) ) {
			$args['body'] = wp_json_encode( $params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		}

		$t0  = microtime( true );
		$res = wp_remote_post( $endpoint, $args );
		$ms  = (int) round( ( microtime( true ) - $t0 ) * 1000 );

		if ( is_wp_error( $res ) ) {
			$err_msg = $res->get_error_message();
			if ( ! $via_proxy ) {
				$err_msg .= ' — ' . __( 'اگر هاست شما در ایران است، تلگرام مسدود است؛ لطفاً آدرس Cloudflare Worker پروکسی را در تنظیمات تلگرام وارد کنید.', 'seo-project-manager' );
			}
			return new \WP_Error( 'seopm_tg_http_error', $err_msg, array( 'status' => 502 ) );
		}

		$code = (int) wp_remote_retrieve_response_code( $res );
		$raw  = wp_remote_retrieve_body( $res );
		$data = json_decode( $raw, true );

		if ( 403 === $code && $via_proxy ) {
			return new \WP_Error(
				'seopm_tg_proxy_forbidden',
				__( 'پروکسی Cloudflare دسترسی را رد کرد (۴۰۳). لطفاً «رمز امنیتی پروکسی (Proxy Secret)» را با مقدار تنظیم‌شده در Worker مطابقت دهید.', 'seo-project-manager' ),
				array( 'status' => 403 )
			);
		}

		if ( ! is_array( $data ) || empty( $data['ok'] ) ) {
			$desc = is_array( $data ) && ! empty( $data['description'] )
				? (string) $data['description']
				: sprintf( 'HTTP %d: %s', $code, mb_substr( wp_strip_all_tags( (string) $raw ), 0, 180 ) );
			return new \WP_Error(
				'seopm_tg_api_error',
				sprintf( __( 'خطای API تلگرام: %s', 'seo-project-manager' ), $desc ),
				array( 'status' => 400 )
			);
		}

		return array(
			'ok'         => true,
			'result'     => $data['result'] ?? array(),
			'latency_ms' => $ms,
			'via_proxy'  => $via_proxy,
		);
	}

	/**
	 * Test bot connection via getMe and persist detected @bot_username.
	 *
	 * @param array $overrides Optional unsaved credentials.
	 * @return array|\WP_Error
	 */
	public static function test_connection( array $overrides = array() ) {
		$res = self::api_request( 'getMe', array(), $overrides );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$me       = is_array( $res['result'] ) ? $res['result'] : array();
		$username = ltrim( sanitize_text_field( $me['username'] ?? '' ), '@' );
		$bot_name = sanitize_text_field( $me['first_name'] ?? '' );

		// Save detected bot username automatically so deep links work immediately.
		if ( '' !== $username ) {
			$all = Settings::all();
			if ( ( $all['telegram_bot_username'] ?? '' ) !== $username ) {
				$all['telegram_bot_username'] = $username;
				update_option( Settings::OPTION, $all, false );
			}
		}

		return array(
			'success'      => true,
			'bot_username' => $username,
			'bot_name'     => $bot_name,
			'latency_ms'   => $res['latency_ms'],
			'via_proxy'    => $res['via_proxy'],
			'message'      => sprintf(
				/* translators: 1: bot name, 2: bot username, 3: route mode, 4: latency */
				__( 'اتصال به ربات «%1$s» (@%2$s) با موفقیت برقرار شد (%3$s · %4$d میلی‌ثانیه).', 'seo-project-manager' ),
				$bot_name ?: 'Telegram Bot',
				$username ?: 'bot',
				$res['via_proxy'] ? 'از طریق پروکسی Cloudflare' : 'اتصال مستقیم',
				(int) $res['latency_ms']
			),
		);
	}

	/**
	 * Fetch recent chats/groups that messaged or started the bot via getUpdates.
	 *
	 * @param array $overrides Optional unsaved credentials.
	 * @return array|\WP_Error
	 */
	public static function get_recent_chats( array $overrides = array() ) {
		$res = self::api_request(
			'getUpdates',
			array(
				'limit'           => 40,
				'allowed_updates' => array( 'message', 'my_chat_member', 'channel_post' ),
			),
			$overrides
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		$updates = is_array( $res['result'] ) ? $res['result'] : array();
		$chats   = array();

		foreach ( array_reverse( $updates ) as $u ) {
			$msg = $u['message'] ?? ( $u['channel_post'] ?? ( $u['my_chat_member'] ?? null ) );
			if ( ! is_array( $msg ) || empty( $msg['chat']['id'] ) ) {
				continue;
			}
			$chat    = $msg['chat'];
			$chat_id = (string) $chat['id'];
			$text    = trim( (string) ( $msg['text'] ?? '' ) );

			$matched_biz_id = 0;
			if ( preg_match( '/^\/start(?:@\S+)?\s+biz_(\d+)/i', $text, $m ) ) {
				$matched_biz_id = (int) $m[1];
			}

			if ( isset( $chats[ $chat_id ] ) ) {
				if ( $matched_biz_id && empty( $chats[ $chat_id ]['matched_business_id'] ) ) {
					$chats[ $chat_id ]['matched_business_id'] = $matched_biz_id;
				}
				continue;
			}

			$type  = (string) ( $chat['type'] ?? 'private' );
			$title = trim( (string) ( $chat['title'] ?? '' ) );
			if ( '' === $title ) {
				$title = trim( (string) ( $chat['first_name'] ?? '' ) . ' ' . (string) ( $chat['last_name'] ?? '' ) );
			}
			$uname = trim( (string) ( $chat['username'] ?? '' ) );

			$chats[ $chat_id ] = array(
				'chat_id'             => $chat_id,
				'type'                => $type,
				'title'               => $title ?: ( $uname ? '@' . $uname : $chat_id ),
				'username'            => $uname ? '@' . ltrim( $uname, '@' ) : '',
				'last_text'           => mb_substr( $text, 0, 80 ),
				'matched_business_id' => $matched_biz_id,
				'date'                => ! empty( $msg['date'] ) ? gmdate( 'Y-m-d H:i:s', (int) $msg['date'] ) : '',
			);
		}

		return array(
			'success' => true,
			'chats'   => array_values( $chats ),
		);
	}

	/**
	 * Send an HTML-formatted message to a Telegram chat ID.
	 *
	 * @param string $chat_id         Target chat ID.
	 * @param string $html_text       Telegram HTML message text.
	 * @param array  $inline_keyboard Optional inline keyboard rows.
	 * @param array  $overrides       Optional credentials overrides.
	 * @return array|\WP_Error
	 */
	public static function send_message( $chat_id, $html_text, array $inline_keyboard = array(), array $overrides = array() ) {
		$chat_id = preg_replace( '/[^0-9\-]/', '', trim( (string) $chat_id ) );
		if ( '' === $chat_id ) {
			return new \WP_Error(
				'seopm_tg_no_chat_id',
				__( 'شناسه چت تلگرام (Chat ID) وارد نشده است.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$payload = array(
			'chat_id'                  => $chat_id,
			'text'                     => (string) $html_text,
			'parse_mode'               => 'HTML',
			'disable_web_page_preview' => false,
		);
		if ( ! empty( $inline_keyboard ) ) {
			$payload['reply_markup'] = array(
				'inline_keyboard' => $inline_keyboard,
			);
		}

		return self::api_request( 'sendMessage', $payload, $overrides );
	}

	/**
	 * Send a quick connectivity test message to a given chat ID (or saved admin chat ID).
	 *
	 * @param array $params { chat_id, bot_token, proxy_url, proxy_secret, business_name }.
	 * @return array|\WP_Error
	 */
	public static function send_test_message( array $params = array() ) {
		$cfg     = self::get_config( $params );
		$chat_id = preg_replace( '/[^0-9\-]/', '', trim( (string) ( $params['chat_id'] ?? $cfg['admin_chat_id'] ) ) );
		if ( '' === $chat_id ) {
			return new \WP_Error(
				'seopm_tg_missing_chat',
				__( 'لطفاً ابتدا شناسه چت تلگرام (Chat ID) را وارد کنید.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		$biz_name = trim( sanitize_text_field( $params['business_name'] ?? '' ) );
		$agency   = trim( (string) Settings::get( 'agency_name' ) ) ?: get_bloginfo( 'name' );

		$text = "✅ <b>اتصال ربات تلگرام با موفقیت برقرار شد!</b>\n\n";
		if ( '' !== $biz_name ) {
			$text .= '🏢 <b>کسب‌وکار:</b> ' . esc_html( $biz_name ) . "\n";
		}
		$text .= '📣 <b>سیستم:</b> ' . esc_html( $agency ) . "\n"
			. "از این پس لینک پیش‌نمایش مقالات یک روز قبل از انتشار جهت بررسی و تأیید، به‌صورت خودکار به این گفتگو ارسال خواهد شد.";

		$res = self::send_message( $chat_id, $text, array(), $params );
		if ( is_wp_error( $res ) ) {
			return $res;
		}

		return array(
			'success'    => true,
			'latency_ms' => $res['latency_ms'],
			'message'    => __( 'پیام تست با موفقیت در تلگرام ارسال شد.', 'seo-project-manager' ),
		);
	}

	/**
	 * Send full article preview link to a business's Telegram chat for client review & approval.
	 *
	 * @param int    $business_id Business ID.
	 * @param string $article_key Article key (optional if task_id provided).
	 * @param int    $task_id     Task ID (optional).
	 * @param bool   $force       Allow re-sending even if already sent for this date.
	 * @return array|\WP_Error
	 */
	public static function send_article_preview( $business_id = 0, $article_key = '', $task_id = 0, $force = true ) {
		$task = $task_id ? Task::get( absint( $task_id ) ) : null;
		if ( $task_id && ! $task ) {
			return new \WP_Error( 'seopm_task_not_found', __( 'تسک یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		if ( $task ) {
			$business_id = (int) $task['business_id'];
			if ( '' === $article_key ) {
				$article_key = ! empty( $task['article_key'] ) ? (string) $task['article_key'] : Article_Generator::make_key( $task['title'] );
			}
		}

		$business_id = Article_Generator::resolve_business_id( $business_id );
		$biz         = $business_id ? Business::get( $business_id, false ) : null;
		if ( ! $biz ) {
			$all_biz = Business::all();
			if ( ! empty( $all_biz ) ) {
				$business_id = absint( $all_biz[0]['id'] );
				$biz         = Business::get( $business_id, false );
			}
		}
		if ( ! $biz ) {
			return new \WP_Error( 'seopm_invalid_business', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		$chat_id = trim( (string) ( $biz['telegram_chat_id'] ?? '' ) );
		if ( '' === $chat_id ) {
			return new \WP_Error(
				'seopm_tg_biz_not_connected',
				sprintf( __( 'شناسه تلگرام (Chat ID) برای کسب‌وکار «%s» ثبت نشده است.', 'seo-project-manager' ), $biz['name'] ),
				array( 'status' => 400 )
			);
		}

		$article_key = sanitize_key( $article_key );
		$draft       = '' !== $article_key ? Article_Generator::get_draft( $business_id, $article_key ) : null;
		if ( ! $draft || ( empty( $draft['has_html'] ) && empty( $draft['has_article'] ) ) ) {
			return new \WP_Error(
				'seopm_tg_no_content',
				__( 'هنوز متن یا کد HTML این مقاله تولید نشده است؛ ابتدا مقاله را آماده کنید.', 'seo-project-manager' ),
				array( 'status' => 400 )
			);
		}

		if ( ! $task ) {
			$task = Task::find_by_article( $business_id, $article_key, $draft['title'] ?? '' );
		}

		$due_date = $task ? (string) $task['due_date'] : '';
		if ( ! $force && '' !== $due_date && ( $draft['review_sent_for_date'] ?? '' ) === $due_date ) {
			return array(
				'skipped' => true,
				'reason'  => 'already_sent_for_date',
			);
		}

		$token = Article_Preview::ensure_token( $business_id, $article_key );
		if ( '' === $token ) {
			return new \WP_Error( 'seopm_preview_token_err', __( 'خطا در ساخت لینک پیش‌نمایش مقاله.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}

		$preview_url  = Article_Preview::get_url( $token );
		$title        = trim( (string) ( $draft['title'] ?: ( $task['title'] ?? '' ) ) );
		$publish_time = (string) ( $biz['wp_publish_time'] ?? '21:00' );
		$jalali_date  = '' !== $due_date ? Jalali::format( $due_date, 'long', true ) : '';

		$lines = array(
			'📝 <b>پیش‌نمایش مقاله جدید آماده بررسی است</b>',
			'',
			'🏢 <b>پروژه:</b> ' . esc_html( $biz['name'] ),
			'📌 <b>عنوان مقاله:</b> ' . esc_html( $title ),
		);
		if ( '' !== $jalali_date ) {
			$lines[] = '📅 <b>زمان برنامه‌ریزی انتشار:</b> ' . esc_html( $jalali_date ) . ' ساعت ' . esc_html( Jalali::fa_digits( $publish_time ) );
		}
		if ( ! empty( $draft['keyword'] ) ) {
			$lines[] = '🔑 <b>کلیدواژه هدف:</b> ' . esc_html( $draft['keyword'] );
		}
		$lines[] = '';
		$lines[] = 'لطفاً از طریق لینک زیر نسخه کامل مقاله (متن و تصاویر) را مشاهده فرمایید و در انتهای صفحه گزینه <b>«تأیید و آماده انتشار»</b> یا <b>«ثبت نظر / اصلاحیه»</b> را انتخاب کنید:';
		$lines[] = '🔗 <a href="' . esc_url( $preview_url ) . '">' . esc_html( $preview_url ) . '</a>';

		$keyboard = array(
			array(
				array(
					'text' => '👁 مشاهده کامل مقاله و ثبت تأیید / نظر',
					'url'  => $preview_url,
				),
			),
		);

		$send_res = self::send_message( $chat_id, implode( "\n", $lines ), $keyboard );
		if ( is_wp_error( $send_res ) ) {
			return $send_res;
		}

		global $wpdb;
		$table      = Database::table( 'article_drafts' );
		$now        = Database::now();
		$new_status = ( 'approved' === ( $draft['review_status'] ?? '' ) ) ? 'approved' : 'sent';

		$wpdb->update(
			$table,
			array(
				'review_status'        => $new_status,
				'review_sent_at'       => $now,
				'review_sent_for_date' => '' !== $due_date ? $due_date : null,
				'updated_at'           => $now,
			),
			array(
				'business_id' => $business_id,
				'article_key' => $article_key,
			),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d', '%s' )
		);

		return array(
			'success'        => true,
			'business_id'    => $business_id,
			'article_key'    => $article_key,
			'review_token'   => $token,
			'review_url'     => $preview_url,
			'review_status'  => $new_status,
			'review_sent_at' => $now,
			'message'        => sprintf(
				__( 'لینک پیش‌نمایش مقاله با موفقیت به تلگرام «%s» ارسال شد.', 'seo-project-manager' ),
				$biz['name']
			),
		);
	}

	/**
	 * Notify the agency admin on Telegram whenever a client approves or submits revision notes.
	 *
	 * @param array      $biz      Business row.
	 * @param array      $draft    Article draft row.
	 * @param array|null $task     Optional linked task.
	 * @param string     $status   'approved' | 'changes_requested'.
	 * @param string     $feedback Client comment.
	 */
	public static function notify_admin_feedback( array $biz, array $draft, $task, $status, $feedback = '' ) {
		$cfg = self::get_config();
		if ( '' === $cfg['bot_token'] || '' === $cfg['admin_chat_id'] ) {
			return;
		}

		$is_approved = ( 'approved' === $status );
		$icon        = $is_approved ? '✅' : '✏️';
		$headline    = $is_approved
			? 'کارفرما مقاله را تأیید کرد (آماده انتشار)'
			: 'کارفرما برای مقاله اصلاحیه / نظر ثبت کرد';

		$preview_url = ! empty( $draft['review_token'] ) ? Article_Preview::get_url( $draft['review_token'] ) : '';
		$due_date    = ( is_array( $task ) && ! empty( $task['due_date'] ) ) ? Jalali::format( $task['due_date'], 'long', true ) : '';

		$lines = array(
			$icon . ' <b>' . esc_html( $headline ) . '</b>',
			'',
			'🏢 <b>کسب‌وکار:</b> ' . esc_html( $biz['name'] ?? '' ),
			'📌 <b>مقاله:</b> ' . esc_html( $draft['title'] ?? '' ),
		);
		if ( '' !== $due_date ) {
			$lines[] = '📅 <b>تاریخ انتشار در تقویم:</b> ' . esc_html( $due_date );
		}
		if ( '' !== trim( $feedback ) ) {
			$lines[] = '';
			$lines[] = '💬 <b>نظر کارفرما:</b>';
			$lines[] = '<blockquote>' . esc_html( trim( $feedback ) ) . '</blockquote>';
		}

		$keyboard = array();
		if ( '' !== $preview_url ) {
			$keyboard[] = array(
				array(
					'text' => '🔗 مشاهده صفحه پیش‌نمایش مقاله',
					'url'  => $preview_url,
				),
			);
		}

		self::send_message( $cfg['admin_chat_id'], implode( "\n", $lines ), $keyboard );
	}

	/**
	 * Daily automated check (WP-Cron or manual run): find all articles scheduled for TOMORROW
	 * and send their preview links to each business's Telegram chat.
	 *
	 * @param bool $ignore_hour When true (manual trigger), runs regardless of configured send hour.
	 * @return array Summary report.
	 */
	public static function run_daily_pre_publish_notifications( $ignore_hour = false ) {
		$cfg = self::get_config();
		if ( '' === $cfg['bot_token'] ) {
			return array(
				'ran'     => false,
				'reason'  => __( 'توکن ربات تلگرام تنظیم نشده است.', 'seo-project-manager' ),
				'sent'    => 0,
				'skipped' => 0,
				'errors'  => array(),
			);
		}
		if ( ! $ignore_hour && ! $cfg['auto_enabled'] ) {
			return array(
				'ran'     => false,
				'reason'  => __( 'ارسال خودکار تلگرام در تنظیمات غیرفعال است.', 'seo-project-manager' ),
				'sent'    => 0,
				'skipped' => 0,
				'errors'  => array(),
			);
		}

		try {
			$tz       = wp_timezone();
			$now_dt   = new \DateTimeImmutable( 'now', $tz );
			$now_hm   = $now_dt->format( 'H:i' );
			$tomorrow = $now_dt->modify( '+1 day' )->format( 'Y-m-d' );
		} catch ( \Exception $e ) {
			$now_hm   = gmdate( 'H:i' );
			$tomorrow = gmdate( 'Y-m-d', strtotime( '+1 day' ) );
		}

		if ( ! $ignore_hour && $now_hm < $cfg['send_hour'] ) {
			return array(
				'ran'      => false,
				'reason'   => sprintf( __( 'هنوز ساعت ارسال (%s) فرا نرسیده است.', 'seo-project-manager' ), $cfg['send_hour'] ),
				'tomorrow' => $tomorrow,
				'sent'     => 0,
				'skipped'  => 0,
				'errors'   => array(),
			);
		}

		global $wpdb;
		$t_tasks = Database::table( 'tasks' );
		$t_biz   = Database::table( 'businesses' );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT t.id AS task_id, t.business_id, t.title, t.article_key, t.due_date, b.name AS business_name
				 FROM {$t_tasks} t
				 INNER JOIN {$t_biz} b ON b.id = t.business_id
				 WHERE t.due_date = %s
				   AND t.task_type IN ('article_writing', 'article_optimization')
				   AND t.status <> 'completed'
				   AND b.telegram_chat_id <> ''
				   AND b.telegram_notify_enabled = 1
				 ORDER BY t.id ASC",
				$tomorrow
			),
			ARRAY_A
		);
		// phpcs:enable

		$sent    = 0;
		$skipped = 0;
		$errors  = array();
		$items   = array();

		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$biz_id = (int) $row['business_id'];
				$akey   = ! empty( $row['article_key'] ) ? (string) $row['article_key'] : Article_Generator::make_key( (string) $row['title'] );
				$draft  = Article_Generator::get_draft( $biz_id, $akey );

				if ( ! $draft || ( empty( $draft['has_html'] ) && empty( $draft['has_article'] ) ) ) {
					$skipped++;
					$items[] = $row['title'] . ' (محتوا هنوز آماده نیست)';
					continue;
				}
				if ( ( $draft['review_sent_for_date'] ?? '' ) === $tomorrow || 'approved' === ( $draft['review_status'] ?? '' ) ) {
					$skipped++;
					$items[] = $row['title'] . ' (قبلاً ارسال یا تأیید شده)';
					continue;
				}

				$res = self::send_article_preview( $biz_id, $akey, (int) $row['task_id'], false );
				if ( is_wp_error( $res ) ) {
					$errors[] = $row['title'] . ': ' . $res->get_error_message();
				} elseif ( ! empty( $res['skipped'] ) ) {
					$skipped++;
				} else {
					$sent++;
					$items[] = $row['title'] . ' ✓ ارسال شد';
				}
			}
		}

		return array(
			'ran'            => true,
			'tomorrow'       => $tomorrow,
			'tomorrow_label' => Jalali::format( $tomorrow, 'long', true ),
			'checked'        => is_array( $rows ) ? count( $rows ) : 0,
			'sent'           => $sent,
			'skipped'        => $skipped,
			'errors'         => $errors,
			'items'          => $items,
			'message'        => sprintf(
				/* translators: 1: tomorrow jalali date, 2: sent count, 3: skipped count */
				__( 'بررسی مقالات فردا (%1$s) انجام شد: %2$d مورد ارسال شد، %3$d مورد رد/تکراری بود.', 'seo-project-manager' ),
				Jalali::format( $tomorrow, 'long', true ),
				$sent,
				$skipped
			),
		);
	}

	/**
	 * Ready-to-deploy Cloudflare Worker proxy code for Iranian hosts.
	 *
	 * @return string
	 */
	public static function cloudflare_worker_snippet() {
		return <<<'JS'
export default {
  async fetch(request, env) {
    // اختیاری: اگر در تنظیمات افزونه «رمز امنیتی پروکسی» گذاشته‌اید،
    // در Cloudflare Worker متغیر محیطی PROXY_SECRET را با همین مقدار بسازید.
    if (env.PROXY_SECRET) {
      const provided = request.headers.get("X-TG-Proxy-Secret") || "";
      if (provided !== env.PROXY_SECRET) {
        return new Response(JSON.stringify({ ok: false, description: "Forbidden" }), {
          status: 403,
          headers: { "Content-Type": "application/json" }
        });
      }
    }

    const url = new URL(request.url);
    if (!url.pathname.startsWith("/bot")) {
      return new Response("SEO Project Manager Telegram Proxy OK", { status: 200 });
    }

    const targetUrl = "https://api.telegram.org" + url.pathname + url.search;
    const headers = new Headers(request.headers);
    headers.delete("Host");
    headers.delete("X-TG-Proxy-Secret");

    const response = await fetch(targetUrl, {
      method: request.method,
      headers,
      body: request.method === "GET" || request.method === "HEAD" ? undefined : request.body
    });

    return new Response(response.body, {
      status: response.status,
      headers: response.headers
    });
  }
};
JS;
	}
}

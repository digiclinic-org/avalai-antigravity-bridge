<?php
/**
 * Public, token-protected, login-free Article Preview & Client Approval page.
 *
 * Clients open https://site.tld/?seopm_preview=<token> directly from Telegram,
 * read the full rendered article (featured image + HTML + full-size in-content images),
 * and click "Approve" or submit revision feedback without needing a WordPress login.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Public article preview & feedback handler.
 */
class Article_Preview {

	const QUERY_VAR = 'seopm_preview';

	/**
	 * Build the public preview URL for a given review token.
	 *
	 * @param string $token Review token.
	 * @return string
	 */
	public static function get_url( $token ) {
		$token = preg_replace( '/[^a-f0-9]/i', '', (string) $token );
		if ( '' === $token ) {
			return '';
		}
		return add_query_arg( self::QUERY_VAR, $token, home_url( '/' ) );
	}

	/**
	 * Ensure a draft has a cryptographically secure review token and return it.
	 *
	 * @param int    $business_id Business ID.
	 * @param string $article_key Article key.
	 * @return string
	 */
	public static function ensure_token( $business_id, $article_key ) {
		global $wpdb;
		$table       = Database::table( 'article_drafts' );
		$business_id = absint( $business_id );
		$article_key = sanitize_key( $article_key );

		if ( ! $business_id || '' === $article_key ) {
			return '';
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing = (string) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT review_token FROM {$table} WHERE business_id = %d AND article_key = %s",
				$business_id,
				$article_key
			)
		);
		if ( '' !== $existing ) {
			return $existing;
		}

		try {
			$token = bin2hex( random_bytes( 20 ) );
		} catch ( \Exception $e ) {
			$token = wp_generate_password( 40, false, false );
		}

		$wpdb->update(
			$table,
			array( 'review_token' => $token ),
			array(
				'business_id' => $business_id,
				'article_key' => $article_key,
			),
			array( '%s' ),
			array( '%d', '%s' )
		);

		return $token;
	}

	/**
	 * Find a draft row by its public review token.
	 *
	 * @param string $token Token string.
	 * @return array|null
	 */
	public static function get_draft_by_token( $token ) {
		$token = preg_replace( '/[^a-f0-9]/i', '', trim( (string) $token ) );
		if ( strlen( $token ) < 24 ) {
			return null;
		}

		global $wpdb;
		$table = Database::table( 'article_drafts' );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE review_token = %s LIMIT 1", $token ),
			ARRAY_A
		);
		return $row ? Article_Generator::format_draft( $row ) : null;
	}

	/**
	 * Handle public client feedback submission (called from public REST endpoint).
	 *
	 * @param array $params { token, status, feedback }.
	 * @return array|\WP_Error
	 */
	public static function submit_feedback( array $params ) {
		$token    = preg_replace( '/[^a-f0-9]/i', '', trim( (string) ( $params['token'] ?? '' ) ) );
		$status   = sanitize_key( (string) ( $params['status'] ?? '' ) );
		$feedback = trim( sanitize_textarea_field( (string) ( $params['feedback'] ?? '' ) ) );

		if ( ! in_array( $status, array( 'approved', 'changes_requested' ), true ) ) {
			return new \WP_Error( 'seopm_invalid_status', __( 'وضعیت انتخاب‌شده معتبر نیست.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		if ( 'changes_requested' === $status && '' === $feedback ) {
			return new \WP_Error( 'seopm_feedback_required', __( 'لطفاً توضیحات یا اصلاحات مورد نظر خود را بنویسید.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$draft = self::get_draft_by_token( $token );
		if ( ! $draft ) {
			return new \WP_Error( 'seopm_invalid_token', __( 'لینک پیش‌نمایش معتبر نیست یا منقضی شده است.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}

		global $wpdb;
		$table = Database::table( 'article_drafts' );
		$now   = Database::now();

		$wpdb->update(
			$table,
			array(
				'review_status'      => $status,
				'review_feedback'    => $feedback,
				'review_feedback_at' => $now,
				'updated_at'         => $now,
			),
			array(
				'business_id' => (int) $draft['business_id'],
				'article_key' => (string) $draft['article_key'],
			),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d', '%s' )
		);

		$biz  = Business::get( (int) $draft['business_id'], false ) ?: array( 'name' => '' );
		$task = Task::find_by_article( (int) $draft['business_id'], (string) $draft['article_key'], $draft['title'] ?? '' );

		// Notify the agency admin instantly on Telegram.
		Telegram_Client::notify_admin_feedback( $biz, $draft, $task, $status, $feedback );

		return array(
			'success'            => true,
			'review_status'      => $status,
			'review_feedback'    => $feedback,
			'review_feedback_at' => $now,
			'message'            => 'approved' === $status
				? __( 'سپاسگزاریم! تأیید شما با موفقیت ثبت شد و مقاله طبق زمان‌بندی منتشر خواهد شد.', 'seo-project-manager' )
				: __( 'اصلاحیه و نظر شما با موفقیت ثبت و برای تیم تحریریه ارسال شد.', 'seo-project-manager' ),
		);
	}

	/**
	 * Intercept /?seopm_preview=<token> and output a clean, responsive RTL Persian preview page.
	 */
	public static function maybe_render() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET[ self::QUERY_VAR ] ) ) {
			return;
		}

		// Prevent caching plugins (LiteSpeed, WP Rocket, etc.) and search engines from caching/indexing drafts.
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow, noarchive', true );
		header( 'Content-Type: text/html; charset=utf-8', true );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$token = preg_replace( '/[^a-f0-9]/i', '', (string) wp_unslash( $_GET[ self::QUERY_VAR ] ) );
		$draft = self::get_draft_by_token( $token );

		if ( ! $draft ) {
			status_header( 404 );
			echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>پیش‌نمایش یافت نشد</title>'
				. '<style>body{font-family:Tahoma,system-ui,-apple-system,sans-serif;background:#f8fafc;color:#0f172a;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px}.box{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:32px;max-width:460px;text-align:center;box-shadow:0 8px 30px rgba(15,23,42,.06)}h1{margin:0 0 10px;font-size:20px}p{margin:0;color:#64748b;line-height:1.8;font-size:14px}</style>'
				. '</head><body><div class="box"><h1>لینک پیش‌نمایش معتبر نیست</h1><p>این لینک پیش‌نمایش وجود ندارد یا حذف شده است. لطفاً لینک جدید را از تیم سئو دریافت کنید.</p></div></body></html>';
			exit;
		}

		status_header( 200 );

		$biz          = Business::get( (int) $draft['business_id'], false ) ?: array();
		$task         = Task::find_by_article( (int) $draft['business_id'], (string) $draft['article_key'], $draft['title'] ?? '' );
		$branding     = Settings::branding();
		$accent       = ! empty( $biz['color'] ) ? $biz['color'] : ( ! empty( $branding['report_color'] ) ? $branding['report_color'] : '#4f46e5' );
		$agency_name  = $branding['agency_name'] ?: get_bloginfo( 'name' );
		$logo_url     = $branding['logo_url'] ?? '';
		$title        = $draft['title'] ?: ( $task['title'] ?? 'پیش‌نمایش مقاله' );
		$slug         = $draft['url_slug'] ?? '';
		$featured_url = $draft['featured_image_url'] ?? '';
		$article_body = '' !== trim( (string) ( $draft['article_html'] ?? '' ) )
			? (string) $draft['article_html']
			: (string) ( $draft['article_content'] ?? '' );

		$publish_time = (string) ( $biz['wp_publish_time'] ?? '21:00' );
		$due_date_fa  = ( $task && ! empty( $task['due_date'] ) )
			? Jalali::format( $task['due_date'], 'long', true ) . ' ساعت ' . Jalali::fa_digits( $publish_time )
			: '';

		$review_status   = (string) ( $draft['review_status'] ?? '' );
		$review_feedback = (string) ( $draft['review_feedback'] ?? '' );
		$review_time_fa  = ! empty( $draft['review_feedback_at'] ) ? Jalali::format_utc( $draft['review_feedback_at'] ) : '';
		$rest_endpoint   = rest_url( 'seopm/v1/public/review' );

		?><!doctype html>
<html lang="fa" dir="rtl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, nofollow, noarchive">
	<title><?php echo esc_html( $title ); ?> — پیش‌نمایش مقاله</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap" rel="stylesheet">
	<style>
		:root {
			--accent: <?php echo esc_attr( $accent ); ?>;
			--bg: #f1f5f9;
			--card: #ffffff;
			--text: #0f172a;
			--muted: #64748b;
			--border: #e2e8f0;
		}
		* { box-sizing: border-box; }
		body {
			margin: 0;
			font-family: 'Vazirmatn', Tahoma, system-ui, -apple-system, sans-serif;
			background: var(--bg);
			color: var(--text);
			line-height: 1.95;
			-webkit-font-smoothing: antialiased;
		}
		.topbar {
			background: #ffffff;
			border-bottom: 1px solid var(--border);
			position: sticky;
			top: 0;
			z-index: 50;
		}
		.topbar-inner {
			max-width: 900px;
			margin: 0 auto;
			padding: 12px 20px;
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			flex-wrap: wrap;
		}
		.brand {
			display: flex;
			align-items: center;
			gap: 10px;
		}
		.brand img {
			height: 32px;
			width: auto;
			border-radius: 6px;
		}
		.brand-name {
			font-weight: 800;
			font-size: 14px;
			color: var(--text);
		}
		.pill {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			padding: 4px 12px;
			border-radius: 999px;
			font-size: 12px;
			font-weight: 700;
			background: #eef2ff;
			color: var(--accent);
			border: 1px solid rgba(79,70,229,.2);
		}
		.pill.is-approved { background: #ecfdf5; color: #047857; border-color: #a7f3d0; }
		.pill.is-changes { background: #fffbeb; color: #b45309; border-color: #fde68a; }
		.wrap {
			max-width: 900px;
			margin: 24px auto 60px;
			padding: 0 16px;
		}
		.meta-strip {
			background: #fff;
			border: 1px solid var(--border);
			border-right: 4px solid var(--accent);
			border-radius: 14px;
			padding: 14px 18px;
			margin-bottom: 18px;
			display: flex;
			flex-wrap: wrap;
			gap: 14px 24px;
			font-size: 13px;
		}
		.meta-item span { color: var(--muted); margin-left: 4px; }
		.meta-item code {
			background: #f1f5f9;
			padding: 2px 8px;
			border-radius: 6px;
			font-family: Consolas, monospace;
			font-size: 12px;
			direction: ltr;
			display: inline-block;
		}
		.article-card {
			background: var(--card);
			border: 1px solid var(--border);
			border-radius: 18px;
			overflow: hidden;
			box-shadow: 0 8px 30px rgba(15,23,42,.05);
		}
		.featured-wrap {
			width: 100%;
			background: #0f172a;
			max-height: 480px;
			overflow: hidden;
		}
		.featured-wrap img {
			width: 100%;
			height: auto;
			display: block;
			object-fit: cover;
		}
		.article-inner {
			padding: 28px 32px 34px;
		}
		.article-title {
			margin: 0 0 20px;
			font-size: 26px;
			line-height: 1.5;
			font-weight: 800;
			color: #0f172a;
		}
		.article-body {
			font-size: 15.5px;
			line-height: 2;
			color: #1e293b;
		}
		.article-body img {
			max-width: 100%;
			height: auto;
			border-radius: 12px;
		}
		.article-body figure.seopm-in-content-figure {
			margin: 24px 0;
			width: 100%;
		}
		.article-body figure.seopm-in-content-figure img {
			width: 100%;
			height: auto;
			display: block;
		}
		.article-body h2 {
			font-size: 20px;
			font-weight: 800;
			margin: 28px 0 12px;
			color: #0f172a;
			padding-bottom: 8px;
			border-bottom: 1px solid #e2e8f0;
		}
		.article-body h3 {
			font-size: 17px;
			font-weight: 700;
			margin: 22px 0 10px;
			color: #1e293b;
		}
		.article-body a {
			color: var(--accent);
			text-decoration: underline;
			text-underline-offset: 3px;
		}
		.article-body table {
			width: 100%;
			border-collapse: collapse;
			margin: 18px 0;
			font-size: 14px;
		}
		.article-body th, .article-body td {
			border: 1px solid #e2e8f0;
			padding: 10px 12px;
			text-align: right;
		}
		.article-body th {
			background: #f8fafc;
			font-weight: 700;
		}
		.review-card {
			margin-top: 24px;
			background: #fff;
			border: 1.5px solid var(--border);
			border-radius: 18px;
			padding: 24px 28px;
			box-shadow: 0 8px 30px rgba(15,23,42,.05);
		}
		.review-card h2 {
			margin: 0 0 6px;
			font-size: 18px;
			font-weight: 800;
		}
		.review-sub {
			margin: 0 0 18px;
			color: var(--muted);
			font-size: 13.5px;
		}
		.review-banner {
			padding: 12px 16px;
			border-radius: 12px;
			margin-bottom: 16px;
			font-size: 13.5px;
			font-weight: 600;
			line-height: 1.7;
		}
		.review-banner.is-approved { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
		.review-banner.is-changes { background: #fffbeb; border: 1px solid #fde68a; color: #92400e; }
		.review-banner.is-error { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
		.review-actions {
			display: flex;
			gap: 12px;
			flex-wrap: wrap;
		}
		.btn {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			gap: 8px;
			padding: 12px 22px;
			border-radius: 12px;
			font-family: inherit;
			font-size: 14.5px;
			font-weight: 700;
			border: 1.5px solid transparent;
			cursor: pointer;
			transition: transform .1s ease, opacity .15s ease, background .15s ease;
		}
		.btn:disabled { opacity: .6; cursor: not-allowed; }
		.btn-approve { background: #10b981; color: #fff; }
		.btn-approve:hover:not(:disabled) { background: #059669; }
		.btn-changes { background: #fff; color: #b45309; border-color: #f59e0b; }
		.btn-changes:hover:not(:disabled) { background: #fffbeb; }
		.btn-send { background: var(--accent); color: #fff; margin-top: 10px; }
		.feedback-wrap {
			margin-top: 16px;
			padding-top: 16px;
			border-top: 1px solid var(--border);
		}
		.feedback-wrap textarea {
			width: 100%;
			min-height: 115px;
			padding: 12px 14px;
			border-radius: 12px;
			border: 1.5px solid #cbd5e1;
			font-family: inherit;
			font-size: 14px;
			line-height: 1.75;
			resize: vertical;
			outline: none;
		}
		.feedback-wrap textarea:focus {
			border-color: var(--accent);
			box-shadow: 0 0 0 3px rgba(79,70,229,.12);
		}
		.footer-note {
			text-align: center;
			color: var(--muted);
			font-size: 12px;
			margin-top: 22px;
		}
		@media (max-width: 640px) {
			.article-inner { padding: 20px 18px 24px; }
			.article-title { font-size: 21px; }
			.review-card { padding: 18px; }
			.btn { width: 100%; }
		}
	</style>
</head>
<body>
	<header class="topbar">
		<div class="topbar-inner">
			<div class="brand">
				<?php if ( $logo_url ) : ?>
					<img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $agency_name ); ?>">
				<?php endif; ?>
				<span class="brand-name"><?php echo esc_html( $agency_name ); ?> — پیش‌نمایش مقاله</span>
			</div>
			<span class="pill <?php echo 'approved' === $review_status ? 'is-approved' : ( 'changes_requested' === $review_status ? 'is-changes' : '' ); ?>" id="seopm-top-pill">
				<?php
				if ( 'approved' === $review_status ) {
					echo '✅ تأیید شده برای انتشار';
				} elseif ( 'changes_requested' === $review_status ) {
					echo '✏️ اصلاحیه ثبت شده';
				} else {
					echo '👁 در انتظار بررسی شما';
				}
				?>
			</span>
		</div>
	</header>

	<main class="wrap">
		<div class="meta-strip">
			<?php if ( ! empty( $biz['name'] ) ) : ?>
				<div class="meta-item"><span>پروژه:</span><strong><?php echo esc_html( $biz['name'] ); ?></strong></div>
			<?php endif; ?>
			<?php if ( '' !== $due_date_fa ) : ?>
				<div class="meta-item"><span>زمان انتشار:</span><strong><?php echo esc_html( $due_date_fa ); ?></strong></div>
			<?php endif; ?>
			<?php if ( '' !== $slug ) : ?>
				<div class="meta-item"><span>نامک (Slug):</span><code><?php echo esc_html( $slug ); ?></code></div>
			<?php endif; ?>
		</div>

		<article class="article-card">
			<?php if ( '' !== $featured_url ) : ?>
				<div class="featured-wrap">
					<img src="<?php echo esc_url( $featured_url ); ?>" alt="<?php echo esc_attr( $title ); ?>">
				</div>
			<?php endif; ?>

			<div class="article-inner">
				<h1 class="article-title"><?php echo esc_html( $title ); ?></h1>
				<div class="article-body">
					<?php echo $article_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted admin-generated HTML article preview. ?>
				</div>
			</div>
		</article>

		<section class="review-card" id="seopm-review-box">
			<h2>تأیید یا ثبت نظر برای این مقاله</h2>
			<p class="review-sub">در صورتی که محتوای مقاله مورد تأیید شماست روی دکمه سبز کلیک کنید؛ در غیر این صورت موارد اصلاحی را بنویسید تا پیش از انتشار اعمال شود.</p>

			<div id="seopm-review-banner" class="review-banner <?php echo 'approved' === $review_status ? 'is-approved' : ( 'changes_requested' === $review_status ? 'is-changes' : '' ); ?>" <?php echo ( 'approved' === $review_status || 'changes_requested' === $review_status ) ? '' : 'hidden'; ?>>
				<?php if ( 'approved' === $review_status ) : ?>
					✅ این مقاله قبلاً توسط شما تأیید شده است<?php echo $review_time_fa ? ' (' . esc_html( $review_time_fa ) . ')' : ''; ?>.
				<?php elseif ( 'changes_requested' === $review_status ) : ?>
					✏️ اصلاحیه ثبت شده<?php echo $review_time_fa ? ' (' . esc_html( $review_time_fa ) . ')' : ''; ?>: <?php echo esc_html( $review_feedback ); ?>
				<?php endif; ?>
			</div>

			<div class="review-actions">
				<button type="button" class="btn btn-approve" id="seopm-btn-approve">✅ تأیید مقاله و آماده انتشار</button>
				<button type="button" class="btn btn-changes" id="seopm-btn-toggle-changes">✏️ نیاز به اصلاح / ثبت نظر</button>
			</div>

			<div class="feedback-wrap" id="seopm-feedback-wrap" <?php echo 'changes_requested' === $review_status ? '' : 'hidden'; ?>>
				<label for="seopm-feedback-input" style="display:block; font-weight:700; font-size:13.5px; margin-bottom:8px;">توضیحات و اصلاحات مورد نظر شما:</label>
				<textarea id="seopm-feedback-input" placeholder="مثال: لطفاً در بخش دوم، قیمت یا توضیحات مربوط به ... را اصلاح کنید..."><?php echo esc_textarea( $review_feedback ); ?></textarea>
				<div>
					<button type="button" class="btn btn-send" id="seopm-btn-submit-changes">ارسال نظر و اصلاحیه به تیم سئو</button>
				</div>
			</div>
		</section>

		<p class="footer-note">این صفحه صرفاً جهت پیش‌نمایش اختصاصی پیش از انتشار ایجاد شده و توسط موتورهای جستجو ایندکس نمی‌شود.</p>
	</main>

	<script>
	(function () {
		var endpoint = <?php echo wp_json_encode( $rest_endpoint ); ?>;
		var token = <?php echo wp_json_encode( $token ); ?>;
		var banner = document.getElementById('seopm-review-banner');
		var topPill = document.getElementById('seopm-top-pill');
		var approveBtn = document.getElementById('seopm-btn-approve');
		var toggleChangesBtn = document.getElementById('seopm-btn-toggle-changes');
		var feedbackWrap = document.getElementById('seopm-feedback-wrap');
		var feedbackInput = document.getElementById('seopm-feedback-input');
		var submitChangesBtn = document.getElementById('seopm-btn-submit-changes');

		function showBanner(type, text) {
			banner.hidden = false;
			banner.className = 'review-banner ' + (type === 'approved' ? 'is-approved' : (type === 'changes' ? 'is-changes' : 'is-error'));
			banner.textContent = text;
		}

		function sendReview(status, feedback) {
			approveBtn.disabled = true;
			submitChangesBtn.disabled = true;
			fetch(endpoint, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ token: token, status: status, feedback: feedback || '' })
			}).then(function (r) {
				return r.json().then(function (d) { return { ok: r.ok, data: d }; });
			}).then(function (res) {
				approveBtn.disabled = false;
				submitChangesBtn.disabled = false;
				if (!res.ok) {
					showBanner('error', (res.data && res.data.message) || 'خطا در ثبت نظر. لطفاً دوباره تلاش کنید.');
					return;
				}
				if (status === 'approved') {
					showBanner('approved', '✅ ' + ((res.data && res.data.message) || 'تأیید شما با موفقیت ثبت شد.'));
					topPill.className = 'pill is-approved';
					topPill.textContent = '✅ تأیید شده برای انتشار';
					feedbackWrap.hidden = true;
				} else {
					showBanner('changes', '✏️ ' + ((res.data && res.data.message) || 'اصلاحیه شما با موفقیت ارسال شد.'));
					topPill.className = 'pill is-changes';
					topPill.textContent = '✏️ اصلاحیه ثبت شده';
				}
			}).catch(function () {
				approveBtn.disabled = false;
				submitChangesBtn.disabled = false;
				showBanner('error', 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت را بررسی کرده و مجدداً تلاش کنید.');
			});
		}

		approveBtn.addEventListener('click', function () {
			sendReview('approved', '');
		});

		toggleChangesBtn.addEventListener('click', function () {
			feedbackWrap.hidden = false;
			feedbackInput.focus();
		});

		submitChangesBtn.addEventListener('click', function () {
			var txt = (feedbackInput.value || '').trim();
			if (!txt) {
				showBanner('error', 'لطفاً ابتدا توضیحات یا موارد اصلاحی خود را در کادر زیر بنویسید.');
				feedbackInput.focus();
				return;
			}
			sendReview('changes_requested', txt);
		});
	})();
	</script>
</body>
</html>
		<?php
		exit;
	}
}

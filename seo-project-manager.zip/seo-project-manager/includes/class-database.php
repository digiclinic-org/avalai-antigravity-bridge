<?php
/**
 * Database schema and migrations.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Database helper.
 */
class Database {

	const DB_VERSION = '1.8.0';
	const OPTION     = 'seopm_db_version';

	/**
	 * Full table name using the site's DB prefix.
	 *
	 * @param string $name Short name (businesses, keywords, tasks, reports, report_versions).
	 * @return string
	 */
	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'seopm_' . $name;
	}

	/**
	 * All short table names.
	 *
	 * @return string[]
	 */
	public static function tables() {
		return array( 'businesses', 'keywords', 'tasks', 'reports', 'report_versions', 'article_drafts', 'notes' );
	}

	/**
	 * Run migrations when the stored version differs from the code version.
	 */
	public static function maybe_upgrade() {
		$installed = get_option( self::OPTION );
		if ( self::DB_VERSION !== $installed ) {
			self::install();
			Activator::setup_capabilities();
			Settings::ensure_defaults();
		}
	}

	/**
	 * Create / update tables via dbDelta, then run versioned data migrations.
	 */
	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$t       = array();
		foreach ( self::tables() as $name ) {
			$t[ $name ] = self::table( $name );
		}

		$sql = array();

		$sql[] = "CREATE TABLE {$t['businesses']} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(191) NOT NULL,
  website_url varchar(255) NOT NULL DEFAULT '',
  sitemap_url varchar(255) NOT NULL DEFAULT '',
  color char(7) NOT NULL DEFAULT '#4f46e5',
  description text NULL,
  prompt_article_writing longtext NULL,
  prompt_html_conversion longtext NULL,
  prompt_image_generation longtext NULL,
  prompt_sources_external_links longtext NULL,
  prompt_internal_links longtext NULL,
  wp_username varchar(191) NOT NULL DEFAULT '',
  wp_app_password text NULL,
  wp_publish_time char(5) NOT NULL DEFAULT '21:00',
  wp_default_category bigint(20) unsigned NOT NULL DEFAULT 0,
  telegram_chat_id varchar(64) NOT NULL DEFAULT '',
  telegram_username varchar(100) NOT NULL DEFAULT '',
  telegram_notify_enabled tinyint(1) NOT NULL DEFAULT 1,
  industry_services text NULL,
  target_location varchar(255) NOT NULL DEFAULT '',
  focus_products_services text NULL,
  content_goals text NULL,
  target_audience text NULL,
  created_by bigint(20) unsigned NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY name (name)
) $charset;";

		$sql[] = "CREATE TABLE {$t['keywords']} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  business_id bigint(20) unsigned NOT NULL,
  keyword varchar(191) NOT NULL,
  weight tinyint(3) unsigned NOT NULL DEFAULT 5,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY business_keyword (business_id,keyword),
  KEY business_id (business_id)
) $charset;";

		$sql[] = "CREATE TABLE {$t['tasks']} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  business_id bigint(20) unsigned NOT NULL,
  title varchar(255) NOT NULL,
  task_type varchar(32) NOT NULL,
  due_date date NOT NULL,
  description text NULL,
  article_key varchar(64) NOT NULL DEFAULT '',
  remote_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
  remote_post_url varchar(500) NOT NULL DEFAULT '',
  remote_status varchar(32) NOT NULL DEFAULT '',
  scheduled_for datetime NULL,
  status varchar(20) NOT NULL DEFAULT 'pending',
  completed_at datetime NULL,
  created_by bigint(20) unsigned NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY business_due (business_id,due_date),
  KEY status_due (status,due_date),
  KEY due_date (due_date),
  KEY task_type (task_type),
  KEY article_key (article_key)
) $charset;";

		$sql[] = "CREATE TABLE {$t['reports']} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  business_id bigint(20) unsigned NOT NULL,
  title varchar(255) NOT NULL,
  report_type varchar(20) NOT NULL DEFAULT 'monthly',
  start_date date NOT NULL,
  end_date date NOT NULL,
  current_version_id bigint(20) unsigned NULL,
  snapshot_data longtext NULL,
  summary longtext NULL,
  pdf_path varchar(255) NULL,
  status varchar(20) NOT NULL DEFAULT 'draft',
  created_by bigint(20) unsigned NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY business_period (business_id,start_date,end_date),
  KEY created_at (created_at)
) $charset;";

		$sql[] = "CREATE TABLE {$t['report_versions']} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  report_id bigint(20) unsigned NOT NULL,
  version_no int(10) unsigned NOT NULL,
  snapshot_data longtext NOT NULL,
  summary longtext NULL,
  pdf_path varchar(255) NULL,
  created_by bigint(20) unsigned NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY report_version (report_id,version_no),
  KEY report_id (report_id)
) $charset;";

		$sql[] = "CREATE TABLE {$t['article_drafts']} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  business_id bigint(20) unsigned NOT NULL,
  article_key varchar(64) NOT NULL,
  title varchar(255) NOT NULL DEFAULT '',
  keyword varchar(191) NOT NULL DEFAULT '',
  url_slug varchar(191) NOT NULL DEFAULT '',
  article_content longtext NULL,
  article_html longtext NULL,
  featured_image_url text NULL,
  featured_image_id bigint(20) unsigned NOT NULL DEFAULT 0,
  images_json longtext NULL,
  image_prompt text NULL,
  seo_title varchar(255) NOT NULL DEFAULT '',
  seo_description text NULL,
  remote_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
  remote_post_url varchar(500) NOT NULL DEFAULT '',
  remote_status varchar(32) NOT NULL DEFAULT '',
  scheduled_for datetime NULL,
  published_at datetime NULL,
  review_token varchar(64) NOT NULL DEFAULT '',
  review_status varchar(20) NOT NULL DEFAULT '',
  review_feedback longtext NULL,
  review_feedback_at datetime NULL,
  review_sent_at datetime NULL,
  review_sent_for_date date NULL,
  provider varchar(32) NOT NULL DEFAULT '',
  model varchar(64) NOT NULL DEFAULT '',
  created_by bigint(20) unsigned NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY biz_article_key (business_id,article_key),
  KEY business_id (business_id),
  KEY review_token (review_token)
) $charset;";

		$sql[] = "CREATE TABLE {$t['notes']} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  business_id bigint(20) unsigned NOT NULL DEFAULT 0,
  title varchar(255) NOT NULL DEFAULT '',
  content longtext NOT NULL,
  color varchar(30) NOT NULL DEFAULT 'default',
  is_pinned tinyint(1) NOT NULL DEFAULT 0,
  tags varchar(255) NOT NULL DEFAULT '',
  created_by bigint(20) unsigned NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY business_id (business_id),
  KEY is_pinned (is_pinned),
  KEY created_at (created_at)
) $charset;";

		dbDelta( $sql );

		$from = get_option( self::OPTION, '0' );
		self::run_migrations( (string) $from );

		update_option( self::OPTION, self::DB_VERSION );
	}

	/**
	 * Versioned data migrations (schema changes are handled by dbDelta).
	 * Add new steps as: if ( version_compare( $from, 'x.y.z', '<' ) ) { ... }.
	 *
	 * @param string $from Previously installed version.
	 */
	private static function run_migrations( $from ) {
		global $wpdb;

		if ( version_compare( $from, '1.1.0', '<' ) ) {
			$biz_table = self::table( 'businesses' );
			$columns   = $wpdb->get_col( "SHOW COLUMNS FROM `{$biz_table}`", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( is_array( $columns ) ) {
				$prompt_cols = array(
					'prompt_article_writing',
					'prompt_html_conversion',
					'prompt_image_generation',
				);
				foreach ( $prompt_cols as $col ) {
					if ( ! in_array( $col, $columns, true ) ) {
						$wpdb->query( "ALTER TABLE `{$biz_table}` ADD COLUMN `{$col}` longtext NULL AFTER `description`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					}
				}
			}
		}

		if ( version_compare( $from, '1.3.0', '<' ) ) {
			$alter_map = array(
				self::table( 'businesses' )     => array(
					'wp_username'         => "varchar(191) NOT NULL DEFAULT ''",
					'wp_app_password'     => 'text NULL',
					'wp_publish_time'     => "char(5) NOT NULL DEFAULT '21:00'",
					'wp_default_category' => 'bigint(20) unsigned NOT NULL DEFAULT 0',
				),
				self::table( 'tasks' )          => array(
					'article_key'     => "varchar(64) NOT NULL DEFAULT ''",
					'remote_post_id'  => 'bigint(20) unsigned NOT NULL DEFAULT 0',
					'remote_post_url' => "varchar(500) NOT NULL DEFAULT ''",
					'remote_status'   => "varchar(32) NOT NULL DEFAULT ''",
					'scheduled_for'   => 'datetime NULL',
				),
				self::table( 'article_drafts' ) => array(
					'featured_image_url' => 'text NULL',
					'featured_image_id'  => 'bigint(20) unsigned NOT NULL DEFAULT 0',
					'image_prompt'       => 'text NULL',
					'seo_title'          => "varchar(255) NOT NULL DEFAULT ''",
					'seo_description'    => 'text NULL',
					'remote_post_id'     => 'bigint(20) unsigned NOT NULL DEFAULT 0',
					'remote_post_url'    => "varchar(500) NOT NULL DEFAULT ''",
					'remote_status'      => "varchar(32) NOT NULL DEFAULT ''",
					'scheduled_for'      => 'datetime NULL',
					'published_at'       => 'datetime NULL',
				),
			);
			foreach ( $alter_map as $tbl => $cols_def ) {
				$existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$tbl}`", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				if ( is_array( $existing_cols ) ) {
					foreach ( $cols_def as $col => $def ) {
						if ( ! in_array( $col, $existing_cols, true ) ) {
							$wpdb->query( "ALTER TABLE `{$tbl}` ADD COLUMN `{$col}` {$def}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						}
					}
				}
			}
		}

		if ( version_compare( $from, '1.4.0', '<' ) ) {
			$drafts_tbl    = self::table( 'article_drafts' );
			$existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$drafts_tbl}`", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( is_array( $existing_cols ) && ! in_array( 'images_json', $existing_cols, true ) ) {
				$wpdb->query( "ALTER TABLE `{$drafts_tbl}` ADD COLUMN `images_json` longtext NULL AFTER `featured_image_id`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
		}

		if ( version_compare( $from, '1.5.0', '<' ) ) {
			$alter_150 = array(
				self::table( 'businesses' )     => array(
					'telegram_chat_id'        => "varchar(64) NOT NULL DEFAULT ''",
					'telegram_username'       => "varchar(100) NOT NULL DEFAULT ''",
					'telegram_notify_enabled' => 'tinyint(1) NOT NULL DEFAULT 1',
				),
				self::table( 'article_drafts' ) => array(
					'review_token'         => "varchar(64) NOT NULL DEFAULT ''",
					'review_status'        => "varchar(20) NOT NULL DEFAULT ''",
					'review_feedback'      => 'longtext NULL',
					'review_feedback_at'   => 'datetime NULL',
					'review_sent_at'       => 'datetime NULL',
					'review_sent_for_date' => 'date NULL',
				),
			);
			foreach ( $alter_150 as $tbl => $cols_def ) {
				$existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$tbl}`", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				if ( is_array( $existing_cols ) ) {
					foreach ( $cols_def as $col => $def ) {
						if ( ! in_array( $col, $existing_cols, true ) ) {
							$wpdb->query( "ALTER TABLE `{$tbl}` ADD COLUMN `{$col}` {$def}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						}
					}
				}
			}
		}

		if ( version_compare( $from, '1.6.0', '<' ) ) {
			$notes_table = self::table( 'notes' );
			$charset     = $wpdb->get_charset_collate();
			$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$notes_table}` (
				  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				  `business_id` bigint(20) unsigned NOT NULL DEFAULT 0,
				  `title` varchar(255) NOT NULL DEFAULT '',
				  `content` longtext NOT NULL,
				  `color` varchar(30) NOT NULL DEFAULT 'default',
				  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
				  `tags` varchar(255) NOT NULL DEFAULT '',
				  `created_by` bigint(20) unsigned NULL,
				  `created_at` datetime NOT NULL,
				  `updated_at` datetime NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `business_id` (`business_id`),
				  KEY `is_pinned` (`is_pinned`),
				  KEY `created_at` (`created_at`)
				) {$charset};"
			); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		if ( version_compare( $from, '1.7.0', '<' ) ) {
			$biz_table     = self::table( 'businesses' );
			$existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$biz_table}`", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( is_array( $existing_cols ) ) {
				$new_prompt_cols = array(
					'prompt_sources_external_links' => 'longtext NULL',
					'prompt_internal_links'         => 'longtext NULL',
				);
				foreach ( $new_prompt_cols as $col => $def ) {
					if ( ! in_array( $col, $existing_cols, true ) ) {
						$wpdb->query( "ALTER TABLE `{$biz_table}` ADD COLUMN `{$col}` {$def}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					}
				}
			}
		}

		if ( version_compare( $from, '1.8.0', '<' ) ) {
			$biz_table     = self::table( 'businesses' );
			$existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$biz_table}`", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( is_array( $existing_cols ) ) {
				$new_biz_cols = array(
					'industry_services'       => 'text NULL',
					'target_location'         => "varchar(255) NOT NULL DEFAULT ''",
					'focus_products_services' => 'text NULL',
					'content_goals'           => 'text NULL',
					'target_audience'         => 'text NULL',
				);
				foreach ( $new_biz_cols as $col => $def ) {
					if ( ! in_array( $col, $existing_cols, true ) ) {
						$wpdb->query( "ALTER TABLE `{$biz_table}` ADD COLUMN `{$col}` {$def}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					}
				}
			}
		}

		/**
		 * Fires after schema update so add-ons can migrate their data.
		 *
		 * @param string $from Previous DB version.
		 * @param string $to   New DB version.
		 */
		do_action( 'seopm_db_migrated', $from, self::DB_VERSION );
	}

	/**
	 * Drop all plugin tables (used only on explicit uninstall).
	 */
	public static function drop_tables() {
		global $wpdb;
		foreach ( self::tables() as $name ) {
			$table = self::table( $name );
			$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
	}

	/**
	 * Current UTC datetime for created_at / updated_at.
	 *
	 * @return string
	 */
	public static function now() {
		return current_time( 'mysql', true );
	}
}

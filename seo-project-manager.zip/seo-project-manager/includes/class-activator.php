<?php
/**
 * Activation routines.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Activator.
 */
class Activator {

	const ROLE = 'seopm_manager';

	/**
	 * Plugin activation.
	 */
	public static function activate() {
		Database::install();
		Settings::ensure_defaults();
		self::setup_capabilities();
		Pdf_Generator::ensure_storage();
	}

	/**
	 * Grant capability to administrators and register the dedicated role.
	 */
	public static function setup_capabilities() {
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( Security::CAP ) ) {
			$admin->add_cap( Security::CAP );
		}

		if ( ! get_role( self::ROLE ) ) {
			add_role(
				self::ROLE,
				__( 'مدیر پروژه سئو', 'seo-project-manager' ),
				array(
					'read'          => true,
					'upload_files'  => true,
					Security::CAP   => true,
				)
			);
		}
	}
}

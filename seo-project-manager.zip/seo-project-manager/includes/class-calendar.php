<?php
/**
 * Calendar: maps tasks to FullCalendar events.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Calendar.
 */
class Calendar {

	/**
	 * Events in a date range.
	 *
	 * @param string $start        Y-m-d (inclusive).
	 * @param string $end          Y-m-d (exclusive, FullCalendar convention).
	 * @param int[]  $business_ids Empty = all.
	 * @return array
	 */
	public static function events( $start, $end, array $business_ids = array() ) {
		$end_inclusive = gmdate( 'Y-m-d', strtotime( $end . ' -1 day' ) );
		$result        = Task::query(
			array(
				'business_ids' => $business_ids,
				'from'         => $start,
				'to'           => $end_inclusive,
				'per_page'     => 500,
				'orderby'      => 'due_date',
			)
		);
		$events = array();
		foreach ( $result['items'] as $task ) {
			$events[] = self::to_event( $task );
		}
		return $events;
	}

	/**
	 * Convert task to event.
	 *
	 * @param array $task Formatted task.
	 * @return array
	 */
	public static function to_event( array $task ) {
		$color = $task['business_color'];
		return array(
			'id'              => (string) $task['id'],
			'title'           => $task['title'],
			'start'           => $task['due_date'],
			'allDay'          => true,
			'backgroundColor' => $color,
			'borderColor'     => $color,
			'textColor'       => self::contrast( $color ),
			'extendedProps'   => $task,
		);
	}

	/**
	 * Readable text color for a background.
	 *
	 * @param string $hex Background color.
	 * @return string
	 */
	public static function contrast( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 6 !== strlen( $hex ) ) {
			return '#ffffff';
		}
		$r   = hexdec( substr( $hex, 0, 2 ) );
		$g   = hexdec( substr( $hex, 2, 2 ) );
		$b   = hexdec( substr( $hex, 4, 2 ) );
		$yiq = ( $r * 299 + $g * 587 + $b * 114 ) / 1000;
		return $yiq >= 150 ? '#1f2937' : '#ffffff';
	}
}

<?php
/**
 * Server-side SVG charts for PDF output (mPDF cannot run JavaScript).
 * Only shapes and digits are drawn in SVG; Persian labels are rendered as HTML.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * SVG chart builder.
 */
class Chart_Svg {

	/**
	 * Mix a hex color with white (ratio 0..1 of white).
	 *
	 * @param string $hex   Color.
	 * @param float  $ratio White ratio.
	 * @return string
	 */
	public static function tint( $hex, $ratio ) {
		return self::mix( $hex, '#ffffff', $ratio );
	}

	/**
	 * Mix a hex color with black.
	 *
	 * @param string $hex   Color.
	 * @param float  $ratio Black ratio.
	 * @return string
	 */
	public static function shade( $hex, $ratio ) {
		return self::mix( $hex, '#000000', $ratio );
	}

	/**
	 * Mix two colors.
	 *
	 * @param string $a     Color A.
	 * @param string $b     Color B.
	 * @param float  $ratio Ratio of B.
	 * @return string
	 */
	public static function mix( $a, $b, $ratio ) {
		$a   = Security::sanitize_color( $a );
		$b   = Security::sanitize_color( $b );
		$out = '#';
		for ( $i = 1; $i <= 5; $i += 2 ) {
			$ca   = hexdec( substr( $a, $i, 2 ) );
			$cb   = hexdec( substr( $b, $i, 2 ) );
			$out .= str_pad( dechex( (int) round( $ca * ( 1 - $ratio ) + $cb * $ratio ) ), 2, '0', STR_PAD_LEFT );
		}
		return $out;
	}

	/**
	 * Wrap as data URI for <img>.
	 *
	 * @param string $svg SVG markup.
	 * @return string
	 */
	public static function data_uri( $svg ) {
		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Donut chart.
	 *
	 * @param array  $segments List of [value, color].
	 * @param string $center   Center text (digits only).
	 * @param string $font     Font family.
	 * @return string SVG markup.
	 */
	public static function donut( array $segments, $center, $font ) {
		$size   = 200;
		$cx     = 100;
		$cy     = 100;
		$r      = 72;
		$stroke = 28;
		$total  = array_sum( wp_list_pluck( $segments, 0 ) );

		$svg  = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 ' . $size . ' ' . $size . '">';
		$svg .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . $r . '" fill="none" stroke="#eef0f4" stroke-width="' . $stroke . '"/>';

		if ( $total > 0 ) {
			$angle = -90.0;
			foreach ( $segments as $seg ) {
				list( $value, $color ) = $seg;
				if ( $value <= 0 ) {
					continue;
				}
				$sweep = $value / $total * 360;
				if ( $sweep >= 359.99 ) {
					$svg .= '<circle cx="' . $cx . '" cy="' . $cy . '" r="' . $r . '" fill="none" stroke="' . esc_attr( $color ) . '" stroke-width="' . $stroke . '"/>';
					break;
				}
				$svg  .= self::arc( $cx, $cy, $r, $angle, $angle + $sweep, $color, $stroke );
				$angle += $sweep;
			}
		}
		$svg .= '<text x="' . $cx . '" y="' . ( $cy + 12 ) . '" text-anchor="middle" font-family="' . esc_attr( $font ) . '" font-size="34" font-weight="bold" fill="#111827">' . esc_html( $center ) . '</text>';
		$svg .= '</svg>';
		return $svg;
	}

	/**
	 * Arc path.
	 *
	 * @param float  $cx     Center X.
	 * @param float  $cy     Center Y.
	 * @param float  $r      Radius.
	 * @param float  $from   Start angle (deg).
	 * @param float  $to     End angle (deg).
	 * @param string $color  Color.
	 * @param int    $stroke Stroke width.
	 * @return string
	 */
	private static function arc( $cx, $cy, $r, $from, $to, $color, $stroke ) {
		$x1    = $cx + $r * cos( deg2rad( $from ) );
		$y1    = $cy + $r * sin( deg2rad( $from ) );
		$x2    = $cx + $r * cos( deg2rad( $to ) );
		$y2    = $cy + $r * sin( deg2rad( $to ) );
		$large = ( $to - $from ) > 180 ? 1 : 0;
		return sprintf(
			'<path d="M %.2f %.2f A %.2f %.2f 0 %d 1 %.2f %.2f" fill="none" stroke="%s" stroke-width="%d"/>',
			$x1,
			$y1,
			$r,
			$r,
			$large,
			$x2,
			$y2,
			esc_attr( $color ),
			$stroke
		);
	}

	/**
	 * Column chart (used for completion trend). Labels are digit-only strings.
	 * Drawn right-to-left so the earliest bucket is on the right.
	 *
	 * @param string[] $labels Labels.
	 * @param int[]    $values Values.
	 * @param string   $color  Bar color.
	 * @param string   $font   Font family.
	 * @return string SVG markup.
	 */
	public static function columns( array $labels, array $values, $color, $font ) {
		$w      = 680;
		$h      = 230;
		$pad_l  = 34;
		$pad_r  = 10;
		$pad_t  = 16;
		$pad_b  = 34;
		$n      = max( 1, count( $values ) );
		$max    = max( 1, max( $values ? $values : array( 0 ) ) );
		$steps  = min( 4, $max );
		$plot_w = $w - $pad_l - $pad_r;
		$plot_h = $h - $pad_t - $pad_b;
		$slot   = $plot_w / $n;
		$bar_w  = max( 3, min( 36, $slot * 0.62 ) );
		$fs     = $n > 20 ? 9 : 11;

		$svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $w . '" height="' . $h . '" viewBox="0 0 ' . $w . ' ' . $h . '">';

		// Grid + Y axis labels.
		for ( $i = 0; $i <= $steps; $i++ ) {
			$val  = $max * $i / $steps;
			$y    = $pad_t + $plot_h - ( $plot_h * $i / $steps );
			$svg .= sprintf( '<line x1="%d" y1="%.2f" x2="%d" y2="%.2f" stroke="#e5e7eb" stroke-width="1"/>', $pad_l, $y, $w - $pad_r, $y );
			$svg .= sprintf( '<text x="%d" y="%.2f" text-anchor="end" font-family="%s" font-size="11" fill="#6b7280">%s</text>', $pad_l - 6, $y + 4, esc_attr( $font ), esc_html( Jalali::fa_digits( (string) round( $val ) ) ) );
		}

		$label_every = $n > 16 ? (int) ceil( $n / 16 ) : 1;
		foreach ( array_values( $values ) as $i => $v ) {
			// Right-to-left: index 0 on the right edge.
			$slot_x = $w - $pad_r - ( $i + 1 ) * $slot;
			$x      = $slot_x + ( $slot - $bar_w ) / 2;
			$bh     = $plot_h * $v / $max;
			$y      = $pad_t + $plot_h - $bh;
			if ( $v > 0 ) {
				$svg .= sprintf( '<rect x="%.2f" y="%.2f" width="%.2f" height="%.2f" rx="2" fill="%s"/>', $x, $y, $bar_w, $bh, esc_attr( $color ) );
				if ( $n <= 20 ) {
					$svg .= sprintf( '<text x="%.2f" y="%.2f" text-anchor="middle" font-family="%s" font-size="10" fill="#374151">%s</text>', $x + $bar_w / 2, $y - 4, esc_attr( $font ), esc_html( Jalali::fa_digits( $v ) ) );
				}
			}
			if ( 0 === $i % $label_every && isset( $labels[ $i ] ) ) {
				$svg .= sprintf( '<text x="%.2f" y="%d" text-anchor="middle" font-family="%s" font-size="%d" fill="#6b7280">%s</text>', $slot_x + $slot / 2, $h - $pad_b + 18, esc_attr( $font ), $fs, esc_html( $labels[ $i ] ) );
			}
		}
		$svg .= sprintf( '<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#9ca3af" stroke-width="1"/>', $pad_l, $pad_t + $plot_h, $w - $pad_r, $pad_t + $plot_h );
		$svg .= '</svg>';
		return $svg;
	}
}

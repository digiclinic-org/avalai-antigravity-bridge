<?php
/**
 * Plugin settings (branding & report options).
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Settings.
 */
class Settings {

	const OPTION = 'seopm_settings';

	/**
	 * Default settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'agency_name'        => get_bloginfo( 'name' ),
			'logo_id'            => 0,
			'preparer_name'      => '',
			'contact_info'       => '',
			'agency_website'     => '',
			'footer_text'        => '',
			'report_theme'       => 'light',
			'use_business_color' => 1,
			'report_color'       => '#4f46e5',
			'pdf_font'           => 'xbriyaz',
			'delete_on_uninstall' => 0,

			// AI Providers
			'ai_active_provider'  => 'none',
			'avalai_api_key'      => '',
			'avalai_model'        => 'gemini-2.5-flash',
			'avalai_custom_model' => '',
			'avalai_base_url'     => '',
			'gemini_api_key'      => '',
			'gemini_model'        => 'gemini-2.5-flash',
			'gemini_base_url'     => '',
			'openai_api_key'     => '',
			'openai_model'       => 'gpt-4o-mini',
			'openai_base_url'    => '',
			'deepseek_api_key'   => '',
			'deepseek_model'     => 'deepseek-chat',
			'deepseek_base_url'  => '',
			'claude_api_key'     => '',
			'claude_model'       => 'claude-3-5-sonnet-20241022',
			'claude_base_url'    => '',
			'ai_temperature'     => 0.7,

			// Telegram Client Review & Pre-Publish Approval
			'telegram_bot_token'     => '',
			'telegram_bot_username'  => '',
			'telegram_proxy_url'     => '',
			'telegram_proxy_secret'  => '',
			'telegram_admin_chat_id' => '',
			'telegram_auto_enabled'  => 1,
			'telegram_send_hour'     => '10:00',
		);
	}

	/**
	 * Report themes.
	 *
	 * @return array
	 */
	public static function themes() {
		return array(
			'light'   => __( 'روشن', 'seo-project-manager' ),
			'minimal' => __( 'مینیمال', 'seo-project-manager' ),
			'formal'  => __( 'رسمی', 'seo-project-manager' ),
		);
	}

	/**
	 * PDF fonts bundled with mPDF that support Persian.
	 *
	 * @return array
	 */
	public static function pdf_fonts() {
		return array(
			'xbriyaz'    => 'XB Riyaz',
			'dejavusans' => 'DejaVu Sans',
		);
	}

	/**
	 * Add defaults without overwriting existing values.
	 */
	public static function ensure_defaults() {
		$current = get_option( self::OPTION );
		if ( ! is_array( $current ) ) {
			add_option( self::OPTION, self::defaults(), '', false );
			return;
		}
		update_option( self::OPTION, array_merge( self::defaults(), $current ), false );
	}

	/**
	 * Get all settings.
	 *
	 * @return array
	 */
	public static function all() {
		$value = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $value ) ? $value : array() );
	}

	/**
	 * Get one setting.
	 *
	 * @param string $key Key.
	 * @return mixed
	 */
	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/**
	 * Sanitize and save settings.
	 *
	 * @param array $input Raw input.
	 * @return array Saved settings.
	 */
	public static function save( array $input ) {
		$themes = self::themes();
		$fonts  = self::pdf_fonts();
		$prev   = self::all();

		// Helper to preserve API keys if masked, not provided, or empty unless cleared
		$save_key = static function ( $key_name ) use ( $input, $prev ) {
			if ( ! empty( $input[ $key_name . '_clear' ] ) ) {
				return '';
			}
			if ( ! isset( $input[ $key_name ] ) ) {
				return $prev[ $key_name ] ?? '';
			}
			$val = trim( sanitize_text_field( $input[ $key_name ] ) );
			$old = $prev[ $key_name ] ?? '';
			if ( '' === $val || false !== strpos( $val, '****' ) || false !== strpos( $val, '...' ) || ( '' !== $old && self::mask_key( $old ) === $val ) ) {
				return $old;
			}
			return $val;
		};

		$clean  = array(
			'agency_name'         => sanitize_text_field( $input['agency_name'] ?? '' ),
			'logo_id'             => absint( $input['logo_id'] ?? 0 ),
			'preparer_name'       => sanitize_text_field( $input['preparer_name'] ?? '' ),
			'contact_info'        => sanitize_textarea_field( $input['contact_info'] ?? '' ),
			'agency_website'      => Security::sanitize_url( $input['agency_website'] ?? '' ),
			'footer_text'         => sanitize_textarea_field( $input['footer_text'] ?? '' ),
			'report_theme'        => isset( $themes[ $input['report_theme'] ?? '' ] ) ? $input['report_theme'] : 'light',
			'use_business_color'  => empty( $input['use_business_color'] ) ? 0 : 1,
			'report_color'        => Security::sanitize_color( $input['report_color'] ?? '' ),
			'pdf_font'            => isset( $fonts[ $input['pdf_font'] ?? '' ] ) ? $input['pdf_font'] : 'xbriyaz',
			'delete_on_uninstall' => empty( $input['delete_on_uninstall'] ) ? 0 : 1,

			// AI Providers
			'ai_active_provider'  => in_array( $input['ai_active_provider'] ?? 'none', array( 'none', 'avalai', 'gemini', 'openai', 'deepseek', 'claude' ), true ) ? $input['ai_active_provider'] : 'none',
			'avalai_api_key'      => $save_key( 'avalai_api_key' ),
			'avalai_model'        => sanitize_text_field( $input['avalai_model'] ?? 'gemini-2.5-flash' ),
			'avalai_custom_model' => sanitize_text_field( $input['avalai_custom_model'] ?? '' ),
			'avalai_base_url'     => Security::sanitize_url( $input['avalai_base_url'] ?? '' ),
			'gemini_api_key'      => $save_key( 'gemini_api_key' ),
			'gemini_model'        => sanitize_text_field( $input['gemini_model'] ?? 'gemini-2.0-flash' ),
			'gemini_base_url'     => Security::sanitize_url( $input['gemini_base_url'] ?? '' ),
			'openai_api_key'      => $save_key( 'openai_api_key' ),
			'openai_model'        => sanitize_text_field( $input['openai_model'] ?? 'gpt-4o-mini' ),
			'openai_base_url'     => Security::sanitize_url( $input['openai_base_url'] ?? '' ),
			'deepseek_api_key'    => $save_key( 'deepseek_api_key' ),
			'deepseek_model'      => sanitize_text_field( $input['deepseek_model'] ?? 'deepseek-chat' ),
			'deepseek_base_url'   => Security::sanitize_url( $input['deepseek_base_url'] ?? '' ),
			'claude_api_key'      => $save_key( 'claude_api_key' ),
			'claude_model'        => sanitize_text_field( $input['claude_model'] ?? 'claude-3-5-sonnet-20241022' ),
			'claude_base_url'     => Security::sanitize_url( $input['claude_base_url'] ?? '' ),
			'ai_temperature'      => isset( $input['ai_temperature'] ) ? floatval( $input['ai_temperature'] ) : 0.7,

			// Telegram Client Review & Pre-Publish Approval
			'telegram_bot_token'     => $save_key( 'telegram_bot_token' ),
			'telegram_bot_username'  => ltrim( sanitize_text_field( $input['telegram_bot_username'] ?? ( $prev['telegram_bot_username'] ?? '' ) ), '@' ),
			'telegram_proxy_url'     => untrailingslashit( Security::sanitize_url( $input['telegram_proxy_url'] ?? '' ) ),
			'telegram_proxy_secret'  => $save_key( 'telegram_proxy_secret' ),
			'telegram_admin_chat_id' => preg_replace( '/[^0-9\-]/', '', trim( (string) ( $input['telegram_admin_chat_id'] ?? '' ) ) ),
			'telegram_auto_enabled'  => empty( $input['telegram_auto_enabled'] ) ? 0 : 1,
			'telegram_send_hour'     => preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', trim( (string) ( $input['telegram_send_hour'] ?? '' ) ) ) ? trim( (string) $input['telegram_send_hour'] ) : '10:00',
		);
		if ( $clean['logo_id'] && ! wp_attachment_is_image( $clean['logo_id'] ) ) {
			$clean['logo_id'] = 0;
		}
		update_option( self::OPTION, $clean, false );
		return $clean;
	}

	/**
	 * Mask an API key for safe display in settings form.
	 *
	 * @param string $key Raw API key.
	 * @return string
	 */
	public static function mask_key( $key ) {
		$key = trim( (string) $key );
		if ( empty( $key ) ) {
			return '';
		}
		$len = strlen( $key );
		if ( $len <= 10 ) {
			return '********';
		}
		return substr( $key, 0, 6 ) . '...' . substr( $key, -4 );
	}

	/**
	 * Branding data used in reports (snapshotted at generation time).
	 *
	 * @return array
	 */
	public static function branding() {
		$s        = self::all();
		$logo_url = '';
		$logo_abs = '';
		if ( $s['logo_id'] ) {
			$logo_url = (string) wp_get_attachment_image_url( $s['logo_id'], 'medium' );
			$file     = get_attached_file( $s['logo_id'] );
			$logo_abs = $file && file_exists( $file ) ? $file : '';
		}
		return array(
			'agency_name'        => $s['agency_name'],
			'logo_url'           => $logo_url,
			'logo_path'          => $logo_abs,
			'preparer_name'      => $s['preparer_name'],
			'contact_info'       => $s['contact_info'],
			'agency_website'     => $s['agency_website'],
			'footer_text'        => $s['footer_text'],
			'report_theme'       => $s['report_theme'],
			'use_business_color' => (int) $s['use_business_color'],
			'report_color'       => $s['report_color'],
			'pdf_font'           => $s['pdf_font'],
		);
	}
}

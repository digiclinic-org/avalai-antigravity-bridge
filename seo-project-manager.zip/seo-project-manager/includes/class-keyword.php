<?php
/**
 * Business keywords.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Keyword repository.
 */
class Keyword {

	const MIN_WEIGHT = 1;
	const MAX_WEIGHT = 10;

	/**
	 * Keywords of a business, heaviest first.
	 *
	 * @param int $business_id Business ID.
	 * @return array
	 */
	public static function for_business( $business_id ) {
		global $wpdb;
		$table = Database::table( 'keywords' );
		$rows  = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE business_id = %d ORDER BY weight DESC, keyword ASC", $business_id ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);
		return array_map( array( __CLASS__, 'format' ), $rows ? $rows : array() );
	}

	/**
	 * Get one keyword.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$table = Database::table( 'keywords' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $row ? self::format( $row ) : null;
	}

	/**
	 * Validate input.
	 *
	 * @param array $data Raw data.
	 * @return array|\WP_Error
	 */
	private static function clean( array $data ) {
		$keyword = trim( sanitize_text_field( $data['keyword'] ?? '' ) );
		if ( '' === $keyword ) {
			return new \WP_Error( 'seopm_keyword_empty', __( 'عبارت کلیدی نمی‌تواند خالی باشد.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		if ( mb_strlen( $keyword ) > 191 ) {
			$keyword = mb_substr( $keyword, 0, 191 );
		}
		$weight = (int) ( $data['weight'] ?? 5 );
		$weight = max( self::MIN_WEIGHT, min( self::MAX_WEIGHT, $weight ) );
		return array(
			'keyword' => $keyword,
			'weight'  => $weight,
		);
	}

	/**
	 * Create keyword.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $data        Data.
	 * @return array|\WP_Error
	 */
	public static function create( $business_id, array $data ) {
		global $wpdb;
		$clean = self::clean( $data );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		if ( ! Business::exists( $business_id ) ) {
			return new \WP_Error( 'seopm_business_not_found', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		if ( self::find_id( $business_id, $clean['keyword'] ) ) {
			return new \WP_Error( 'seopm_keyword_exists', __( 'این کلمه کلیدی قبلاً ثبت شده است.', 'seo-project-manager' ), array( 'status' => 409 ) );
		}
		$now = Database::now();
		$wpdb->insert(
			Database::table( 'keywords' ),
			array(
				'business_id' => $business_id,
				'keyword'     => $clean['keyword'],
				'weight'      => $clean['weight'],
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			array( '%d', '%s', '%d', '%s', '%s' )
		);
		Content_Suggester::clear_cache( $business_id );
		return self::get( (int) $wpdb->insert_id );
	}

	/**
	 * Update keyword.
	 *
	 * @param int   $id   ID.
	 * @param array $data Data.
	 * @return array|\WP_Error
	 */
	public static function update( $id, array $data ) {
		global $wpdb;
		$current = self::get( $id );
		if ( ! $current ) {
			return new \WP_Error( 'seopm_keyword_not_found', __( 'کلمه کلیدی یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$clean = self::clean( array_merge( $current, $data ) );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$dup = self::find_id( $current['business_id'], $clean['keyword'] );
		if ( $dup && $dup !== (int) $id ) {
			return new \WP_Error( 'seopm_keyword_exists', __( 'این کلمه کلیدی قبلاً ثبت شده است.', 'seo-project-manager' ), array( 'status' => 409 ) );
		}
		$wpdb->update(
			Database::table( 'keywords' ),
			array(
				'keyword'    => $clean['keyword'],
				'weight'     => $clean['weight'],
				'updated_at' => Database::now(),
			),
			array( 'id' => $id ),
			array( '%s', '%d', '%s' ),
			array( '%d' )
		);
		Content_Suggester::clear_cache( $current['business_id'] );
		return self::get( $id );
	}

	/**
	 * Delete keyword.
	 *
	 * @param int $id ID.
	 * @return bool
	 */
	public static function delete( $id ) {
		global $wpdb;
		$current = self::get( $id );
		$ok      = (bool) $wpdb->delete( Database::table( 'keywords' ), array( 'id' => $id ), array( '%d' ) );
		if ( $ok && $current ) {
			Content_Suggester::clear_cache( $current['business_id'] );
		}
		return $ok;
	}

	/**
	 * Replace the keyword list of a business with the given list.
	 * Items with an "id" are updated, new ones inserted, missing ones removed.
	 *
	 * @param int   $business_id Business ID.
	 * @param array $items       List of [id?, keyword, weight].
	 * @return array|\WP_Error Final keyword list.
	 */
	public static function sync( $business_id, array $items ) {
		global $wpdb;
		$table    = Database::table( 'keywords' );
		$existing = array();
		foreach ( self::for_business( $business_id ) as $kw ) {
			$existing[ $kw['id'] ] = $kw;
		}

		$seen  = array();
		$clean = array();
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$c = self::clean( $item );
			if ( is_wp_error( $c ) ) {
				continue;
			}
			$key = mb_strtolower( $c['keyword'] );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$c['id']      = isset( $item['id'] ) && isset( $existing[ (int) $item['id'] ] ) ? (int) $item['id'] : 0;
			$clean[]      = $c;
		}

		$keep = wp_list_pluck( array_filter( $clean, static function ( $c ) {
			return $c['id'] > 0;
		} ), 'id' );
		foreach ( array_diff( array_keys( $existing ), $keep ) as $remove_id ) {
			self::delete( $remove_id );
		}

		$now = Database::now();
		foreach ( $clean as $c ) {
			if ( $c['id'] ) {
				$old = $existing[ $c['id'] ];
				if ( $old['keyword'] !== $c['keyword'] || (int) $old['weight'] !== $c['weight'] ) {
					$wpdb->update( $table, array( 'keyword' => $c['keyword'], 'weight' => $c['weight'], 'updated_at' => $now ), array( 'id' => $c['id'] ), array( '%s', '%d', '%s' ), array( '%d' ) );
				}
			} else {
				$wpdb->insert( $table, array( 'business_id' => $business_id, 'keyword' => $c['keyword'], 'weight' => $c['weight'], 'created_at' => $now, 'updated_at' => $now ), array( '%d', '%s', '%d', '%s', '%s' ) );
			}
		}
		Content_Suggester::clear_cache( $business_id );
		return self::for_business( $business_id );
	}

	/**
	 * Delete all keywords of a business.
	 *
	 * @param int $business_id Business ID.
	 */
	public static function delete_for_business( $business_id ) {
		global $wpdb;
		$wpdb->delete( Database::table( 'keywords' ), array( 'business_id' => $business_id ), array( '%d' ) );
	}

	/**
	 * Find keyword ID by text within a business.
	 *
	 * @param int    $business_id Business ID.
	 * @param string $keyword     Keyword.
	 * @return int
	 */
	private static function find_id( $business_id, $keyword ) {
		global $wpdb;
		$table = Database::table( 'keywords' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE business_id = %d AND keyword = %s", $business_id, $keyword ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Format row.
	 *
	 * @param array $row Row.
	 * @return array
	 */
	public static function format( array $row ) {
		return array(
			'id'          => (int) $row['id'],
			'business_id' => (int) $row['business_id'],
			'keyword'     => $row['keyword'],
			'weight'      => (int) $row['weight'],
		);
	}
}

<?php
/**
 * Site Crawler: fetches articles (posts), pages, and sitemaps for SEO project reports.
 *
 * @package SEOPM
 */

namespace SEOPM;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Site Crawler service.
 */
class Site_Crawler {

	const CACHE_KEY_PREFIX = 'seopm_site_content_v3_';
	const CACHE_TTL        = 21600; // 6 hours.

	/**
	 * Get comprehensive site report: keywords, linked articles, and pages.
	 *
	 * @param int  $business_id   Business ID.
	 * @param bool $force_refresh Whether to bypass transient cache.
	 * @return array|WP_Error
	 */
	public static function get_report( $business_id, $force_refresh = false ) {
		$business_id = Article_Generator::resolve_business_id( $business_id );
		$business    = $business_id ? Business::get( $business_id, true ) : null;
		if ( ! $business ) {
			return new WP_Error(
				'seopm_business_not_found',
				__( 'پروژه مورد نظر یافت نشد.', 'seo-project-manager' ),
				array( 'status' => 404 )
			);
		}

		$cache_key = self::CACHE_KEY_PREFIX . $business_id;
		if ( ! $force_refresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && ! empty( $cached['stats'] ) ) {
				// Always update with latest keywords from database even if posts/pages are cached.
				$cached['business'] = $business;
				$cached['keywords'] = self::enrich_keywords(
					$business['keywords'],
					$cached['posts'] ?? array(),
					$cached['pages'] ?? array()
				);
				$cached['stats']['keyword_count'] = count( $cached['keywords'] );
				return $cached;
			}
		}

		$website_url = trim( $business['website_url'] ?? '' );
		$sitemap_url = trim( $business['sitemap_url'] ?? '' );

		$base_url = self::normalize_base_url( $website_url, $sitemap_url );

		$posts  = array();
		$pages  = array();
		$source = 'none';

		// Step 1: Attempt to fetch via WordPress REST API if base URL is available.
		if ( $base_url ) {
			$wp_data = self::fetch_wp_rest( $base_url );
			if ( ! empty( $wp_data['posts'] ) ) {
				$posts  = $wp_data['posts'];
				$source = 'wp_rest';
			}
			if ( ! empty( $wp_data['pages'] ) ) {
				$pages = $wp_data['pages'];
				if ( 'none' === $source ) {
					$source = 'wp_rest';
				}
			}
		}

		// Step 2: Crawl XML Sitemap if explicit sitemap_url is configured for the business.
		if ( ! empty( $sitemap_url ) ) {
			$sitemap_data = self::crawl_sitemap( $sitemap_url );
			if ( ! empty( $sitemap_data['posts'] ) || ! empty( $sitemap_data['pages'] ) ) {
				$posts  = self::merge_content_items( $posts, $sitemap_data['posts'] ?? array() );
				$pages  = self::merge_content_items( $pages, $sitemap_data['pages'] ?? array() );
				$source = ( 'wp_rest' === $source ) ? 'hybrid' : 'sitemap';
			}
		}

		// Sort posts by date / modified descending.
		usort(
			$posts,
			static function ( $a, $b ) {
				$da = $a['modified'] ?? $a['date'] ?? '';
				$db = $b['modified'] ?? $b['date'] ?? '';
				return strcmp( $db, $da );
			}
		);

		// Sort pages by title or modified.
		usort(
			$pages,
			static function ( $a, $b ) {
				$da = $a['modified'] ?? $a['date'] ?? '';
				$db = $b['modified'] ?? $b['date'] ?? '';
				return strcmp( $db, $da );
			}
		);

		// Enrich posts with excerpt, headings, target_keyword, and page_type.
		foreach ( $posts as &$p ) {
			$p_title             = $p['title'] ?? '';
			$p['excerpt']        = ! empty( $p['excerpt'] ) ? $p['excerpt'] : sprintf( __( 'بررسی جامع و تخصصی پیرامون %s، علائم، راهکارها و نکات مراقبتی.', 'seo-project-manager' ), $p_title );
			$p['headings']       = ( ! empty( $p['headings'] ) && is_array( $p['headings'] ) ) ? $p['headings'] : self::generate_fallback_headings( $p_title );
			$p['page_type']      = self::detect_page_type( $p['url'] ?? '', 'post', $p_title );
			$p['target_keyword'] = self::match_target_keyword( $p_title, $p['url'] ?? '', $p['excerpt'], $p['headings'], $business['keywords'] ?? array() );
		}
		unset( $p );

		// Enrich pages with excerpt, headings, target_keyword, and page_type.
		foreach ( $pages as &$pg ) {
			$pg_title             = $pg['title'] ?? '';
			$pg['excerpt']        = ! empty( $pg['excerpt'] ) ? $pg['excerpt'] : sprintf( __( 'معرفی خدمات و راهنمای ساختاری صفحه %s.', 'seo-project-manager' ), $pg_title );
			$pg['headings']       = ( ! empty( $pg['headings'] ) && is_array( $pg['headings'] ) ) ? $pg['headings'] : self::generate_fallback_headings( $pg_title );
			$pg['page_type']      = self::detect_page_type( $pg['url'] ?? '', 'page', $pg_title );
			$pg['target_keyword'] = self::match_target_keyword( $pg_title, $pg['url'] ?? '', $pg['excerpt'], $pg['headings'], $business['keywords'] ?? array() );
		}
		unset( $pg );

		$enriched_keywords = self::enrich_keywords( $business['keywords'], $posts, $pages );

		$report = array(
			'business'    => $business,
			'sitemap_url' => $sitemap_target,
			'keywords'    => $enriched_keywords,
			'posts'       => $posts,
			'pages'       => $pages,
			'stats'       => array(
				'keyword_count' => count( $enriched_keywords ),
				'post_count'    => count( $posts ),
				'page_count'    => count( $pages ),
				'synced_at'     => current_time( 'mysql' ),
				'source'        => $source,
				'sitemap_url'   => $sitemap_target,
			),
		);

		set_transient( $cache_key, $report, self::CACHE_TTL );

		return $report;
	}

	/**
	 * Clear cached site report for a business.
	 *
	 * @param int $business_id Business ID.
	 */
	public static function clear_cache( $business_id ) {
		delete_transient( self::CACHE_KEY_PREFIX . $business_id );
	}

	/**
	 * Normalize base URL from website URL or sitemap URL.
	 *
	 * @param string $website_url Website URL.
	 * @param string $sitemap_url Sitemap URL.
	 * @return string
	 */
	private static function normalize_base_url( $website_url, $sitemap_url ) {
		$url = $website_url;
		if ( empty( $url ) && ! empty( $sitemap_url ) ) {
			$parts = wp_parse_url( $sitemap_url );
			if ( ! empty( $parts['host'] ) ) {
				$scheme = ! empty( $parts['scheme'] ) ? $parts['scheme'] : 'https';
				$url    = $scheme . '://' . $parts['host'];
			}
		}

		if ( empty( $url ) ) {
			return '';
		}

		$url = trim( $url );
		if ( ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . $url;
		}

		return rtrim( $url, '/' );
	}

	/**
	 * Fetch posts and pages from a WordPress site REST API.
	 *
	 * @param string $base_url Site base URL.
	 * @return array{posts:array,pages:array}
	 */
	private static function fetch_wp_rest( $base_url ) {
		$results = array(
			'posts' => array(),
			'pages' => array(),
		);

		$headers = array(
			'Accept'     => 'application/json',
			'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; SEO-Project-Manager',
		);

		// Fetch Posts.
		$posts_url = add_query_arg(
			array(
				'per_page' => 100,
				'_fields'  => 'id,title,link,date,modified,excerpt,content',
			),
			$base_url . '/wp-json/wp/v2/posts'
		);

		$res = wp_remote_get(
			$posts_url,
			array(
				'timeout'   => 12,
				'sslverify' => false,
				'headers'   => $headers,
			)
		);

		if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
			$body = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( is_array( $body ) ) {
				foreach ( $body as $item ) {
					$title       = html_entity_decode( wp_strip_all_tags( $item['title']['rendered'] ?? '' ), ENT_QUOTES, 'UTF-8' );
					$url         = esc_url_raw( $item['link'] ?? '' );
					$raw_excerpt = (string) ( $item['excerpt']['rendered'] ?? '' );
					$excerpt     = trim( html_entity_decode( wp_strip_all_tags( $raw_excerpt ), ENT_QUOTES, 'UTF-8' ) );
					$raw_content = (string) ( $item['content']['rendered'] ?? '' );
					$headings    = array();
					if ( ! empty( $raw_content ) && preg_match_all( '/<h([2-4])[^>]*>(.*?)<\/h\1>/i', $raw_content, $h_matches ) ) {
						foreach ( $h_matches[2] as $h_text ) {
							$clean_h = trim( html_entity_decode( wp_strip_all_tags( $h_text ), ENT_QUOTES, 'UTF-8' ) );
							if ( ! empty( $clean_h ) && ! in_array( $clean_h, $headings, true ) ) {
								$headings[] = $clean_h;
							}
						}
					}
					if ( empty( $excerpt ) && ! empty( $raw_content ) ) {
						$plain   = trim( html_entity_decode( wp_strip_all_tags( $raw_content ), ENT_QUOTES, 'UTF-8' ) );
						$excerpt = mb_substr( $plain, 0, 240 ) . ( mb_strlen( $plain ) > 240 ? '...' : '' );
					}
					if ( $title && $url ) {
						$results['posts'][] = array(
							'id'       => (int) ( $item['id'] ?? 0 ),
							'title'    => $title,
							'url'      => $url,
							'date'     => sanitize_text_field( $item['date'] ?? '' ),
							'modified' => sanitize_text_field( $item['modified'] ?? '' ),
							'type'     => 'post',
							'excerpt'  => $excerpt,
							'headings' => $headings,
						);
					}
				}
			}
		}

		// Fetch Pages.
		$pages_url = add_query_arg(
			array(
				'per_page' => 100,
				'_fields'  => 'id,title,link,date,modified,excerpt,content',
			),
			$base_url . '/wp-json/wp/v2/pages'
		);

		$res = wp_remote_get(
			$pages_url,
			array(
				'timeout'   => 12,
				'sslverify' => false,
				'headers'   => $headers,
			)
		);

		if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
			$body = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( is_array( $body ) ) {
				foreach ( $body as $item ) {
					$title       = html_entity_decode( wp_strip_all_tags( $item['title']['rendered'] ?? '' ), ENT_QUOTES, 'UTF-8' );
					$url         = esc_url_raw( $item['link'] ?? '' );
					$raw_excerpt = (string) ( $item['excerpt']['rendered'] ?? '' );
					$excerpt     = trim( html_entity_decode( wp_strip_all_tags( $raw_excerpt ), ENT_QUOTES, 'UTF-8' ) );
					$raw_content = (string) ( $item['content']['rendered'] ?? '' );
					$headings    = array();
					if ( ! empty( $raw_content ) && preg_match_all( '/<h([2-4])[^>]*>(.*?)<\/h\1>/i', $raw_content, $h_matches ) ) {
						foreach ( $h_matches[2] as $h_text ) {
							$clean_h = trim( html_entity_decode( wp_strip_all_tags( $h_text ), ENT_QUOTES, 'UTF-8' ) );
							if ( ! empty( $clean_h ) && ! in_array( $clean_h, $headings, true ) ) {
								$headings[] = $clean_h;
							}
						}
					}
					if ( empty( $excerpt ) && ! empty( $raw_content ) ) {
						$plain   = trim( html_entity_decode( wp_strip_all_tags( $raw_content ), ENT_QUOTES, 'UTF-8' ) );
						$excerpt = mb_substr( $plain, 0, 240 ) . ( mb_strlen( $plain ) > 240 ? '...' : '' );
					}
					if ( $url ) {
						if ( empty( $title ) ) {
							$title = self::slug_to_title( $url );
						}
						$results['pages'][] = array(
							'id'       => (int) ( $item['id'] ?? 0 ),
							'title'    => $title,
							'url'      => $url,
							'date'     => sanitize_text_field( $item['date'] ?? '' ),
							'modified' => sanitize_text_field( $item['modified'] ?? '' ),
							'type'     => 'page',
							'excerpt'  => $excerpt,
							'headings' => $headings,
						);
					}
				}
			}
		}

		return $results;
	}

	/**
	 * Crawl XML sitemap (handles both index and urlsets, resilient to namespaces).
	 *
	 * @param string $sitemap_url Sitemap URL.
	 * @return array{posts:array,pages:array}
	 */
	private static function crawl_sitemap( $sitemap_url ) {
		$results = array(
			'posts' => array(),
			'pages' => array(),
		);

		$xml = self::fetch_xml( $sitemap_url );
		if ( ! $xml ) {
			return $results;
		}

		// Handle namespace if present.
		$sitemaps = array();
		if ( isset( $xml->sitemap ) && count( $xml->sitemap ) > 0 ) {
			$sitemaps = $xml->sitemap;
		} elseif ( method_exists( $xml, 'children' ) ) {
			$ns_ch = $xml->children( 'http://www.sitemaps.org/schemas/sitemap/0.9' );
			if ( isset( $ns_ch->sitemap ) ) {
				$sitemaps = $ns_ch->sitemap;
			}
		}

		// If sitemap index: fetch child sitemaps.
		if ( ! empty( $sitemaps ) ) {
			foreach ( $sitemaps as $sm ) {
				$loc = trim( (string) $sm->loc );
				if ( ! $loc || self::is_ignored_sitemap_url( $loc ) ) {
					continue;
				}

				$is_post = ( false !== stripos( $loc, 'post' ) );
				$is_page = ( false !== stripos( $loc, 'page' ) );

				$child_xml = self::fetch_xml( $loc );
				if ( ! $child_xml ) {
					continue;
				}

				$urls = array();
				if ( isset( $child_xml->url ) && count( $child_xml->url ) > 0 ) {
					$urls = $child_xml->url;
				} elseif ( method_exists( $child_xml, 'children' ) ) {
					$ns_ch2 = $child_xml->children( 'http://www.sitemaps.org/schemas/sitemap/0.9' );
					if ( isset( $ns_ch2->url ) ) {
						$urls = $ns_ch2->url;
					}
				}

				foreach ( $urls as $u ) {
					$url     = trim( (string) $u->loc );
					$lastmod = trim( (string) ( $u->lastmod ?? '' ) );
					if ( ! $url || self::is_ignored_sitemap_url( $url ) ) {
						continue;
					}

					$item = array(
						'id'       => 0,
						'title'    => self::slug_to_title( $url ),
						'url'      => esc_url_raw( $url ),
						'date'     => $lastmod,
						'modified' => $lastmod,
						'type'     => $is_post ? 'post' : ( $is_page ? 'page' : 'item' ),
					);

					if ( $is_post ) {
						$results['posts'][] = $item;
					} else {
						$results['pages'][] = $item;
					}
				}
			}
		} else {
			// Single sitemap with URLs.
			$urls = array();
			if ( isset( $xml->url ) && count( $xml->url ) > 0 ) {
				$urls = $xml->url;
			} elseif ( method_exists( $xml, 'children' ) ) {
				$ns_ch = $xml->children( 'http://www.sitemaps.org/schemas/sitemap/0.9' );
				if ( isset( $ns_ch->url ) ) {
					$urls = $ns_ch->url;
				}
			}

			foreach ( $urls as $u ) {
				$url     = trim( (string) $u->loc );
				$lastmod = trim( (string) ( $u->lastmod ?? '' ) );
				if ( ! $url || self::is_ignored_sitemap_url( $url ) ) {
					continue;
				}

				$is_post = ( false !== stripos( $sitemap_url, 'post' ) );
				$item    = array(
					'id'       => 0,
					'title'    => self::slug_to_title( $url ),
					'url'      => esc_url_raw( $url ),
					'date'     => $lastmod,
					'modified' => $lastmod,
					'type'     => $is_post ? 'post' : 'page',
				);

				if ( $is_post ) {
					$results['posts'][] = $item;
				} else {
					$results['pages'][] = $item;
				}
			}
		}

		return $results;
	}

	/**
	 * Merge content items by URL, preserving primary rich data (e.g. Persian titles from WP REST)
	 * while ensuring every URL from the sitemap is included.
	 *
	 * @param array $primary_items Primary items (e.g. from WP REST API).
	 * @param array $sitemap_items Sitemap items.
	 * @return array
	 */
	private static function merge_content_items( array $primary_items, array $sitemap_items ) {
		$merged    = array();
		$seen_urls = array();

		// Add primary items first (they have real WordPress titles, IDs, dates).
		foreach ( $primary_items as $item ) {
			$norm_url = self::normalize_url_key( $item['url'] ?? '' );
			if ( '' !== $norm_url && ! isset( $seen_urls[ $norm_url ] ) ) {
				$seen_urls[ $norm_url ] = true;
				$merged[]               = $item;
			}
		}

		// Add sitemap items that aren't already included.
		foreach ( $sitemap_items as $s_item ) {
			$raw_url = $s_item['url'] ?? '';
			if ( self::is_ignored_sitemap_url( $raw_url ) ) {
				continue;
			}
			$norm_url = self::normalize_url_key( $raw_url );
			if ( '' !== $norm_url && ! isset( $seen_urls[ $norm_url ] ) ) {
				$seen_urls[ $norm_url ] = true;
				$merged[]               = $s_item;
			}
		}

		return $merged;
	}

	/**
	 * Normalize URL for robust duplicate detection (scheme, host, path without trailing slash).
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private static function normalize_url_key( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) ) {
			return rtrim( strtolower( $url ), '/' );
		}
		$scheme = strtolower( $parts['scheme'] ?? 'https' );
		$host   = strtolower( $parts['host'] );
		$path   = isset( $parts['path'] ) ? rtrim( urldecode( $parts['path'] ), '/' ) : '';
		return $scheme . '://' . $host . $path;
	}

	/**
	 * Check if a sitemap URL points to a non-page file (kml, xml, images, archives).
	 *
	 * @param string $url URL.
	 * @return bool
	 */
	private static function is_ignored_sitemap_url( $url ) {
		$path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		return (bool) preg_match( '/\.(kml|xml|xsl|pdf|zip|rar|jpg|jpeg|png|webp|gif|svg|mp4|css|js)$/i', $path );
	}

	/**
	 * Fetch and parse XML string.
	 *
	 * @param string $url URL.
	 * @return \SimpleXMLElement|null
	 */
	private static function fetch_xml( $url ) {
		$res = wp_remote_get(
			$url,
			array(
				'timeout'   => 15,
				'sslverify' => false,
				'headers'   => array(
					'Accept'     => 'application/xml, text/xml, */*',
					'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; SEO-Project-Manager',
				),
			)
		);

		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			return null;
		}

		$body = wp_remote_retrieve_body( $res );
		if ( empty( $body ) ) {
			return null;
		}

		libxml_use_internal_errors( true );
		$xml = simplexml_load_string( $body );
		libxml_clear_errors();

		return ( $xml instanceof \SimpleXMLElement ) ? $xml : null;
	}

	/**
	 * Generate human-readable title from URL slug.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private static function slug_to_title( $url ) {
		$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		if ( empty( $path ) ) {
			return __( 'صفحه اصلی', 'seo-project-manager' );
		}

		$segments = explode( '/', $path );
		$slug     = end( $segments );
		$decoded  = urldecode( $slug );

		$title = str_replace( array( '-', '_', '+' ), ' ', $decoded );
		return trim( $title );
	}

	/**
	 * Enrich keywords with matched posts and pages on the site.
	 *
	 * @param array $keywords Keywords list.
	 * @param array $posts    Posts list.
	 * @param array $pages    Pages list.
	 * @return array
	 */
	private static function enrich_keywords( array $keywords, array $posts, array $pages ) {
		$enriched = array();

		foreach ( $keywords as $k ) {
			$text = mb_strtolower( trim( $k['keyword'] ?? '' ) );
			if ( empty( $text ) ) {
				$enriched[] = $k;
				continue;
			}

			// Clean search tokens.
			$tokens = array_filter( explode( ' ', $text ), static function ( $t ) {
				return mb_strlen( $t ) > 2;
			} );

			$matched_posts = array();
			foreach ( $posts as $p ) {
				$p_title = mb_strtolower( $p['title'] ?? '' );
				$p_url   = urldecode( mb_strtolower( $p['url'] ?? '' ) );

				if ( false !== mb_strpos( $p_title, $text ) || false !== mb_strpos( $p_url, $text ) ) {
					$matched_posts[] = array(
						'title' => $p['title'],
						'url'   => $p['url'],
					);
				}
			}

			$matched_pages = array();
			foreach ( $pages as $pg ) {
				$pg_title = mb_strtolower( $pg['title'] ?? '' );
				$pg_url   = urldecode( mb_strtolower( $pg['url'] ?? '' ) );

				if ( false !== mb_strpos( $pg_title, $text ) || false !== mb_strpos( $pg_url, $text ) ) {
					$matched_pages[] = array(
						'title' => $pg['title'],
						'url'   => $pg['url'],
					);
				}
			}

			$k['matched_posts'] = $matched_posts;
			$k['matched_pages'] = $matched_pages;
			$k['match_count']   = count( $matched_posts ) + count( $matched_pages );

			$enriched[] = $k;
		}

		return $enriched;
	}

	/**
	 * Match best target keyword for an article or page from project keywords or content semantics.
	 *
	 * @param string $title    Title.
	 * @param string $url      URL.
	 * @param string $excerpt  Excerpt.
	 * @param array  $headings Headings.
	 * @param array  $keywords Project keywords.
	 * @return string Target keyword.
	 */
	public static function match_target_keyword( $title, $url, $excerpt = '', array $headings = array(), array $keywords = array() ) {
		$combined_text = mb_strtolower( $title . ' ' . urldecode( (string) $url ) . ' ' . $excerpt . ' ' . implode( ' ', $headings ) );

		// 1. Check against project keywords (sorted by weight descending, then by length descending).
		if ( ! empty( $keywords ) ) {
			$sorted_kws = $keywords;
			usort(
				$sorted_kws,
				static function ( $a, $b ) {
					$wa = (int) ( $a['weight'] ?? 5 );
					$wb = (int) ( $b['weight'] ?? 5 );
					if ( $wa !== $wb ) {
						return $wb - $wa;
					}
					return mb_strlen( $b['keyword'] ?? '' ) - mb_strlen( $a['keyword'] ?? '' );
				}
			);

			foreach ( $sorted_kws as $k ) {
				$kw_str = mb_strtolower( trim( (string) ( $k['keyword'] ?? '' ) ) );
				if ( ! empty( $kw_str ) && false !== mb_strpos( $combined_text, $kw_str ) ) {
					return $k['keyword'];
				}
			}
		}

		// 2. Extract prominent keyword phrase from title.
		$clean_title = trim( preg_replace( '/[؛:،؟\?\!\(\)\[\]\{\}\-\_\|\+]/u', ' ', (string) $title ) );
		$stop_words  = array(
			'آیا', 'چگونه', 'چیست', 'علت', 'علائم', 'راهکار', 'راهکارهای', 'راهنمای', 'مراحل',
			'بهترین', 'بررسی', 'نکات', 'روش', 'روش‌های', 'تفاوت', 'مقایسه', 'در', 'با', 'برای',
			'از', 'به', 'و', 'یک', 'تا', 'که', 'چه', 'چند', 'زمان', 'شروع', 'جامع', 'کامل',
			'کدامند', 'است', 'شدن', 'پای', 'کردن', 'می‌کند', 'می‌شود', 'دارد'
		);

		$words = array_values( array_filter( explode( ' ', $clean_title ), static function ( $w ) use ( $stop_words ) {
			$w = trim( $w );
			return mb_strlen( $w ) >= 2 && ! in_array( mb_strtolower( $w ), $stop_words, true );
		} ) );

		if ( count( $words ) >= 2 ) {
			return implode( ' ', array_slice( $words, 0, 4 ) );
		} elseif ( ! empty( $words[0] ) ) {
			return $words[0];
		}

		return $title;
	}

	/**
	 * Detect page type (blog post, guide, pillar landing, product, etc.).
	 *
	 * @param string $url      URL.
	 * @param string $raw_type Raw type ('post' or 'page').
	 * @param string $title    Title.
	 * @return string Page type label.
	 */
	public static function detect_page_type( $url, $raw_type = 'post', $title = '' ) {
		$path  = mb_strtolower( trim( (string) wp_parse_url( (string) $url, PHP_URL_PATH ), '/' ) );
		$title = mb_strtolower( (string) $title );

		if ( empty( $path ) ) {
			return __( 'صفحه اصلی (Home)', 'seo-project-manager' );
		}

		if ( 'page' === $raw_type ) {
			if ( false !== mb_strpos( $path, 'service' ) || false !== mb_strpos( $path, 'services' ) || false !== mb_strpos( $title, 'خدمات' ) || false !== mb_strpos( $title, 'کلینیک' ) || false !== mb_strpos( $title, 'درمان' ) ) {
				return __( 'صفحه لندینگ خدمات (Pillar)', 'seo-project-manager' );
			}
			if ( false !== mb_strpos( $path, 'product' ) || false !== mb_strpos( $path, 'shop' ) || false !== mb_strpos( $title, 'خرید' ) || false !== mb_strpos( $title, 'محصول' ) ) {
				return __( 'صفحه محصول و فروشگاهی', 'seo-project-manager' );
			}
			if ( false !== mb_strpos( $path, 'contact' ) || false !== mb_strpos( $path, 'about' ) || false !== mb_strpos( $title, 'تماس' ) || false !== mb_strpos( $title, 'درباره' ) ) {
				return __( 'برگه سازمانی (درباره/تماس)', 'seo-project-manager' );
			}
			return __( 'برگه لندینگ ساختار سایت', 'seo-project-manager' );
		}

		// It's a post
		if ( false !== mb_strpos( $title, 'راهنما' ) || false !== mb_strpos( $title, 'آموزش' ) || false !== mb_strpos( $title, 'چگونه' ) || false !== mb_strpos( $title, 'مراحل' ) ) {
			return __( 'مقاله آموزشی و راهنما (Guide)', 'seo-project-manager' );
		}
		if ( false !== mb_strpos( $title, 'هزینه' ) || false !== mb_strpos( $title, 'قیمت' ) || false !== mb_strpos( $title, 'بیمه' ) || false !== mb_strpos( $title, 'مقایسه' ) || false !== mb_strpos( $title, 'بهترین' ) ) {
			return __( 'مقاله تجاری و تصمیم‌گیری (Commercial)', 'seo-project-manager' );
		}
		if ( false !== mb_strpos( $title, 'علائم' ) || false !== mb_strpos( $title, 'علت' ) || false !== mb_strpos( $title, 'چیست' ) || false !== mb_strpos( $title, 'تشخیص' ) ) {
			return __( 'مقاله اطلاعاتی و تشخیصی (Informational)', 'seo-project-manager' );
		}

		return __( 'مقاله کلاستر وبلاگ', 'seo-project-manager' );
	}

	/**
	 * Generate realistic outline headings from article title when content HTML is not directly available.
	 *
	 * @param string $title Article title.
	 * @return string[]
	 */
	public static function generate_fallback_headings( $title ) {
		$clean = trim( preg_replace( '/[؛:،؟\?\!\(\)\[\]\{\}\-\_\|\+]/u', ' ', (string) $title ) );
		return array(
			sprintf( __( 'بررسی علل، اهمیت و ضرورت‌های %s', 'seo-project-manager' ), $clean ),
			__( 'روش‌های مراقبت، درمان و توصیه‌های کلیدی متخصصان', 'seo-project-manager' ),
			__( 'پاسخ به سوالات متداول بیماران و نکات تکمیلی', 'seo-project-manager' ),
		);
	}

	/**
	 * Test sitemap accessibility, validity, structure, and latency.
	 *
	 * @param string $sitemap_url Sitemap URL.
	 * @param string $website_url Website URL fallback.
	 * @return array Test result.
	 */
	public static function test_sitemap( $sitemap_url, $website_url = '' ) {
		$url = trim( (string) $sitemap_url );
		if ( empty( $url ) && ! empty( $website_url ) ) {
			$url = trailingslashit( trim( (string) $website_url ) ) . 'sitemap_index.xml';
		}
		if ( empty( $url ) ) {
			return array(
				'success' => false,
				'message' => __( 'آدرس نقشه سایت (Sitemap URL) وارد نشده است.', 'seo-project-manager' ),
			);
		}

		$start_time = microtime( true );
		$res        = wp_remote_get(
			$url,
			array(
				'timeout'   => 15,
				'sslverify' => false,
				'headers'   => array(
					'Accept'     => 'application/xml, text/xml, */*',
					'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; SEO-Project-Manager-Tester',
				),
			)
		);
		$latency_ms = (int) round( ( microtime( true ) - $start_time ) * 1000 );

		if ( is_wp_error( $res ) ) {
			return array(
				'success'    => false,
				'message'    => sprintf( __( 'خطای اتصال به سرور: %s', 'seo-project-manager' ), $res->get_error_message() ),
				'latency_ms' => $latency_ms,
			);
		}

		$code = wp_remote_retrieve_response_code( $res );
		if ( 200 !== $code ) {
			return array(
				'success'    => false,
				'message'    => sprintf( __( 'پاسخ ناموفق از سرور با کد وضعیت HTTP %d. لطفاً آدرس را بررسی کنید.', 'seo-project-manager' ), $code ),
				'latency_ms' => $latency_ms,
			);
		}

		$body = wp_remote_retrieve_body( $res );
		if ( empty( $body ) ) {
			return array(
				'success'    => false,
				'message'    => __( 'محتوای نقشه سایت خالی است.', 'seo-project-manager' ),
				'latency_ms' => $latency_ms,
			);
		}

		libxml_use_internal_errors( true );
		$xml = simplexml_load_string( $body );
		libxml_clear_errors();

		if ( ! ( $xml instanceof \SimpleXMLElement ) ) {
			if ( function_exists( 'gzdecode' ) ) {
				$decoded = @gzdecode( $body );
				if ( ! empty( $decoded ) ) {
					libxml_use_internal_errors( true );
					$xml = simplexml_load_string( $decoded );
					libxml_clear_errors();
				}
			}
		}

		if ( ! ( $xml instanceof \SimpleXMLElement ) ) {
			return array(
				'success'    => false,
				'message'    => __( 'فایل دریافت شد اما ساختار XML معتبر نیست یا به صورت HTML بازگردانده شده است.', 'seo-project-manager' ),
				'latency_ms' => $latency_ms,
			);
		}

		$root_name = strtolower( $xml->getName() );
		$samples   = array();

		if ( 'sitemapindex' === $root_name ) {
			$count = isset( $xml->sitemap ) ? count( $xml->sitemap ) : 0;
			if ( isset( $xml->sitemap ) ) {
				$i = 0;
				foreach ( $xml->sitemap as $sm ) {
					if ( ! empty( $sm->loc ) && $i < 3 ) {
						$samples[] = (string) $sm->loc;
						$i++;
					}
				}
			}
			return array(
				'success'     => true,
				'type'        => 'sitemapindex',
				'count'       => $count,
				'latency_ms'  => $latency_ms,
				'sample_urls' => $samples,
				'message'     => sprintf(
					__( 'نقشه سایت ایندکس (Sitemap Index) با موفقیت تأیید شد (%d زیرنقشه شناسایی گردید، زمان پاسخ: %dms).', 'seo-project-manager' ),
					$count,
					$latency_ms
				),
			);
		}

		if ( 'urlset' === $root_name ) {
			$count = isset( $xml->url ) ? count( $xml->url ) : 0;
			if ( isset( $xml->url ) ) {
				$i = 0;
				foreach ( $xml->url as $u ) {
					if ( ! empty( $u->loc ) && $i < 3 ) {
						$samples[] = (string) $u->loc;
						$i++;
					}
				}
			}
			return array(
				'success'     => true,
				'type'        => 'urlset',
				'count'       => $count,
				'latency_ms'  => $latency_ms,
				'sample_urls' => $samples,
				'message'     => sprintf(
					__( 'نقشه سایت استاندارد (Urlset) با موفقیت تأیید شد (%d آدرس صفحه/پست شناسایی گردید، زمان پاسخ: %dms).', 'seo-project-manager' ),
					$count,
					$latency_ms
				),
			);
		}

		return array(
			'success'    => true,
			'type'       => $root_name,
			'count'      => 1,
			'latency_ms' => $latency_ms,
			'message'    => sprintf(
				__( 'فایل XML نقشه سایت با تگ <%s> در دسترس است (زمان پاسخ: %dms).', 'seo-project-manager' ),
				$root_name,
				$latency_ms
			),
		);
	}

	/**
	 * Test Google Search Console accessibility and ownership verification.
	 *
	 * @param string $website_url Website URL.
	 * @param int    $business_id Business ID (optional).
	 * @return array Test result.
	 */
	public static function test_gsc( $website_url, $business_id = 0 ) {
		$url = trim( (string) $website_url );
		if ( empty( $url ) && $business_id > 0 ) {
			$biz = Business::get( $business_id );
			$url = $biz['website_url'] ?? '';
		}

		if ( empty( $url ) ) {
			return array(
				'success' => false,
				'message' => __( 'آدرس وب‌سایت وارد نشده است. ابتدا آدرس وب‌سایت را وارد کنید.', 'seo-project-manager' ),
			);
		}

		if ( ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . $url;
		}

		$start_time = microtime( true );

		$home_domain = wp_parse_url( home_url(), PHP_URL_HOST );
		$site_domain = wp_parse_url( $url, PHP_URL_HOST );
		$is_local    = ( $home_domain && $site_domain && strtolower( $home_domain ) === strtolower( $site_domain ) );

		$gsc_sites_cache = get_option( 'easy_mcp_ai_gsc_sites_cache', array() );
		$has_service_account = ! empty( get_option( 'easy_mcp_ai_gsc_service_account_json' ) );

		if ( $is_local ) {
			$rm_options    = get_option( 'rank-math-options-general', array() );
			$google_verify = $rm_options['google_verify'] ?? '';
			if ( ! empty( $google_verify ) ) {
				$latency_ms = (int) round( ( microtime( true ) - $start_time ) * 1000 );
				return array(
					'success'           => true,
					'verified'          => true,
					'verification_code' => $google_verify,
					'latency_ms'        => $latency_ms,
					'method'            => 'rank_math',
					'message'           => sprintf(
						__( 'مالکیت سرچ کنسول از طریق تنظیمات محلی Rank Math تأیید شده است (کد تگ: %s، زمان پاسخ: %dms).', 'seo-project-manager' ),
						mb_substr( $google_verify, 0, 16 ) . '...',
						$latency_ms
					),
				);
			}

			$sitekit_token = get_option( 'googlesitekit_search_console_property' );
			if ( ! empty( $sitekit_token ) ) {
				$latency_ms = (int) round( ( microtime( true ) - $start_time ) * 1000 );
				return array(
					'success'    => true,
					'verified'   => true,
					'latency_ms' => $latency_ms,
					'method'     => 'site_kit',
					'message'    => sprintf(
						__( 'اتصال گوگل سرچ کنسول از طریق افزونه رسمی Google Site Kit فعال است (پراپرتی: %s، زمان پاسخ: %dms).', 'seo-project-manager' ),
						esc_html( $sitekit_token ),
						$latency_ms
					),
				);
			}
		}

		$res = wp_remote_get(
			$url,
			array(
				'timeout'   => 15,
				'sslverify' => false,
				'headers'   => array(
					'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
					'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				),
			)
		);
		$latency_ms = (int) round( ( microtime( true ) - $start_time ) * 1000 );

		if ( is_wp_error( $res ) ) {
			return array(
				'success'    => false,
				'verified'   => false,
				'message'    => sprintf( __( 'خطای اتصال به وب‌سایت جهت بررسی سرچ کنسول: %s', 'seo-project-manager' ), $res->get_error_message() ),
				'latency_ms' => $latency_ms,
			);
		}

		$code = wp_remote_retrieve_response_code( $res );
		if ( 200 !== $code ) {
			return array(
				'success'    => false,
				'verified'   => false,
				'message'    => sprintf( __( 'پاسخ سرور وب‌سایت با خطای HTTP %d همراه بود.', 'seo-project-manager' ), $code ),
				'latency_ms' => $latency_ms,
			);
		}

		$html = wp_remote_retrieve_body( $res );
		if ( empty( $html ) ) {
			return array(
				'success'    => false,
				'verified'   => false,
				'message'    => __( 'صفحه اصلی سایت خالی است و تگ متادیتا یافت نشد.', 'seo-project-manager' ),
				'latency_ms' => $latency_ms,
			);
		}

		$matched = preg_match( '/<meta[^>]+name=["\']google-site-verification["\'][^>]+content=["\']([^"\']+)["\']/i', $html, $matches );
		if ( ! $matched ) {
			$matched = preg_match( '/<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']google-site-verification["\']/i', $html, $matches );
		}

		if ( $matched && ! empty( $matches[1] ) ) {
			$token = trim( $matches[1] );
			return array(
				'success'           => true,
				'verified'          => true,
				'verification_code' => $token,
				'latency_ms'        => $latency_ms,
				'method'            => 'meta_tag',
				'message'           => sprintf(
					__( 'تگ تأیید مالکیت سرچ کنسول (google-site-verification) در هدر صفحه اصلی سایت یافت شد و دسترسی برقرار است (زمان پاسخ: %dms).', 'seo-project-manager' ),
					$latency_ms
				),
			);
		}

		$has_gtag = ( false !== strpos( $html, 'googletagmanager.com' ) || false !== strpos( $html, 'gtag(' ) );

		return array(
			'success'             => true,
			'verified'            => false,
			'has_gtag'            => $has_gtag,
			'latency_ms'          => $latency_ms,
			'gsc_sites_cache'     => $gsc_sites_cache,
			'has_service_account' => $has_service_account,
			'message'             => $has_gtag
				? sprintf( __( 'وب‌سایت در دسترس است (%dms) و اسکریپت گوگل تگ منیجر یافت شد، اما تگ مستقیم google-site-verification در HTML وجود ندارد (ممکن است تأیید از طریق DNS یا GTM باشد).', 'seo-project-manager' ), $latency_ms )
				: sprintf( __( 'وب‌سایت در دسترس است (%dms)، اما تگ تأیید google-site-verification در صفحه اصلی یافت نشد. می‌توانید کد تأیید را در هدر یا افزونه سئو ثبت کنید.', 'seo-project-manager' ), $latency_ms ),
		);
	}
}

<?php
/**
 * Businesses (clients / SEO projects).
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Business repository.
 */
class Business {

	/**
	 * List businesses with aggregated task stats.
	 *
	 * @param array $args { search }.
	 * @return array
	 */
	public static function all( array $args = array() ) {
		global $wpdb;
		$b     = Database::table( 'businesses' );
		$t     = Database::table( 'tasks' );
		$k     = Database::table( 'keywords' );
		$today = Jalali::today();

		$where  = '1=1';
		$params = array( $today );
		if ( ! empty( $args['search'] ) ) {
			$where   .= ' AND b.name LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		$sql = "SELECT b.*,
				COALESCE(ts.total,0) AS task_total,
				COALESCE(ts.completed,0) AS task_completed,
				COALESCE(ts.overdue,0) AS task_overdue,
				(SELECT COUNT(*) FROM {$k} kk WHERE kk.business_id = b.id) AS keyword_count
			FROM {$b} b
			LEFT JOIN (
				SELECT business_id,
					COUNT(*) AS total,
					SUM(status = 'completed') AS completed,
					SUM(status <> 'completed' AND due_date < %s) AS overdue
				FROM {$t} GROUP BY business_id
			) ts ON ts.business_id = b.id
			WHERE {$where}
			ORDER BY b.name ASC";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		// phpcs:enable

		return array_map( array( __CLASS__, 'format' ), $rows ? $rows : array() );
	}

	/**
	 * Minimal list for selects: id, name, color.
	 *
	 * @return array
	 */
	public static function options() {
		$cached = wp_cache_get( 'options', 'seopm_businesses' );
		if ( false !== $cached ) {
			return $cached;
		}
		global $wpdb;
		$b    = Database::table( 'businesses' );
		$rows = $wpdb->get_results( "SELECT id, name, color FROM {$b} ORDER BY name ASC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out  = array_map(
			static function ( $r ) {
				return array(
					'id'    => (int) $r['id'],
					'name'  => $r['name'],
					'color' => $r['color'],
				);
			},
			$rows ? $rows : array()
		);
		wp_cache_set( 'options', $out, 'seopm_businesses', 300 );
		return $out;
	}

	/**
	 * Get business.
	 *
	 * @param int  $id            ID.
	 * @param bool $with_keywords Include keywords.
	 * @return array|null
	 */
	public static function get( $id, $with_keywords = true ) {
		global $wpdb;
		$b   = Database::table( 'businesses' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$b} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $row ) {
			return null;
		}
		$data = self::format( $row );
		if ( $with_keywords ) {
			$data['keywords'] = Keyword::for_business( $id );
		}
		return $data;
	}

	/**
	 * Whether a business exists.
	 *
	 * @param int $id ID.
	 * @return bool
	 */
	public static function exists( $id ) {
		global $wpdb;
		$b = Database::table( 'businesses' );
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$b} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Sanitize an AI prompt without stripping HTML tags or newlines.
	 *
	 * @param mixed $value Raw prompt text.
	 * @return string
	 */
	private static function sanitize_prompt( $value ) {
		$value = wp_check_invalid_utf8( (string) $value );
		$value = str_replace( "\0", '', $value );
		return trim( $value );
	}

	/**
	 * Sanitize publish time HH:MM (defaults to 21:00).
	 *
	 * @param mixed $value Raw time string.
	 * @return string
	 */
	private static function sanitize_publish_time( $value ) {
		$value = trim( (string) $value );
		if ( preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $value ) ) {
			return $value;
		}
		return '21:00';
	}

	/**
	 * Fetch raw WordPress publishing credentials for internal publisher use.
	 *
	 * @param int $id Business ID.
	 * @return array|null
	 */
	public static function get_wp_credentials( $id ) {
		global $wpdb;
		$b   = Database::table( 'businesses' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, name, website_url, wp_username, wp_app_password, wp_publish_time, wp_default_category FROM {$b} WHERE id = %d", absint( $id ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $row ) {
			return null;
		}
		return array(
			'id'                  => (int) $row['id'],
			'name'                => (string) $row['name'],
			'website_url'         => (string) ( $row['website_url'] ?? '' ),
			'wp_username'         => trim( (string) ( $row['wp_username'] ?? '' ) ),
			'wp_app_password'     => trim( (string) ( $row['wp_app_password'] ?? '' ) ),
			'wp_publish_time'     => self::sanitize_publish_time( $row['wp_publish_time'] ?? '21:00' ),
			'wp_default_category' => absint( $row['wp_default_category'] ?? 0 ),
		);
	}

	/**
	 * Validate input.
	 *
	 * @param array $data         Raw data.
	 * @param array $existing_raw Optional existing raw DB row for preserving masked secrets.
	 * @return array|\WP_Error
	 */
	private static function clean( array $data, array $existing_raw = array() ) {
		$name = trim( sanitize_text_field( $data['name'] ?? '' ) );
		if ( '' === $name ) {
			return new \WP_Error( 'seopm_business_name', __( 'نام کسب‌وکار الزامی است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$existing_pass = trim( (string) ( $existing_raw['wp_app_password'] ?? '' ) );
		if ( array_key_exists( 'wp_app_password', $data ) ) {
			$raw_pass = trim( (string) $data['wp_app_password'] );
			if ( '' === $raw_pass && empty( $data['clear_wp_password'] ) && '' !== $existing_pass ) {
				$wp_pass = $existing_pass;
			} elseif ( false !== strpos( $raw_pass, '****' ) || false !== strpos( $raw_pass, '...' ) ) {
				$wp_pass = $existing_pass;
			} else {
				$wp_pass = $raw_pass;
			}
		} else {
			$wp_pass = $existing_pass;
		}
		if ( ! empty( $data['clear_wp_password'] ) ) {
			$wp_pass = '';
		}

		return array(
			'name'                    => mb_substr( $name, 0, 191 ),
			'website_url'             => Security::sanitize_url( $data['website_url'] ?? '' ),
			'sitemap_url'             => Security::sanitize_url( $data['sitemap_url'] ?? '' ),
			'color'                   => Security::sanitize_color( $data['color'] ?? '' ),
			'description'             => sanitize_textarea_field( $data['description'] ?? '' ),
			'prompt_suggestions_brief'      => self::sanitize_prompt( $data['prompt_suggestions_brief'] ?? '' ),
			'prompt_article_writing'        => self::sanitize_prompt( $data['prompt_article_writing'] ?? '' ),
			'prompt_html_conversion'        => self::sanitize_prompt( $data['prompt_html_conversion'] ?? '' ),
			'prompt_image_generation'       => self::sanitize_prompt( $data['prompt_image_generation'] ?? '' ),
			'prompt_sources_external_links' => self::sanitize_prompt( $data['prompt_sources_external_links'] ?? '' ),
			'prompt_internal_links'         => self::sanitize_prompt( $data['prompt_internal_links'] ?? '' ),
			'wp_username'             => mb_substr( trim( sanitize_text_field( $data['wp_username'] ?? '' ) ), 0, 191 ),
			'wp_app_password'         => $wp_pass,
			'wp_publish_time'         => self::sanitize_publish_time( $data['wp_publish_time'] ?? '21:00' ),
			'wp_default_category'     => absint( $data['wp_default_category'] ?? 0 ),
			'telegram_chat_id'        => mb_substr( preg_replace( '/[^0-9\-]/', '', trim( (string) ( $data['telegram_chat_id'] ?? '' ) ) ), 0, 64 ),
			'telegram_username'       => mb_substr( trim( sanitize_text_field( $data['telegram_username'] ?? '' ) ), 0, 100 ),
			'telegram_notify_enabled' => isset( $data['telegram_notify_enabled'] ) ? ( empty( $data['telegram_notify_enabled'] ) ? 0 : 1 ) : 1,
			'industry_services'       => sanitize_textarea_field( $data['industry_services'] ?? '' ),
			'target_location'         => mb_substr( trim( sanitize_text_field( $data['target_location'] ?? '' ) ), 0, 255 ),
			'focus_products_services' => sanitize_textarea_field( $data['focus_products_services'] ?? '' ),
			'content_goals'           => self::sanitize_content_goals( $data['content_goals'] ?? '' ),
			'target_audience'         => sanitize_textarea_field( $data['target_audience'] ?? '' ),
		);
	}

	/**
	 * Sanitize content goals.
	 *
	 * @param mixed $goals Array or JSON or comma-separated string.
	 * @return string JSON-encoded array.
	 */
	public static function sanitize_content_goals( $goals ) {
		if ( is_string( $goals ) ) {
			$decoded = json_decode( $goals, true );
			if ( is_array( $decoded ) ) {
				$goals = $decoded;
			} else {
				$goals = array_filter( array_map( 'trim', explode( ',', $goals ) ) );
			}
		}
		if ( ! is_array( $goals ) ) {
			return '[]';
		}
		$allowed = array( 'traffic_google', 'leads_calls', 'sales', 'brand_awareness', 'rank_support' );
		$clean   = array();
		foreach ( $goals as $g ) {
			$key = sanitize_key( (string) $g );
			if ( in_array( $key, $allowed, true ) && ! in_array( $key, $clean, true ) ) {
				$clean[] = $key;
			}
		}
		return wp_json_encode( $clean, JSON_UNESCAPED_UNICODE );
	}

	/**
	 * Create business (optionally with keywords).
	 *
	 * @param array $data Data.
	 * @return array|\WP_Error
	 */
	public static function create( array $data ) {
		global $wpdb;
		$clean = self::clean( $data );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$now                 = Database::now();
		$clean['created_by'] = get_current_user_id();
		$clean['created_at'] = $now;
		$clean['updated_at'] = $now;
		$ok                  = $wpdb->insert(
			Database::table( 'businesses' ),
			$clean,
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
		if ( ! $ok ) {
			return new \WP_Error( 'seopm_db_error', __( 'خطا در ذخیره اطلاعات.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}
		$id = (int) $wpdb->insert_id;
		if ( isset( $data['keywords'] ) && is_array( $data['keywords'] ) ) {
			Keyword::sync( $id, $data['keywords'] );
		}
		wp_cache_delete( 'options', 'seopm_businesses' );
		do_action( 'seopm_business_created', $id );
		return self::get( $id );
	}

	/**
	 * Update business (and keywords if provided).
	 *
	 * @param int   $id   ID.
	 * @param array $data Data.
	 * @return array|\WP_Error
	 */
	public static function update( $id, array $data ) {
		global $wpdb;
		$b        = Database::table( 'businesses' );
		$raw_row  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$b} WHERE id = %d", absint( $id ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $raw_row ) {
			return new \WP_Error( 'seopm_business_not_found', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$current = self::format( $raw_row );
		$merged  = array_merge( $current, $data );
		if ( ! array_key_exists( 'wp_app_password', $data ) ) {
			unset( $merged['wp_app_password'] );
		}
		$clean = self::clean( $merged, $raw_row );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$clean['updated_at'] = Database::now();
		$wpdb->update(
			$b,
			$clean,
			array( 'id' => absint( $id ) ),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
		if ( isset( $data['keywords'] ) && is_array( $data['keywords'] ) ) {
			Keyword::sync( $id, $data['keywords'] );
		}
		wp_cache_delete( 'options', 'seopm_businesses' );
		$cache_dirty = (
			$clean['name'] !== (string) ( $current['name'] ?? '' ) ||
			$clean['website_url'] !== (string) ( $current['website_url'] ?? '' ) ||
			$clean['sitemap_url'] !== (string) ( $current['sitemap_url'] ?? '' ) ||
			$clean['description'] !== (string) ( $current['description'] ?? '' ) ||
			$clean['industry_services'] !== (string) ( $current['industry_services'] ?? '' ) ||
			$clean['target_location'] !== (string) ( $current['target_location'] ?? '' ) ||
			$clean['focus_products_services'] !== (string) ( $current['focus_products_services'] ?? '' ) ||
			$clean['target_audience'] !== (string) ( $current['target_audience'] ?? '' ) ||
			( isset( $data['keywords'] ) && is_array( $data['keywords'] ) )
		);
		if ( $cache_dirty ) {
			Site_Crawler::clear_cache( $id );
			Content_Suggester::clear_cache( $id );
		}
		do_action( 'seopm_business_updated', $id );
		return self::get( $id );
	}

	/**
	 * Counts of related records (for delete confirmation).
	 *
	 * @param int $id ID.
	 * @return array
	 */
	public static function related_counts( $id ) {
		global $wpdb;
		$t = Database::table( 'tasks' );
		$r = Database::table( 'reports' );
		$k = Database::table( 'keywords' );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array(
			'tasks'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE business_id = %d", $id ) ),
			'reports'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$r} WHERE business_id = %d", $id ) ),
			'keywords' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$k} WHERE business_id = %d", $id ) ),
		);
		// phpcs:enable
	}

	/**
	 * Delete business with its keywords and tasks; reports are deleted unless kept.
	 *
	 * @param int  $id           ID.
	 * @param bool $keep_reports Keep report archive (snapshots are self-contained).
	 * @return bool|\WP_Error
	 */
	public static function delete( $id, $keep_reports = false ) {
		global $wpdb;
		if ( ! self::exists( $id ) ) {
			return new \WP_Error( 'seopm_business_not_found', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$wpdb->query( 'START TRANSACTION' );
		Keyword::delete_for_business( $id );
		$wpdb->delete( Database::table( 'article_drafts' ), array( 'business_id' => $id ), array( '%d' ) );
		$wpdb->delete( Database::table( 'tasks' ), array( 'business_id' => $id ), array( '%d' ) );
		$wpdb->delete( Database::table( 'businesses' ), array( 'id' => $id ), array( '%d' ) );
		$wpdb->query( 'COMMIT' );

		if ( ! $keep_reports ) {
			foreach ( Report::ids_for_business( $id ) as $report_id ) {
				Report::delete( $report_id );
			}
		}
		wp_cache_delete( 'options', 'seopm_businesses' );
		Site_Crawler::clear_cache( $id );
		Content_Suggester::clear_cache( $id );
		do_action( 'seopm_business_deleted', $id );
		return true;
	}

	/**
	 * Format row.
	 *
	 * @param array $row Row.
	 * @return array
	 */
	public static function format( array $row ) {
		$raw_wp_pass  = trim( (string) ( $row['wp_app_password'] ?? '' ) );
		$wp_user      = trim( (string) ( $row['wp_username'] ?? '' ) );
		$site_url     = (string) ( $row['website_url'] ?? '' );
		$tg_chat_id   = trim( (string) ( $row['telegram_chat_id'] ?? '' ) );
		$tg_username  = trim( (string) ( $row['telegram_username'] ?? '' ) );
		$tg_notify    = isset( $row['telegram_notify_enabled'] ) ? (bool) (int) $row['telegram_notify_enabled'] : true;

		$data = array(
			'id'                      => (int) $row['id'],
			'name'                    => $row['name'],
			'website_url'             => $site_url,
			'sitemap_url'             => $row['sitemap_url'],
			'color'                   => $row['color'],
			'description'             => (string) ( $row['description'] ?? '' ),
			'prompt_suggestions_brief'      => (string) ( $row['prompt_suggestions_brief'] ?? '' ),
			'prompt_article_writing'        => (string) ( $row['prompt_article_writing'] ?? '' ),
			'prompt_html_conversion'        => (string) ( $row['prompt_html_conversion'] ?? '' ),
			'prompt_image_generation'       => (string) ( $row['prompt_image_generation'] ?? '' ),
			'prompt_sources_external_links' => (string) ( $row['prompt_sources_external_links'] ?? '' ),
			'prompt_internal_links'         => (string) ( $row['prompt_internal_links'] ?? '' ),
			'wp_username'             => $wp_user,
			'wp_app_password'         => Settings::mask_key( $raw_wp_pass ),
			'wp_has_password'         => '' !== $raw_wp_pass,
			'wp_connected'            => '' !== $site_url && '' !== $wp_user && '' !== $raw_wp_pass,
			'wp_publish_time'         => self::sanitize_publish_time( $row['wp_publish_time'] ?? '21:00' ),
			'wp_default_category'     => absint( $row['wp_default_category'] ?? 0 ),
			'telegram_chat_id'        => $tg_chat_id,
			'telegram_username'       => $tg_username,
			'telegram_notify_enabled' => $tg_notify,
			'telegram_connected'      => '' !== $tg_chat_id,
			'industry_services'       => (string) ( $row['industry_services'] ?? '' ),
			'target_location'         => (string) ( $row['target_location'] ?? '' ),
			'focus_products_services' => (string) ( $row['focus_products_services'] ?? '' ),
			'content_goals'           => ! empty( $row['content_goals'] ) ? ( json_decode( $row['content_goals'], true ) ?: array() ) : array(),
			'target_audience'         => (string) ( $row['target_audience'] ?? '' ),
			'created_at'              => $row['created_at'],
			'updated_at'              => $row['updated_at'],
		);
		if ( isset( $row['task_total'] ) ) {
			$total                  = (int) $row['task_total'];
			$completed              = (int) $row['task_completed'];
			$data['task_total']     = $total;
			$data['task_completed'] = $completed;
			$data['task_overdue']   = (int) $row['task_overdue'];
			$data['keyword_count']  = (int) $row['keyword_count'];
			$data['completion']     = Task::rate( $completed, $total );
		}
		return $data;
	}

	/**
	 * Get formatted text representation of a business section or shortcode.
	 *
	 * @param array  $biz Business data array.
	 * @param string $section Section identifier: 'basic_info', 'business_profile', 'content_goals', 'target_audience', 'external_access', 'keywords'.
	 * @return string Formatted section string.
	 */
	public static function get_section_text( array $biz, $section = 'basic_info' ) {
		switch ( $section ) {
			case 'business_profile':
				$lines = array(
					'=== اطلاعات کسب‌وکار (بخش اول) ===',
					'- نام برند / کسب‌وکار: ' . ( $biz['name'] ?? '—' ),
					'- آدرس وب‌سایت: ' . ( $biz['website_url'] ?? '—' ),
					'- آدرس نقشه سایت (Sitemap): ' . ( $biz['sitemap_url'] ?? '—' ),
				);
				if ( ! empty( $biz['industry_services'] ) ) {
					$lines[] = '- حوزه فعالیت و خدمات یا محصولات اصلی: ' . $biz['industry_services'];
				}
				if ( ! empty( $biz['target_location'] ) ) {
					$lines[] = '- شهر یا محدوده جغرافیایی هدف: ' . $biz['target_location'];
				}
				if ( ! empty( $biz['focus_products_services'] ) ) {
					$lines[] = '- خدمات یا محصولات با اولویت تمرکز: ' . $biz['focus_products_services'];
				}
				if ( ! empty( $biz['description'] ) ) {
					$lines[] = '- توضیحات کوتاه برند: ' . $biz['description'];
				}
				return implode( "\n", $lines );

			case 'content_goals':
				$goals = $biz['content_goals'] ?? array();
				if ( ! is_array( $goals ) ) {
					$goals = json_decode( (string) $goals, true ) ?: array();
				}
				$goal_map = array(
					'traffic_google'  => 'جذب ورودی از گوگل (Organic Search Traffic)',
					'leads_calls'     => 'دریافت تماس، مشاوره یا درخواست خدمات (Lead Generation)',
					'sales'           => 'فروش مستقیم محصول یا خدمت (Sales & Conversion)',
					'brand_awareness' => 'افزایش آگاهی از برند و اعتبار تخصصی (Brand Authority)',
					'rank_support'    => 'حمایت از رتبه صفحات خدمات و دسته‌بندی‌ها (Topic Cluster / Pillar Support)',
				);
				$selected_goals = array();
				foreach ( $goals as $g ) {
					if ( isset( $goal_map[ $g ] ) ) {
						$selected_goals[] = '  * ' . $goal_map[ $g ];
					}
				}
				$lines = array(
					'=== اهداف و اولویت‌های تولید محتوا (بخش دوم) ===',
					! empty( $selected_goals ) ? "- اولویت‌های اصلی تولید محتوا:\n" . implode( "\n", $selected_goals ) : '- اولویت مشخصی ثبت نشده است.',
				);
				return implode( "\n", $lines );

			case 'target_audience':
				$lines = array(
					'=== ویژگی‌ها و پرسونای مخاطب هدف (بخش سوم) ===',
					! empty( $biz['target_audience'] ) ? '- پرسونای مخاطب و دغدغه‌ها: ' . $biz['target_audience'] : '- اطلاعات مخاطب هدف ثبت نشده است.',
				);
				return implode( "\n", $lines );

			case 'gsc_data':
				if ( class_exists( 'SEOPM\\Google_Search_Console' ) ) {
					return Google_Search_Console::get_gsc_digest_for_business( $biz );
				}
				return '- سرویس گوگل سرچ کنسول در دسترس نیست.';

			case 'external_access':
				$sm_status = ! empty( $biz['sitemap_url'] ) ? 'نقشه سایت ثبت شده (' . $biz['sitemap_url'] . ')' : 'نقشه سایت ثبت نشده است.';
				$gsc_info  = 'اتصال گوگل سرچ کنسول بررسی نشده است.';
				$gsc_block = '';
				if ( class_exists( 'SEOPM\\Google_Search_Console' ) ) {
					$match = Google_Search_Console::match_property( $biz['website_url'] ?? '' );
					if ( ! empty( $match['found'] ) ) {
						$gsc_info  = 'پراپرتی متصل سرچ کنسول: ' . $match['property'] . ' (سطح دسترسی: ' . ( $match['permission'] ?? 'siteFullUser' ) . ')';
						$gsc_block = "\n\n" . Google_Search_Console::get_gsc_digest_for_business( $biz );
					} elseif ( Google_Search_Console::has_credentials() ) {
						$gsc_info = 'سرویس اکانت گوگل فعال است (ایمیل: ' . Google_Search_Console::get_client_email() . ')، در انتظار اشتراک‌گذاری در سرچ کنسول.';
					}
				}
				$lines = array(
					'=== دسترسی‌های خارجی و ابزارهای سئو (بخش چهارم) ===',
					'- وضعیت نقشه سایت (Sitemap): ' . $sm_status,
					'- وضعیت گوگل سرچ کنسول (GSC): ' . $gsc_info,
				);
				return implode( "\n", $lines ) . $gsc_block;

			case 'keywords':
				$keywords = array();
				if ( ! empty( $biz['keywords'] ) && is_array( $biz['keywords'] ) ) {
					$keywords = $biz['keywords'];
				} elseif ( ! empty( $biz['id'] ) ) {
					$keywords = Keyword::for_business( $biz['id'] );
				}
				$lines = array( '=== کلمات کلیدی هدف کسب‌وکار ===' );
				if ( ! empty( $keywords ) ) {
					$i = 1;
					foreach ( $keywords as $kw ) {
						$word   = is_array( $kw ) ? ( $kw['keyword'] ?? '' ) : (string) $kw;
						$weight = is_array( $kw ) ? ( $kw['weight'] ?? 5 ) : 5;
						if ( ! empty( $word ) ) {
							$lines[] = sprintf( '%d. %s (وزن/اولویت: %d از ۱۰)', $i++, $word, $weight );
						}
					}
				} else {
					$lines[] = '- هنوز کلمه کلیدی هدفی برای این کسب‌وکار ثبت نشده است.';
				}
				return implode( "\n", $lines );

			case 'basic_info':
			default:
				$parts = array(
					self::get_section_text( $biz, 'business_profile' ),
					self::get_section_text( $biz, 'content_goals' ),
					self::get_section_text( $biz, 'target_audience' ),
					self::get_section_text( $biz, 'external_access' ),
				);
				return implode( "\n\n", $parts );
		}
	}

	/**
	 * Expand shortcodes in text with business data and optional article context.
	 *
	 * Supported shortcodes:
	 * Business: [basic_info], [business_profile], [content_goals], [target_audience], [external_access], [keywords], [brand_color], [business_name]
	 * Article:  [article_title], [article_keyword], [article_slug], [article_headings], [article_summary]
	 *
	 * @param string    $text    Prompt or template text.
	 * @param array|int $biz     Business data or business ID.
	 * @param array     $article Optional article data { title, keyword, url_slug, headings, summary }.
	 * @return string Expanded text.
	 */
	public static function expand_shortcodes( $text, $biz, array $article = array() ) {
		if ( empty( $text ) || ! is_string( $text ) ) {
			return $text;
		}

		if ( is_numeric( $biz ) ) {
			$biz = self::get( (int) $biz, true );
		}
		if ( ! is_array( $biz ) ) {
			return $text;
		}

		$replacements = array(
			// Main Tab: اطلاعات پایه
			'[basic_info]'       => self::get_section_text( $biz, 'basic_info' ),
			'[business_info]'    => self::get_section_text( $biz, 'basic_info' ),
			'[اطلاعات_پایه]'     => self::get_section_text( $biz, 'basic_info' ),

			// Section 1: اطلاعات کسب‌وکار
			'[business_profile]' => self::get_section_text( $biz, 'business_profile' ),
			'[biz_profile]'      => self::get_section_text( $biz, 'business_profile' ),
			'[section_1]'        => self::get_section_text( $biz, 'business_profile' ),
			'[بخش_اول]'          => self::get_section_text( $biz, 'business_profile' ),

			// Section 2: هدف تولید محتوا
			'[content_goals]'    => self::get_section_text( $biz, 'content_goals' ),
			'[goals]'            => self::get_section_text( $biz, 'content_goals' ),
			'[section_2]'        => self::get_section_text( $biz, 'content_goals' ),
			'[بخش_دوم]'          => self::get_section_text( $biz, 'content_goals' ),

			// Section 3: ویژگی‌های مخاطب
			'[target_audience]'  => self::get_section_text( $biz, 'target_audience' ),
			'[audience]'         => self::get_section_text( $biz, 'target_audience' ),
			'[section_3]'        => self::get_section_text( $biz, 'target_audience' ),
			'[بخش_سوم]'          => self::get_section_text( $biz, 'target_audience' ),

			// Section 4: دسترسی‌های خارجی
			'[external_access]'      => self::get_section_text( $biz, 'external_access' ),
			'[integrations]'         => self::get_section_text( $biz, 'external_access' ),
			'[section_4]'            => self::get_section_text( $biz, 'external_access' ),
			'[بخش_چهارم]'            => self::get_section_text( $biz, 'external_access' ),

			// Google Search Console Smart Performance Digest
			'[gsc_data]'             => self::get_section_text( $biz, 'gsc_data' ),
			'[search_console]'       => self::get_section_text( $biz, 'gsc_data' ),
			'[gsc]'                  => self::get_section_text( $biz, 'gsc_data' ),
			'[دیتای_سرچ_کنسول]'      => self::get_section_text( $biz, 'gsc_data' ),
			'[دیتای_گوگل_سرچ_کنسول]' => self::get_section_text( $biz, 'gsc_data' ),

			// Main Tab: کلمات کلیدی
			'[keywords]'         => self::get_section_text( $biz, 'keywords' ),
			'[target_keywords]'  => self::get_section_text( $biz, 'keywords' ),
			'[کلمات_کلیدی]'      => self::get_section_text( $biz, 'keywords' ),

			// Brand Color & Identity
			'[brand_color]'      => (string) ( $biz['color'] ?? '' ),
			'[رنگ_برند]'         => (string) ( $biz['color'] ?? '' ),
			'[business_name]'    => (string) ( $biz['name'] ?? '' ),
			'[نام_کسب‌وکار]'     => (string) ( $biz['name'] ?? '' ),
			'[site_url]'         => (string) ( $biz['website_url'] ?? '' ),
			'[آدرس_سایت]'        => (string) ( $biz['website_url'] ?? '' ),
		);

		// Article-level dynamic shortcodes (expanded whenever article context is present).
		if ( ! empty( $article ) ) {
			$title    = trim( (string) ( $article['title'] ?? $article['best_title'] ?? '' ) );
			$keyword  = trim( (string) ( $article['keyword'] ?? '' ) );
			$slug     = trim( (string) ( $article['url_slug'] ?? $article['slug'] ?? '' ) );
			$headings = trim( (string) ( $article['headings'] ?? $article['article_headings'] ?? '' ) );
			$summary  = trim( (string) ( $article['summary'] ?? $article['article_summary'] ?? $article['excerpt'] ?? '' ) );

			$article_replacements = array(
				'[article_title]'    => $title,
				'[عنوان_مقاله]'      => $title,
				'[title]'            => $title,
				'{title}'            => $title,
				'{{title}}'          => $title,

				'[article_keyword]'  => $keyword,
				'[کلمه_کلیدی]'       => $keyword,
				'[keyword]'          => $keyword,
				'{keyword}'          => $keyword,
				'{{keyword}}'        => $keyword,

				'[article_slug]'     => $slug,
				'[اسلاگ]'            => $slug,
				'[slug]'             => $slug,
				'{slug}'             => $slug,

				'[article_headings]' => $headings,
				'[هدینگ‌ها]'         => $headings,
				'[headings]'         => $headings,

				'[article_summary]'  => $summary,
				'[خلاصه_مقاله]'      => $summary,
				'[summary]'          => $summary,
			);

			$replacements = array_merge( $replacements, $article_replacements );
		}

		return str_ireplace( array_keys( $replacements ), array_values( $replacements ), $text );
	}
}

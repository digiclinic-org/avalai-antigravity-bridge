<?php
/**
 * PDF report template (rendered by mPDF).
 * All values come from the frozen snapshot ($view), never from live tables.
 *
 * @package SEOPM
 * @var array $view View model from Pdf_Generator::view_model().
 */

use SEOPM\Chart_Svg;
use SEOPM\Jalali;

defined( 'ABSPATH' ) || exit;

$fa       = static function ( $v ) {
	return Jalali::fa_digits( $v );
};
$jd       = static function ( $d ) {
	return $d ? Jalali::format( $d ) : '—';
};
$accent   = $view['accent'];
$theme    = $view['theme'];
$font     = $view['font'];
$stats    = wp_parse_args( $view['stats'], array( 'total' => 0, 'completed' => 0, 'in_progress' => 0, 'pending' => 0, 'overdue' => 0, 'completion' => 0 ) );
$types    = $view['labels']['types'] ?? array();
$statuses = $view['labels']['statuses'] ?? array();
$branding = $view['branding'];
$business = $view['business'];
$snap     = $view['snapshot'];
$period   = $snap['period'] ?? array( 'start' => '', 'end' => '' );

$status_colors = array(
	'pending'     => '#b45309',
	'in_progress' => '#1d4ed8',
	'completed'   => '#15803d',
	'overdue'     => '#b91c1c',
);
$status_bg     = array(
	'pending'     => '#fef3c7',
	'in_progress' => '#dbeafe',
	'completed'   => '#dcfce7',
	'overdue'     => '#fee2e2',
);

// Theme palette.
$dark = '#1f2937';
if ( 'formal' === $theme ) {
	$cover_bg   = $dark;
	$cover_text = '#ffffff';
	$th_bg      = $dark;
	$th_text    = '#ffffff';
	$card_bg    = '#f8fafc';
	$card_brd   = '#cbd5e1';
	$h_color    = $dark;
} elseif ( 'minimal' === $theme ) {
	$cover_bg   = '#ffffff';
	$cover_text = $dark;
	$th_bg      = '#f3f4f6';
	$th_text    = '#374151';
	$card_bg    = '#ffffff';
	$card_brd   = '#e5e7eb';
	$h_color    = $dark;
} else {
	$cover_bg   = $accent;
	$cover_text = '#ffffff';
	$th_bg      = Chart_Svg::tint( $accent, 0.85 );
	$th_text    = Chart_Svg::shade( $accent, 0.45 );
	$card_bg    = Chart_Svg::tint( $accent, 0.93 );
	$card_brd   = Chart_Svg::tint( $accent, 0.75 );
	$h_color    = Chart_Svg::shade( $accent, 0.35 );
}
if ( 'light' === $theme ) {
	// Very light business colors need dark text on the cover.
	$cover_text = \SEOPM\Calendar::contrast( $cover_bg );
}

$logo_src = $view['logo'] ? $view['logo'] : $view['default_logo'];

$badge = static function ( $task ) use ( $statuses, $status_colors, $status_bg ) {
	$key   = ! empty( $task['overdue'] ) ? 'overdue' : $task['status'];
	$label = 'overdue' === $key ? __( 'عقب‌افتاده', 'seo-project-manager' ) : ( $statuses[ $task['status'] ] ?? $task['status'] );
	return '<span style="color:' . esc_attr( $status_colors[ $key ] ) . ';background-color:' . esc_attr( $status_bg[ $key ] ) . ';padding:1px 6px;font-size:8.5pt;">' . esc_html( $label ) . '</span>';
};

$bar = static function ( $pct, $color, $height = 9 ) {
	$pct = max( 0, min( 100, (int) $pct ) );
	$out = '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;"><tr>';
	if ( $pct > 0 ) {
		$out .= '<td width="' . $pct . '%" style="background-color:' . esc_attr( $color ) . ';height:' . (int) $height . 'px;font-size:1pt;">&nbsp;</td>';
	}
	if ( $pct < 100 ) {
		$out .= '<td width="' . ( 100 - $pct ) . '%" style="background-color:#eef0f4;height:' . (int) $height . 'px;font-size:1pt;">&nbsp;</td>';
	}
	return $out . '</tr></table>';
};

$generated_local = ! empty( $snap['generated_at'] ) ? get_date_from_gmt( $snap['generated_at'], 'Y-m-d' ) : '';
$no_data         = '<div class="empty">' . esc_html__( 'داده‌ای برای نمایش وجود ندارد', 'seo-project-manager' ) . '</div>';
?>
<html dir="rtl" lang="fa">
<head>
<meta charset="utf-8">
<style>
	body { font-family: <?php echo esc_attr( $font ); ?>; font-size: 10pt; color: #1f2937; line-height: 1.7; }
	h2 { font-size: 14pt; color: <?php echo esc_attr( $h_color ); ?>; margin: 18px 0 8px; padding-bottom: 4px; border-bottom: 2px solid <?php echo esc_attr( $accent ); ?>; }
	h3 { font-size: 11pt; color: #374151; margin: 12px 0 6px; }
	table.data { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
	table.data th { background-color: <?php echo esc_attr( $th_bg ); ?>; color: <?php echo esc_attr( $th_text ); ?>; font-weight: bold; font-size: 9pt; padding: 6px 5px; text-align: right; border-bottom: 1px solid <?php echo esc_attr( $card_brd ); ?>; }
	table.data td { padding: 5px; font-size: 9pt; border-bottom: 1px solid #e5e7eb; vertical-align: middle; }
	table.data tr.group td { background-color: #f9fafb; font-weight: bold; color: <?php echo esc_attr( $h_color ); ?>; font-size: 9.5pt; }
	table.data tr.zebra td { background-color: #fbfbfd; }
	td.num, th.num { text-align: center; }
	.cards td.card { background-color: <?php echo esc_attr( $card_bg ); ?>; border: 1px solid <?php echo esc_attr( $card_brd ); ?>; padding: 10px; text-align: center; }
	div.v { font-size: 20pt; font-weight: bold; color: <?php echo esc_attr( $h_color ); ?>; line-height: 1.3; }
	div.l { font-size: 9pt; color: #6b7280; }
	.empty { padding: 18px; text-align: center; color: #6b7280; background-color: #f9fafb; border: 1px dashed #d1d5db; }
	.muted { color: #6b7280; }
	.legend td { padding: 3px 4px; font-size: 9.5pt; }
	.dot { width: 10px; height: 10px; }
	.bar-bg { background-color: #eef0f4; height: 9px; }
	.summary { border: 1px solid <?php echo esc_attr( $card_brd ); ?>; background-color: <?php echo esc_attr( $card_bg ); ?>; padding: 12px 14px; }
	.summary p { margin: 0 0 6px; }
</style>
</head>
<body>

<htmlpageheader name="seopmHeader">
	<table width="100%" style="border-bottom: 2px solid <?php echo esc_attr( $accent ); ?>; padding-bottom: 4px;">
		<tr>
			<td width="60%" style="text-align:right; font-size:9pt;">
				<img src="<?php echo esc_attr( $logo_src ); ?>" style="height:22px; vertical-align:middle;" />
				&nbsp;<b><?php echo esc_html( $branding['agency_name'] ?? '' ); ?></b>
			</td>
			<td width="40%" style="text-align:left; font-size:9pt; color:#6b7280;">
				<?php echo esc_html( $business['name'] ?? '' ); ?> · <?php echo esc_html( $jd( $period['start'] ) . ' – ' . $jd( $period['end'] ) ); ?>
			</td>
		</tr>
	</table>
</htmlpageheader>

<htmlpagefooter name="seopmFooter">
	<table width="100%" style="border-top: 1px solid #e5e7eb; font-size:8pt; color:#6b7280; padding-top:4px;">
		<tr>
			<td width="40%" style="text-align:right;">
				<?php echo esc_html( $branding['agency_name'] ?? '' ); ?>
				<?php if ( ! empty( $branding['agency_website'] ) ) : ?>
					· <?php echo esc_html( preg_replace( '#^https?://#', '', $branding['agency_website'] ) ); ?>
				<?php endif; ?>
			</td>
			<td width="30%" style="text-align:center;"><?php echo esc_html__( 'تاریخ تولید:', 'seo-project-manager' ) . ' ' . esc_html( $jd( $generated_local ) ); ?></td>
			<td width="30%" style="text-align:left;"><?php esc_html_e( 'صفحه', 'seo-project-manager' ); ?> {PAGENO} <?php esc_html_e( 'از', 'seo-project-manager' ); ?> {nbpg}</td>
		</tr>
	</table>
</htmlpagefooter>

<!-- ===================== Cover ===================== -->
<div style="background-color: <?php echo esc_attr( $cover_bg ); ?>; color: <?php echo esc_attr( $cover_text ); ?>; padding: 34px 30px 30px; border-radius: 10px; <?php echo 'minimal' === $theme ? 'border-top: 6px solid ' . esc_attr( $accent ) . ';' : ''; ?><?php echo 'formal' === $theme ? 'border-bottom: 6px solid ' . esc_attr( $accent ) . ';' : ''; ?>">
	<table width="100%"><tr>
		<td style="text-align:right; vertical-align:top;">
			<img src="<?php echo esc_attr( $logo_src ); ?>" style="height:56px;" />
		</td>
		<td style="text-align:left; vertical-align:top; font-size:9.5pt; color: <?php echo esc_attr( $cover_text ); ?>;">
			<?php echo esc_html( $branding['agency_name'] ?? '' ); ?>
		</td>
	</tr></table>
	<div style="height: 70px;"></div>
	<div style="font-size: 11pt; color: <?php echo esc_attr( $cover_text ); ?>;"><?php esc_html_e( 'گزارش مدیریتی پروژه سئو', 'seo-project-manager' ); ?></div>
	<div style="font-size: 24pt; font-weight: bold; color: <?php echo esc_attr( $cover_text ); ?>; line-height:1.4;"><?php echo esc_html( $snap['title'] ?? '' ); ?></div>
	<div style="height: 14px;"></div>
	<div style="font-size: 16pt; font-weight: bold; color: <?php echo esc_attr( $cover_text ); ?>;"><?php echo esc_html( $business['name'] ?? '' ); ?></div>
	<?php if ( ! empty( $business['website_url'] ) ) : ?>
		<div style="font-size: 10pt; text-align: right; color: <?php echo esc_attr( $cover_text ); ?>;"><?php echo esc_html( preg_replace( '#^https?://#', '', $business['website_url'] ) ); ?></div>
	<?php endif; ?>
	<div style="height: 20px;"></div>
	<div style="font-size: 11pt; color: <?php echo esc_attr( $cover_text ); ?>;">
		<?php esc_html_e( 'دوره گزارش:', 'seo-project-manager' ); ?>
		<b><?php echo esc_html( Jalali::format( $period['start'], 'long' ) . ' ' . __( 'تا', 'seo-project-manager' ) . ' ' . Jalali::format( $period['end'], 'long' ) ); ?></b>
	</div>
</div>

<div style="height: 26px;"></div>

<table width="100%" class="cards" cellspacing="8">
	<tr>
		<td class="card" width="25%"><div class="v"><?php echo esc_html( $fa( $stats['total'] ) ); ?></div><div class="l"><?php esc_html_e( 'تسک برنامه‌ریزی‌شده', 'seo-project-manager' ); ?></div></td>
		<td class="card" width="25%"><div class="v" style="color:#15803d;"><?php echo esc_html( $fa( $stats['completed'] ) ); ?></div><div class="l"><?php esc_html_e( 'تکمیل‌شده', 'seo-project-manager' ); ?></div></td>
		<td class="card" width="25%"><div class="v" style="color:#b91c1c;"><?php echo esc_html( $fa( $stats['overdue'] ) ); ?></div><div class="l"><?php esc_html_e( 'عقب‌افتاده', 'seo-project-manager' ); ?></div></td>
		<td class="card" width="25%"><div class="v"><?php echo esc_html( $fa( $stats['completion'] . '%' ) ); ?></div><div class="l"><?php esc_html_e( 'درصد تکمیل', 'seo-project-manager' ); ?></div></td>
	</tr>
</table>

<div style="height: 40px;"></div>
<table width="100%" style="font-size:9.5pt; color:#4b5563;">
	<?php if ( ! empty( $branding['preparer_name'] ) ) : ?>
		<tr><td width="28%" class="muted"><?php esc_html_e( 'تهیه‌کننده:', 'seo-project-manager' ); ?></td><td><?php echo esc_html( $branding['preparer_name'] ); ?></td></tr>
	<?php endif; ?>
	<tr><td width="28%" class="muted"><?php esc_html_e( 'تاریخ تولید گزارش:', 'seo-project-manager' ); ?></td><td><?php echo esc_html( Jalali::format( $generated_local, 'long' ) ); ?></td></tr>
	<?php if ( ! empty( $branding['contact_info'] ) ) : ?>
		<tr><td class="muted"><?php esc_html_e( 'اطلاعات تماس:', 'seo-project-manager' ); ?></td><td><?php echo nl2br( esc_html( $branding['contact_info'] ) ); ?></td></tr>
	<?php endif; ?>
</table>

<!-- ===================== Executive summary ===================== -->
<pagebreak />
<sethtmlpageheader name="seopmHeader" value="on" show-this-page="1" />
<sethtmlpagefooter name="seopmFooter" value="on" />

<h2><?php esc_html_e( '۱. خلاصه مدیریتی', 'seo-project-manager' ); ?></h2>
<table width="100%" class="cards" cellspacing="6">
	<tr>
		<td class="card" width="33%"><div class="v"><?php echo esc_html( $fa( $stats['total'] ) ); ?></div><div class="l"><?php esc_html_e( 'کل تسک‌های برنامه‌ریزی‌شده در بازه', 'seo-project-manager' ); ?></div></td>
		<td class="card" width="33%"><div class="v" style="color:#15803d;"><?php echo esc_html( $fa( $stats['completed'] ) ); ?></div><div class="l"><?php esc_html_e( 'تسک‌های تکمیل‌شده', 'seo-project-manager' ); ?></div></td>
		<td class="card" width="33%"><div class="v" style="color:#1d4ed8;"><?php echo esc_html( $fa( $stats['in_progress'] ) ); ?></div><div class="l"><?php esc_html_e( 'تسک‌های در حال انجام', 'seo-project-manager' ); ?></div></td>
	</tr>
	<tr>
		<td class="card"><div class="v" style="color:#b45309;"><?php echo esc_html( $fa( $stats['pending'] ) ); ?></div><div class="l"><?php esc_html_e( 'تسک‌های در انتظار', 'seo-project-manager' ); ?></div></td>
		<td class="card"><div class="v" style="color:#b91c1c;"><?php echo esc_html( $fa( $stats['overdue'] ) ); ?></div><div class="l"><?php esc_html_e( 'تسک‌های عقب‌افتاده', 'seo-project-manager' ); ?></div></td>
		<td class="card"><div class="v"><?php echo esc_html( $fa( $stats['completion'] . '%' ) ); ?></div><div class="l"><?php esc_html_e( 'درصد تکمیل تسک‌ها', 'seo-project-manager' ); ?></div></td>
	</tr>
</table>
<div class="muted" style="font-size:8.5pt;"><?php esc_html_e( 'تسک عقب‌افتاده: تسکی که تا زمان تولید گزارش تکمیل نشده و موعد آن گذشته است (زیرمجموعه تسک‌های در انتظار و در حال انجام).', 'seo-project-manager' ); ?></div>

<h2><?php esc_html_e( '۲. نمودارهای عملکرد', 'seo-project-manager' ); ?></h2>
<?php if ( $stats['total'] > 0 ) : ?>
	<table width="100%">
		<tr>
			<td width="50%" style="vertical-align:top;">
				<h3><?php esc_html_e( 'تکمیل‌شده در مقابل تکمیل‌نشده', 'seo-project-manager' ); ?></h3>
				<table width="100%"><tr>
					<td width="50%" style="text-align:center;">
						<img width="130" src="<?php echo esc_attr( Chart_Svg::data_uri( Chart_Svg::donut( array( array( $stats['completed'], '#16a34a' ), array( $stats['in_progress'], '#3b82f6' ), array( $stats['pending'], '#f59e0b' ) ), $fa( $stats['completion'] . '%' ), $font ) ) ); ?>" />
					</td>
					<td width="50%" style="vertical-align:middle;">
						<table class="legend">
							<tr><td width="12" style="background-color:#16a34a;font-size:6pt;">&nbsp;</td><td width="4"></td><td><?php esc_html_e( 'تکمیل‌شده', 'seo-project-manager' ); ?></td><td><b><?php echo esc_html( $fa( $stats['completed'] ) ); ?></b></td></tr>
							<tr><td width="12" style="background-color:#3b82f6;font-size:6pt;">&nbsp;</td><td width="4"></td><td><?php esc_html_e( 'در حال انجام', 'seo-project-manager' ); ?></td><td><b><?php echo esc_html( $fa( $stats['in_progress'] ) ); ?></b></td></tr>
							<tr><td width="12" style="background-color:#f59e0b;font-size:6pt;">&nbsp;</td><td width="4"></td><td><?php esc_html_e( 'در انتظار', 'seo-project-manager' ); ?></td><td><b><?php echo esc_html( $fa( $stats['pending'] ) ); ?></b></td></tr>
						</table>
					</td>
				</tr></table>
			</td>
			<td width="50%" style="vertical-align:top;">
				<h3><?php esc_html_e( 'توزیع تسک‌ها بر اساس نوع فعالیت', 'seo-project-manager' ); ?></h3>
				<table width="100%" class="legend">
					<?php
					$max_type = max( 1, max( wp_list_pluck( $view['by_type'], 'total' ) ?: array( 0 ) ) );
					foreach ( $view['by_type'] as $type_key => $bt ) :
						$w = $bt['total'] > 0 ? max( 2, round( $bt['total'] / $max_type * 100 ) ) : 0;
						?>
						<tr>
							<td width="40%" style="font-size:9pt;"><?php echo esc_html( $types[ $type_key ] ?? $bt['label'] ); ?></td>
							<td width="48%"><?php echo $bar( $w, $accent, 10 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td width="12%" style="text-align:center;"><b><?php echo esc_html( $fa( $bt['total'] ) ); ?></b></td>
						</tr>
					<?php endforeach; ?>
				</table>
			</td>
		</tr>
	</table>
<?php else : ?>
	<?php echo $no_data; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
<?php endif; ?>

<h3><?php esc_html_e( 'روند تکمیل تسک‌ها در طول بازه', 'seo-project-manager' ); ?>
	<span class="muted" style="font-size:8.5pt; font-weight:normal;">(<?php echo 'week' === ( $view['trend']['granularity'] ?? 'day' ) ? esc_html__( 'هفتگی', 'seo-project-manager' ) : esc_html__( 'روزانه', 'seo-project-manager' ); ?>)</span>
</h3>
<?php if ( array_sum( $view['trend']['values'] ?? array() ) > 0 ) : ?>
	<div style="text-align:center;">
		<img width="640" src="<?php echo esc_attr( Chart_Svg::data_uri( Chart_Svg::columns( $view['trend']['labels'], $view['trend']['values'], $accent, $font ) ) ); ?>" />
	</div>
<?php else : ?>
	<?php echo $no_data; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
<?php endif; ?>

<!-- ===================== Task performance ===================== -->
<pagebreak />
<h2><?php esc_html_e( '۳. گزارش عملکرد تسک‌ها', 'seo-project-manager' ); ?></h2>
<?php if ( $view['tasks'] ) : ?>
	<table class="data" repeat_header="1">
		<thead>
			<tr>
				<th class="num" width="6%"><?php esc_html_e( 'ردیف', 'seo-project-manager' ); ?></th>
				<th width="36%"><?php esc_html_e( 'عنوان تسک', 'seo-project-manager' ); ?></th>
				<th width="17%"><?php esc_html_e( 'نوع فعالیت', 'seo-project-manager' ); ?></th>
				<th class="num" width="14%"><?php esc_html_e( 'تاریخ برنامه‌ریزی‌شده', 'seo-project-manager' ); ?></th>
				<th class="num" width="13%"><?php esc_html_e( 'وضعیت', 'seo-project-manager' ); ?></th>
				<th class="num" width="14%"><?php esc_html_e( 'تاریخ تکمیل', 'seo-project-manager' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php
		$row_no = 0;
		foreach ( $view['grouped'] as $type_key => $list ) :
			?>
			<tr class="group"><td colspan="6"><?php echo esc_html( ( $types[ $type_key ] ?? $type_key ) . ' (' . $fa( count( $list ) ) . ')' ); ?></td></tr>
			<?php
			foreach ( $list as $task ) :
				++$row_no;
				?>
				<tr<?php echo 0 === $row_no % 2 ? ' class="zebra"' : ''; ?>>
					<td class="num"><?php echo esc_html( $fa( $row_no ) ); ?></td>
					<td><?php echo esc_html( $task['title'] ); ?></td>
					<td><?php echo esc_html( $types[ $task['task_type'] ] ?? $task['task_type'] ); ?></td>
					<td class="num"><?php echo esc_html( $jd( $task['due_date'] ) ); ?></td>
					<td class="num"><?php echo $badge( $task ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
					<td class="num"><?php echo esc_html( $task['completed_on'] ? $jd( $task['completed_on'] ) : '—' ); ?></td>
				</tr>
			<?php endforeach; ?>
		<?php endforeach; ?>
		</tbody>
	</table>
<?php else : ?>
	<?php echo $no_data; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
<?php endif; ?>

<!-- ===================== Breakdown by type ===================== -->
<h2><?php esc_html_e( '۴. گزارش تفکیکی فعالیت‌ها', 'seo-project-manager' ); ?></h2>
<table class="data">
	<thead>
		<tr>
			<th width="26%"><?php esc_html_e( 'نوع فعالیت', 'seo-project-manager' ); ?></th>
			<th class="num" width="10%"><?php esc_html_e( 'کل', 'seo-project-manager' ); ?></th>
			<th class="num" width="11%"><?php esc_html_e( 'تکمیل‌شده', 'seo-project-manager' ); ?></th>
			<th class="num" width="12%"><?php esc_html_e( 'در حال انجام', 'seo-project-manager' ); ?></th>
			<th class="num" width="11%"><?php esc_html_e( 'در انتظار', 'seo-project-manager' ); ?></th>
			<th class="num" width="11%"><?php esc_html_e( 'عقب‌افتاده', 'seo-project-manager' ); ?></th>
			<th width="19%"><?php esc_html_e( 'درصد تکمیل', 'seo-project-manager' ); ?></th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ( $view['by_type'] as $type_key => $bt ) : ?>
		<tr>
			<td><b><?php echo esc_html( $types[ $type_key ] ?? $bt['label'] ); ?></b></td>
			<td class="num"><?php echo esc_html( $fa( $bt['total'] ) ); ?></td>
			<td class="num"><?php echo esc_html( $fa( $bt['completed'] ) ); ?></td>
			<td class="num"><?php echo esc_html( $fa( $bt['in_progress'] ) ); ?></td>
			<td class="num"><?php echo esc_html( $fa( $bt['pending'] ) ); ?></td>
			<td class="num"><?php echo esc_html( $fa( $bt['overdue'] ) ); ?></td>
			<td>
				<?php if ( $bt['total'] > 0 ) : ?>
					<table width="100%"><tr>
						<td width="70%"><?php echo $bar( $bt['completion'], $accent ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
						<td width="30%" style="text-align:left; font-size:8.5pt;"><?php echo esc_html( $fa( $bt['completion'] . '%' ) ); ?></td>
					</tr></table>
				<?php else : ?>
					<span class="muted">—</span>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>

<!-- ===================== Open tasks ===================== -->
<h2><?php esc_html_e( '۵. تسک‌های انجام‌نشده', 'seo-project-manager' ); ?></h2>
<?php
$open_sections = array(
	array( __( 'تسک‌های عقب‌افتاده', 'seo-project-manager' ), $view['overdue'] ),
	array( __( 'تسک‌های باقی‌مانده (در انتظار و در حال انجام)', 'seo-project-manager' ), $view['remaining'] ),
);
if ( ! $view['overdue'] && ! $view['remaining'] ) :
	?>
	<div class="empty"><?php esc_html_e( 'همه تسک‌های این بازه تکمیل شده‌اند.', 'seo-project-manager' ); ?></div>
	<?php
else :
	foreach ( $open_sections as $sec ) :
		if ( ! $sec[1] ) {
			continue;
		}
		?>
		<h3><?php echo esc_html( $sec[0] . ' (' . $fa( count( $sec[1] ) ) . ')' ); ?></h3>
		<table class="data" repeat_header="1">
			<thead>
				<tr>
					<th class="num" width="6%"><?php esc_html_e( 'ردیف', 'seo-project-manager' ); ?></th>
					<th width="44%"><?php esc_html_e( 'عنوان', 'seo-project-manager' ); ?></th>
					<th width="20%"><?php esc_html_e( 'نوع فعالیت', 'seo-project-manager' ); ?></th>
					<th class="num" width="15%"><?php esc_html_e( 'تاریخ برنامه‌ریزی‌شده', 'seo-project-manager' ); ?></th>
					<th class="num" width="15%"><?php esc_html_e( 'وضعیت', 'seo-project-manager' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $sec[1] as $i => $task ) : ?>
				<tr<?php echo 1 === $i % 2 ? ' class="zebra"' : ''; ?>>
					<td class="num"><?php echo esc_html( $fa( $i + 1 ) ); ?></td>
					<td><?php echo esc_html( $task['title'] ); ?></td>
					<td><?php echo esc_html( $types[ $task['task_type'] ] ?? $task['task_type'] ); ?></td>
					<td class="num"><?php echo esc_html( $jd( $task['due_date'] ) ); ?></td>
					<td class="num"><?php echo $badge( $task ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	endforeach;
endif;
?>

<!-- ===================== Manager summary ===================== -->
<?php if ( '' !== trim( wp_strip_all_tags( $view['summary'] ) ) ) : ?>
	<h2><?php esc_html_e( '۶. جمع‌بندی مدیر پروژه', 'seo-project-manager' ); ?></h2>
	<div class="summary"><?php echo wp_kses_post( wpautop( $view['summary'] ) ); ?></div>
<?php endif; ?>

<?php if ( ! empty( $branding['footer_text'] ) ) : ?>
	<div style="margin-top: 22px; padding-top: 8px; border-top: 1px solid #e5e7eb; font-size: 9pt; color:#4b5563;">
		<?php echo nl2br( esc_html( $branding['footer_text'] ) ); ?>
	</div>
<?php endif; ?>

<?php if ( ! empty( $branding['preparer_name'] ) ) : ?>
	<div style="margin-top: 14px; font-size: 9.5pt; text-align:left;">
		<?php esc_html_e( 'تهیه‌کننده گزارش:', 'seo-project-manager' ); ?> <b><?php echo esc_html( $branding['preparer_name'] ); ?></b>
	</div>
<?php endif; ?>

</body>
</html>

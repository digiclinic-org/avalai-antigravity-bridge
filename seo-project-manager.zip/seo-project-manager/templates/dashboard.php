<?php
/**
 * Dashboard page (data loaded via REST).
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="seopm-page-head">
	<div>
		<h1><?php esc_html_e( 'داشبورد', 'seo-project-manager' ); ?></h1>
		<p class="seopm-sub"><?php esc_html_e( 'نمای کلی وضعیت پروژه‌ها و تسک‌ها', 'seo-project-manager' ); ?></p>
	</div>
	<div class="seopm-actions">
		<a class="seopm-btn seopm-btn-ghost" href="<?php echo esc_url( SEOPM\Admin\Admin_Pages::url( 'businesses', array( 'new' => 1 ) ) ); ?>"><span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'کسب‌وکار', 'seo-project-manager' ); ?></a>
		<button type="button" class="seopm-btn seopm-btn-ghost" data-action="new-task"><span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'تسک', 'seo-project-manager' ); ?></button>
		<a class="seopm-btn seopm-btn-ghost" href="<?php echo esc_url( SEOPM\Admin\Admin_Pages::url( 'calendar' ) ); ?>"><span class="dashicons dashicons-calendar-alt"></span><?php esc_html_e( 'تقویم', 'seo-project-manager' ); ?></a>
		<a class="seopm-btn seopm-btn-primary" href="<?php echo esc_url( SEOPM\Admin\Admin_Pages::url( 'reports', array( 'new' => 1 ) ) ); ?>"><span class="dashicons dashicons-media-document"></span><?php esc_html_e( 'ایجاد گزارش', 'seo-project-manager' ); ?></a>
	</div>
</div>
<div id="seopm-dashboard" class="seopm-dashboard" aria-live="polite">
	<div class="seopm-skeleton seopm-skeleton-cards"></div>
</div>

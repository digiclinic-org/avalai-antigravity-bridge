<?php
/**
 * Notes page template.
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="seopm-page-head">
	<div>
		<h1><?php esc_html_e( 'یادداشت‌های سئو و پروژه', 'seo-project-manager' ); ?></h1>
		<p class="seopm-sub"><?php esc_html_e( 'ثبت ایده‌ها، یادداشت‌های فنی، استراتژی محتوا و چک‌لیست‌های پروژه‌ها به تفکیک کسب‌وکار', 'seo-project-manager' ); ?></p>
	</div>
	<div class="seopm-actions">
		<button type="button" class="seopm-btn seopm-btn-primary" id="seopm-new-note-btn">
			<span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'یادداشت جدید', 'seo-project-manager' ); ?>
		</button>
	</div>
</div>

<div id="seopm-notes-app" class="seopm-notes-app" aria-live="polite"></div>

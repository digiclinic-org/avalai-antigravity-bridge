<?php
/**
 * Reports page: archive or single report view.
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;

$seopm_report_id = isset( $_GET['report'] ) ? absint( $_GET['report'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

if ( $seopm_report_id ) {
	$seopm_version = isset( $_GET['version'] ) ? absint( $_GET['version'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$report        = SEOPM\Report::get( $seopm_report_id, $seopm_version ? $seopm_version : null );
	if ( ! $report ) {
		echo '<div class="seopm-card seopm-empty-state"><p>' . esc_html__( 'گزارش یافت نشد.', 'seo-project-manager' ) . '</p><a class="seopm-btn seopm-btn-ghost" href="' . esc_url( SEOPM\Admin\Admin_Pages::url( 'reports' ) ) . '">' . esc_html__( 'بازگشت به آرشیو', 'seo-project-manager' ) . '</a></div>';
		return;
	}
	include __DIR__ . '/partials/report-view.php';
	return;
}
?>
<div class="seopm-page-head">
	<div>
		<h1><?php esc_html_e( 'گزارش‌ها', 'seo-project-manager' ); ?></h1>
		<p class="seopm-sub"><?php esc_html_e( 'تولید و آرشیو گزارش‌های مدیریتی برای کارفرمایان', 'seo-project-manager' ); ?></p>
	</div>
	<div class="seopm-actions">
		<button type="button" class="seopm-btn seopm-btn-primary" data-action="new-report"><span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'ایجاد گزارش جدید', 'seo-project-manager' ); ?></button>
	</div>
</div>
<div class="seopm-card">
	<div class="seopm-filters" id="seopm-report-filters"></div>
	<div id="seopm-report-list" aria-live="polite"></div>
	<div class="seopm-table-foot" id="seopm-report-foot"></div>
</div>

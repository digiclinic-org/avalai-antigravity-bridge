<?php
/**
 * Task calendar page.
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="seopm-cal-layout">
	<div class="seopm-card seopm-calendar-card">
		<div class="seopm-cal-toolbar">
			<div class="seopm-cal-nav">
				<button type="button" class="seopm-icon-btn" data-cal="prev" title="<?php esc_attr_e( 'قبلی', 'seo-project-manager' ); ?>" aria-label="<?php esc_attr_e( 'قبلی', 'seo-project-manager' ); ?>"><span class="dashicons dashicons-arrow-right-alt2"></span></button>
				<button type="button" class="seopm-icon-btn" data-cal="next" title="<?php esc_attr_e( 'بعدی', 'seo-project-manager' ); ?>" aria-label="<?php esc_attr_e( 'بعدی', 'seo-project-manager' ); ?>"><span class="dashicons dashicons-arrow-left-alt2"></span></button>
				<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm" data-cal="today"><?php esc_html_e( 'امروز', 'seo-project-manager' ); ?></button>
				<h2 class="seopm-cal-title" id="seopm-cal-title"></h2>
			</div>
			<div class="seopm-cal-tools">
				<div class="seopm-segmented" role="group" aria-label="<?php esc_attr_e( 'حالت نمایش', 'seo-project-manager' ); ?>">
					<button type="button" data-view="jalaliMonth" class="is-active"><?php esc_html_e( 'ماهانه', 'seo-project-manager' ); ?></button>
					<button type="button" data-view="dayGridWeek"><?php esc_html_e( 'هفتگی', 'seo-project-manager' ); ?></button>
					<button type="button" data-view="dayGridDay"><?php esc_html_e( 'روزانه', 'seo-project-manager' ); ?></button>
				</div>
				<div id="seopm-cal-filter" class="seopm-multiselect"></div>
				<button type="button" class="seopm-btn seopm-btn-primary" data-action="new-task"><span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'تسک جدید', 'seo-project-manager' ); ?></button>
			</div>
		</div>
		<div class="seopm-cal-legend" id="seopm-cal-legend">
			<span><i class="seopm-st seopm-st-pending"></i><?php esc_html_e( 'در انتظار', 'seo-project-manager' ); ?></span>
			<span><i class="seopm-st seopm-st-in_progress"></i><?php esc_html_e( 'در حال انجام', 'seo-project-manager' ); ?></span>
			<span><i class="seopm-st seopm-st-completed"></i><?php esc_html_e( 'تکمیل‌شده', 'seo-project-manager' ); ?></span>
			<span><i class="seopm-st seopm-st-overdue"></i><?php esc_html_e( 'عقب‌افتاده', 'seo-project-manager' ); ?></span>
			<span class="seopm-muted"><?php esc_html_e( 'برای ایجاد تسک جدید روی هر روز کلیک کنید یا دکمه + را بزنید؛ تسک‌ها را برای تغییر تاریخ بکشید.', 'seo-project-manager' ); ?></span>
		</div>
		<div id="seopm-calendar"></div>
	</div>

	<aside class="seopm-card seopm-cal-sidebar" aria-label="<?php esc_attr_e( 'راهنمای کسب‌وکارها و وضعیت‌ها', 'seo-project-manager' ); ?>">
		<div class="seopm-cal-sidebar-head">
			<h3><span class="dashicons dashicons-art" aria-hidden="true"></span><?php esc_html_e( 'راهنمای کسب‌وکارها', 'seo-project-manager' ); ?></h3>
			<button type="button" class="seopm-btn-link seopm-small" id="seopm-cal-legend-reset" hidden><?php esc_html_e( 'نمایش همه', 'seo-project-manager' ); ?></button>
		</div>
		<p class="seopm-muted seopm-small seopm-cal-sidebar-hint"><?php esc_html_e( 'رنگ تسک در تقویم بر اساس دایره رنگی کسب‌وکار است. برای فیلتر سریع روی کسب‌وکار کلیک کنید.', 'seo-project-manager' ); ?></p>
		<div class="seopm-cal-search-box" style="margin-bottom: 10px;">
			<input type="search" id="seopm-cal-biz-search" placeholder="<?php esc_attr_e( 'جستجوی کسب‌وکار...', 'seo-project-manager' ); ?>" class="seopm-input seopm-input-sm" style="width: 100%;" autocomplete="off">
		</div>
		<div class="seopm-cal-biz-legend" id="seopm-cal-biz-legend"></div>

		<div class="seopm-cal-sidebar-divider"></div>
		<div class="seopm-cal-status-guide">
			<h4 class="seopm-cal-subhead"><span class="dashicons dashicons-flag" aria-hidden="true"></span><?php esc_html_e( 'راهنمای وضعیت تسک‌ها', 'seo-project-manager' ); ?></h4>
			<ul class="seopm-cal-status-list">
				<li><i class="seopm-st seopm-st-pending"></i><span><?php esc_html_e( 'در انتظار', 'seo-project-manager' ); ?></span></li>
				<li><i class="seopm-st seopm-st-in_progress"></i><span><?php esc_html_e( 'در حال انجام', 'seo-project-manager' ); ?></span></li>
				<li><i class="seopm-st seopm-st-completed"></i><span><?php esc_html_e( 'تکمیل‌شده', 'seo-project-manager' ); ?></span></li>
				<li><i class="seopm-st seopm-st-overdue"></i><span><?php esc_html_e( 'عقب‌افتاده', 'seo-project-manager' ); ?></span></li>
			</ul>
		</div>
	</aside>
</div>

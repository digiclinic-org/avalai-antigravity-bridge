<?php
/**
 * Task management page.
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="seopm-page-head">
	<div>
		<h1><?php esc_html_e( 'مدیریت تسک‌ها', 'seo-project-manager' ); ?></h1>
		<p class="seopm-sub"><?php esc_html_e( 'فهرست، فیلتر و مدیریت سریع تسک‌های همه کسب‌وکارها', 'seo-project-manager' ); ?></p>
	</div>
	<div class="seopm-actions">
		<button type="button" class="seopm-btn seopm-btn-primary" data-action="new-task"><span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'تسک جدید', 'seo-project-manager' ); ?></button>
	</div>
</div>
<div class="seopm-card">
	<div class="seopm-filters" id="seopm-task-filters"></div>
	<div class="seopm-tabs" id="seopm-task-tabs" role="tablist"></div>
	<div id="seopm-task-list" aria-live="polite"></div>
	<div class="seopm-table-foot" id="seopm-task-foot"></div>
</div>

<?php
/**
 * Top navigation shared by all plugin pages.
 *
 * @package SEOPM
 * @var array  $nav  Menu items.
 * @var string $page Current page key.
 */

defined( 'ABSPATH' ) || exit;
?>
<header class="seopm-topbar">
	<div class="seopm-brand">
		<span class="seopm-brand-icon dashicons dashicons-chart-area" aria-hidden="true"></span>
		<span><?php esc_html_e( 'مدیریت پروژه‌های سئو', 'seo-project-manager' ); ?></span>
	</div>
	<nav class="seopm-nav" aria-label="<?php esc_attr_e( 'منوی افزونه', 'seo-project-manager' ); ?>">
		<?php foreach ( $nav as $slug => $item ) : ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . $slug ) ); ?>" class="<?php echo $item[1] === $page ? 'is-active' : ''; ?>"<?php echo $item[1] === $page ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $item[0] ); ?></a>
		<?php endforeach; ?>
	</nav>
</header>

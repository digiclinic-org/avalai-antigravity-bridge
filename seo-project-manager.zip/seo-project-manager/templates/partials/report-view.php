<?php
/**
 * Screen view of a report, rendered from its frozen snapshot.
 *
 * @package SEOPM
 * @var array $report Report from SEOPM\Report::get().
 */

use SEOPM\Admin\Admin_Pages;
use SEOPM\Jalali;
use SEOPM\Pdf_Generator;

defined( 'ABSPATH' ) || exit;

$view     = Pdf_Generator::view_model( $report['snapshot'], $report['summary'] );
$stats    = wp_parse_args( $view['stats'], array( 'total' => 0, 'completed' => 0, 'in_progress' => 0, 'pending' => 0, 'overdue' => 0, 'completion' => 0 ) );
$types    = $view['labels']['types'] ?? array();
$statuses = $view['labels']['statuses'] ?? array();
$period   = $view['snapshot']['period'] ?? array( 'start' => '', 'end' => '' );
$fa       = array( Jalali::class, 'fa_digits' );
$status_cell = static function ( $t ) use ( $statuses ) {
	$key   = ! empty( $t['overdue'] ) ? 'overdue' : $t['status'];
	$label = 'overdue' === $key ? __( 'عقب‌افتاده', 'seo-project-manager' ) : ( $statuses[ $t['status'] ] ?? $t['status'] );
	return '<span class="seopm-badge seopm-badge-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</span>';
};
$chart_data = array(
	'accent'  => $view['accent'],
	'status'  => array( $stats['completed'], $stats['in_progress'], $stats['pending'] ),
	'types'   => array(
		'labels' => array_values( array_map( static function ( $k, $bt ) use ( $types ) {
			return $types[ $k ] ?? $bt['label'];
		}, array_keys( $view['by_type'] ), $view['by_type'] ) ),
		'values' => array_values( wp_list_pluck( $view['by_type'], 'total' ) ),
	),
	'trend'   => $view['trend'],
);
?>
<div class="seopm-page-head">
	<div>
		<a class="seopm-back" href="<?php echo esc_url( Admin_Pages::url( 'reports' ) ); ?>"><span class="dashicons dashicons-arrow-right-alt"></span><?php esc_html_e( 'آرشیو گزارش‌ها', 'seo-project-manager' ); ?></a>
		<h1><?php echo esc_html( $view['snapshot']['title'] ?? $report['title'] ); ?></h1>
		<p class="seopm-sub">
			<span class="seopm-chip"><i style="background:<?php echo esc_attr( $view['business']['color'] ?? '#64748b' ); ?>"></i><?php echo esc_html( $view['business']['name'] ?? '' ); ?></span>
			<?php echo esc_html( Jalali::format( $period['start'] ) . ' – ' . Jalali::format( $period['end'] ) ); ?>
			· <?php echo esc_html( SEOPM\Report::types()[ $report['report_type'] ] ?? '' ); ?>
		</p>
	</div>
	<div class="seopm-actions" id="seopm-report-actions" data-report="<?php echo (int) $report['id']; ?>" data-version="<?php echo (int) $report['version_no']; ?>" data-current="<?php echo $report['is_current'] ? '1' : '0'; ?>">
		<label class="seopm-inline-label"><?php esc_html_e( 'نسخه', 'seo-project-manager' ); ?>
			<select id="seopm-version-select">
				<?php foreach ( $report['versions'] as $i => $ver ) : ?>
					<option value="<?php echo (int) $ver['version_no']; ?>" <?php selected( $ver['version_no'], $report['version_no'] ); ?>>
						<?php echo esc_html( __( 'نسخه', 'seo-project-manager' ) . ' ' . $fa( $ver['version_no'] ) . ' — ' . Jalali::format_utc( $ver['created_at'] ) . ( 0 === $i ? ' (' . __( 'جاری', 'seo-project-manager' ) . ')' : '' ) ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>
		<a class="seopm-btn seopm-btn-primary" href="<?php echo esc_url( Admin_Pages::download_url( $report['id'], $report['version_no'] ) ); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-download"></span><?php esc_html_e( 'دانلود PDF', 'seo-project-manager' ); ?></a>
		<?php if ( $report['is_current'] ) : ?>
			<button type="button" class="seopm-btn seopm-btn-ghost" data-action="edit-summary"><span class="dashicons dashicons-edit"></span><?php esc_html_e( 'ویرایش جمع‌بندی', 'seo-project-manager' ); ?></button>
			<button type="button" class="seopm-btn seopm-btn-ghost" data-action="regen-pdf"><span class="dashicons dashicons-update"></span><?php esc_html_e( 'تولید مجدد PDF', 'seo-project-manager' ); ?></button>
			<button type="button" class="seopm-btn seopm-btn-ghost" data-action="new-version"><span class="dashicons dashicons-backup"></span><?php esc_html_e( 'نسخه جدید با داده فعلی', 'seo-project-manager' ); ?></button>
		<?php endif; ?>
		<button type="button" class="seopm-btn seopm-btn-danger-ghost" data-action="delete-report"><span class="dashicons dashicons-trash"></span></button>
	</div>
</div>

<?php if ( ! $report['is_current'] ) : ?>
	<div class="seopm-notice"><?php esc_html_e( 'در حال مشاهده نسخه قدیمی این گزارش هستید. این نسخه فقط‌خواندنی است.', 'seo-project-manager' ); ?></div>
<?php endif; ?>
<?php if ( 'failed' === $report['status'] && $report['is_current'] ) : ?>
	<div class="seopm-notice seopm-notice-error"><?php esc_html_e( 'تولید PDF این گزارش ناموفق بود. «تولید مجدد PDF» را امتحان کنید.', 'seo-project-manager' ); ?></div>
<?php endif; ?>

<div class="seopm-report" style="--seopm-accent: <?php echo esc_attr( $view['accent'] ); ?>;">
	<section class="seopm-report-hero">
		<div>
			<div class="seopm-report-kicker"><?php esc_html_e( 'گزارش مدیریتی پروژه سئو', 'seo-project-manager' ); ?></div>
			<h2><?php echo esc_html( $view['business']['name'] ?? '' ); ?></h2>
			<?php if ( ! empty( $view['business']['website_url'] ) ) : ?>
				<a dir="ltr" href="<?php echo esc_url( $view['business']['website_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( preg_replace( '#^https?://#', '', $view['business']['website_url'] ) ); ?></a>
			<?php endif; ?>
		</div>
		<div class="seopm-report-meta">
			<div><?php esc_html_e( 'دوره:', 'seo-project-manager' ); ?> <b><?php echo esc_html( Jalali::format( $period['start'], 'long' ) . ' ' . __( 'تا', 'seo-project-manager' ) . ' ' . Jalali::format( $period['end'], 'long' ) ); ?></b></div>
			<div><?php esc_html_e( 'تاریخ تولید:', 'seo-project-manager' ); ?> <b><?php echo esc_html( Jalali::format_utc( $view['snapshot']['generated_at'] ?? '' ) ); ?></b></div>
			<?php if ( ! empty( $view['branding']['preparer_name'] ) ) : ?>
				<div><?php esc_html_e( 'تهیه‌کننده:', 'seo-project-manager' ); ?> <b><?php echo esc_html( $view['branding']['preparer_name'] ); ?></b></div>
			<?php endif; ?>
		</div>
	</section>

	<section class="seopm-stats seopm-stats-6">
		<?php
		$cards = array(
			array( __( 'کل تسک‌ها', 'seo-project-manager' ), $stats['total'], '' ),
			array( __( 'تکمیل‌شده', 'seo-project-manager' ), $stats['completed'], 'completed' ),
			array( __( 'در حال انجام', 'seo-project-manager' ), $stats['in_progress'], 'in_progress' ),
			array( __( 'در انتظار', 'seo-project-manager' ), $stats['pending'], 'pending' ),
			array( __( 'عقب‌افتاده', 'seo-project-manager' ), $stats['overdue'], 'overdue' ),
			array( __( 'درصد تکمیل', 'seo-project-manager' ), $stats['completion'] . '%', 'rate' ),
		);
		foreach ( $cards as $c ) :
			?>
			<div class="seopm-stat seopm-stat-<?php echo esc_attr( $c[2] ); ?>"><div class="seopm-stat-value"><?php echo esc_html( $fa( $c[1] ) ); ?></div><div class="seopm-stat-label"><?php echo esc_html( $c[0] ); ?></div></div>
		<?php endforeach; ?>
	</section>

	<section class="seopm-report-charts" id="seopm-report-charts" data-chart="<?php echo esc_attr( wp_json_encode( $chart_data ) ); ?>">
		<div class="seopm-card"><h3><?php esc_html_e( 'تکمیل‌شده در مقابل تکمیل‌نشده', 'seo-project-manager' ); ?></h3><div class="seopm-chart-box"><canvas id="seopm-chart-status"></canvas></div></div>
		<div class="seopm-card"><h3><?php esc_html_e( 'توزیع بر اساس نوع فعالیت', 'seo-project-manager' ); ?></h3><div class="seopm-chart-box"><canvas id="seopm-chart-types"></canvas></div></div>
		<div class="seopm-card seopm-span-2"><h3><?php esc_html_e( 'روند تکمیل تسک‌ها', 'seo-project-manager' ); ?></h3><div class="seopm-chart-box seopm-chart-wide"><canvas id="seopm-chart-trend"></canvas></div></div>
	</section>

	<section class="seopm-card">
		<h3><?php esc_html_e( 'گزارش عملکرد تسک‌ها', 'seo-project-manager' ); ?></h3>
		<?php if ( $view['tasks'] ) : ?>
			<div class="seopm-table-wrap">
			<table class="seopm-table">
				<thead><tr>
					<th><?php esc_html_e( 'ردیف', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'عنوان تسک', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'نوع فعالیت', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'تاریخ برنامه‌ریزی‌شده', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'تاریخ تکمیل', 'seo-project-manager' ); ?></th>
				</tr></thead>
				<tbody>
				<?php
				$n = 0;
				foreach ( $view['grouped'] as $type_key => $list ) :
					?>
					<tr class="seopm-group-row"><td colspan="6"><?php echo esc_html( ( $types[ $type_key ] ?? $type_key ) . ' (' . $fa( count( $list ) ) . ')' ); ?></td></tr>
					<?php
					foreach ( $list as $t ) :
						++$n;
						?>
						<tr>
							<td data-label="<?php esc_attr_e( 'ردیف', 'seo-project-manager' ); ?>"><?php echo esc_html( $fa( $n ) ); ?></td>
							<td data-label="<?php esc_attr_e( 'عنوان', 'seo-project-manager' ); ?>"><?php echo esc_html( $t['title'] ); ?></td>
							<td data-label="<?php esc_attr_e( 'نوع', 'seo-project-manager' ); ?>"><?php echo esc_html( $types[ $t['task_type'] ] ?? $t['task_type'] ); ?></td>
							<td data-label="<?php esc_attr_e( 'تاریخ', 'seo-project-manager' ); ?>"><?php echo esc_html( Jalali::format( $t['due_date'] ) ); ?></td>
							<td data-label="<?php esc_attr_e( 'وضعیت', 'seo-project-manager' ); ?>"><?php echo $status_cell( $t ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<td data-label="<?php esc_attr_e( 'تکمیل', 'seo-project-manager' ); ?>"><?php echo esc_html( $t['completed_on'] ? Jalali::format( $t['completed_on'] ) : '—' ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php else : ?>
			<div class="seopm-empty"><?php esc_html_e( 'داده‌ای برای نمایش وجود ندارد', 'seo-project-manager' ); ?></div>
		<?php endif; ?>
	</section>

	<section class="seopm-card">
		<h3><?php esc_html_e( 'گزارش تفکیکی فعالیت‌ها', 'seo-project-manager' ); ?></h3>
		<div class="seopm-table-wrap">
		<table class="seopm-table">
			<thead><tr>
				<th><?php esc_html_e( 'نوع فعالیت', 'seo-project-manager' ); ?></th>
				<th><?php esc_html_e( 'کل', 'seo-project-manager' ); ?></th>
				<th><?php esc_html_e( 'تکمیل‌شده', 'seo-project-manager' ); ?></th>
				<th><?php esc_html_e( 'در حال انجام', 'seo-project-manager' ); ?></th>
				<th><?php esc_html_e( 'در انتظار', 'seo-project-manager' ); ?></th>
				<th><?php esc_html_e( 'عقب‌افتاده', 'seo-project-manager' ); ?></th>
				<th><?php esc_html_e( 'درصد تکمیل', 'seo-project-manager' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $view['by_type'] as $type_key => $bt ) : ?>
				<tr>
					<td><b><?php echo esc_html( $types[ $type_key ] ?? $bt['label'] ); ?></b></td>
					<td><?php echo esc_html( $fa( $bt['total'] ) ); ?></td>
					<td><?php echo esc_html( $fa( $bt['completed'] ) ); ?></td>
					<td><?php echo esc_html( $fa( $bt['in_progress'] ) ); ?></td>
					<td><?php echo esc_html( $fa( $bt['pending'] ) ); ?></td>
					<td><?php echo esc_html( $fa( $bt['overdue'] ) ); ?></td>
					<td><div class="seopm-progress"><span style="width:<?php echo (int) $bt['completion']; ?>%"></span></div><small><?php echo esc_html( $fa( $bt['completion'] . '%' ) ); ?></small></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
	</section>

	<section class="seopm-card">
		<h3><?php esc_html_e( 'تسک‌های انجام‌نشده', 'seo-project-manager' ); ?></h3>
		<?php $open = array_merge( $view['overdue'], $view['remaining'] ); ?>
		<?php if ( $open ) : ?>
			<div class="seopm-table-wrap">
			<table class="seopm-table">
				<thead><tr>
					<th><?php esc_html_e( 'عنوان', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'نوع فعالیت', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'تاریخ برنامه‌ریزی‌شده', 'seo-project-manager' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'seo-project-manager' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $open as $t ) : ?>
					<tr>
						<td><?php echo esc_html( $t['title'] ); ?></td>
						<td><?php echo esc_html( $types[ $t['task_type'] ] ?? $t['task_type'] ); ?></td>
						<td><?php echo esc_html( Jalali::format( $t['due_date'] ) ); ?></td>
						<td><?php echo $status_cell( $t ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php else : ?>
			<div class="seopm-empty"><?php esc_html_e( 'همه تسک‌های این بازه تکمیل شده‌اند.', 'seo-project-manager' ); ?></div>
		<?php endif; ?>
	</section>

	<section class="seopm-card">
		<h3><?php esc_html_e( 'جمع‌بندی مدیر پروژه', 'seo-project-manager' ); ?></h3>
		<div class="seopm-summary" id="seopm-summary-content">
			<?php if ( '' !== trim( wp_strip_all_tags( $view['summary'] ) ) ) : ?>
				<?php echo wp_kses_post( wpautop( $view['summary'] ) ); ?>
			<?php else : ?>
				<p class="seopm-muted"><?php esc_html_e( 'هنوز جمع‌بندی‌ای ثبت نشده است. این بخش فقط در صورت ثبت متن در PDF نمایش داده می‌شود.', 'seo-project-manager' ); ?></p>
			<?php endif; ?>
		</div>
		<textarea id="seopm-summary-raw" hidden><?php echo esc_textarea( $view['summary'] ); ?></textarea>
	</section>
</div>

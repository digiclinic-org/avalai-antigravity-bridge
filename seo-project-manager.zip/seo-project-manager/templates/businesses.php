<?php
/**
 * Businesses page.
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="seopm-page-head">
	<div>
		<h1><?php esc_html_e( 'کسب‌وکارها', 'seo-project-manager' ); ?></h1>
		<p class="seopm-sub"><?php esc_html_e( 'کارفرماها و پروژه‌های سئو به همراه کلمات کلیدی هدف', 'seo-project-manager' ); ?></p>
	</div>
	<div class="seopm-actions">
		<label class="seopm-search">
			<span class="dashicons dashicons-search" aria-hidden="true"></span>
			<input type="search" id="seopm-business-search" placeholder="<?php esc_attr_e( 'جست‌وجوی کسب‌وکار...', 'seo-project-manager' ); ?>">
		</label>
		<button type="button" class="seopm-btn seopm-btn-primary" data-action="new-business"><span class="dashicons dashicons-plus-alt2"></span><?php esc_html_e( 'کسب‌وکار جدید', 'seo-project-manager' ); ?></button>
	</div>
</div>
<div id="seopm-businesses" class="seopm-grid" aria-live="polite">
	<div class="seopm-skeleton seopm-skeleton-cards"></div>
</div>

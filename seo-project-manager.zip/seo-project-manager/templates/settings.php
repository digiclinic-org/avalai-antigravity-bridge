<?php
/**
 * Settings page (AI API Providers, Branding & Reports, System).
 *
 * @package SEOPM
 */

use SEOPM\Settings;
use SEOPM\AI_Client;

defined( 'ABSPATH' ) || exit;

$s         = Settings::all();
$logo_url  = $s['logo_id'] ? wp_get_attachment_image_url( $s['logo_id'], 'medium' ) : '';
$providers = AI_Client::get_providers();
$active_ai = $s['ai_active_provider'] ?? 'none';
?>
<div class="seopm-page-head">
	<div>
		<h1><?php esc_html_e( 'تنظیمات', 'seo-project-manager' ); ?></h1>
		<p class="seopm-sub"><?php esc_html_e( 'اتصال به API هوش مصنوعی، برندینگ آژانس و ظاهر گزارش‌های سئو', 'seo-project-manager' ); ?></p>
	</div>
</div>

<?php if ( isset( $_GET['updated'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<div class="seopm-notice seopm-notice-success"><?php esc_html_e( 'تنظیمات با موفقیت ذخیره شد.', 'seo-project-manager' ); ?></div>
<?php endif; ?>

<!-- Settings Sub-tabs -->
<div class="seopm-tabs seopm-settings-tabs" id="seopm-settings-tabs" style="margin-bottom: 20px;">
	<button type="button" class="is-active" data-tab="ai">
		<span class="dashicons dashicons-admin-site-alt3"></span>
		<?php esc_html_e( 'اتصال به هوش مصنوعی (AI APIs)', 'seo-project-manager' ); ?>
		<?php if ( 'none' !== $active_ai && ! empty( $s[ $active_ai . '_api_key' ] ) ) : ?>
			<span class="seopm-badge" style="background:#ecfdf5; color:#047857; font-size:11px; margin-right:4px;">متصل</span>
		<?php endif; ?>
	</button>
	<button type="button" data-tab="branding">
		<span class="dashicons dashicons-art"></span>
		<?php esc_html_e( 'برندینگ و ظاهر گزارش', 'seo-project-manager' ); ?>
	</button>
	<button type="button" data-tab="telegram">
		<span class="dashicons dashicons-share"></span>
		<?php esc_html_e( 'تلگرام و پیش‌نمایش کارفرما', 'seo-project-manager' ); ?>
		<?php if ( ! empty( $s['telegram_bot_token'] ) ) : ?>
			<span class="seopm-badge" style="background:#ecfdf5; color:#047857; font-size:11px; margin-right:4px;">فعال</span>
		<?php endif; ?>
	</button>
	<button type="button" data-tab="task-types">
		<span class="dashicons dashicons-category"></span>
		<?php esc_html_e( 'انواع تسک (Task Types)', 'seo-project-manager' ); ?>
	</button>
	<?php if ( current_user_can( 'manage_options' ) ) : ?>
		<button type="button" data-tab="system">
			<span class="dashicons dashicons-admin-settings"></span>
			<?php esc_html_e( 'تنظیمات سیستم', 'seo-project-manager' ); ?>
		</button>
	<?php endif; ?>
</div>

<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="seopm-settings" id="seopm-settings-form">
	<input type="hidden" name="action" value="seopm_save_settings">
	<?php wp_nonce_field( 'seopm_save_settings' ); ?>

	<!-- ============================================================== -->
	<!-- TAB 1: AI PROVIDERS                                            -->
	<!-- ============================================================== -->
	<div class="seopm-tab-pane" id="seopm-pane-ai">

		<!-- 1. Active Provider Switcher -->
		<section class="seopm-card">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:10px;">
				<div>
					<h2 style="margin:0 0 4px;"><?php esc_html_e( 'انتخاب مدل هوش مصنوعی فعال', 'seo-project-manager' ); ?></h2>
					<p class="seopm-muted seopm-small" style="margin:0;"><?php esc_html_e( 'روی یکی از کارت‌های زیر یا تیک «انتخاب به‌عنوان ارائه‌دهنده فعال» در هر باکس کلیک کنید و سپس «ذخیره تنظیمات» را بزنید.', 'seo-project-manager' ); ?></p>
				</div>
				<div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
					<span class="seopm-badge" id="seopm-active-provider-badge" style="background:var(--seopm-surface-2); border:1px solid var(--seopm-border); font-size:12px; padding:5px 10px;">
						<?php
						$curr_name = 'none' === $active_ai ? __( 'موتور داخلی سئو (بدون نیاز به API)', 'seo-project-manager' ) : ( $providers[ $active_ai ]['name'] ?? $active_ai );
						echo esc_html( 'ارائه‌دهنده فعال فعلی: ' . $curr_name );
						?>
					</span>
					<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-sm">
						<span class="dashicons dashicons-saved"></span>
						<?php esc_html_e( 'ذخیره تنظیمات', 'seo-project-manager' ); ?>
					</button>
				</div>
			</div>

			<div class="seopm-ai-provider-grid">
				<!-- Heuristic Option -->
				<label class="seopm-ai-select-card <?php echo 'none' === $active_ai ? 'is-selected' : ''; ?>" data-provider-label="<?php esc_attr_e( 'موتور داخلی سئو (بدون نیاز به API)', 'seo-project-manager' ); ?>">
					<input type="radio" name="seopm[ai_active_provider]" value="none" <?php checked( $active_ai, 'none' ); ?>>
					<span class="seopm-ai-check" aria-hidden="true"><span class="dashicons dashicons-yes"></span></span>
					<div class="seopm-ai-card-content">
						<div class="seopm-ai-card-head">
							<span class="dashicons dashicons-admin-generic" style="color:var(--seopm-primary); font-size:20px;"></span>
							<strong><?php esc_html_e( 'موتور داخلی سئو', 'seo-project-manager' ); ?></strong>
						</div>
						<p class="seopm-muted seopm-small"><?php esc_html_e( 'تحلیل ساختاری سئو، سایت‌مپ و پیلارها بدون نیاز به کلید API خارجی (رایگان و محلی)', 'seo-project-manager' ); ?></p>
						<span class="seopm-badge seopm-badge-ghost"><?php esc_html_e( 'پیش‌فرض بدون API', 'seo-project-manager' ); ?></span>
					</div>
				</label>

				<!-- AvalAI (No Sanctions / Iran-friendly) -->
				<?php
				$has_avalai = ! empty( $s['avalai_api_key'] );
				?>
				<label class="seopm-ai-select-card <?php echo 'avalai' === $active_ai ? 'is-selected' : ''; ?>" data-provider-label="<?php echo esc_attr( $providers['avalai']['name'] ); ?>">
					<input type="radio" name="seopm[ai_active_provider]" value="avalai" <?php checked( $active_ai, 'avalai' ); ?>>
					<span class="seopm-ai-check" aria-hidden="true"><span class="dashicons dashicons-yes"></span></span>
					<div class="seopm-ai-card-content">
						<div class="seopm-ai-card-head">
							<span style="font-size:18px;">⚡</span>
							<strong><?php esc_html_e( 'اول‌ای‌آی (AvalAI)', 'seo-project-manager' ); ?></strong>
						</div>
						<p class="seopm-muted seopm-small"><?php esc_html_e( 'بدون نیاز به فیلترشکن و بدون تحریم روی هاست ایران؛ دسترسی هم‌زمان به Gemini 2.5، GPT-4o، Claude و DeepSeek', 'seo-project-manager' ); ?></p>
						<div style="display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
							<span class="seopm-badge" style="background:#f5f3ff; color:#6d28d9; border:1px solid #ddd6fe;">پیشنهادی برای ایران</span>
							<span class="seopm-badge" style="<?php echo $has_avalai ? 'background:#ecfdf5; color:#047857;' : 'background:#fef3c7; color:#b45309;'; ?>">
								<?php echo $has_avalai ? esc_html__( '✔ کلید ثبت شده', 'seo-project-manager' ) : esc_html__( '⚠ نیازمند کلید API', 'seo-project-manager' ); ?>
							</span>
						</div>
					</div>
				</label>

				<!-- Gemini -->
				<?php
				$has_gemini = ! empty( $s['gemini_api_key'] );
				?>
				<label class="seopm-ai-select-card <?php echo 'gemini' === $active_ai ? 'is-selected' : ''; ?>" data-provider-label="<?php echo esc_attr( $providers['gemini']['name'] ); ?>">
					<input type="radio" name="seopm[ai_active_provider]" value="gemini" <?php checked( $active_ai, 'gemini' ); ?>>
					<span class="seopm-ai-check" aria-hidden="true"><span class="dashicons dashicons-yes"></span></span>
					<div class="seopm-ai-card-content">
						<div class="seopm-ai-card-head">
							<span style="font-size:18px;">💎</span>
							<strong><?php esc_html_e( 'گوگل جمنای (Gemini)', 'seo-project-manager' ); ?></strong>
						</div>
						<p class="seopm-muted seopm-small"><?php esc_html_e( 'Gemini 2.5 Flash / Pro با سرعت بالا، درک عمیق زبان فارسی و تحلیل عالی', 'seo-project-manager' ); ?></p>
						<span class="seopm-badge" style="<?php echo $has_gemini ? 'background:#ecfdf5; color:#047857;' : 'background:#fef3c7; color:#b45309;'; ?>">
							<?php echo $has_gemini ? esc_html__( '✔ کلید ثبت شده', 'seo-project-manager' ) : esc_html__( '⚠ نیازمند کلید API', 'seo-project-manager' ); ?>
						</span>
					</div>
				</label>

				<!-- OpenAI / ChatGPT -->
				<?php
				$has_openai = ! empty( $s['openai_api_key'] );
				?>
				<label class="seopm-ai-select-card <?php echo 'openai' === $active_ai ? 'is-selected' : ''; ?>" data-provider-label="<?php echo esc_attr( $providers['openai']['name'] ); ?>">
					<input type="radio" name="seopm[ai_active_provider]" value="openai" <?php checked( $active_ai, 'openai' ); ?>>
					<span class="seopm-ai-check" aria-hidden="true"><span class="dashicons dashicons-yes"></span></span>
					<div class="seopm-ai-card-content">
						<div class="seopm-ai-card-head">
							<span style="font-size:18px;">🤖</span>
							<strong><?php esc_html_e( 'چت جی‌پی‌تی (ChatGPT)', 'seo-project-manager' ); ?></strong>
						</div>
						<p class="seopm-muted seopm-small"><?php esc_html_e( 'OpenAI GPT-4o و GPT-4o Mini با استاندارد بالای درک دستورات سئو و نگارش روان', 'seo-project-manager' ); ?></p>
						<span class="seopm-badge" style="<?php echo $has_openai ? 'background:#ecfdf5; color:#047857;' : 'background:#fef3c7; color:#b45309;'; ?>">
							<?php echo $has_openai ? esc_html__( '✔ کلید ثبت شده', 'seo-project-manager' ) : esc_html__( '⚠ نیازمند کلید API', 'seo-project-manager' ); ?>
						</span>
					</div>
				</label>

				<!-- DeepSeek -->
				<?php
				$has_deepseek = ! empty( $s['deepseek_api_key'] );
				?>
				<label class="seopm-ai-select-card <?php echo 'deepseek' === $active_ai ? 'is-selected' : ''; ?>" data-provider-label="<?php echo esc_attr( $providers['deepseek']['name'] ); ?>">
					<input type="radio" name="seopm[ai_active_provider]" value="deepseek" <?php checked( $active_ai, 'deepseek' ); ?>>
					<span class="seopm-ai-check" aria-hidden="true"><span class="dashicons dashicons-yes"></span></span>
					<div class="seopm-ai-card-content">
						<div class="seopm-ai-card-head">
							<span style="font-size:18px;">🐋</span>
							<strong><?php esc_html_e( 'دیپ‌سیک (DeepSeek)', 'seo-project-manager' ); ?></strong>
						</div>
						<p class="seopm-muted seopm-small"><?php esc_html_e( 'DeepSeek-V3 و DeepSeek-R1 با قدرت استدلال، فوق‌العاده مقرون‌به‌صرفه و اقتصادی', 'seo-project-manager' ); ?></p>
						<span class="seopm-badge" style="<?php echo $has_deepseek ? 'background:#ecfdf5; color:#047857;' : 'background:#fef3c7; color:#b45309;'; ?>">
							<?php echo $has_deepseek ? esc_html__( '✔ کلید ثبت شده', 'seo-project-manager' ) : esc_html__( '⚠ نیازمند کلید API', 'seo-project-manager' ); ?>
						</span>
					</div>
				</label>

				<!-- Claude -->
				<?php
				$has_claude = ! empty( $s['claude_api_key'] );
				?>
				<label class="seopm-ai-select-card <?php echo 'claude' === $active_ai ? 'is-selected' : ''; ?>" data-provider-label="<?php echo esc_attr( $providers['claude']['name'] ); ?>">
					<input type="radio" name="seopm[ai_active_provider]" value="claude" <?php checked( $active_ai, 'claude' ); ?>>
					<span class="seopm-ai-check" aria-hidden="true"><span class="dashicons dashicons-yes"></span></span>
					<div class="seopm-ai-card-content">
						<div class="seopm-ai-card-head">
							<span style="font-size:18px;">🧠</span>
							<strong><?php esc_html_e( 'آنت‌روپیک کلود (Claude)', 'seo-project-manager' ); ?></strong>
						</div>
						<p class="seopm-muted seopm-small"><?php esc_html_e( 'Claude 3.5 Sonnet و Haiku با تفکر عمیق محتوایی و جلوگیری دقیق از کلمات تکراری', 'seo-project-manager' ); ?></p>
						<span class="seopm-badge" style="<?php echo $has_claude ? 'background:#ecfdf5; color:#047857;' : 'background:#fef3c7; color:#b45309;'; ?>">
							<?php echo $has_claude ? esc_html__( '✔ کلید ثبت شده', 'seo-project-manager' ) : esc_html__( '⚠ نیازمند کلید API', 'seo-project-manager' ); ?>
						</span>
					</div>
				</label>
			</div>
		</section>

		<!-- 1.5. AvalAI Card (Recommended for Iran) -->
		<section class="seopm-card seopm-provider-config-card <?php echo 'avalai' === $active_ai ? 'is-active-provider' : ''; ?>" data-provider-card="avalai" style="border-top: 4px solid #7c3aed;">
			<div class="seopm-provider-card-header">
				<div style="display:flex; align-items:center; gap:10px;">
					<span class="seopm-provider-icon" style="background:#f5f3ff; color:#7c3aed;">⚡</span>
					<div>
						<h3 style="margin:0; font-size:16px;"><?php esc_html_e( 'تنظیمات اول‌ای‌آی (AvalAI — بدون تحریم و فیلترینگ)', 'seo-project-manager' ); ?></h3>
						<span class="seopm-muted seopm-small"><?php esc_html_e( 'اتصال پایدار روی هاست‌های ایران به مدل‌های Gemini 2.5، ChatGPT، Claude و DeepSeek تنها با یک کلید API', 'seo-project-manager' ); ?></span>
					</div>
				</div>
				<div class="seopm-provider-head-actions">
					<button type="button" class="seopm-activate-provider-btn <?php echo 'avalai' === $active_ai ? 'is-active' : ''; ?>" data-activate-provider="avalai">
						<span class="seopm-activate-box"><span class="dashicons dashicons-yes"></span></span>
						<span class="seopm-activate-text"><?php echo 'avalai' === $active_ai ? esc_html__( 'ارائه‌دهنده فعال', 'seo-project-manager' ) : esc_html__( 'انتخاب به‌عنوان ارائه‌دهنده فعال', 'seo-project-manager' ); ?></span>
					</button>
					<a href="https://chat.avalai.ir/platform/api-keys" target="_blank" rel="noopener noreferrer" class="seopm-btn seopm-btn-ghost seopm-btn-sm" style="font-size:12px;">
						<span class="dashicons dashicons-external"></span> <?php esc_html_e( 'دریافت کلید API', 'seo-project-manager' ); ?>
					</a>
				</div>
			</div>

			<div class="seopm-form-grid" style="margin-top:14px;">
				<div class="seopm-field seopm-span-2">
					<span><?php esc_html_e( 'کلید API اول‌ای‌آی (AvalAI API Key)', 'seo-project-manager' ); ?></span>
					<div class="seopm-key-input-wrap">
						<input type="password" name="seopm[avalai_api_key]" id="seopm-avalai-key" value="<?php echo esc_attr( Settings::mask_key( $s['avalai_api_key'] ) ); ?>" placeholder="aa-..." dir="ltr" class="seopm-key-input" autocomplete="new-password">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm seopm-toggle-key-visibility" data-target="seopm-avalai-key" title="<?php esc_attr_e( 'نمایش/مخفی‌سازی کلید', 'seo-project-manager' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'کلید API ساخته‌شده در پنل AvalAI (معمولاً با aa- شروع می‌شود) را اینجا وارد کنید.', 'seo-project-manager' ); ?></small>
				</div>

				<label class="seopm-field">
					<span><?php esc_html_e( 'انتخاب مدل از طریق AvalAI', 'seo-project-manager' ); ?></span>
					<select name="seopm[avalai_model]" id="seopm-avalai-model">
						<?php foreach ( $providers['avalai']['models'] as $m_key => $m_label ) : ?>
							<option value="<?php echo esc_attr( $m_key ); ?>" <?php selected( $s['avalai_model'], $m_key ); ?>><?php echo esc_html( $m_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label class="seopm-field">
					<span><?php esc_html_e( 'نام مدل دلخواه (اختیاری)', 'seo-project-manager' ); ?></span>
					<input type="text" name="seopm[avalai_custom_model]" id="seopm-avalai-custom-model" value="<?php echo esc_attr( $s['avalai_custom_model'] ?? '' ); ?>" placeholder="مثلاً: gemini-2.5-pro یا gpt-4.1-mini" dir="ltr">
					<small class="seopm-muted"><?php esc_html_e( 'اگر می‌خواهید مدل دیگری از لیست AvalAI استفاده کنید نام دقیق آن را وارد کنید؛ در غیر این صورت خالی بگذارید.', 'seo-project-manager' ); ?></small>
				</label>

				<label class="seopm-field seopm-span-2">
					<span><?php esc_html_e( 'آدرس سرور پایه (Base URL - اختیاری)', 'seo-project-manager' ); ?></span>
					<input type="url" name="seopm[avalai_base_url]" id="seopm-avalai-url" value="<?php echo esc_attr( $s['avalai_base_url'] ); ?>" placeholder="https://api.avalai.ir/v1" dir="ltr">
					<small class="seopm-muted"><?php esc_html_e( 'در صورت خالی بودن به‌صورت خودکار به آدرس رسمی https://api.avalai.ir/v1 متصل می‌شود.', 'seo-project-manager' ); ?></small>
				</label>
			</div>

			<div class="seopm-test-bar">
				<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-sm">
					<span class="dashicons dashicons-saved"></span>
					<?php esc_html_e( 'ذخیره تنظیمات', 'seo-project-manager' ); ?>
				</button>
				<button type="button" class="seopm-btn seopm-btn-secondary seopm-btn-sm seopm-test-ai-btn" data-provider="avalai">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'تست اتصال به اول‌ای‌آی (AvalAI)', 'seo-project-manager' ); ?>
				</button>
				<div class="seopm-test-result" id="seopm-test-result-avalai"></div>
			</div>
		</section>

		<!-- 2. Google Gemini Card -->
		<section class="seopm-card seopm-provider-config-card <?php echo 'gemini' === $active_ai ? 'is-active-provider' : ''; ?>" data-provider-card="gemini" style="border-top: 4px solid #1a73e8;">
			<div class="seopm-provider-card-header">
				<div style="display:flex; align-items:center; gap:10px;">
					<span class="seopm-provider-icon" style="background:#e8f0fe; color:#1a73e8;">💎</span>
					<div>
						<h3 style="margin:0; font-size:16px;"><?php esc_html_e( 'تنظیمات گوگل جمنای (Google Gemini)', 'seo-project-manager' ); ?></h3>
						<span class="seopm-muted seopm-small"><?php esc_html_e( 'اتصال مستقیم به Gemini API شرکت گوگل با پشتیبانی از مدل‌های سریع و رایگان Gemini Flash', 'seo-project-manager' ); ?></span>
					</div>
				</div>
				<div class="seopm-provider-head-actions">
					<button type="button" class="seopm-activate-provider-btn <?php echo 'gemini' === $active_ai ? 'is-active' : ''; ?>" data-activate-provider="gemini">
						<span class="seopm-activate-box"><span class="dashicons dashicons-yes"></span></span>
						<span class="seopm-activate-text"><?php echo 'gemini' === $active_ai ? esc_html__( 'ارائه‌دهنده فعال', 'seo-project-manager' ) : esc_html__( 'انتخاب به‌عنوان ارائه‌دهنده فعال', 'seo-project-manager' ); ?></span>
					</button>
					<a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" class="seopm-btn seopm-btn-ghost seopm-btn-sm" style="font-size:12px;">
						<span class="dashicons dashicons-external"></span> <?php esc_html_e( 'دریافت کلید API', 'seo-project-manager' ); ?>
					</a>
				</div>
			</div>

			<div class="seopm-form-grid" style="margin-top:14px;">
				<div class="seopm-field seopm-span-2">
					<span><?php esc_html_e( 'کلید API جمنای (Gemini API Key)', 'seo-project-manager' ); ?></span>
					<div class="seopm-key-input-wrap">
						<input type="password" name="seopm[gemini_api_key]" id="seopm-gemini-key" value="<?php echo esc_attr( Settings::mask_key( $s['gemini_api_key'] ) ); ?>" placeholder="AIzaSy..." dir="ltr" class="seopm-key-input" autocomplete="new-password">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm seopm-toggle-key-visibility" data-target="seopm-gemini-key" title="<?php esc_attr_e( 'نمایش/مخفی‌سازی کلید', 'seo-project-manager' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'کلید API شخصی خود را وارد نمایید. این کلید به‌صورت ایمن در پایگاه‌داده نگهداری می‌شود.', 'seo-project-manager' ); ?></small>
				</div>

				<label class="seopm-field">
					<span><?php esc_html_e( 'انتخاب مدل Gemini', 'seo-project-manager' ); ?></span>
					<select name="seopm[gemini_model]" id="seopm-gemini-model">
						<?php foreach ( $providers['gemini']['models'] as $m_key => $m_label ) : ?>
							<option value="<?php echo esc_attr( $m_key ); ?>" <?php selected( $s['gemini_model'], $m_key ); ?>><?php echo esc_html( $m_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label class="seopm-field">
					<span><?php esc_html_e( 'آدرس سرور پایه (Base URL - اختیاری)', 'seo-project-manager' ); ?></span>
					<input type="url" name="seopm[gemini_base_url]" id="seopm-gemini-url" value="<?php echo esc_attr( $s['gemini_base_url'] ); ?>" placeholder="https://generativelanguage.googleapis.com/v1beta" dir="ltr">
					<small class="seopm-muted"><?php esc_html_e( 'در صورت استفاده از پروکسی یا سرور واسط ایرانی پر کنید، در غیر این صورت خالی بگذارید.', 'seo-project-manager' ); ?></small>
				</label>
			</div>

			<div class="seopm-test-bar">
				<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-sm">
					<span class="dashicons dashicons-saved"></span>
					<?php esc_html_e( 'ذخیره تنظیمات', 'seo-project-manager' ); ?>
				</button>
				<button type="button" class="seopm-btn seopm-btn-secondary seopm-btn-sm seopm-test-ai-btn" data-provider="gemini">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'تست اتصال به جمنای', 'seo-project-manager' ); ?>
				</button>
				<div class="seopm-test-result" id="seopm-test-result-gemini"></div>
			</div>
		</section>

		<!-- 3. OpenAI / ChatGPT Card -->
		<section class="seopm-card seopm-provider-config-card <?php echo 'openai' === $active_ai ? 'is-active-provider' : ''; ?>" data-provider-card="openai" style="border-top: 4px solid #10a37f;">
			<div class="seopm-provider-card-header">
				<div style="display:flex; align-items:center; gap:10px;">
					<span class="seopm-provider-icon" style="background:#e6f7f2; color:#10a37f;">🤖</span>
					<div>
						<h3 style="margin:0; font-size:16px;"><?php esc_html_e( 'تنظیمات چت جی‌پی‌تی (OpenAI / ChatGPT)', 'seo-project-manager' ); ?></h3>
						<span class="seopm-muted seopm-small"><?php esc_html_e( 'اتصال به API شرکت OpenAI با مدل‌های GPT-4o و GPT-4o Mini', 'seo-project-manager' ); ?></span>
					</div>
				</div>
				<div class="seopm-provider-head-actions">
					<button type="button" class="seopm-activate-provider-btn <?php echo 'openai' === $active_ai ? 'is-active' : ''; ?>" data-activate-provider="openai">
						<span class="seopm-activate-box"><span class="dashicons dashicons-yes"></span></span>
						<span class="seopm-activate-text"><?php echo 'openai' === $active_ai ? esc_html__( 'ارائه‌دهنده فعال', 'seo-project-manager' ) : esc_html__( 'انتخاب به‌عنوان ارائه‌دهنده فعال', 'seo-project-manager' ); ?></span>
					</button>
					<a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" class="seopm-btn seopm-btn-ghost seopm-btn-sm" style="font-size:12px;">
						<span class="dashicons dashicons-external"></span> <?php esc_html_e( 'دریافت کلید API', 'seo-project-manager' ); ?>
					</a>
				</div>
			</div>

			<div class="seopm-form-grid" style="margin-top:14px;">
				<div class="seopm-field seopm-span-2">
					<span><?php esc_html_e( 'کلید API اوپن‌ای‌آی (OpenAI API Key)', 'seo-project-manager' ); ?></span>
					<div class="seopm-key-input-wrap">
						<input type="password" name="seopm[openai_api_key]" id="seopm-openai-key" value="<?php echo esc_attr( Settings::mask_key( $s['openai_api_key'] ) ); ?>" placeholder="sk-proj-..." dir="ltr" class="seopm-key-input" autocomplete="new-password">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm seopm-toggle-key-visibility" data-target="seopm-openai-key" title="<?php esc_attr_e( 'نمایش/مخفی‌سازی کلید', 'seo-project-manager' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'کلید پلتفرم OpenAI که با sk- شروع می‌شود.', 'seo-project-manager' ); ?></small>
				</div>

				<label class="seopm-field">
					<span><?php esc_html_e( 'انتخاب مدل ChatGPT', 'seo-project-manager' ); ?></span>
					<select name="seopm[openai_model]" id="seopm-openai-model">
						<?php foreach ( $providers['openai']['models'] as $m_key => $m_label ) : ?>
							<option value="<?php echo esc_attr( $m_key ); ?>" <?php selected( $s['openai_model'], $m_key ); ?>><?php echo esc_html( $m_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label class="seopm-field">
					<span><?php esc_html_e( 'آدرس سرور پایه (Base URL - اختیاری)', 'seo-project-manager' ); ?></span>
					<input type="url" name="seopm[openai_base_url]" id="seopm-openai-url" value="<?php echo esc_attr( $s['openai_base_url'] ); ?>" placeholder="https://api.openai.com/v1" dir="ltr">
					<small class="seopm-muted"><?php esc_html_e( 'سازگار با اندپوینت‌های واسط و پروکسی‌ها (مانند AvalAI یا ریورس پروکسی اختصاصی).', 'seo-project-manager' ); ?></small>
				</label>
			</div>

			<div class="seopm-test-bar">
				<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-sm">
					<span class="dashicons dashicons-saved"></span>
					<?php esc_html_e( 'ذخیره تنظیمات', 'seo-project-manager' ); ?>
				</button>
				<button type="button" class="seopm-btn seopm-btn-secondary seopm-btn-sm seopm-test-ai-btn" data-provider="openai">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'تست اتصال به OpenAI / ChatGPT', 'seo-project-manager' ); ?>
				</button>
				<div class="seopm-test-result" id="seopm-test-result-openai"></div>
			</div>
		</section>

		<!-- 4. DeepSeek Card -->
		<section class="seopm-card seopm-provider-config-card <?php echo 'deepseek' === $active_ai ? 'is-active-provider' : ''; ?>" data-provider-card="deepseek" style="border-top: 4px solid #0891b2;">
			<div class="seopm-provider-card-header">
				<div style="display:flex; align-items:center; gap:10px;">
					<span class="seopm-provider-icon" style="background:#ecfeff; color:#0891b2;">🐋</span>
					<div>
						<h3 style="margin:0; font-size:16px;"><?php esc_html_e( 'تنظیمات دیپ‌سیک (DeepSeek)', 'seo-project-manager' ); ?></h3>
						<span class="seopm-muted seopm-small"><?php esc_html_e( 'اتصال به پلتفرم دیپ‌سیک با کیفیت استثنایی در استدلال زبان فارسی و هزینه بسیار اقتصادی', 'seo-project-manager' ); ?></span>
					</div>
				</div>
				<div class="seopm-provider-head-actions">
					<button type="button" class="seopm-activate-provider-btn <?php echo 'deepseek' === $active_ai ? 'is-active' : ''; ?>" data-activate-provider="deepseek">
						<span class="seopm-activate-box"><span class="dashicons dashicons-yes"></span></span>
						<span class="seopm-activate-text"><?php echo 'deepseek' === $active_ai ? esc_html__( 'ارائه‌دهنده فعال', 'seo-project-manager' ) : esc_html__( 'انتخاب به‌عنوان ارائه‌دهنده فعال', 'seo-project-manager' ); ?></span>
					</button>
					<a href="https://platform.deepseek.com/api_keys" target="_blank" rel="noopener noreferrer" class="seopm-btn seopm-btn-ghost seopm-btn-sm" style="font-size:12px;">
						<span class="dashicons dashicons-external"></span> <?php esc_html_e( 'دریافت کلید API', 'seo-project-manager' ); ?>
					</a>
				</div>
			</div>

			<div class="seopm-form-grid" style="margin-top:14px;">
				<div class="seopm-field seopm-span-2">
					<span><?php esc_html_e( 'کلید API دیپ‌سیک (DeepSeek API Key)', 'seo-project-manager' ); ?></span>
					<div class="seopm-key-input-wrap">
						<input type="password" name="seopm[deepseek_api_key]" id="seopm-deepseek-key" value="<?php echo esc_attr( Settings::mask_key( $s['deepseek_api_key'] ) ); ?>" placeholder="sk-..." dir="ltr" class="seopm-key-input" autocomplete="new-password">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm seopm-toggle-key-visibility" data-target="seopm-deepseek-key" title="<?php esc_attr_e( 'نمایش/مخفی‌سازی کلید', 'seo-project-manager' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'کلید ثبت‌شده در platform.deepseek.com را وارد نمایید.', 'seo-project-manager' ); ?></small>
				</div>

				<label class="seopm-field">
					<span><?php esc_html_e( 'انتخاب مدل DeepSeek', 'seo-project-manager' ); ?></span>
					<select name="seopm[deepseek_model]" id="seopm-deepseek-model">
						<?php foreach ( $providers['deepseek']['models'] as $m_key => $m_label ) : ?>
							<option value="<?php echo esc_attr( $m_key ); ?>" <?php selected( $s['deepseek_model'], $m_key ); ?>><?php echo esc_html( $m_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label class="seopm-field">
					<span><?php esc_html_e( 'آدرس سرور پایه (Base URL - اختیاری)', 'seo-project-manager' ); ?></span>
					<input type="url" name="seopm[deepseek_base_url]" id="seopm-deepseek-url" value="<?php echo esc_attr( $s['deepseek_base_url'] ); ?>" placeholder="https://api.deepseek.com" dir="ltr">
					<small class="seopm-muted"><?php esc_html_e( 'در صورت خالی بودن، از آدرس رسمی https://api.deepseek.com استفاده می‌شود.', 'seo-project-manager' ); ?></small>
				</label>
			</div>

			<div class="seopm-test-bar">
				<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-sm">
					<span class="dashicons dashicons-saved"></span>
					<?php esc_html_e( 'ذخیره تنظیمات', 'seo-project-manager' ); ?>
				</button>
				<button type="button" class="seopm-btn seopm-btn-secondary seopm-btn-sm seopm-test-ai-btn" data-provider="deepseek">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'تست اتصال به DeepSeek', 'seo-project-manager' ); ?>
				</button>
				<div class="seopm-test-result" id="seopm-test-result-deepseek"></div>
			</div>
		</section>

		<!-- 5. Anthropic Claude Card -->
		<section class="seopm-card seopm-provider-config-card <?php echo 'claude' === $active_ai ? 'is-active-provider' : ''; ?>" data-provider-card="claude" style="border-top: 4px solid #d97706;">
			<div class="seopm-provider-card-header">
				<div style="display:flex; align-items:center; gap:10px;">
					<span class="seopm-provider-icon" style="background:#fef3c7; color:#d97706;">🧠</span>
					<div>
						<h3 style="margin:0; font-size:16px;"><?php esc_html_e( 'تنظیمات آنت‌روپیک کلود (Anthropic Claude)', 'seo-project-manager' ); ?></h3>
						<span class="seopm-muted seopm-small"><?php esc_html_e( 'اتصال به مدل‌های پرچمدار Claude 3.5 Sonnet جهت بهترین نگارش و بریف‌نویسی دقیق سئو', 'seo-project-manager' ); ?></span>
					</div>
				</div>
				<div class="seopm-provider-head-actions">
					<button type="button" class="seopm-activate-provider-btn <?php echo 'claude' === $active_ai ? 'is-active' : ''; ?>" data-activate-provider="claude">
						<span class="seopm-activate-box"><span class="dashicons dashicons-yes"></span></span>
						<span class="seopm-activate-text"><?php echo 'claude' === $active_ai ? esc_html__( 'ارائه‌دهنده فعال', 'seo-project-manager' ) : esc_html__( 'انتخاب به‌عنوان ارائه‌دهنده فعال', 'seo-project-manager' ); ?></span>
					</button>
					<a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener noreferrer" class="seopm-btn seopm-btn-ghost seopm-btn-sm" style="font-size:12px;">
						<span class="dashicons dashicons-external"></span> <?php esc_html_e( 'دریافت کلید API', 'seo-project-manager' ); ?>
					</a>
				</div>
			</div>

			<div class="seopm-form-grid" style="margin-top:14px;">
				<div class="seopm-field seopm-span-2">
					<span><?php esc_html_e( 'کلید API کلود (Claude API Key)', 'seo-project-manager' ); ?></span>
					<div class="seopm-key-input-wrap">
						<input type="password" name="seopm[claude_api_key]" id="seopm-claude-key" value="<?php echo esc_attr( Settings::mask_key( $s['claude_api_key'] ) ); ?>" placeholder="sk-ant-..." dir="ltr" class="seopm-key-input" autocomplete="new-password">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm seopm-toggle-key-visibility" data-target="seopm-claude-key" title="<?php esc_attr_e( 'نمایش/مخفی‌سازی کلید', 'seo-project-manager' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'کلید API آنت‌روپیک که معمولاً با sk-ant- آغاز می‌شود.', 'seo-project-manager' ); ?></small>
				</div>

				<label class="seopm-field">
					<span><?php esc_html_e( 'انتخاب مدل Claude', 'seo-project-manager' ); ?></span>
					<select name="seopm[claude_model]" id="seopm-claude-model">
						<?php foreach ( $providers['claude']['models'] as $m_key => $m_label ) : ?>
							<option value="<?php echo esc_attr( $m_key ); ?>" <?php selected( $s['claude_model'], $m_key ); ?>><?php echo esc_html( $m_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>

				<label class="seopm-field">
					<span><?php esc_html_e( 'آدرس سرور پایه (Base URL - اختیاری)', 'seo-project-manager' ); ?></span>
					<input type="url" name="seopm[claude_base_url]" id="seopm-claude-url" value="<?php echo esc_attr( $s['claude_base_url'] ); ?>" placeholder="https://api.anthropic.com/v1" dir="ltr">
					<small class="seopm-muted"><?php esc_html_e( 'در صورت استفاده از پروکسی معکوس یا واسط، آدرس آن را وارد کنید.', 'seo-project-manager' ); ?></small>
				</label>
			</div>

			<div class="seopm-test-bar">
				<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-sm">
					<span class="dashicons dashicons-saved"></span>
					<?php esc_html_e( 'ذخیره تنظیمات', 'seo-project-manager' ); ?>
				</button>
				<button type="button" class="seopm-btn seopm-btn-secondary seopm-btn-sm seopm-test-ai-btn" data-provider="claude">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'تست اتصال به Anthropic Claude', 'seo-project-manager' ); ?>
				</button>
				<div class="seopm-test-result" id="seopm-test-result-claude"></div>
			</div>
		</section>

		<!-- 6. Common AI Generation Parameters -->
		<section class="seopm-card">
			<h2><?php esc_html_e( 'پارامترهای عمومی هوش مصنوعی', 'seo-project-manager' ); ?></h2>
			<div class="seopm-form-grid">
				<label class="seopm-field">
					<span><?php esc_html_e( 'میزان خلاقیت (Temperature: بین ۰.۰ تا ۱.۰)', 'seo-project-manager' ); ?></span>
					<input type="number" step="0.05" min="0" max="1" name="seopm[ai_temperature]" value="<?php echo esc_attr( $s['ai_temperature'] ); ?>" style="width:120px;">
					<small class="seopm-muted"><?php esc_html_e( 'مقدار پیش‌فرض ۰.۷ است؛ اعداد کمتر عناوین متمرکزتر و اعداد بیشتر خلاقیت بالاتری ایجاد می‌کنند.', 'seo-project-manager' ); ?></small>
				</label>
			</div>
		</section>

	</div>

	<!-- ============================================================== -->
	<!-- TAB 2: BRANDING & REPORTS                                      -->
	<!-- ============================================================== -->
	<div class="seopm-tab-pane" id="seopm-pane-branding" style="display:none;">

		<section class="seopm-card">
			<h2><?php esc_html_e( 'برندینگ گزارش', 'seo-project-manager' ); ?></h2>
			<div class="seopm-form-grid">
				<label class="seopm-field"><span><?php esc_html_e( 'نام مجموعه یا آژانس سئو', 'seo-project-manager' ); ?></span>
					<input type="text" name="seopm[agency_name]" value="<?php echo esc_attr( $s['agency_name'] ); ?>"></label>
				<label class="seopm-field"><span><?php esc_html_e( 'نام تهیه‌کننده گزارش', 'seo-project-manager' ); ?></span>
					<input type="text" name="seopm[preparer_name]" value="<?php echo esc_attr( $s['preparer_name'] ); ?>"></label>
				<label class="seopm-field"><span><?php esc_html_e( 'وب‌سایت مجموعه (اختیاری)', 'seo-project-manager' ); ?></span>
					<input type="url" dir="ltr" name="seopm[agency_website]" value="<?php echo esc_attr( $s['agency_website'] ); ?>" placeholder="https://"></label>
				<div class="seopm-field"><span><?php esc_html_e( 'لوگوی مجموعه', 'seo-project-manager' ); ?></span>
					<div class="seopm-logo-picker">
						<div class="seopm-logo-preview" id="seopm-logo-preview"><?php if ( $logo_url ) : ?><img src="<?php echo esc_url( $logo_url ); ?>" alt=""><?php else : ?><span class="dashicons dashicons-format-image"></span><?php endif; ?></div>
						<input type="hidden" name="seopm[logo_id]" id="seopm-logo-id" value="<?php echo (int) $s['logo_id']; ?>">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm" id="seopm-logo-select"><?php esc_html_e( 'انتخاب از رسانه', 'seo-project-manager' ); ?></button>
						<button type="button" class="seopm-btn seopm-btn-link seopm-btn-sm" id="seopm-logo-remove" <?php echo $s['logo_id'] ? '' : 'hidden'; ?>><?php esc_html_e( 'حذف', 'seo-project-manager' ); ?></button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'در صورت انتخاب نکردن، لوگوی پیش‌فرض سیستم استفاده می‌شود. فرمت PNG یا JPG توصیه می‌شود.', 'seo-project-manager' ); ?></small>
				</div>
				<label class="seopm-field seopm-span-2"><span><?php esc_html_e( 'اطلاعات تماس (اختیاری)', 'seo-project-manager' ); ?></span>
					<textarea name="seopm[contact_info]" rows="2"><?php echo esc_textarea( $s['contact_info'] ); ?></textarea></label>
				<label class="seopm-field seopm-span-2"><span><?php esc_html_e( 'متن ثابت انتهای گزارش (اختیاری)', 'seo-project-manager' ); ?></span>
					<textarea name="seopm[footer_text]" rows="3"><?php echo esc_textarea( $s['footer_text'] ); ?></textarea></label>
			</div>
		</section>

		<section class="seopm-card">
			<h2><?php esc_html_e( 'قالب گزارش', 'seo-project-manager' ); ?></h2>
			<div class="seopm-theme-picker">
				<?php foreach ( Settings::themes() as $key => $label ) : ?>
					<label class="seopm-theme-option">
						<input type="radio" name="seopm[report_theme]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $s['report_theme'], $key ); ?>>
						<span class="seopm-theme-thumb seopm-theme-<?php echo esc_attr( $key ); ?>"><i></i><b></b><b></b><b></b></span>
						<span><?php echo esc_html( $label ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
			<div class="seopm-form-grid">
				<label class="seopm-check seopm-span-2">
					<input type="checkbox" name="seopm[use_business_color]" value="1" id="seopm-use-business-color" <?php checked( $s['use_business_color'], 1 ); ?>>
					<?php esc_html_e( 'رنگ اصلی گزارش از رنگ اختصاصی کسب‌وکار گرفته شود', 'seo-project-manager' ); ?>
				</label>
				<label class="seopm-field" id="seopm-report-color-field"><span><?php esc_html_e( 'رنگ ثابت گزارش', 'seo-project-manager' ); ?></span>
					<input type="text" name="seopm[report_color]" class="seopm-color" value="<?php echo esc_attr( $s['report_color'] ); ?>"></label>
				<label class="seopm-field"><span><?php esc_html_e( 'فونت PDF', 'seo-project-manager' ); ?></span>
					<select name="seopm[pdf_font]">
						<?php foreach ( Settings::pdf_fonts() as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $s['pdf_font'], $key ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					<small class="seopm-muted"><?php esc_html_e( 'پنل مدیریت از فونت پیشخوان/قالب شما استفاده می‌کند؛ این گزینه فقط برای فایل PDF است.', 'seo-project-manager' ); ?></small>
				</label>
			</div>
		</section>

	</div>

	<!-- ============================================================== -->
	<!-- TAB 3: TELEGRAM & CLIENT PREVIEW REVIEW                        -->
	<!-- ============================================================== -->
	<div class="seopm-tab-pane" id="seopm-pane-telegram" style="display:none;">

		<!-- 1. Bot Credentials & Admin Alerts -->
		<section class="seopm-card">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:10px;">
				<div>
					<h2 style="margin:0 0 4px;"><?php esc_html_e( 'ربات تلگرام و تنظیمات ارسال به کارفرما', 'seo-project-manager' ); ?></h2>
					<p class="seopm-muted seopm-small" style="margin:0;"><?php esc_html_e( 'ارسال خودکار لینک پیش‌نمایش اختصاصی مقاله به تلگرام کارفرما جهت بررسی، ثبت نظر و تأیید قبل از انتشار', 'seo-project-manager' ); ?></p>
				</div>
				<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-sm">
					<span class="dashicons dashicons-saved"></span>
					<?php esc_html_e( 'ذخیره تنظیمات', 'seo-project-manager' ); ?>
				</button>
			</div>

			<div class="seopm-grid seopm-grid-2">
				<label class="seopm-field">
					<span><?php esc_html_e( 'توکن ربات تلگرام (Bot Token)', 'seo-project-manager' ); ?> <span style="color:var(--seopm-danger)">*</span></span>
					<div style="display:flex; gap:6px;">
						<input type="password" name="seopm[telegram_bot_token]" id="seopm-tg-token" value="<?php echo esc_attr( $s['telegram_bot_token'] ?? '' ); ?>" placeholder="123456789:ABCdefGhIJKlmNoPQRstuVWXyz" style="font-family:monospace; direction:ltr; flex:1;">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm seopm-pw-toggle" data-target="seopm-tg-token" title="<?php esc_attr_e( 'نمایش / مخفی‌سازی', 'seo-project-manager' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm" id="seopm-btn-test-tg-conn" title="<?php esc_attr_e( 'تست اتصال به ربات', 'seo-project-manager' ); ?>"><span class="dashicons dashicons-update"></span> <?php esc_html_e( 'بررسی اتصال', 'seo-project-manager' ); ?></button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'توکن دریافتی از @BotFather در تلگرام.', 'seo-project-manager' ); ?></small>
				</label>

				<label class="seopm-field">
					<span><?php esc_html_e( 'نام کاربری ربات (@username)', 'seo-project-manager' ); ?></span>
					<div style="display:flex; gap:6px; align-items:center;">
						<input type="text" name="seopm[telegram_bot_username]" id="seopm-tg-username" dir="ltr" value="<?php echo esc_attr( $s['telegram_bot_username'] ?? '' ); ?>" placeholder="MyAgencyBot" style="font-family:monospace;">
						<?php if ( ! empty( $s['telegram_bot_username'] ) ) : ?>
							<a href="https://t.me/<?php echo esc_attr( $s['telegram_bot_username'] ); ?>" target="_blank" rel="noopener noreferrer" class="seopm-btn seopm-btn-ghost seopm-btn-sm" title="<?php esc_attr_e( 'باز کردن در تلگرام', 'seo-project-manager' ); ?>">
								<span class="dashicons dashicons-external"></span>
							</a>
						<?php endif; ?>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'پس از زدن «بررسی اتصال» به‌صورت خودکار شناسایی و ذخیره می‌شود.', 'seo-project-manager' ); ?></small>
				</label>
			</div>

			<div style="margin-top:14px;">
				<label class="seopm-field">
					<span><?php esc_html_e( 'شناسه چت مدیر آژانس (Admin Chat ID)', 'seo-project-manager' ); ?></span>
					<div style="display:flex; gap:6px; max-width:540px;">
						<input type="text" name="seopm[telegram_admin_chat_id]" id="seopm-tg-admin-chat" dir="ltr" value="<?php echo esc_attr( $s['telegram_admin_chat_id'] ?? '' ); ?>" placeholder="مثلاً: 123456789" style="font-family:monospace; flex:1;">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm" id="seopm-btn-test-tg-msg"><span class="dashicons dashicons-email-alt"></span> <?php esc_html_e( 'ارسال پیام تست', 'seo-project-manager' ); ?></button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'هر زمان که کارفرمایی مقاله را تأیید کند یا یادداشت اصلاحیه بنویسد، فوراً یک پیام به این چت آیدی ارسال می‌شود.', 'seo-project-manager' ); ?></small>
				</label>
			</div>
			<div id="seopm-tg-test-status" class="seopm-notice" style="display:none; margin-top:14px;"></div>
		</section>

		<!-- 2. Iranian Host Anti-Filter (Cloudflare Worker Reverse-Proxy) -->
		<section class="seopm-card">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
				<h2 style="margin:0;"><?php esc_html_e( 'عبور از فیلترینگ تلگرام در هاست ایران (پروکسی رایگان Cloudflare)', 'seo-project-manager' ); ?></h2>
				<span class="seopm-badge <?php echo ! empty( $s['telegram_proxy_url'] ) ? 'seopm-badge-primary' : 'seopm-badge-ghost'; ?>">
					<?php echo ! empty( $s['telegram_proxy_url'] ) ? esc_html__( 'پروکسی فعال', 'seo-project-manager' ) : esc_html__( 'اتصال مستقیم', 'seo-project-manager' ); ?>
				</span>
			</div>
			<p class="seopm-muted seopm-small" style="line-height:1.7;">
				<?php esc_html_e( 'به دلیل فیلتر بودن دامنه api.telegram.org بر روی سرورها و هاست‌های داخل ایران، درخواست‌ها به تلگرام مسدود می‌شوند. با ساخت یک ورکر رایگان در Cloudflare (کمتر از ۱ دقیقه)، تمام درخواست‌ها از طریق ورکر شما به تلگرام هدایت می‌شوند.', 'seo-project-manager' ); ?>
			</p>

			<div class="seopm-grid seopm-grid-2" style="margin-top:14px;">
				<label class="seopm-field">
					<span><?php esc_html_e( 'آدرس پروکسی ورکر کلودفلر (Cloudflare Worker URL)', 'seo-project-manager' ); ?></span>
					<input type="url" name="seopm[telegram_proxy_url]" id="seopm-tg-proxy-url" dir="ltr" value="<?php echo esc_attr( $s['telegram_proxy_url'] ?? '' ); ?>" placeholder="https://my-tg-worker.myaccount.workers.dev" style="font-family:monospace;">
					<small class="seopm-muted"><?php esc_html_e( 'آدرس ساب‌دامین ورکر ساخته‌شده در حساب کلودفلر شما (اگر خالی باشد اتصال مستقیم برقرار می‌شود).', 'seo-project-manager' ); ?></small>
				</label>

				<label class="seopm-field">
					<span><?php esc_html_e( 'رمز امنیتی پروکسی (اختیاری)', 'seo-project-manager' ); ?></span>
					<div style="display:flex; gap:6px;">
						<input type="password" name="seopm[telegram_proxy_secret]" id="seopm-tg-proxy-secret" dir="ltr" value="<?php echo esc_attr( $s['telegram_proxy_secret'] ?? '' ); ?>" placeholder="یک کلید دلخواه تصادفی" style="font-family:monospace; flex:1;">
						<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm seopm-pw-toggle" data-target="seopm-tg-proxy-secret"><span class="dashicons dashicons-visibility"></span></button>
					</div>
					<small class="seopm-muted"><?php esc_html_e( 'جهت جلوگیری از سوءاستفاده دیگران از ورکر شما (در ورکر متغیر PROXY_SECRET تنظیم می‌شود).', 'seo-project-manager' ); ?></small>
				</label>
			</div>

			<!-- Collapsible Cloudflare Worker Code Snippet -->
			<details class="seopm-details" style="margin-top:16px; border:1px solid var(--seopm-border); border-radius:8px; padding:10px 14px; background:var(--seopm-surface-2);">
				<summary style="font-weight:700; cursor:pointer; color:var(--seopm-primary);"><?php esc_html_e( 'کد آماده Cloudflare Worker برای کپی (کلیک کنید)', 'seo-project-manager' ); ?></summary>
				<div style="margin-top:10px;">
					<p class="seopm-small seopm-muted"><?php esc_html_e( 'کافیست در داشبورد Cloudflare به منوی Workers & Pages رفته، Create Application را بزنید و این کد را در ویرایشگر جایگزین کنید و Deploy نمایید:', 'seo-project-manager' ); ?></p>
					<pre style="background:#1e293b; color:#f8fafc; padding:12px; border-radius:6px; font-size:12px; direction:ltr; text-align:left; overflow-x:auto;"><code><?php echo esc_html( \SEOPM\Telegram_Client::cloudflare_worker_snippet() ); ?></code></pre>
				</div>
			</details>
		</section>

		<!-- 3. Pre-Publish Automated Daily Scheduler -->
		<section class="seopm-card">
			<h2 style="margin:0 0 8px;"><?php esc_html_e( 'زمان‌بندی و ارسال خودکار روز قبل از انتشار', 'seo-project-manager' ); ?></h2>
			<p class="seopm-muted seopm-small"><?php esc_html_e( 'سیستم هر روز در ساعت تعیین‌شده، مقالاتی که برای روز کاری فردا در تقویم زمان‌بندی شده‌اند را بررسی می‌کند و لینک پیش‌نمایش آن‌ها را به کارفرمای مربوطه ارسال می‌نماید.', 'seo-project-manager' ); ?></p>

			<div style="display:flex; flex-direction:column; gap:12px; margin-top:14px;">
				<label class="seopm-check" style="font-weight:600;">
					<input type="checkbox" name="seopm[telegram_auto_enabled]" value="1" <?php checked( ! empty( $s['telegram_auto_enabled'] ), true ); ?>>
					<?php esc_html_e( 'فعال‌سازی ارسال خودکار پیش‌نمایش به تلگرام کارفرما یک روز قبل از تاریخ انتشار', 'seo-project-manager' ); ?>
				</label>

				<div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
					<label class="seopm-field" style="margin:0;">
						<span style="font-size:12px; font-weight:600;"><?php esc_html_e( 'ساعت اجرای روزانه بررسی و ارسال:', 'seo-project-manager' ); ?></span>
						<select name="seopm[telegram_send_hour]" style="width:130px; margin-top:4px;">
							<?php
							$curr_h = (string) ( $s['telegram_send_hour'] ?? '10:00' );
							for ( $h = 7; $h <= 22; $h++ ) {
								$val = sprintf( '%02d:00', $h );
								echo '<option value="' . esc_attr( $val ) . '" ' . selected( $curr_h, $val, false ) . '>' . esc_html( $val ) . '</option>';
							}
							?>
						</select>
					</label>

					<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm" id="seopm-btn-run-tg-daily" style="margin-top:20px;">
						<span class="dashicons dashicons-controls-play"></span>
						<?php esc_html_e( 'اجرای دستی بررسی مقالات فردا و ارسال به تلگرام', 'seo-project-manager' ); ?>
					</button>
				</div>
			</div>
			<div id="seopm-tg-daily-status" class="seopm-notice" style="display:none; margin-top:14px;"></div>
		</section>

		<!-- 4. Helper Tool: Fetch Recent Chats for Chat ID -->
		<section class="seopm-card">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; flex-wrap:wrap; gap:8px;">
				<div>
					<h3 style="margin:0 0 4px;"><?php esc_html_e( 'ابزار دریافت شناسه چت‌ها (Chat ID Finder)', 'seo-project-manager' ); ?></h3>
					<p class="seopm-muted seopm-small" style="margin:0;"><?php esc_html_e( 'کافیست کارفرما یا مدیر در تلگرام دکمه Start را در ربات بزند یا پیامی ارسال کند، سپس روی دکمه زیر کلیک کنید تا Chat ID او فوراً نمایش داده شود.', 'seo-project-manager' ); ?></p>
				</div>
				<button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-sm" id="seopm-btn-fetch-recent-chats">
					<span class="dashicons dashicons-search"></span>
					<?php esc_html_e( 'بروزرسانی چت‌های اخیر', 'seo-project-manager' ); ?>
				</button>
			</div>
			<div id="seopm-tg-recent-chats-wrap" style="margin-top:10px;">
				<p class="seopm-muted seopm-small" style="margin:0;"><?php esc_html_e( 'هنوز واکشی نشده است. برای مشاهده چت‌های اخیر روی «بروزرسانی چت‌های اخیر» کلیک کنید.', 'seo-project-manager' ); ?></p>
			</div>
		</section>

	</div>

	<!-- ============================================================== -->
	<!-- TAB: TASK TYPES                                                -->
	<!-- ============================================================== -->
	<div class="seopm-tab-pane" id="seopm-pane-task-types" style="display:none;">
		<section class="seopm-card">
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:12px;">
				<div>
					<h2 style="margin:0 0 4px;"><?php esc_html_e( 'مدیریت انواع تسک (Task Types)', 'seo-project-manager' ); ?></h2>
					<p class="seopm-muted seopm-small" style="margin:0;"><?php esc_html_e( 'انواع تسک‌های پروژه را مشاهده کرده یا نوع تسک جدید (سئو تکنیکال، لینک‌سازی، تحقیق کلمات کلیدی، ویدیو مارکتینگ و...) تعریف کنید.', 'seo-project-manager' ); ?></p>
				</div>
			</div>

			<div style="background:var(--seopm-surface-2); border:1px solid var(--seopm-border); border-radius:var(--seopm-radius-sm); padding:16px; margin-bottom:20px;">
				<h3 style="margin:0 0 10px; font-size:14px;"><?php esc_html_e( 'افزودن نوع تسک جدید', 'seo-project-manager' ); ?></h3>
				<div style="display:flex; gap:12px; align-items:flex-end; flex-wrap:wrap;">
					<label class="seopm-field" style="flex:1; min-width:200px; margin:0;">
						<span style="font-size:12px; font-weight:600;"><?php esc_html_e( 'عنوان نوع تسک *', 'seo-project-manager' ); ?></span>
						<input type="text" id="seopm-new-type-label" placeholder="<?php esc_attr_e( 'مثلاً: سئو تکنیکال یا لینک‌سازی', 'seo-project-manager' ); ?>" style="margin-top:4px;">
					</label>
					<label class="seopm-field" style="flex:1; min-width:180px; margin:0;">
						<span style="font-size:12px; font-weight:600;"><?php esc_html_e( 'شناسه انگلیسی (اختیاری)', 'seo-project-manager' ); ?></span>
						<input type="text" id="seopm-new-type-key" dir="ltr" placeholder="technical_seo" style="margin-top:4px;">
					</label>
					<button type="button" class="seopm-btn seopm-btn-primary" id="seopm-btn-add-type" style="height:38px; margin-top:20px;">
						<span class="dashicons dashicons-plus-alt2"></span>
						<?php esc_html_e( 'افزودن نوع تسک', 'seo-project-manager' ); ?>
					</button>
				</div>
				<div id="seopm-type-add-msg" style="margin-top:10px; display:none;"></div>
			</div>

			<div id="seopm-types-table-wrap">
				<p class="seopm-muted"><?php esc_html_e( 'در حال بارگذاری لیست انواع تسک...', 'seo-project-manager' ); ?></p>
			</div>
		</section>
	</div>

	<!-- ============================================================== -->
	<!-- TAB 3: SYSTEM                                                  -->
	<!-- ============================================================== -->
	<?php if ( current_user_can( 'manage_options' ) ) : ?>
		<div class="seopm-tab-pane" id="seopm-pane-system" style="display:none;">
			<section class="seopm-card seopm-danger-zone">
				<h2><?php esc_html_e( 'حذف افزونه', 'seo-project-manager' ); ?></h2>
				<label class="seopm-check">
					<input type="checkbox" name="seopm[delete_on_uninstall]" value="1" <?php checked( $s['delete_on_uninstall'], 1 ); ?>>
					<?php esc_html_e( 'هنگام حذف کامل افزونه، تمام داده‌ها (کسب‌وکارها، تسک‌ها، گزارش‌ها و فایل‌های PDF) پاک شوند.', 'seo-project-manager' ); ?>
				</label>
				<p class="seopm-muted"><?php esc_html_e( 'غیرفعال‌سازی افزونه هیچ داده‌ای را حذف نمی‌کند.', 'seo-project-manager' ); ?></p>
			</section>
		</div>
	<?php endif; ?>

	<div class="seopm-form-actions" style="margin-top:20px;">
		<button type="submit" class="seopm-btn seopm-btn-primary seopm-btn-lg">
			<span class="dashicons dashicons-saved"></span>
			<?php esc_html_e( 'ذخیره تمام تنظیمات', 'seo-project-manager' ); ?>
		</button>
	</div>
</form>

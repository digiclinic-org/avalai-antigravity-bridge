<?php
/**
 * Admin menu.
 *
 * @package SEOPM
 */

namespace SEOPM\Admin;

use SEOPM\Security;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the plugin menu.
 */
class Admin_Menu {

	/**
	 * Pages renderer.
	 *
	 * @var Admin_Pages
	 */
	private $pages;

	/**
	 * Constructor.
	 *
	 * @param Admin_Pages $pages Pages.
	 */
	public function __construct( Admin_Pages $pages ) {
		$this->pages = $pages;
	}

	/**
	 * Hook.
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'register' ) );
	}

	/**
	 * Menu definition: slug => [title, template].
	 *
	 * @return array
	 */
	public static function items() {
		return array(
			'seopm-dashboard'   => array( __( 'داشبورد', 'seo-project-manager' ), 'dashboard' ),
			'seopm-businesses'  => array( __( 'کسب‌وکارها', 'seo-project-manager' ), 'businesses' ),
			'seopm-suggestions' => array( __( 'مقالات', 'seo-project-manager' ), 'suggestions' ),
			'seopm-calendar'    => array( __( 'تقویم تسک‌ها', 'seo-project-manager' ), 'calendar' ),
			'seopm-tasks'       => array( __( 'مدیریت تسک‌ها', 'seo-project-manager' ), 'tasks' ),
			'seopm-notes'       => array( __( 'یادداشت‌ها', 'seo-project-manager' ), 'notes' ),
			'seopm-reports'     => array( __( 'گزارش‌ها', 'seo-project-manager' ), 'reports' ),
			'seopm-settings'    => array( __( 'تنظیمات', 'seo-project-manager' ), 'settings' ),
		);
	}

	/**
	 * Register menus.
	 */
	public function register() {
		$title = __( 'مدیریت پروژه‌های سئو', 'seo-project-manager' );
		add_menu_page( $title, $title, Security::CAP, 'seopm-dashboard', array( $this->pages, 'render' ), 'dashicons-chart-area', 26 );

		foreach ( self::items() as $slug => $item ) {
			$hook = add_submenu_page( 'seopm-dashboard', $item[0] . ' ‹ ' . $title, $item[0], Security::CAP, $slug, array( $this->pages, 'render' ) );
			$this->pages->register_hook( $hook, $item[1] );
		}
	}
}

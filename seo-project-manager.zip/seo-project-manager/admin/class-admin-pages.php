<?php
/**
 * Admin pages: rendering, assets and admin-post handlers.
 *
 * @package SEOPM
 */

namespace SEOPM\Admin;

use SEOPM\Business;
use SEOPM\Jalali;
use SEOPM\Pdf_Generator;
use SEOPM\Report;
use SEOPM\Security;
use SEOPM\Settings;
use SEOPM\Task;
use SEOPM\Telegram_Client;

defined( 'ABSPATH' ) || exit;

/**
 * Admin pages.
 */
class Admin_Pages {

	/**
	 * Hook suffix => page key.
	 *
	 * @var array
	 */
	private $hooks = array();

	/**
	 * Register hooks.
	 */
	public function init() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_post_seopm_download', array( $this, 'handle_download' ) );
		add_action( 'admin_post_seopm_save_settings', array( $this, 'handle_settings' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
	}

	/**
	 * Map a hook suffix to a page.
	 *
	 * @param string $hook Hook suffix.
	 * @param string $page Page key.
	 */
	public function register_hook( $hook, $page ) {
		if ( $hook ) {
			$this->hooks[ $hook ] = $page;
		}
	}

	/**
	 * Current page key.
	 *
	 * @return string|null
	 */
	private function current_page() {
		$slug  = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$items = Admin_Menu::items();
		return isset( $items[ $slug ] ) ? $items[ $slug ][1] : null;
	}

	/**
	 * Body class on plugin pages.
	 *
	 * @param string $classes Classes.
	 * @return string
	 */
	public function body_class( $classes ) {
		$screen = get_current_screen();
		if ( $screen && isset( $this->hooks[ $screen->id ] ) ) {
			$classes .= ' seopm-screen seopm-page-' . sanitize_html_class( $this->hooks[ $screen->id ] );
		}
		$page = $this->current_page();
		if ( $page ) {
			$classes .= ' seopm-screen seopm-page-' . sanitize_html_class( $page );
		}
		return $classes;
	}

	/**
	 * Page URL.
	 *
	 * @param string $page Page key.
	 * @param array  $args Query args.
	 * @return string
	 */
	public static function url( $page, array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'seopm-' . $page ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Secure download URL for a report version.
	 *
	 * @param int $report_id Report ID.
	 * @param int $version   Version number.
	 * @return string
	 */
	public static function download_url( $report_id, $version ) {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'seopm_download',
					'report'  => (int) $report_id,
					'version' => (int) $version,
				),
				admin_url( 'admin-post.php' )
			),
			'seopm_download_' . (int) $report_id
		);
	}

	/**
	 * Enqueue assets on plugin pages only.
	 *
	 * @param string $hook Hook suffix.
	 */
	public function enqueue( $hook ) {
		if ( ! isset( $this->hooks[ $hook ] ) ) {
			return;
		}
		$page = $this->hooks[ $hook ];
		$v    = SEOPM_VERSION;
		$url  = SEOPM_URL . 'assets/';

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'seopm-admin', $url . 'css/admin.css', array( 'dashicons' ), $v );

		// Prevent WordPress core from converting Unicode emojis into broken external s.w.org twemoji images.
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );

		wp_register_script( 'seopm-jalali', $url . 'js/core/jalali.js', array(), $v, true );
		wp_register_script( 'seopm-ui', $url . 'js/core/ui.js', array( 'seopm-jalali', 'wp-api-fetch' ), $v, true );
		wp_register_script( 'seopm-datepicker', $url . 'js/core/datepicker.js', array( 'seopm-ui' ), $v, true );
		wp_register_script( 'seopm-task-form', $url . 'js/core/task-form.js', array( 'seopm-ui', 'seopm-datepicker' ), $v, true );

		wp_add_inline_script( 'seopm-ui', 'window.SEOPM_CONFIG = ' . wp_json_encode( $this->config( $page ) ) . ';', 'before' );

		$deps = array( 'seopm-ui', 'seopm-datepicker', 'seopm-task-form' );
		switch ( $page ) {
			case 'businesses':
				wp_enqueue_style( 'wp-color-picker' );
				$deps[] = 'wp-color-picker';
				break;
			case 'calendar':
				wp_register_script( 'seopm-fullcalendar', $url . 'js/vendor/fullcalendar/index.global.min.js', array(), '6.1.15', true );
				$deps[] = 'seopm-fullcalendar';
				break;
			case 'reports':
				wp_register_script( 'seopm-chartjs', $url . 'js/vendor/chartjs/chart.umd.min.js', array(), '4.4.4', true );
				$deps[] = 'seopm-chartjs';
				break;
			case 'settings':
				wp_enqueue_media();
				wp_enqueue_style( 'wp-color-picker' );
				$deps[] = 'wp-color-picker';
				break;
		}
		wp_enqueue_script( 'seopm-page-' . $page, $url . 'js/' . $page . '.js', $deps, $v, true );
	}

	/**
	 * JS configuration.
	 *
	 * @param string $page Current page slug.
	 * @return array
	 */
	private function config( $page = '' ) {
		$urls = array();
		foreach ( array_keys( Admin_Menu::items() ) as $slug ) {
			$urls[ substr( $slug, 6 ) ] = self::url( substr( $slug, 6 ) );
		}
		$cfg = array(
			'today'       => Jalali::today(),
			'types'       => Task::types(),
			'statuses'    => Task::statuses(),
			'reportTypes' => Report::types(),
			'businesses'  => Business::options(),
			'telegram'    => array(
				'configured'   => Telegram_Client::is_configured(),
				'bot_username' => Telegram_Client::get_config()['bot_username'],
			),
			'urls'        => $urls,
		);

		if ( 'dashboard' === $page ) {
			$cfg['initialData'] = \SEOPM\Dashboard::data();
		} elseif ( 'businesses' === $page || 'suggestions' === $page ) {
			$cfg['initialData'] = Business::all();
		} elseif ( 'notes' === $page ) {
			$cfg['initialData'] = array(
				'notes'  => \SEOPM\Note::all(),
				'colors' => \SEOPM\Note::colors(),
			);
		} elseif ( 'tasks' === $page ) {
			$search   = isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
			$business = isset( $_GET['business'] ) ? sanitize_text_field( wp_unslash( $_GET['business'] ) ) : '';
			$type     = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '';
			$status   = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
			$from     = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
			$to       = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
			$orderby  = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'due_date';
			$order    = isset( $_GET['order'] ) ? sanitize_key( wp_unslash( $_GET['order'] ) ) : 'asc';
			$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;

			$args = array(
				'business_ids' => $business ? array_filter( array_map( 'absint', explode( ',', $business ) ) ) : '',
				'type'         => $type,
				'status'       => $status,
				'search'       => $search,
				'from'         => $from,
				'to'           => $to,
				'orderby'      => $orderby,
				'order'        => $order,
				'page'         => $paged,
				'per_page'     => 20,
			);
			$counts = Task::counts( $args );
			if ( $status && isset( $counts[ $status ] ) ) {
				$total = (int) $counts[ $status ];
			} else {
				$total = (int) $counts['total'];
			}
			$query          = Task::query( $args, false );
			$query['total'] = $total;
			$query['pages'] = (int) ceil( $total / 20 );

			$cfg['initialData'] = array_merge( $query, array( 'counts' => $counts ) );
		}

		return $cfg;
	}

	/**
	 * Render the current page.
	 */
	public function render() {
		if ( ! Security::can_manage() ) {
			wp_die( esc_html__( 'شما مجوز دسترسی به این بخش را ندارید.', 'seo-project-manager' ), 403 );
		}
		$page = $this->current_page();
		if ( ! $page ) {
			return;
		}
		$nav = Admin_Menu::items();
		echo '<div class="wrap seopm-wrap seopm-wrap-' . esc_attr( $page ) . '"><div class="seopm-app seopm-app-' . esc_attr( $page ) . '" dir="rtl">';
		include SEOPM_PATH . 'templates/partials/nav.php';
		include SEOPM_PATH . 'templates/' . $page . '.php';
		echo '</div></div>';
	}

	/**
	 * Stream a report PDF (admin-post.php?action=seopm_download).
	 */
	public function handle_download() {
		$report_id = isset( $_GET['report'] ) ? absint( $_GET['report'] ) : 0;
		$version   = isset( $_GET['version'] ) ? absint( $_GET['version'] ) : 0;

		if ( ! Security::can_manage() ) {
			wp_die( esc_html__( 'شما مجوز دسترسی به این بخش را ندارید.', 'seo-project-manager' ), 403 );
		}
		check_admin_referer( 'seopm_download_' . $report_id );

		$report = Report::get( $report_id, $version ? $version : null );
		if ( ! $report ) {
			wp_die( esc_html__( 'گزارش یافت نشد.', 'seo-project-manager' ), 404 );
		}
		$file = Report::pdf_file( $report_id, $report['version_no'] );
		if ( ! $file && $report['is_current'] ) {
			// Rebuild missing file of the current version from its snapshot.
			Report::generate_pdf( $report_id );
			$file = Report::pdf_file( $report_id, $report['version_no'] );
		}
		if ( ! $file ) {
			// Fallback: render print-ready HTML page that triggers window.print()
			$version_row = Report::version( $report_id, $report['version_no'] );
			$snapshot    = $version_row ? json_decode( $version_row['snapshot_data'], true ) : null;
			if ( is_array( $snapshot ) && ! empty( $snapshot['business'] ) ) {
				$font = $snapshot['branding']['pdf_font'] ?? 'xbriyaz';
				$html = Pdf_Generator::render_html( $snapshot, (string) ( $version_row['summary'] ?? '' ), $font );
				$print_bar = '<div id="seopm-print-bar" dir="rtl" style="background:#1e293b;color:#fff;padding:12px 20px;display:flex;align-items:center;justify-content:space-between;font-family:tahoma,sans-serif;font-size:13px;position:sticky;top:0;z-index:99999;box-shadow:0 2px 8px rgba(0,0,0,0.2);">'
					. '<div><strong>پیش‌نمایش چاپ گزارش سئو:</strong> جهت دریافت فایل، در کادر چاپ مرورگر مقصد (Destination) را روی «Save as PDF» قرار دهید.</div>'
					. '<div>'
					. '<button type="button" onclick="window.print()" style="background:#4f46e5;color:#fff;border:none;padding:7px 16px;border-radius:6px;cursor:pointer;font-weight:bold;margin-left:8px;font-family:inherit;">🖨️ چاپ / ذخیره PDF</button>'
					. '<button type="button" onclick="window.history.back()" style="background:#475569;color:#fff;border:none;padding:7px 12px;border-radius:6px;cursor:pointer;font-family:inherit;">بازگشت به پنل</button>'
					. '</div>'
					. '</div>'
					. '<style>@media print { #seopm-print-bar { display: none !important; } body { padding: 0 !important; margin: 0 !important; } }</style>'
					. '<script>window.addEventListener("load", function(){ setTimeout(function(){ window.print(); }, 400); });</script>';
				$html = preg_replace( '/<body[^>]*>/i', '$0' . $print_bar, $html, 1 );
				header( 'Content-Type: text/html; charset=UTF-8' );
				echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				exit;
			}
			wp_die( esc_html__( 'فایل PDF این نسخه موجود نیست.', 'seo-project-manager' ), 404 );
		}
		Pdf_Generator::stream( $file, Pdf_Generator::download_name( $report ), 'seo-report-' . $report['id'] . '-v' . $report['version_no'] . '.pdf' );
	}

	/**
	 * Save settings form.
	 */
	public function handle_settings() {
		if ( ! Security::can_manage() ) {
			wp_die( esc_html__( 'شما مجوز دسترسی به این بخش را ندارید.', 'seo-project-manager' ), 403 );
		}
		check_admin_referer( 'seopm_save_settings' );
		$input = isset( $_POST['seopm'] ) && is_array( $_POST['seopm'] ) ? wp_unslash( $_POST['seopm'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized in Settings::save().
		// Destructive option requires the capability to manage the whole site.
		if ( ! current_user_can( 'manage_options' ) ) {
			$input['delete_on_uninstall'] = Settings::get( 'delete_on_uninstall' );
		}
		Settings::save( $input );
		wp_safe_redirect( self::url( 'settings', array( 'updated' => 1 ) ) );
		exit;
	}
}

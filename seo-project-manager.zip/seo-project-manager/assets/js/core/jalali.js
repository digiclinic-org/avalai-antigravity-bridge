/**
 * Jalali calendar helpers (algorithm from jalaali-js, MIT).
 * Dates are exchanged with the server as Gregorian "YYYY-MM-DD" strings.
 */
( function ( window ) {
	'use strict';

	var BREAKS = [ -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178 ];
	var MONTHS = [ 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' ];
	// Indexed by Date.getDay() (0 = Sunday).
	var WEEKDAYS = [ 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه' ];
	var WEEKDAYS_SHORT = [ 'ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش' ];

	function div( a, b ) {
		return ~~( a / b );
	}
	function mod( a, b ) {
		return a - ~~( a / b ) * b;
	}

	function jalCal( jy, withoutLeap ) {
		var bl = BREAKS.length, gy = jy + 621, leapJ = -14, jp = BREAKS[ 0 ], jm, jump = 0, leap, leapG, march, n, i;
		for ( i = 1; i < bl; i += 1 ) {
			jm = BREAKS[ i ];
			jump = jm - jp;
			if ( jy < jm ) {
				break;
			}
			leapJ = leapJ + div( jump, 33 ) * 8 + div( mod( jump, 33 ), 4 );
			jp = jm;
		}
		n = jy - jp;
		leapJ = leapJ + div( n, 33 ) * 8 + div( mod( n, 33 ) + 3, 4 );
		if ( mod( jump, 33 ) === 4 && jump - n === 4 ) {
			leapJ += 1;
		}
		leapG = div( gy, 4 ) - div( ( div( gy, 100 ) + 1 ) * 3, 4 ) - 150;
		march = 20 + leapJ - leapG;
		if ( withoutLeap ) {
			return { gy: gy, march: march };
		}
		if ( jump - n < 6 ) {
			n = n - jump + div( jump + 4, 33 ) * 33;
		}
		leap = mod( mod( n + 1, 33 ) - 1, 4 );
		if ( leap === -1 ) {
			leap = 4;
		}
		return { leap: leap, gy: gy, march: march };
	}

	function g2d( gy, gm, gd ) {
		var d = div( ( gy + div( gm - 8, 6 ) + 100100 ) * 1461, 4 ) + div( 153 * mod( gm + 9, 12 ) + 2, 5 ) + gd - 34840408;
		return d - div( div( gy + 100100 + div( gm - 8, 6 ), 100 ) * 3, 4 ) + 752;
	}

	function d2g( jdn ) {
		var j = 4 * jdn + 139361631, i, gd, gm, gy;
		j = j + div( div( 4 * jdn + 183187720, 146097 ) * 3, 4 ) * 4 - 3908;
		i = div( mod( j, 1461 ), 4 ) * 5 + 308;
		gd = div( mod( i, 153 ), 5 ) + 1;
		gm = mod( div( i, 153 ), 12 ) + 1;
		gy = div( j, 1461 ) - 100100 + div( 8 - gm, 6 );
		return { gy: gy, gm: gm, gd: gd };
	}

	function toJalali( gy, gm, gd ) {
		var jdn = g2d( gy, gm, gd ), g = d2g( jdn ), jy = g.gy - 621, r = jalCal( jy, false ), k = jdn - g2d( g.gy, 3, r.march );
		if ( k >= 0 ) {
			if ( k <= 185 ) {
				return { jy: jy, jm: 1 + div( k, 31 ), jd: mod( k, 31 ) + 1 };
			}
			k -= 186;
		} else {
			jy -= 1;
			k += 179;
			if ( r.leap === 1 ) {
				k += 1;
			}
		}
		return { jy: jy, jm: 7 + div( k, 30 ), jd: mod( k, 30 ) + 1 };
	}

	function toGregorian( jy, jm, jd ) {
		var r = jalCal( jy, true );
		return d2g( g2d( r.gy, 3, r.march ) + ( jm - 1 ) * 31 - div( jm, 7 ) * ( jm - 7 ) + jd - 1 );
	}

	function isLeap( jy ) {
		return jalCal( jy, false ).leap === 0;
	}

	function monthLength( jy, jm ) {
		if ( jm <= 6 ) {
			return 31;
		}
		if ( jm <= 11 ) {
			return 30;
		}
		return isLeap( jy ) ? 30 : 29;
	}

	function pad( n ) {
		return ( n < 10 ? '0' : '' ) + n;
	}

	function faDigits( value ) {
		return String( value ).replace( /\d/g, function ( d ) {
			return '۰۱۲۳۴۵۶۷۸۹'.charAt( +d );
		} ).replace( /%/g, '٪' );
	}

	function toLatinDigits( value ) {
		return String( value ).replace( /[۰-۹]/g, function ( d ) {
			return '۰۱۲۳۴۵۶۷۸۹'.indexOf( d );
		} ).replace( /[٠-٩]/g, function ( d ) {
			return '٠١٢٣٤٥٦٧٨٩'.indexOf( d );
		} );
	}

	/** "YYYY-MM-DD" -> {gy, gm, gd} */
	function parseISO( iso ) {
		var m = /^(\d{4})-(\d{2})-(\d{2})/.exec( iso || '' );
		return m ? { gy: +m[ 1 ], gm: +m[ 2 ], gd: +m[ 3 ] } : null;
	}

	function isoFromParts( gy, gm, gd ) {
		return gy + '-' + pad( gm ) + '-' + pad( gd );
	}

	/** Local Date -> "YYYY-MM-DD" (no timezone shift). */
	function isoFromDate( date ) {
		return isoFromParts( date.getFullYear(), date.getMonth() + 1, date.getDate() );
	}

	/** "YYYY-MM-DD" -> local Date at midnight. */
	function dateFromISO( iso ) {
		var p = parseISO( iso );
		return p ? new Date( p.gy, p.gm - 1, p.gd ) : null;
	}

	function jalaliFromISO( iso ) {
		var p = parseISO( iso );
		return p ? toJalali( p.gy, p.gm, p.gd ) : null;
	}

	function isoFromJalali( jy, jm, jd ) {
		var g = toGregorian( jy, jm, jd );
		return isoFromParts( g.gy, g.gm, g.gd );
	}

	/**
	 * Format a Gregorian ISO date as Jalali.
	 * @param {string} iso
	 * @param {string} style numeric | long | month | short (d month)
	 */
	function format( iso, style ) {
		var j = jalaliFromISO( iso );
		if ( ! j ) {
			return '';
		}
		var out;
		switch ( style ) {
			case 'long':
				out = j.jd + ' ' + MONTHS[ j.jm - 1 ] + ' ' + j.jy;
				break;
			case 'month':
				out = MONTHS[ j.jm - 1 ] + ' ' + j.jy;
				break;
			case 'short':
				out = j.jd + ' ' + MONTHS[ j.jm - 1 ];
				break;
			default:
				out = j.jy + '/' + pad( j.jm ) + '/' + pad( j.jd );
		}
		return faDigits( out );
	}

	/** Parse "1405/08/24" (Persian or Latin digits) into ISO, or null. */
	function parseJalaliString( str ) {
		var m = /^\s*(\d{4})\s*[\/\-.]\s*(\d{1,2})\s*[\/\-.]\s*(\d{1,2})\s*$/.exec( toLatinDigits( str || '' ) );
		if ( ! m ) {
			return null;
		}
		var jy = +m[ 1 ], jm = +m[ 2 ], jd = +m[ 3 ];
		if ( jm < 1 || jm > 12 || jd < 1 || jd > monthLength( jy, jm ) ) {
			return null;
		}
		return isoFromJalali( jy, jm, jd );
	}

	/** Difference in days between two ISO dates (b - a). */
	function diffDays( a, b ) {
		var da = dateFromISO( a ), db = dateFromISO( b );
		return Math.round( ( Date.UTC( db.getFullYear(), db.getMonth(), db.getDate() ) - Date.UTC( da.getFullYear(), da.getMonth(), da.getDate() ) ) / 86400000 );
	}

	function addDays( iso, days ) {
		var d = dateFromISO( iso );
		d.setDate( d.getDate() + days );
		return isoFromDate( d );
	}

	window.SEOPM = window.SEOPM || {};
	window.SEOPM.jalali = {
		MONTHS: MONTHS,
		WEEKDAYS: WEEKDAYS,
		WEEKDAYS_SHORT: WEEKDAYS_SHORT,
		toJalali: toJalali,
		toGregorian: toGregorian,
		isLeap: isLeap,
		monthLength: monthLength,
		faDigits: faDigits,
		toLatinDigits: toLatinDigits,
		isoFromDate: isoFromDate,
		dateFromISO: dateFromISO,
		jalaliFromISO: jalaliFromISO,
		isoFromJalali: isoFromJalali,
		format: format,
		parseJalaliString: parseJalaliString,
		diffDays: diffDays,
		addDays: addDays,
		pad: pad
	};
}( window ) );

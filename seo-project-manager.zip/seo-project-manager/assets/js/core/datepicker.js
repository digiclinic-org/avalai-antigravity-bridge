/**
 * Lightweight Jalali date picker (click-to-select calendar popup).
 * Displays Shamsi dates; the value it exposes is always Gregorian "YYYY-MM-DD".
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var J = SEOPM.jalali;
	var el = SEOPM.ui.el;
	var icon = SEOPM.ui.icon;
	var openPicker = null;

	/**
	 * @param {Object} opts {value: iso, onChange(iso), placeholder, required, allowEmpty}
	 * @return {{element:Node, input:Node, getValue:Function, setValue:Function}}
	 */
	function create( opts ) {
		opts = opts || {};
		var value = opts.value || '';
		var input = el( 'input', {
			type: 'text',
			class: 'seopm-date-input',
			readOnly: true,
			placeholder: opts.placeholder || 'انتخاب تاریخ از تقویم...',
			autocomplete: 'off',
			'aria-label': opts.label || 'تاریخ',
			'aria-haspopup': 'dialog'
		} );
		var trigger = el( 'button', { type: 'button', class: 'seopm-date-trigger', 'aria-label': 'باز کردن تقویم', tabindex: '-1' }, icon( 'calendar-alt' ) );
		var wrap = el( 'div', { class: 'seopm-datepicker' }, [ input, trigger ] );

		function render() {
			input.value = value ? J.format( value ) : '';
			input.classList.remove( 'is-invalid' );
		}

		function setValue( iso, silent ) {
			value = iso || '';
			render();
			if ( ! silent && opts.onChange ) {
				opts.onChange( value );
			}
		}

		function toggle() {
			if ( openPicker && openPicker.owner === wrap ) {
				closeOpen();
			} else {
				open();
			}
		}

		input.addEventListener( 'click', function ( e ) {
			e.stopPropagation();
			toggle();
		} );
		trigger.addEventListener( 'click', function ( e ) {
			e.stopPropagation();
			toggle();
		} );
		input.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Escape' && openPicker ) {
				e.stopPropagation();
				closeOpen();
			} else if ( e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown' ) {
				e.preventDefault();
				open();
			}
		} );

		function open() {
			if ( openPicker && openPicker.owner === wrap ) {
				position( openPicker.pop, wrap );
				return;
			}
			closeOpen();
			var todayIso = ( SEOPM.config && typeof SEOPM.config.today === 'string' && J.jalaliFromISO( SEOPM.config.today ) )
				? SEOPM.config.today
				: J.isoFromDate( new Date() );
			var base = J.jalaliFromISO( value ) || J.jalaliFromISO( todayIso );
			var state = { jy: base.jy, jm: base.jm };
			var pop = el( 'div', { class: 'seopm-dp-pop seopm-app', dir: 'rtl', role: 'dialog', 'aria-label': 'تقویم شمسی' } );
			pop.addEventListener( 'mousedown', function ( e ) {
				e.stopPropagation();
			} );
			pop.addEventListener( 'click', function ( e ) {
				e.stopPropagation();
			} );

			function draw() {
				SEOPM.ui.clear( pop );

				var monthSelect = el( 'select', { class: 'seopm-dp-select', 'aria-label': 'انتخاب ماه' }, J.MONTHS.map( function ( mName, mIdx ) {
					var o = el( 'option', { value: String( mIdx + 1 ), text: mName } );
					if ( mIdx + 1 === state.jm ) {
						o.selected = true;
					}
					return o;
				} ) );
				monthSelect.addEventListener( 'change', function () {
					state.jm = parseInt( monthSelect.value, 10 );
					draw();
				} );

				var yearOptions = [];
				for ( var y = base.jy - 2; y <= base.jy + 3; y++ ) {
					var yo = el( 'option', { value: String( y ), text: J.faDigits( y ) } );
					if ( y === state.jy ) {
						yo.selected = true;
					}
					yearOptions.push( yo );
				}
				var yearSelect = el( 'select', { class: 'seopm-dp-select seopm-dp-year', 'aria-label': 'انتخاب سال' }, yearOptions );
				yearSelect.addEventListener( 'change', function () {
					state.jy = parseInt( yearSelect.value, 10 );
					draw();
				} );

				var head = el( 'div', { class: 'seopm-dp-head' }, [
					el( 'button', { type: 'button', class: 'seopm-icon-btn', 'aria-label': 'ماه قبل', title: 'ماه قبل', onclick: function () {
						state.jm -= 1;
						if ( state.jm < 1 ) {
							state.jm = 12;
							state.jy -= 1;
						}
						draw();
					} }, icon( 'arrow-right-alt2' ) ),
					el( 'div', { class: 'seopm-dp-ym' }, [ monthSelect, yearSelect ] ),
					el( 'button', { type: 'button', class: 'seopm-icon-btn', 'aria-label': 'ماه بعد', title: 'ماه بعد', onclick: function () {
						state.jm += 1;
						if ( state.jm > 12 ) {
							state.jm = 1;
							state.jy += 1;
						}
						draw();
					} }, icon( 'arrow-left-alt2' ) )
				] );

				var grid = el( 'div', { class: 'seopm-dp-grid' } );
				[ 'ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج' ].forEach( function ( d ) {
					grid.appendChild( el( 'span', { class: 'seopm-dp-wd', text: d } ) );
				} );
				var firstIso = J.isoFromJalali( state.jy, state.jm, 1 );
				var offset = ( J.dateFromISO( firstIso ).getDay() + 1 ) % 7; // Saturday = 0
				for ( var i = 0; i < offset; i++ ) {
					grid.appendChild( el( 'span' ) );
				}
				var len = J.monthLength( state.jy, state.jm );
				for ( var d = 1; d <= len; d++ ) {
					( function ( day ) {
						var iso = J.isoFromJalali( state.jy, state.jm, day );
						var cls = 'seopm-dp-day';
						if ( iso === value ) {
							cls += ' is-selected';
						}
						if ( iso === todayIso ) {
							cls += ' is-today';
						}
						if ( ( offset + day - 1 ) % 7 === 6 ) {
							cls += ' is-friday';
						}
						grid.appendChild( el( 'button', { type: 'button', class: cls, text: J.faDigits( day ), onclick: function () {
							setValue( iso );
							closeOpen();
						} } ) );
					}( d ) );
				}

				function quick( label, days ) {
					return el( 'button', { type: 'button', class: 'seopm-dp-quick', text: label, onclick: function () {
						setValue( J.addDays( todayIso, days ) );
						closeOpen();
					} } );
				}
				var foot = el( 'div', { class: 'seopm-dp-foot' }, [
					el( 'div', { class: 'seopm-dp-quicks' }, [ quick( 'امروز', 0 ), quick( 'فردا', 1 ), quick( '۳ روز بعد', 3 ), quick( 'هفته بعد', 7 ) ] ),
					opts.allowEmpty !== false ? el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-link seopm-btn-sm', text: 'پاک کردن', onclick: function () {
						setValue( '' );
						closeOpen();
					} } ) : null
				] );
				SEOPM.ui.append( pop, [ head, grid, foot ] );
			}

			draw();
			document.body.appendChild( pop );
			position( pop, wrap );
			openPicker = { owner: wrap, pop: pop };
		}

		render();
		return {
			element: wrap,
			input: input,
			getValue: function () {
				return value;
			},
			setValue: setValue
		};
	}

	function position( pop, anchor ) {
		var r = anchor.getBoundingClientRect();
		var popW = pop.offsetWidth || 280;
		var popH = pop.offsetHeight || 310;
		var top = r.bottom + 6;
		var left = r.right - popW;

		if ( left < 8 ) {
			left = 8;
		}
		if ( left + popW > window.innerWidth - 8 ) {
			left = Math.max( 8, window.innerWidth - popW - 8 );
		}
		if ( top + popH > window.innerHeight - 8 && r.top > popH + 12 ) {
			top = Math.max( 8, r.top - popH - 6 );
		}
		if ( top + popH > window.innerHeight - 8 ) {
			top = Math.max( 8, window.innerHeight - popH - 8 );
		}

		pop.style.top = top + 'px';
		pop.style.left = left + 'px';
	}

	function closeOpen() {
		if ( openPicker ) {
			openPicker.pop.remove();
			openPicker = null;
		}
	}

	document.addEventListener( 'mousedown', function ( e ) {
		if ( openPicker && ! openPicker.pop.contains( e.target ) && ! openPicker.owner.contains( e.target ) ) {
			closeOpen();
		}
	} );
	window.addEventListener( 'resize', function () {
		if ( openPicker ) {
			position( openPicker.pop, openPicker.owner );
		}
	} );
	document.addEventListener( 'scroll', function ( e ) {
		if ( openPicker && ! openPicker.pop.contains( e.target ) ) {
			if ( document.body.contains( openPicker.owner ) ) {
				position( openPicker.pop, openPicker.owner );
			} else {
				closeOpen();
			}
		}
	}, true );

	SEOPM.datepicker = { create: create, close: closeOpen };
}( window, document ) );

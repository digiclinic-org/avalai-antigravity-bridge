/**
 * Shared UI kit: safe DOM builder, API wrapper, modal, toast, badges.
 * Never inserts user data via innerHTML.
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM = window.SEOPM || {};
	var J = SEOPM.jalali;
	var CONFIG = window.SEOPM_CONFIG || {};
	if ( ! /^\d{4}-\d{2}-\d{2}$/.test( String( CONFIG.today || '' ) ) && J && J.isoFromDate ) {
		CONFIG.today = J.isoFromDate( new Date() );
	}
	SEOPM.config = CONFIG;

	/**
	 * Create element: el('div', {class:'x', onclick: fn, dataset:{a:1}}, [children|string]).
	 */
	function el( tag, attrs, children ) {
		var node = document.createElement( tag );
		attrs = attrs || {};
		Object.keys( attrs ).forEach( function ( key ) {
			var val = attrs[ key ];
			if ( val === null || val === undefined || val === false ) {
				return;
			}
			if ( key === 'class' ) {
				node.className = val;
			} else if ( key === 'text' ) {
				node.textContent = val;
			} else if ( key === 'style' && typeof val === 'object' ) {
				Object.keys( val ).forEach( function ( s ) {
					node.style.setProperty( s, val[ s ] );
				} );
			} else if ( key === 'dataset' ) {
				Object.keys( val ).forEach( function ( d ) {
					node.dataset[ d ] = val[ d ];
				} );
			} else if ( key.indexOf( 'on' ) === 0 && typeof val === 'function' ) {
				node.addEventListener( key.slice( 2 ), val );
			} else if ( val === true ) {
				node.setAttribute( key, '' );
			} else {
				node.setAttribute( key, val );
			}
		} );
		append( node, children );
		return node;
	}

	function append( node, children ) {
		if ( children === null || children === undefined || children === false ) {
			return node;
		}
		if ( ! Array.isArray( children ) ) {
			children = [ children ];
		}
		children.forEach( function ( c ) {
			if ( c === null || c === undefined || c === false ) {
				return;
			}
			if ( Array.isArray( c ) ) {
				append( node, c );
			} else if ( c instanceof Node || ( typeof c === 'object' && c && c.nodeType ) ) {
				node.appendChild( c );
			} else {
				node.appendChild( document.createTextNode( String( c ) ) );
			}
		} );
		return node;
	}

	function clear( node ) {
		while ( node.firstChild ) {
			node.removeChild( node.firstChild );
		}
		return node;
	}

	function icon( name ) {
		return el( 'span', { class: 'dashicons dashicons-' + name, 'aria-hidden': 'true' } );
	}

	/* ---------------------------------- API ---------------------------------- */

	function query( params ) {
		var parts = [];
		Object.keys( params || {} ).forEach( function ( k ) {
			var v = params[ k ];
			if ( v === null || v === undefined || v === '' ) {
				return;
			}
			if ( Array.isArray( v ) ) {
				if ( v.length ) {
					parts.push( encodeURIComponent( k ) + '=' + encodeURIComponent( v.join( ',' ) ) );
				}
				return;
			}
			parts.push( encodeURIComponent( k ) + '=' + encodeURIComponent( v ) );
		} );
		return parts.length ? '?' + parts.join( '&' ) : '';
	}

	/**
	 * Call the plugin REST API. Nonce is attached by wp.apiFetch middleware.
	 * @return {Promise}
	 */
	function api( path, options ) {
		options = options || {};
		var req = { path: '/seopm/v1' + path + query( options.query ), method: options.method || 'GET' };
		if ( options.data ) {
			req.data = options.data;
		}
		if ( options.parse === false ) {
			req.parse = false;
		}
		return window.wp.apiFetch( req ).catch( function ( err ) {
			var msg = ( err && err.message ) || 'خطای ارتباط با سرور';
			if ( ! options.silent ) {
				toast( msg, 'error' );
			}
			throw err;
		} );
	}

	/* --------------------------------- Toast --------------------------------- */

	var toastWrap;
	/**
	 * Toast message. Optional action: {label, onClick} (e.g. undo).
	 */
	function toast( message, type, action ) {
		if ( ! toastWrap ) {
			toastWrap = el( 'div', { class: 'seopm-toasts', role: 'status', 'aria-live': 'polite' } );
			document.body.appendChild( toastWrap );
		}
		var timer;
		var t = el( 'div', { class: 'seopm-toast seopm-toast-' + ( type || 'success' ) }, [
			icon( type === 'error' ? 'warning' : 'yes-alt' ),
			el( 'span', { text: message } ),
			action ? el( 'button', { type: 'button', class: 'seopm-toast-action', text: action.label, onclick: function () {
				clearTimeout( timer );
				dismiss();
				action.onClick();
			} } ) : null
		] );
		function dismiss() {
			t.classList.add( 'is-leaving' );
			setTimeout( function () {
				t.remove();
			}, 300 );
		}
		toastWrap.appendChild( t );
		timer = setTimeout( dismiss, action ? 7000 : ( type === 'error' ? 5000 : 2800 ) );
	}

	/* --------------------------------- Modal --------------------------------- */

	/**
	 * Open a modal.
	 * @param {Object} opts {title, body(Node), footer(Node[]), size:'md'|'lg'|'sm', accent, onClose}
	 * @return {{close:Function, root:Node, body:Node, setBusy:Function}}
	 */
	function modal( opts ) {
		var previous = document.activeElement;
		var titleId = 'seopm-modal-title-' + Date.now();
		var body = el( 'div', { class: 'seopm-modal-body' }, opts.body );
		var footer = opts.footer ? el( 'div', { class: 'seopm-modal-footer' }, opts.footer ) : null;
		var closeBtn = el( 'button', { type: 'button', class: 'seopm-icon-btn', 'aria-label': 'بستن' }, icon( 'no-alt' ) );
		var dialog = el( 'div', {
			class: 'seopm-modal seopm-modal-' + ( opts.size || 'md' ),
			role: 'dialog',
			'aria-modal': 'true',
			'aria-labelledby': titleId,
			style: opts.accent ? { '--seopm-modal-accent': opts.accent } : null
		}, [
			el( 'div', { class: 'seopm-modal-head' }, [ el( 'h2', { id: titleId, text: opts.title || '' } ), closeBtn ] ),
			body,
			footer
		] );
		var root = el( 'div', { class: 'seopm-modal-backdrop seopm-app', dir: 'rtl' }, dialog );
		document.body.appendChild( root );
		document.body.classList.add( 'seopm-modal-open' );
		requestAnimationFrame( function () {
			root.classList.add( 'is-open' );
		} );

		function close() {
			if ( window.SEOPM && window.SEOPM.datepicker && window.SEOPM.datepicker.close ) {
				window.SEOPM.datepicker.close();
			}
			root.classList.remove( 'is-open' );
			document.removeEventListener( 'keydown', onKey );
			setTimeout( function () {
				root.remove();
				if ( ! document.querySelector( '.seopm-modal-backdrop' ) ) {
					document.body.classList.remove( 'seopm-modal-open' );
				}
				if ( previous && previous.focus ) {
					previous.focus();
				}
			}, 150 );
			if ( opts.onClose ) {
				opts.onClose();
			}
		}

		function onKey( e ) {
			if ( e.key === 'Escape' && root === lastModal() ) {
				close();
			} else if ( e.key === 'Tab' ) {
				var f = dialog.querySelectorAll( 'button:not([disabled]), [href], input:not([type=hidden]):not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])' );
				if ( ! f.length ) {
					return;
				}
				if ( e.shiftKey && document.activeElement === f[ 0 ] ) {
					e.preventDefault();
					f[ f.length - 1 ].focus();
				} else if ( ! e.shiftKey && document.activeElement === f[ f.length - 1 ] ) {
					e.preventDefault();
					f[ 0 ].focus();
				}
			}
		}

		closeBtn.addEventListener( 'click', close );
		root.addEventListener( 'mousedown', function ( e ) {
			if ( e.target === root ) {
				close();
			}
		} );
		document.addEventListener( 'keydown', onKey );
		setTimeout( function () {
			var first = dialog.querySelector( '[autofocus], input:not([type=hidden]), select, textarea, .seopm-modal-footer button' );
			( first || closeBtn ).focus();
		}, 60 );

		return {
			root: root,
			body: body,
			close: close,
			setBusy: function ( busy ) {
				dialog.classList.toggle( 'is-busy', !! busy );
				dialog.querySelectorAll( '.seopm-modal-footer button' ).forEach( function ( b ) {
					b.disabled = !! busy;
				} );
			}
		};
	}

	function lastModal() {
		var all = document.querySelectorAll( '.seopm-modal-backdrop' );
		return all[ all.length - 1 ];
	}

	/** Confirmation dialog. Resolves true/false. */
	function confirmDialog( message, opts ) {
		opts = opts || {};
		return new Promise( function ( resolve ) {
			var done = false;
			var extra = opts.extra || null;
			var m = modal( {
				title: opts.title || 'تأیید',
				size: 'sm',
				body: [ el( 'p', { class: 'seopm-confirm-text', text: message } ), extra ],
				footer: [
					button( 'انصراف', 'ghost', function () {
						m.close();
					} ),
					button( opts.confirmText || 'تأیید', opts.danger ? 'danger' : 'primary', function () {
						done = true;
						m.close();
						resolve( true );
					} )
				],
				onClose: function () {
					if ( ! done ) {
						resolve( false );
					}
				}
			} );
		} );
	}

	function button( label, variant, onClick, iconName ) {
		return el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-' + ( variant || 'ghost' ), onclick: onClick }, [ iconName ? icon( iconName ) : null, label ] );
	}

	/* ------------------------------- Formatting ------------------------------ */

	var STATUS_ICONS = { pending: 'clock', in_progress: 'update', completed: 'yes', overdue: 'warning' };

	function statusKey( task ) {
		return task.overdue ? 'overdue' : task.status;
	}

	/** Badge for the real status. Overdue is shown separately (date text / red marker), never as a second badge. */
	function statusBadge( task ) {
		return el( 'span', { class: 'seopm-badge seopm-badge-' + task.status }, [ icon( STATUS_ICONS[ task.status ] ), CONFIG.statuses[ task.status ] || task.status ] );
	}

	function businessChip( name, color ) {
		return el( 'span', { class: 'seopm-chip' }, [ el( 'i', { style: { background: color || '#64748b' } } ), name || '—' ] );
	}

	function contrast( hex ) {
		var h = ( hex || '' ).replace( '#', '' );
		if ( h.length !== 6 ) {
			return '#ffffff';
		}
		var r = parseInt( h.substr( 0, 2 ), 16 ), g = parseInt( h.substr( 2, 2 ), 16 ), b = parseInt( h.substr( 4, 2 ), 16 );
		return ( r * 299 + g * 587 + b * 114 ) / 1000 >= 150 ? '#1f2937' : '#ffffff';
	}

	/** Human friendly due text relative to today. */
	function dueText( iso, completed ) {
		var diff = J.diffDays( CONFIG.today, iso );
		if ( completed ) {
			return J.format( iso );
		}
		if ( diff === 0 ) {
			return 'امروز';
		}
		if ( diff === 1 ) {
			return 'فردا';
		}
		if ( diff === -1 ) {
			return 'دیروز';
		}
		if ( diff < 0 ) {
			return J.faDigits( -diff ) + ' روز تأخیر';
		}
		if ( diff <= 7 ) {
			return J.faDigits( diff ) + ' روز دیگر';
		}
		return J.format( iso );
	}

	function debounce( fn, wait ) {
		var t;
		return function () {
			var args = arguments, ctx = this;
			clearTimeout( t );
			t = setTimeout( function () {
				fn.apply( ctx, args );
			}, wait || 250 );
		};
	}

	function select( options, value, attrs ) {
		var s = el( 'select', attrs || {} );
		options.forEach( function ( o ) {
			var opt = el( 'option', { value: o.value, text: o.label } );
			if ( String( o.value ) === String( value ) ) {
				opt.selected = true;
			}
			s.appendChild( opt );
		} );
		return s;
	}

	function field( label, control, extraClass ) {
		return el( 'label', { class: 'seopm-field ' + ( extraClass || '' ) }, [ el( 'span', { text: label } ), control ] );
	}

	function emptyState( text, action ) {
		return el( 'div', { class: 'seopm-empty' }, [ icon( 'info-outline' ), el( 'p', { text: text } ), action || null ] );
	}

	function businessOptions( withAll ) {
		var list = ( CONFIG.businesses || [] ).map( function ( b ) {
			return { value: b.id, label: b.name };
		} );
		if ( withAll ) {
			list.unshift( { value: '', label: withAll } );
		}
		return list;
	}

	function mapOptions( obj, allLabel ) {
		var list = Object.keys( obj ).map( function ( k ) {
			return { value: k, label: obj[ k ] };
		} );
		if ( allLabel ) {
			list.unshift( { value: '', label: allLabel } );
		}
		return list;
	}

	function findBusiness( id ) {
		return ( CONFIG.businesses || [] ).filter( function ( b ) {
			return +b.id === +id;
		} )[ 0 ];
	}

	function refreshBusinesses() {
		return api( '/businesses', { silent: true } ).then( function ( list ) {
			CONFIG.businesses = list.map( function ( b ) {
				return { id: b.id, name: b.name, color: b.color };
			} );
			return list;
		} );
	}

	function progress( pct, color ) {
		return el( 'div', { class: 'seopm-progress' }, el( 'span', { style: { width: pct + '%', background: color || null } } ) );
	}

	SEOPM.ui = {
		el: el,
		append: append,
		clear: clear,
		icon: icon,
		api: api,
		toast: toast,
		modal: modal,
		confirm: confirmDialog,
		button: button,
		statusBadge: statusBadge,
		statusKey: statusKey,
		businessChip: businessChip,
		contrast: contrast,
		dueText: dueText,
		debounce: debounce,
		select: select,
		field: field,
		emptyState: emptyState,
		businessOptions: businessOptions,
		mapOptions: mapOptions,
		findBusiness: findBusiness,
		refreshBusinesses: refreshBusinesses,
		progress: progress,
		STATUS_ICONS: STATUS_ICONS
	};
}( window, document ) );

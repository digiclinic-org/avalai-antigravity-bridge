/**
 * Task calendar (FullCalendar + Jalali layer).
 *
 * FullCalendar only knows Gregorian months, so the monthly view is a custom
 * dayGrid view whose visible range is computed from the Jalali month of the
 * current date (Saturday-first weeks). Navigation is driven by our own toolbar.
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var ui = SEOPM.ui;
	var J = SEOPM.jalali;
	var el = ui.el;
	var C = SEOPM.config;
	var FC = window.FullCalendar;
	var calEl = document.getElementById( 'seopm-calendar' );
	if ( ! calEl || ! FC ) {
		return;
	}

	var STORE_KEY = 'seopm_calendar_filter';
	var VIEW_KEY = 'seopm_calendar_view';
	var titleEl = document.getElementById( 'seopm-cal-title' );
	var filterEl = document.getElementById( 'seopm-cal-filter' );
	var bizLegendEl = document.getElementById( 'seopm-cal-biz-legend' );
	var legendResetBtn = document.getElementById( 'seopm-cal-legend-reset' );
	var bizSearchInput = document.getElementById( 'seopm-cal-biz-search' );
	var bizSearchQuery = '';

	/* ------------------------------ Storage ------------------------------ */

	function store( key, value ) {
		try {
			if ( value === null ) {
				window.localStorage.removeItem( key );
			} else {
				window.localStorage.setItem( key, JSON.stringify( value ) );
			}
		} catch ( e ) {}
	}
	function restore( key ) {
		try {
			var v = window.localStorage.getItem( key );
			return v ? JSON.parse( v ) : null;
		} catch ( e ) {
			return null;
		}
	}

	/* ------------------------------ Filter ------------------------------ */

	// null = all businesses (also includes ones created later).
	var selectedIds = restore( STORE_KEY );
	if ( selectedIds && ! Array.isArray( selectedIds ) ) {
		selectedIds = null;
	}
	if ( selectedIds ) {
		// Drop businesses that were deleted since the filter was saved.
		var stored = selectedIds.length;
		selectedIds = selectedIds.filter( function ( id ) {
			return !! ui.findBusiness( id );
		} );
		if ( stored && ! selectedIds.length ) {
			selectedIds = null;
		}
		store( STORE_KEY, selectedIds );
	}

	function isSelected( id ) {
		return selectedIds === null || selectedIds.indexOf( +id ) !== -1;
	}

	function filterParam() {
		if ( selectedIds === null ) {
			return null;
		}
		return selectedIds.length ? selectedIds : [ 0 ]; // [0] = nothing matches.
	}

	var filterBtn = el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-ghost seopm-ms-btn', 'aria-haspopup': 'true', 'aria-expanded': 'false' } );
	var filterPanel = el( 'div', { class: 'seopm-ms-panel', hidden: true } );
	ui.append( filterEl, [ filterBtn, filterPanel ] );

	function drawFilterButton() {
		var list = C.businesses || [];
		var label;
		if ( selectedIds === null || selectedIds.length === list.length ) {
			label = 'همه کسب‌وکارها';
		} else if ( ! selectedIds.length ) {
			label = 'هیچ کسب‌وکاری';
		} else if ( selectedIds.length === 1 ) {
			var b = ui.findBusiness( selectedIds[ 0 ] );
			label = b ? b.name : '۱ کسب‌وکار';
		} else {
			label = J.faDigits( selectedIds.length ) + ' کسب‌وکار';
		}
		var dots = el( 'span', { class: 'seopm-ms-dots' } );
		list.filter( function ( b ) {
			return isSelected( b.id );
		} ).slice( 0, 4 ).forEach( function ( b ) {
			dots.appendChild( el( 'i', { style: { background: b.color } } ) );
		} );
		ui.clear( filterBtn );
		ui.append( filterBtn, [ ui.icon( 'filter' ), dots, el( 'span', { class: 'seopm-ms-label', text: label } ), ui.icon( 'arrow-down-alt2' ) ] );
	}

	function drawFilterPanel() {
		var list = C.businesses || [];
		ui.clear( filterPanel );
		if ( ! list.length ) {
			filterPanel.appendChild( el( 'div', { class: 'seopm-muted seopm-small', text: 'کسب‌وکاری ثبت نشده است.' } ) );
			return;
		}
		var allBox = el( 'input', { type: 'checkbox' } );
		allBox.checked = selectedIds === null || selectedIds.length === list.length;
		allBox.indeterminate = ! allBox.checked && selectedIds && selectedIds.length > 0;
		allBox.addEventListener( 'change', function () {
			setSelection( allBox.checked ? null : [] );
		} );
		filterPanel.appendChild( el( 'label', { class: 'seopm-ms-item seopm-ms-all' }, [ allBox, el( 'b', { text: 'همه کسب‌وکارها' } ) ] ) );
		list.forEach( function ( b ) {
			var box = el( 'input', { type: 'checkbox', value: b.id } );
			box.checked = isSelected( b.id );
			box.addEventListener( 'change', function () {
				var current = selectedIds === null ? list.map( function ( x ) {
					return +x.id;
				} ) : selectedIds.slice();
				if ( box.checked ) {
					current.push( +b.id );
				} else {
					current = current.filter( function ( id ) {
						return id !== +b.id;
					} );
				}
				setSelection( current.length === list.length ? null : current );
			} );
			filterPanel.appendChild( el( 'label', { class: 'seopm-ms-item' }, [
				box,
				el( 'i', { class: 'seopm-dot', style: { background: b.color } } ),
				el( 'span', { text: b.name } ),
				el( 'button', { type: 'button', class: 'seopm-btn-link seopm-ms-only', text: 'فقط این', onclick: function ( e ) {
					e.preventDefault();
					setSelection( [ +b.id ] );
				} } )
			] ) );
		} );
	}

	function drawBizLegend() {
		if ( ! bizLegendEl ) {
			return;
		}
		var list = C.businesses || [];
		ui.clear( bizLegendEl );
		if ( legendResetBtn ) {
			legendResetBtn.hidden = selectedIds === null;
		}
		if ( ! list.length ) {
			bizLegendEl.appendChild( el( 'div', { class: 'seopm-muted seopm-small', text: 'هنوز کسب‌وکاری ثبت نشده است.' } ) );
			return;
		}
		var filtered = bizSearchQuery ? list.filter( function ( b ) {
			return ( b.name || '' ).toLowerCase().indexOf( bizSearchQuery ) !== -1;
		} ) : list;

		if ( ! filtered.length ) {
			bizLegendEl.appendChild( el( 'div', { class: 'seopm-muted seopm-small', text: 'کسب‌وکاری با این نام یافت نشد.' } ) );
			return;
		}

		filtered.forEach( function ( b ) {
			var active = isSelected( b.id );
			var onlyThis = selectedIds !== null && selectedIds.length === 1 && +selectedIds[ 0 ] === +b.id;
			var item = el( 'button', {
				type: 'button',
				class: 'seopm-cal-biz-item' + ( onlyThis ? ' is-focused' : '' ) + ( ! active ? ' is-dimmed' : '' ),
				title: onlyThis ? 'کلیک برای نمایش همه کسب‌وکارها' : 'کلیک برای نمایش فقط تسک‌های «' + b.name + '»',
				onclick: function () {
					if ( onlyThis ) {
						setSelection( null );
					} else {
						setSelection( [ +b.id ] );
					}
				}
			}, [
				el( 'span', { class: 'seopm-cal-biz-dot', style: { background: b.color || '#4f46e5' } } ),
				el( 'span', { class: 'seopm-cal-biz-name', text: b.name } )
			] );
			bizLegendEl.appendChild( item );
		} );
	}

	if ( bizSearchInput ) {
		bizSearchInput.addEventListener( 'input', function () {
			bizSearchQuery = ( bizSearchInput.value || '' ).trim().toLowerCase();
			drawBizLegend();
		} );
	}

	if ( legendResetBtn ) {
		legendResetBtn.addEventListener( 'click', function () {
			setSelection( null );
		} );
	}

	function setSelection( ids ) {
		selectedIds = ids;
		store( STORE_KEY, ids );
		drawFilterButton();
		drawFilterPanel();
		drawBizLegend();
		calendar.refetchEvents();
	}

	filterBtn.addEventListener( 'click', function () {
		var open = filterPanel.hidden;
		filterPanel.hidden = ! open;
		filterBtn.setAttribute( 'aria-expanded', String( open ) );
		if ( open ) {
			drawFilterPanel();
		}
	} );
	document.addEventListener( 'mousedown', function ( e ) {
		if ( ! filterPanel.hidden && ! filterEl.contains( e.target ) ) {
			filterPanel.hidden = true;
			filterBtn.setAttribute( 'aria-expanded', 'false' );
		}
	} );
	document.addEventListener( 'keydown', function ( e ) {
		if ( e.key === 'Escape' && ! filterPanel.hidden ) {
			filterPanel.hidden = true;
			filterBtn.focus();
		}
	} );

	/* --------------------------- Jalali helpers --------------------------- */

	function jalaliMonthRange( date ) {
		var j = J.toJalali( date.getFullYear(), date.getMonth() + 1, date.getDate() );
		var first = J.dateFromISO( J.isoFromJalali( j.jy, j.jm, 1 ) );
		var last = J.dateFromISO( J.isoFromJalali( j.jy, j.jm, J.monthLength( j.jy, j.jm ) ) );
		var start = new Date( first );
		start.setDate( start.getDate() - ( ( start.getDay() + 1 ) % 7 ) ); // back to Saturday
		var end = new Date( last );
		end.setDate( end.getDate() + ( 6 - ( ( end.getDay() + 1 ) % 7 ) ) + 1 ); // after Friday (exclusive)
		return { start: start, end: end, jy: j.jy, jm: j.jm };
	}

	function currentJalali() {
		var d = calendar.getDate();
		return J.toJalali( d.getFullYear(), d.getMonth() + 1, d.getDate() );
	}

	function updateTitle() {
		var view = calendar.view;
		var text;
		if ( view.type === 'jalaliMonth' ) {
			var j = currentJalali();
			text = J.MONTHS[ j.jm - 1 ] + ' ' + J.faDigits( j.jy );
		} else if ( view.type === 'dayGridWeek' ) {
			var s = J.isoFromDate( view.currentStart );
			var e = J.addDays( J.isoFromDate( view.currentEnd ), -1 );
			text = J.format( s, 'short' ) + ' تا ' + J.format( e, 'long' );
		} else {
			var d = view.currentStart;
			text = J.WEEKDAYS[ d.getDay() ] + '، ' + J.format( J.isoFromDate( d ), 'long' );
		}
		titleEl.textContent = text;
		document.querySelectorAll( '[data-view]' ).forEach( function ( b ) {
			b.classList.toggle( 'is-active', b.dataset.view === view.type );
			b.setAttribute( 'aria-pressed', b.dataset.view === view.type ? 'true' : 'false' );
		} );
	}

	/* ------------------------------ Calendar ------------------------------ */

	function isNarrow() {
		return !! ( window.matchMedia && window.matchMedia( '(max-width: 640px)' ).matches );
	}
	var isMobile = isNarrow();
	var savedView = restore( VIEW_KEY );
	var initialView = savedView && [ 'jalaliMonth', 'dayGridWeek', 'dayGridDay' ].indexOf( savedView ) !== -1 ? savedView : ( isMobile ? 'dayGridDay' : 'jalaliMonth' );

	var initialIso = /^\d{4}-\d{2}-\d{2}$/.test( String( C.today || '' ) ) ? C.today : J.isoFromDate( new Date() );
	C.today = initialIso;

	var calendar = new FC.Calendar( calEl, {
		initialView: initialView,
		initialDate: initialIso,
		direction: 'rtl',
		firstDay: 6,
		headerToolbar: false,
		height: 'auto',
		fixedWeekCount: false,
		editable: true,
		eventDurationEditable: false,
		eventStartEditable: true,
		dayMaxEvents: 4,
		eventDisplay: 'block',
		eventOrder: 'extendedProps.statusOrder,title',
		views: {
			jalaliMonth: {
				type: 'dayGrid',
				visibleRange: function ( currentDate ) {
					var r = jalaliMonthRange( currentDate );
					return { start: r.start, end: r.end };
				}
			},
			dayGridWeek: { dayMaxEvents: false },
			dayGridDay: { dayMaxEvents: false }
		},

		events: function ( info, success, failure ) {
			ui.api( '/calendar/events', { query: {
				start: J.isoFromDate( info.start ),
				end: J.isoFromDate( info.end ),
				business_ids: filterParam()
			}, silent: false } ).then( function ( events ) {
				events.forEach( function ( ev ) {
					var key = ev.extendedProps.overdue ? 'overdue' : ev.extendedProps.status;
					ev.extendedProps.statusKey = key;
					ev.extendedProps.statusOrder = { overdue: 0, in_progress: 1, pending: 2, completed: 3 }[ key ];
				} );
				success( events );
			} ).catch( failure );
		},

		datesSet: updateTitle,

		dayHeaderContent: function ( arg ) {
			var nodes = [ el( 'span', { class: 'seopm-wd', text: J.WEEKDAYS[ arg.date.getDay() ] } ), el( 'span', { class: 'seopm-wd-short', 'aria-hidden': 'true', text: J.WEEKDAYS_SHORT[ arg.date.getDay() ] } ) ];
			if ( arg.view.type !== 'jalaliMonth' ) {
				nodes.push( el( 'span', { class: 'seopm-wd-date', text: J.format( J.isoFromDate( arg.date ), 'short' ) } ) );
			}
			return { domNodes: nodes };
		},

		// Rendered through FullCalendar (never inject nodes into cells it manages).
		dayCellContent: function ( arg ) {
			var j = J.toJalali( arg.date.getFullYear(), arg.date.getMonth() + 1, arg.date.getDate() );
			var add = addButton( J.isoFromDate( arg.date ) );
			if ( arg.view.type === 'dayGridDay' ) {
				return { domNodes: [ add ] };
			}
			var label = J.faDigits( j.jd );
			if ( j.jd === 1 && arg.view.type === 'jalaliMonth' ) {
				label += ' ' + J.MONTHS[ j.jm - 1 ];
			}
			return { domNodes: [ el( 'span', { class: 'seopm-daynum', text: label } ), add ] };
		},

		dayCellClassNames: function ( arg ) {
			var cls = [];
			if ( arg.view.type === 'jalaliMonth' ) {
				var j = J.toJalali( arg.date.getFullYear(), arg.date.getMonth() + 1, arg.date.getDate() );
				var cur = currentJalali();
				if ( j.jm !== cur.jm || j.jy !== cur.jy ) {
					cls.push( 'seopm-other-month' );
				}
			}
			if ( arg.date.getDay() === 5 ) {
				cls.push( 'seopm-friday' );
			}
			return cls;
		},

		moreLinkContent: function ( arg ) {
			return '+' + J.faDigits( arg.num ) + ( isNarrow() ? '' : ' مورد دیگر' );
		},

		eventClassNames: function ( arg ) {
			var p = arg.event.extendedProps;
			return [ 'seopm-ev', 'seopm-ev-' + p.status ].concat( p.overdue ? [ 'seopm-ev-overdue' ] : [] );
		},

		eventContent: function ( arg ) {
			var p = arg.event.extendedProps;
			var nodes = [
				el( 'span', { class: 'seopm-ev-icon', 'aria-hidden': 'true' }, ui.icon( ui.STATUS_ICONS[ p.status ] ) ),
				el( 'span', { class: 'seopm-ev-title', text: arg.event.title } ),
				( p.remote_status === 'future' || p.remote_status === 'publish' ) ? el( 'span', { class: 'seopm-ev-wp', title: p.remote_status === 'future' ? 'زمان‌بندی شده در سایت مقصد (ساعت ۲۱:۰۰)' : 'منتشر شده در سایت مقصد' }, ui.icon( 'cloud-upload' ) ) : null,
				p.overdue ? el( 'span', { class: 'seopm-ev-flag', title: 'عقب‌افتاده', 'aria-hidden': 'true' } ) : null
			];
			if ( arg.view.type !== 'jalaliMonth' ) {
				nodes.push( el( 'span', { class: 'seopm-ev-meta', text: p.business_name + ' · ' + p.task_type_label } ) );
			}
			// FullCalendar fails on null entries, so drop optional nodes that are absent.
			return { domNodes: nodes.filter( Boolean ) };
		},

		eventDidMount: function ( arg ) {
			var p = arg.event.extendedProps;
			var label = C.statuses[ p.status ] + ( p.overdue ? '، عقب‌افتاده' : '' );
			arg.el.setAttribute( 'title', arg.event.title + '\n' + p.business_name + ' · ' + p.task_type_label + '\n' + label );
			arg.el.setAttribute( 'aria-label', arg.event.title + '، ' + p.business_name + '، ' + label );
		},

		eventClick: function ( info ) {
			info.jsEvent.preventDefault();
			SEOPM.taskForm.details( info.event.extendedProps, { onChange: function () {
				calendar.refetchEvents();
			} } );
		},

		// A single click does not create a task (too easy to trigger by accident):
		// double-click a day (see the dblclick listener below) or use the "+" button.

		eventDrop: function ( info ) {
			var iso = J.isoFromDate( info.event.start );
			ui.api( '/tasks/' + info.event.id + '/date', { method: 'PATCH', data: { due_date: iso } } ).then( function () {
				ui.toast( 'تاریخ «' + info.event.title + '» به ' + J.format( iso, 'long' ) + ' منتقل شد.' );
				calendar.refetchEvents();
			} ).catch( function () {
				info.revert();
			} );
		}
	} );

	function addButton( iso ) {
		var add = el( 'button', {
			type: 'button',
			class: 'seopm-day-add',
			title: 'تسک جدید در این روز',
			'aria-label': 'تسک جدید در ' + J.format( iso, 'long' ),
			onclick: function ( e ) {
				e.preventDefault();
				e.stopPropagation();
				createOn( iso );
			}
		}, ui.icon( 'plus-alt2' ) );
		// Keep FullCalendar from treating the button press as a day click / drag start.
		[ 'pointerdown', 'mousedown', 'touchstart' ].forEach( function ( type ) {
			add.addEventListener( type, function ( e ) {
				e.stopPropagation();
			} );
		} );
		return add;
	}

	function createOn( iso ) {
		SEOPM.taskForm.open( { date: iso, businessId: singleSelected(), onSaved: function () {
			calendar.refetchEvents();
		} } );
	}

	function singleSelected() {
		return selectedIds && selectedIds.length === 1 ? selectedIds[ 0 ] : null;
	}

	calendar.render();

	// Clicking a day cell opens the New Task modal on desktop (or Day view on narrow mobile screens).
	calEl.addEventListener( 'click', function ( e ) {
		if ( e.target.closest( '.fc-event, .fc-daygrid-more-link, button, a:not(.fc-daygrid-day-number)' ) ) {
			return;
		}
		var cell = e.target.closest( 'td.fc-day[data-date]' );
		if ( ! cell ) {
			return;
		}
		var iso = cell.getAttribute( 'data-date' );
		if ( ! iso ) {
			return;
		}
		e.preventDefault();
		e.stopPropagation();
		if ( isNarrow() && calendar.view.type === 'jalaliMonth' ) {
			calendar.changeView( 'dayGridDay', iso );
		} else {
			createOn( iso );
		}
	} );
	drawFilterButton();
	drawBizLegend();

	/* ------------------------------ Toolbar ------------------------------ */

	document.querySelectorAll( '[data-cal]' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var action = btn.dataset.cal;
			if ( action === 'today' ) {
				calendar.gotoDate( C.today );
				return;
			}
			if ( calendar.view.type === 'jalaliMonth' ) {
				var j = currentJalali();
				var jm = j.jm + ( action === 'next' ? 1 : -1 ), jy = j.jy;
				if ( jm > 12 ) {
					jm = 1;
					jy += 1;
				} else if ( jm < 1 ) {
					jm = 12;
					jy -= 1;
				}
				calendar.gotoDate( J.isoFromJalali( jy, jm, 1 ) );
			} else if ( action === 'next' ) {
				calendar.next();
			} else {
				calendar.prev();
			}
		} );
	} );

	document.querySelectorAll( '[data-view]' ).forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var target = btn.dataset.view;
			var anchor = calendar.getDate();
			if ( target !== 'jalaliMonth' && calendar.view.type === 'jalaliMonth' ) {
				// Moving from month to week/day: prefer today if it is inside the shown month.
				var r = jalaliMonthRange( anchor );
				var today = J.dateFromISO( C.today );
				var t = J.toJalali( today.getFullYear(), today.getMonth() + 1, today.getDate() );
				anchor = t.jy === r.jy && t.jm === r.jm ? today : J.dateFromISO( J.isoFromJalali( r.jy, r.jm, 1 ) );
			}
			calendar.changeView( target, anchor );
			store( VIEW_KEY, target );
		} );
	} );

	document.addEventListener( 'seopm:new-task', function () {
		var anchor = J.isoFromDate( calendar.getDate() );
		var view = calendar.view;
		var inView = C.today >= J.isoFromDate( view.currentStart ) && C.today < J.isoFromDate( view.currentEnd );
		SEOPM.taskForm.open( { date: inView ? C.today : anchor, businessId: singleSelected(), onSaved: function () {
			calendar.refetchEvents();
		} } );
	} );
}( window, document ) );

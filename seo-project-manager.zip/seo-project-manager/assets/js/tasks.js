/**
 * Task management page: filters, tabs, sortable table, quick actions, bulk actions.
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var ui = SEOPM.ui;
	var J = SEOPM.jalali;
	var el = ui.el;
	var C = SEOPM.config;

	var listEl = document.getElementById( 'seopm-task-list' );
	var filtersEl = document.getElementById( 'seopm-task-filters' );
	var tabsEl = document.getElementById( 'seopm-task-tabs' );
	var footEl = document.getElementById( 'seopm-task-foot' );
	if ( ! listEl ) {
		return;
	}

	var params = new URLSearchParams( window.location.search );
	var state = {
		search: params.get( 'search' ) || '',
		business_ids: params.get( 'business' ) || '',
		type: params.get( 'type' ) || '',
		status: params.get( 'status' ) || '',
		from: params.get( 'from' ) || '',
		to: params.get( 'to' ) || '',
		orderby: params.get( 'orderby' ) || 'due_date',
		order: params.get( 'order' ) || 'asc',
		page: +( params.get( 'paged' ) || 1 ),
		per_page: 20
	};
	var selected = {};
	var lastItems = [];
	var requestId = 0;

	/* ------------------------------ Filters ------------------------------ */

	var searchInput = el( 'input', { type: 'search', value: state.search, placeholder: 'جست‌وجو در عنوان تسک...', 'aria-label': 'جست‌وجو' } );
	var bizSelect = ui.select( ui.businessOptions( 'همه کسب‌وکارها' ), state.business_ids, { 'aria-label': 'کسب‌وکار' } );
	var typeSelect = ui.select( ui.mapOptions( C.types, 'همه انواع' ), state.type, { 'aria-label': 'نوع تسک' } );
	var fromPicker = SEOPM.datepicker.create( { value: state.from, placeholder: 'از تاریخ', label: 'از تاریخ', onChange: function ( v ) {
		state.from = v;
		reload( true );
	} } );
	var toPicker = SEOPM.datepicker.create( { value: state.to, placeholder: 'تا تاریخ', label: 'تا تاریخ', onChange: function ( v ) {
		state.to = v;
		reload( true );
	} } );
	var resetBtn = el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-link seopm-btn-sm', onclick: function () {
		state.search = state.business_ids = state.type = state.status = state.from = state.to = '';
		searchInput.value = '';
		bizSelect.value = '';
		typeSelect.value = '';
		fromPicker.setValue( '', true );
		toPicker.setValue( '', true );
		reload( true );
	} }, [ ui.icon( 'image-rotate' ), 'حذف فیلترها' ] );

	ui.append( filtersEl, [
		el( 'label', { class: 'seopm-search seopm-grow' }, [ ui.icon( 'search' ), searchInput ] ),
		bizSelect,
		typeSelect,
		fromPicker.element,
		toPicker.element,
		resetBtn
	] );

	searchInput.addEventListener( 'input', ui.debounce( function () {
		state.search = searchInput.value.trim();
		reload( true );
	}, 300 ) );
	bizSelect.addEventListener( 'change', function () {
		state.business_ids = bizSelect.value;
		reload( true );
	} );
	typeSelect.addEventListener( 'change', function () {
		state.type = typeSelect.value;
		reload( true );
	} );
	window.addEventListener( 'seopm:type-created', function ( e ) {
		var item = e.detail;
		if ( item && item.key && item.label ) {
			var opt = el( 'option', { value: item.key, text: item.label } );
			typeSelect.appendChild( opt );
		}
	} );

	/* -------------------------------- Tabs -------------------------------- */

	var TABS = [
		[ '', 'همه', 'total' ],
		[ 'pending', 'در انتظار', 'pending' ],
		[ 'in_progress', 'در حال انجام', 'in_progress' ],
		[ 'completed', 'تکمیل‌شده', 'completed' ],
		[ 'overdue', 'عقب‌افتاده', 'overdue' ]
	];

	function drawTabs( counts ) {
		ui.clear( tabsEl );
		TABS.forEach( function ( t ) {
			tabsEl.appendChild( el( 'button', {
				type: 'button',
				role: 'tab',
				class: ( state.status === t[ 0 ] ? 'is-active ' : '' ) + ( t[ 0 ] === 'overdue' ? 'seopm-tab-danger' : '' ),
				'aria-selected': state.status === t[ 0 ] ? 'true' : 'false',
				onclick: function () {
					state.status = t[ 0 ];
					reload( true );
				}
			}, [ t[ 1 ], el( 'span', { class: 'seopm-count', text: J.faDigits( counts ? counts[ t[ 2 ] ] : 0 ) } ) ] ) );
		} );
	}

	/* -------------------------------- Data -------------------------------- */

	function syncUrl() {
		var p = new URLSearchParams();
		p.set( 'page', 'seopm-tasks' );
		[ 'search', 'type', 'status', 'from', 'to' ].forEach( function ( k ) {
			if ( state[ k ] ) {
				p.set( k, state[ k ] );
			}
		} );
		if ( state.business_ids ) {
			p.set( 'business', state.business_ids );
		}
		if ( state.orderby !== 'due_date' || state.order !== 'asc' ) {
			p.set( 'orderby', state.orderby );
			p.set( 'order', state.order );
		}
		if ( state.page > 1 ) {
			p.set( 'paged', state.page );
		}
		window.history.replaceState( null, '', window.location.pathname + '?' + p.toString() );
	}

	function reload( resetPage ) {
		if ( resetPage ) {
			state.page = 1;
		}
		selected = {};
		syncUrl();
		var id = ++requestId;
		listEl.classList.add( 'is-loading' );
		ui.api( '/tasks', { query: state } ).then( function ( res ) {
			if ( id !== requestId ) {
				return;
			}
			listEl.classList.remove( 'is-loading' );
			applyResult( res );
		} ).catch( function () {
			listEl.classList.remove( 'is-loading' );
		} );
	}

	function applyResult( res ) {
		lastItems = res.items;
		drawTabs( res.counts );
		drawTable( res.items );
		drawFoot( res );
	}

	/* -------------------------------- Table ------------------------------- */

	function sortHeader( label, key ) {
		var active = state.orderby === key;
		return el( 'th', { class: 'seopm-sortable' + ( active ? ' is-sorted' : '' ), 'aria-sort': active ? ( state.order === 'asc' ? 'ascending' : 'descending' ) : 'none' },
			el( 'button', { type: 'button', onclick: function () {
				state.order = active && state.order === 'asc' ? 'desc' : 'asc';
				state.orderby = key;
				reload( true );
			} }, [ label, ui.icon( active ? ( state.order === 'asc' ? 'arrow-up-alt2' : 'arrow-down-alt2' ) : 'sort' ) ] ) );
	}

	function drawTable( items ) {
		ui.clear( listEl );
		if ( ! items.length ) {
			var anyFilter = state.search || state.business_ids || state.type || state.status || state.from || state.to;
			listEl.appendChild( ui.emptyState( anyFilter ? 'تسکی با این فیلترها یافت نشد.' : 'هنوز تسکی ثبت نشده است.', anyFilter ? null : ui.button( 'ایجاد تسک', 'primary', newTask, 'plus-alt2' ) ) );
			return;
		}
		var checkAll = el( 'input', { type: 'checkbox', 'aria-label': 'انتخاب همه' } );
		checkAll.addEventListener( 'change', function () {
			items.forEach( function ( t ) {
				if ( checkAll.checked ) {
					selected[ t.id ] = true;
				} else {
					delete selected[ t.id ];
				}
			} );
			listEl.querySelectorAll( 'tbody input[type=checkbox]' ).forEach( function ( c ) {
				c.checked = checkAll.checked;
			} );
			drawBulk();
		} );

		var tbody = el( 'tbody' );
		items.forEach( function ( t ) {
			tbody.appendChild( row( t ) );
		} );

		listEl.appendChild( el( 'div', { class: 'seopm-table-wrap' }, el( 'table', { class: 'seopm-table seopm-table-tasks' }, [
			el( 'thead', {}, el( 'tr', {}, [
				el( 'th', { class: 'seopm-col-check' }, checkAll ),
				sortHeader( 'عنوان', 'title' ),
				el( 'th', { text: 'کسب‌وکار' } ),
				el( 'th', { text: 'نوع' } ),
				sortHeader( 'تاریخ انجام', 'due_date' ),
				el( 'th', { text: 'وضعیت' } )
			] ) ),
			tbody
		] ) ) );
	}

	function row( t ) {
		var check = el( 'input', { type: 'checkbox', 'aria-label': 'انتخاب ' + t.title } );
		check.checked = !! selected[ t.id ];
		check.addEventListener( 'change', function () {
			if ( check.checked ) {
				selected[ t.id ] = true;
			} else {
				delete selected[ t.id ];
			}
			drawBulk();
		} );

		var actions = el( 'span', { class: 'seopm-row-actions' }, [
			el( 'button', { type: 'button', class: 'seopm-icon-btn', title: 'ویرایش', 'aria-label': 'ویرایش ' + t.title, onclick: function () {
				SEOPM.taskForm.open( { task: t, onSaved: function () {
					reload();
				}, onDeleted: function () {
					reload();
				} } );
			} }, ui.icon( 'edit' ) ),
			el( 'button', { type: 'button', class: 'seopm-icon-btn seopm-danger-hover', title: 'حذف', 'aria-label': 'حذف ' + t.title, onclick: function () {
				SEOPM.taskForm.remove( t, function () {
					reload();
				} );
			} }, ui.icon( 'trash' ) )
		] );

		return el( 'tr', { class: t.overdue ? 'is-overdue' : '' }, [
			el( 'td', { class: 'seopm-col-check' }, check ),
			el( 'td', { 'data-label': 'عنوان', class: 'seopm-col-title' }, el( 'div', { class: 'seopm-title-cell' }, [
				el( 'div', { class: 'seopm-title-main' }, [
					el( 'button', { type: 'button', class: 'seopm-link-btn', text: t.title, onclick: function () {
						SEOPM.taskForm.details( t, { onChange: function () {
							reload();
						} } );
					} } ),
					t.status === 'completed' && t.completed_at ? el( 'div', { class: 'seopm-small seopm-muted', text: 'تکمیل: ' + SEOPM.taskForm.fmtUtc( t.completed_at ) } ) : null
				] ),
				actions
			] ) ),
			el( 'td', { 'data-label': 'کسب‌وکار' }, ui.businessChip( t.business_name, t.business_color ) ),
			el( 'td', { 'data-label': 'نوع', text: t.task_type_label } ),
			el( 'td', { 'data-label': 'تاریخ انجام' }, [
				el( 'div', { text: J.format( t.due_date ) } ),
				t.status !== 'completed' ? el( 'div', { class: 'seopm-small ' + ( t.overdue ? 'seopm-text-danger' : 'seopm-muted' ), text: ui.dueText( t.due_date ) } ) : null
			] ),
			el( 'td', { 'data-label': 'وضعیت' }, SEOPM.taskForm.statusPicker( t, function () {
				reload();
			} ) )
		] );
	}

	/* ------------------------- Footer / pagination ------------------------- */

	var bulkEl = el( 'div', { class: 'seopm-bulk' } );
	var pagerEl = el( 'div', { class: 'seopm-pager' } );
	ui.append( footEl, [ bulkEl, pagerEl ] );

	function drawBulk() {
		ui.clear( bulkEl );
		var ids = Object.keys( selected ).map( Number );
		if ( ! ids.length ) {
			return;
		}
		var action = ui.select( [
			{ value: '', label: 'عملیات گروهی...' },
			{ value: 'pending', label: 'تغییر به: در انتظار' },
			{ value: 'in_progress', label: 'تغییر به: در حال انجام' },
			{ value: 'completed', label: 'تغییر به: تکمیل‌شده' },
			{ value: 'delete', label: 'حذف' }
		], '', { 'aria-label': 'عملیات گروهی' } );
		ui.append( bulkEl, [
			el( 'span', { class: 'seopm-small', text: J.faDigits( ids.length ) + ' مورد انتخاب شده' } ),
			action,
			ui.button( 'اعمال', 'ghost', function () {
				if ( ! action.value ) {
					return;
				}
				var run = function () {
					ui.api( '/tasks/bulk', { method: 'POST', data: { ids: ids, action: action.value } } ).then( function ( r ) {
						ui.toast( J.faDigits( r.affected ) + ' تسک به‌روزرسانی شد.' );
						reload();
					} );
				};
				if ( action.value === 'delete' ) {
					ui.confirm( J.faDigits( ids.length ) + ' تسک حذف شود؟', { title: 'حذف گروهی', danger: true, confirmText: 'حذف' } ).then( function ( ok ) {
						if ( ok ) {
							run();
						}
					} );
				} else {
					run();
				}
			} )
		] );
	}

	function drawFoot( res ) {
		drawBulk();
		ui.clear( pagerEl );
		if ( res.pages <= 1 ) {
			if ( res.total ) {
				pagerEl.appendChild( el( 'span', { class: 'seopm-small seopm-muted', text: J.faDigits( res.total ) + ' تسک' } ) );
			}
			return;
		}
		var go = function ( p ) {
			state.page = p;
			reload();
		};
		ui.append( pagerEl, [
			el( 'span', { class: 'seopm-small seopm-muted', text: J.faDigits( res.total ) + ' تسک · صفحه ' + J.faDigits( state.page ) + ' از ' + J.faDigits( res.pages ) } ),
			el( 'button', { type: 'button', class: 'seopm-icon-btn', disabled: state.page <= 1, 'aria-label': 'صفحه قبل', onclick: function () {
				go( state.page - 1 );
			} }, ui.icon( 'arrow-right-alt2' ) ),
			el( 'button', { type: 'button', class: 'seopm-icon-btn', disabled: state.page >= res.pages, 'aria-label': 'صفحه بعد', onclick: function () {
				go( state.page + 1 );
			} }, ui.icon( 'arrow-left-alt2' ) )
		] );
	}

	function newTask() {
		SEOPM.taskForm.open( { businessId: state.business_ids ? +state.business_ids.split( ',' )[ 0 ] : null, onSaved: function () {
			reload();
		} } );
	}
	document.addEventListener( 'seopm:new-task', newTask );

	if ( C.initialData ) {
		var init = C.initialData;
		C.initialData = null;
		applyResult( init );
	} else {
		reload();
	}
}( window, document ) );

/**
 * Reports: archive, creation form and single report view.
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var ui = SEOPM.ui;
	var J = SEOPM.jalali;
	var el = ui.el;
	var C = SEOPM.config;
	var params = new URLSearchParams( window.location.search );

	function reportUrl( id, version ) {
		return C.urls.reports + '&report=' + id + ( version ? '&version=' + version : '' );
	}

	/* ============================ Create form ============================ */

	function openCreate( presetBusiness ) {
		if ( ! ( C.businesses || [] ).length ) {
			ui.toast( 'ابتدا یک کسب‌وکار ایجاد کنید.', 'error' );
			return;
		}
		var today = J.jalaliFromISO( C.today );
		var business = ui.select( ui.businessOptions(), presetBusiness || C.businesses[ 0 ].id );
		var typeMonthly = el( 'input', { type: 'radio', name: 'seopm-rtype', value: 'monthly', checked: true } );
		var typeCustom = el( 'input', { type: 'radio', name: 'seopm-rtype', value: 'custom' } );
		var monthSel = ui.select( J.MONTHS.map( function ( m, i ) {
			return { value: i + 1, label: m };
		} ), today.jm );
		var years = [];
		for ( var y = today.jy + 1; y >= today.jy - 5; y-- ) {
			years.push( { value: y, label: J.faDigits( y ) } );
		}
		var yearSel = ui.select( years, today.jy );
		var startPicker = SEOPM.datepicker.create( { value: J.isoFromJalali( today.jy, today.jm, 1 ), allowEmpty: false, onChange: preview } );
		var endPicker = SEOPM.datepicker.create( { value: C.today, allowEmpty: false, onChange: preview } );
		var title = el( 'input', { type: 'text', maxlength: '255' } );
		var summary = el( 'textarea', { rows: '5', placeholder: 'فعالیت‌های انجام‌شده، موانع، اقدامات باقی‌مانده و برنامه‌های بعدی (اختیاری؛ بعداً هم قابل ویرایش است)' } );
		var info = el( 'div', { class: 'seopm-info-box', 'aria-live': 'polite' } );
		var error = el( 'div', { class: 'seopm-form-error', role: 'alert', hidden: true } );
		var monthRow = el( 'div', { class: 'seopm-field seopm-span-2' }, [ el( 'span', { text: 'ماه گزارش' } ), el( 'div', { class: 'seopm-inline' }, [ monthSel, yearSel ] ) ] );
		var customRow = el( 'div', { class: 'seopm-inline-fields seopm-span-2', hidden: true }, [
			el( 'div', { class: 'seopm-field' }, [ el( 'span', { text: 'تاریخ شروع' } ), startPicker.element ] ),
			el( 'div', { class: 'seopm-field' }, [ el( 'span', { text: 'تاریخ پایان' } ), endPicker.element ] )
		] );

		function currentType() {
			return typeCustom.checked ? 'custom' : 'monthly';
		}

		function payload() {
			return {
				business_id: +business.value,
				report_type: currentType(),
				jyear: +yearSel.value,
				jmonth: +monthSel.value,
				start_date: startPicker.getValue(),
				end_date: endPicker.getValue()
			};
		}

		var previewTimer;
		function preview() {
			monthRow.hidden = currentType() !== 'monthly';
			customRow.hidden = currentType() !== 'custom';
			clearTimeout( previewTimer );
			previewTimer = setTimeout( function () {
				ui.api( '/reports/preview', { query: payload(), silent: true } ).then( function ( r ) {
					title.placeholder = r.default_title;
					ui.clear( info );
					ui.append( info, [
						ui.icon( 'info-outline' ),
						el( 'span', { text: 'بازه: ' + J.format( r.start ) + ' تا ' + J.format( r.end ) + ' — ' } ),
						el( 'b', { text: J.faDigits( r.count ) + ' تسک' } ),
						el( 'span', { text: r.count ? ' در این بازه یافت شد.' : ' در این بازه وجود ندارد؛ گزارش با پیام «داده‌ای برای نمایش وجود ندارد» تولید می‌شود.' } )
					] );
				} ).catch( function ( err ) {
					ui.clear( info );
					info.appendChild( el( 'span', { class: 'seopm-text-danger', text: ( err && err.message ) || '' } ) );
				} );
			}, 200 );
		}
		[ business, monthSel, yearSel, typeMonthly, typeCustom ].forEach( function ( c ) {
			c.addEventListener( 'change', preview );
		} );

		var m = ui.modal( {
			title: 'ایجاد گزارش جدید',
			size: 'md',
			body: el( 'div', { class: 'seopm-form-grid' }, [
				ui.field( 'کسب‌وکار *', business, 'seopm-span-2' ),
				el( 'div', { class: 'seopm-field seopm-span-2' }, [ el( 'span', { text: 'نوع گزارش' } ), el( 'div', { class: 'seopm-radio-cards' }, [
					el( 'label', {}, [ typeMonthly, el( 'b', { text: 'گزارش ماهانه' } ), el( 'small', { text: 'یک ماه شمسی کامل' } ) ] ),
					el( 'label', {}, [ typeCustom, el( 'b', { text: 'بازه زمانی دلخواه' } ), el( 'small', { text: 'تاریخ شروع و پایان دستی' } ) ] )
				] ) ] ),
				monthRow,
				customRow,
				ui.field( 'عنوان گزارش (اختیاری)', title, 'seopm-span-2' ),
				ui.field( 'جمع‌بندی مدیر پروژه (اختیاری)', summary, 'seopm-span-2' ),
				el( 'div', { class: 'seopm-span-2' }, info ),
				error
			] ),
			footer: [
				ui.button( 'انصراف', 'ghost', function () {
					m.close();
				} ),
				ui.button( 'ایجاد گزارش و PDF', 'primary', submit, 'media-document' )
			]
		} );
		preview();

		function submit() {
			var data = payload();
			data.title = title.value.trim();
			data.summary = summary.value;
			m.setBusy( true );
			error.hidden = true;
			ui.api( '/reports', { method: 'POST', data: data, silent: true } ).then( function ( r ) {
				ui.toast( 'گزارش ایجاد شد.' );
				window.location.href = reportUrl( r.id );
			} ).catch( function ( err ) {
				m.setBusy( false );
				error.textContent = ( err && err.message ) || 'خطا در تولید گزارش';
				error.hidden = false;
			} );
		}
	}

	/* ============================== Archive ============================== */

	function initArchive() {
		var listEl = document.getElementById( 'seopm-report-list' );
		var filtersEl = document.getElementById( 'seopm-report-filters' );
		var footEl = document.getElementById( 'seopm-report-foot' );
		if ( ! listEl ) {
			return;
		}
		var state = { business_id: params.get( 'business' ) || '', jmonth: '', from: '', to: '', page: 1, per_page: 20 };

		var bizSel = ui.select( ui.businessOptions( 'همه کسب‌وکارها' ), state.business_id, { 'aria-label': 'کسب‌وکار' } );
		var monthOpts = [ { value: '', label: 'همه ماه‌ها' } ];
		var t = J.jalaliFromISO( C.today );
		for ( var i = 0; i < 24; i++ ) {
			var jm = t.jm - i, jy = t.jy;
			while ( jm < 1 ) {
				jm += 12;
				jy -= 1;
			}
			monthOpts.push( { value: jy + '-' + jm, label: J.MONTHS[ jm - 1 ] + ' ' + J.faDigits( jy ) } );
		}
		var monthSel = ui.select( monthOpts, '', { 'aria-label': 'ماه' } );
		var from = SEOPM.datepicker.create( { placeholder: 'از تاریخ', onChange: function ( v ) {
			state.from = v;
			load( true );
		} } );
		var to = SEOPM.datepicker.create( { placeholder: 'تا تاریخ', onChange: function ( v ) {
			state.to = v;
			load( true );
		} } );
		ui.append( filtersEl, [ bizSel, monthSel, from.element, to.element ] );
		bizSel.addEventListener( 'change', function () {
			state.business_id = bizSel.value;
			load( true );
		} );
		monthSel.addEventListener( 'change', function () {
			state.jmonth = monthSel.value;
			load( true );
		} );

		function load( reset ) {
			if ( reset ) {
				state.page = 1;
			}
			listEl.classList.add( 'is-loading' );
			ui.api( '/reports', { query: state } ).then( function ( res ) {
				listEl.classList.remove( 'is-loading' );
				draw( res );
			} );
		}

		function draw( res ) {
			ui.clear( listEl );
			ui.clear( footEl );
			if ( ! res.items.length ) {
				var filtered = state.business_id || state.jmonth || state.from || state.to;
				listEl.appendChild( ui.emptyState( filtered ? 'گزارشی با این فیلترها یافت نشد.' : 'هنوز گزارشی ایجاد نشده است.', filtered ? null : ui.button( 'ایجاد گزارش جدید', 'primary', function () {
					openCreate();
				}, 'plus-alt2' ) ) );
				return;
			}
			var tbody = el( 'tbody' );
			res.items.forEach( function ( r ) {
				tbody.appendChild( el( 'tr', {}, [
					el( 'td', { 'data-label': 'شناسه', class: 'seopm-muted', text: J.faDigits( '#' + r.id ) } ),
					el( 'td', { 'data-label': 'کسب‌وکار' }, ui.businessChip( r.business_name, r.business_color ) ),
					el( 'td', { 'data-label': 'عنوان' }, el( 'a', { href: reportUrl( r.id ), class: 'seopm-strong-link', text: r.title } ) ),
					el( 'td', { 'data-label': 'بازه', text: J.format( r.start_date ) + ' – ' + J.format( r.end_date ) } ),
					el( 'td', { 'data-label': 'نوع' }, el( 'span', { class: 'seopm-tag', text: r.report_type_label } ) ),
					el( 'td', { 'data-label': 'نسخه', text: 'نسخه ' + J.faDigits( r.current_version ) } ),
					el( 'td', { 'data-label': 'ایجاد', class: 'seopm-small', text: SEOPM.taskForm.fmtUtc( r.created_at ) } ),
					el( 'td', { 'data-label': 'وضعیت' }, r.status === 'generated' && r.has_pdf
						? el( 'span', { class: 'seopm-badge seopm-badge-completed' }, [ ui.icon( 'pdf' ), 'PDF آماده' ] )
						: el( 'span', { class: 'seopm-badge seopm-badge-overdue' }, [ ui.icon( 'warning' ), r.status === 'failed' ? 'خطا در PDF' : 'بدون PDF' ] ) ),
					el( 'td', { class: 'seopm-col-actions' }, [
						el( 'a', { class: 'seopm-icon-btn', href: reportUrl( r.id ), title: 'مشاهده', 'aria-label': 'مشاهده' }, ui.icon( 'visibility' ) ),
						el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-ghost seopm-btn-sm', title: 'دانلود PDF', onclick: function () {
							ui.api( '/reports/' + r.id ).then( function ( full ) {
								window.open( full.download_url, '_blank' );
							} );
						} }, [ ui.icon( 'download' ), 'PDF' ] ),
						el( 'button', { type: 'button', class: 'seopm-icon-btn', title: 'تولید مجدد PDF', 'aria-label': 'تولید مجدد PDF', onclick: function ( e ) {
							var b = e.currentTarget;
							b.disabled = true;
							ui.api( '/reports/' + r.id + '/pdf', { method: 'POST' } ).then( function () {
								ui.toast( 'PDF دوباره تولید شد.' );
								load();
							} ).catch( function () {
								b.disabled = false;
							} );
						} }, ui.icon( 'update' ) ),
						el( 'button', { type: 'button', class: 'seopm-icon-btn seopm-danger-hover', title: 'حذف', 'aria-label': 'حذف', onclick: function () {
							deleteReport( r.id, r.title, load );
						} }, ui.icon( 'trash' ) )
					] )
				] ) );
			} );
			listEl.appendChild( el( 'div', { class: 'seopm-table-wrap' }, el( 'table', { class: 'seopm-table' }, [
				el( 'thead', {}, el( 'tr', {}, [ 'شناسه', 'کسب‌وکار', 'عنوان گزارش', 'بازه', 'نوع', 'نسخه', 'تاریخ ایجاد', 'وضعیت', '' ].map( function ( h ) {
					return el( 'th', { text: h } );
				} ) ) ),
				tbody
			] ) ) );
			if ( res.pages > 1 ) {
				ui.append( footEl, el( 'div', { class: 'seopm-pager' }, [
					el( 'span', { class: 'seopm-small seopm-muted', text: 'صفحه ' + J.faDigits( state.page ) + ' از ' + J.faDigits( res.pages ) } ),
					el( 'button', { type: 'button', class: 'seopm-icon-btn', disabled: state.page <= 1, 'aria-label': 'قبلی', onclick: function () {
						state.page--;
						load();
					} }, ui.icon( 'arrow-right-alt2' ) ),
					el( 'button', { type: 'button', class: 'seopm-icon-btn', disabled: state.page >= res.pages, 'aria-label': 'بعدی', onclick: function () {
						state.page++;
						load();
					} }, ui.icon( 'arrow-left-alt2' ) )
				] ) );
			}
		}

		load();
	}

	function deleteReport( id, title, done ) {
		ui.confirm( 'گزارش «' + title + '» و تمام نسخه‌ها و فایل‌های PDF آن حذف شود؟', { title: 'حذف گزارش', danger: true, confirmText: 'حذف' } ).then( function ( ok ) {
			if ( ! ok ) {
				return;
			}
			ui.api( '/reports/' + id, { method: 'DELETE' } ).then( function () {
				ui.toast( 'گزارش حذف شد.' );
				done();
			} );
		} );
	}

	/* ============================ Single view ============================ */

	function initView() {
		var actions = document.getElementById( 'seopm-report-actions' );
		if ( ! actions ) {
			return;
		}
		var id = +actions.dataset.report;

		var versionSel = document.getElementById( 'seopm-version-select' );
		if ( versionSel ) {
			versionSel.addEventListener( 'change', function () {
				window.location.href = reportUrl( id, versionSel.value );
			} );
		}

		function busy( btn, promise ) {
			btn.disabled = true;
			btn.classList.add( 'is-busy' );
			return promise.finally( function () {
				btn.disabled = false;
				btn.classList.remove( 'is-busy' );
			} );
		}

		actions.addEventListener( 'click', function ( e ) {
			var btn = e.target.closest( '[data-action]' );
			if ( ! btn ) {
				return;
			}
			switch ( btn.dataset.action ) {
				case 'regen-pdf':
					busy( btn, ui.api( '/reports/' + id + '/pdf', { method: 'POST' } ).then( function () {
						ui.toast( 'PDF با همان داده‌های ثبت‌شده دوباره تولید شد.' );
					} ) );
					break;
				case 'new-version':
					ui.confirm( 'یک نسخه جدید از این گزارش با داده‌های فعلی تسک‌ها ساخته می‌شود. نسخه‌های قبلی بدون تغییر در تاریخچه باقی می‌مانند.', { title: 'تولید نسخه جدید', confirmText: 'تولید نسخه جدید' } ).then( function ( ok ) {
						if ( ok ) {
							busy( btn, ui.api( '/reports/' + id + '/regenerate', { method: 'POST' } ).then( function () {
								window.location.href = reportUrl( id );
							} ) );
						}
					} );
					break;
				case 'edit-summary':
					editSummary( id );
					break;
				case 'delete-report':
					deleteReport( id, document.querySelector( '.seopm-page-head h1' ).textContent, function () {
						window.location.href = C.urls.reports;
					} );
					break;
			}
		} );

		drawCharts();
	}

	function editSummary( id ) {
		var raw = document.getElementById( 'seopm-summary-raw' );
		var titleNow = document.querySelector( '.seopm-page-head h1' ).textContent;
		var title = el( 'input', { type: 'text', value: titleNow, maxlength: '255' } );
		var area = el( 'textarea', { rows: '10' } );
		area.value = raw ? raw.value : '';
		var m = ui.modal( {
			title: 'ویرایش جمع‌بندی گزارش',
			size: 'lg',
			body: el( 'div', { class: 'seopm-form-grid' }, [
				ui.field( 'عنوان گزارش', title, 'seopm-span-2' ),
				ui.field( 'جمع‌بندی مدیر پروژه', area, 'seopm-span-2' ),
				el( 'p', { class: 'seopm-muted seopm-small seopm-span-2', text: 'فقط متن جمع‌بندی و عنوان تغییر می‌کند؛ آمار و تسک‌های این نسخه ثابت می‌مانند. PDF به‌صورت خودکار به‌روزرسانی می‌شود. تگ‌های ساده HTML مانند <strong> و <ul> مجاز هستند.' } )
			] ),
			footer: [
				ui.button( 'انصراف', 'ghost', function () {
					m.close();
				} ),
				ui.button( 'ذخیره و به‌روزرسانی PDF', 'primary', function () {
					m.setBusy( true );
					ui.api( '/reports/' + id + '/summary', { method: 'PUT', data: { summary: area.value, title: title.value } } ).then( function () {
						window.location.reload();
					} ).catch( function () {
						m.setBusy( false );
					} );
				} )
			]
		} );
	}

	function drawCharts() {
		var box = document.getElementById( 'seopm-report-charts' );
		if ( ! box || ! window.Chart ) {
			return;
		}
		var data = JSON.parse( box.dataset.chart );
		var Chart = window.Chart;
		Chart.defaults.font.family = window.getComputedStyle( document.body ).fontFamily;
		Chart.defaults.color = '#4b5563';
		var tooltipNum = { callbacks: { label: function ( ctx ) {
			return ' ' + J.faDigits( ctx.formattedValue );
		} } };

		function noData( canvas ) {
			var parent = canvas.parentNode;
			canvas.remove();
			parent.appendChild( ui.emptyState( 'داده‌ای برای نمایش وجود ندارد' ) );
		}

		var statusCanvas = document.getElementById( 'seopm-chart-status' );
		if ( data.status.reduce( function ( a, b ) {
			return a + b;
		}, 0 ) ) {
			new Chart( statusCanvas, {
				type: 'doughnut',
				data: { labels: [ 'تکمیل‌شده', 'در حال انجام', 'در انتظار' ], datasets: [ { data: data.status, backgroundColor: [ '#16a34a', '#3b82f6', '#f59e0b' ], borderWidth: 0 } ] },
				options: { maintainAspectRatio: false, cutout: '65%', plugins: { legend: { position: 'bottom', rtl: true }, tooltip: tooltipNum } }
			} );
		} else {
			noData( statusCanvas );
		}

		var typeCanvas = document.getElementById( 'seopm-chart-types' );
		if ( data.types.values.reduce( function ( a, b ) {
			return a + b;
		}, 0 ) ) {
			new Chart( typeCanvas, {
				type: 'bar',
				data: { labels: data.types.labels, datasets: [ { data: data.types.values, backgroundColor: data.accent, borderRadius: 6, maxBarThickness: 22 } ] },
				options: { indexAxis: 'y', maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: tooltipNum }, scales: {
					x: { beginAtZero: true, reverse: true, ticks: { precision: 0, callback: function ( v ) {
						return J.faDigits( v );
					} } },
					y: { position: 'right' }
				} }
			} );
		} else {
			noData( typeCanvas );
		}

		var trendCanvas = document.getElementById( 'seopm-chart-trend' );
		if ( data.trend.values.reduce( function ( a, b ) {
			return a + b;
		}, 0 ) ) {
			new Chart( trendCanvas, {
				type: 'bar',
				data: { labels: data.trend.labels, datasets: [ { label: 'تسک تکمیل‌شده', data: data.trend.values, backgroundColor: data.accent, borderRadius: 4, maxBarThickness: 28 } ] },
				options: { maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: tooltipNum }, scales: {
					x: { reverse: true, grid: { display: false } },
					y: { beginAtZero: true, position: 'right', ticks: { precision: 0, callback: function ( v ) {
						return J.faDigits( v );
					} } }
				} }
			} );
		} else {
			noData( trendCanvas );
		}
	}

	/* ================================ Init ================================ */

	document.querySelectorAll( '[data-action="new-report"]' ).forEach( function ( b ) {
		b.addEventListener( 'click', function () {
			openCreate();
		} );
	} );
	initArchive();
	initView();
	if ( params.get( 'new' ) ) {
		openCreate( params.get( 'business' ) ? +params.get( 'business' ) : null );
	}
}( window, document ) );

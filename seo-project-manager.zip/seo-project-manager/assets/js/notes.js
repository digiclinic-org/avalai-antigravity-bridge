/**
 * Notes page JavaScript module.
 *
 * @package SEOPM
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM = window.SEOPM || {};
	var ui    = SEOPM.ui;
	var el    = ui.el;

	var appContainer = null;
	var state = {
		notes: ( SEOPM.config && SEOPM.config.initialData && SEOPM.config.initialData.notes ) || [],
		colors: ( SEOPM.config && SEOPM.config.initialData && SEOPM.config.initialData.colors ) || {},
		businesses: ( SEOPM.config && SEOPM.config.businesses ) || [],
		filterBiz: '',
		filterSearch: '',
		filterColor: '',
		filterPinned: 'all',
		loading: false
	};

	function init() {
		appContainer = document.getElementById( 'seopm-notes-app' );
		if ( ! appContainer ) {
			return;
		}

		var newNoteBtn = document.getElementById( 'seopm-new-note-btn' );
		if ( newNoteBtn ) {
			newNoteBtn.addEventListener( 'click', function () {
				openNoteModal( null );
			} );
		}

		renderApp();
	}

	function fetchNotes() {
		state.loading = true;
		renderApp();

		var query = {};
		if ( state.filterBiz !== '' && state.filterBiz !== 'all' ) {
			query.business_id = state.filterBiz;
		}
		if ( state.filterColor ) {
			query.color = state.filterColor;
		}
		if ( state.filterSearch ) {
			query.search = state.filterSearch;
		}
		if ( state.filterPinned === 'pinned' ) {
			query.is_pinned = 1;
		} else if ( state.filterPinned === 'unpinned' ) {
			query.is_pinned = 0;
		}

		ui.api( '/notes', { query: query } ).then( function ( res ) {
			state.loading = false;
			state.notes   = res.notes || [];
			if ( res.colors ) {
				state.colors = res.colors;
			}
			renderApp();
		} ).catch( function () {
			state.loading = false;
			renderApp();
		} );
	}

	function renderApp() {
		if ( ! appContainer ) {
			return;
		}
		ui.clear( appContainer );

		// 1. Controls / Filter bar
		var filterBar = renderFilterBar();
		appContainer.appendChild( filterBar );

		if ( state.loading ) {
			var loadingEl = el( 'div', { class: 'seopm-notes-loading' }, [
				el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon', style: { fontSize: '28px', width: '28px', height: '28px', color: '#4f46e5' } } ),
				el( 'p', { text: 'در حال بارگذاری یادداشت‌ها...', style: { marginTop: '8px', color: '#64748b', fontWeight: '500' } } )
			] );
			appContainer.appendChild( loadingEl );
			return;
		}

		// Filter notes in memory if needed
		var filtered = state.notes;

		if ( ! filtered.length ) {
			appContainer.appendChild( renderEmptyState() );
			return;
		}

		var pinnedNotes = filtered.filter( function ( n ) { return n.is_pinned; } );
		var otherNotes  = filtered.filter( function ( n ) { return ! n.is_pinned; } );

		// 2. Pinned Notes Section
		if ( pinnedNotes.length > 0 ) {
			var pinnedSection = el( 'div', { class: 'seopm-notes-section seopm-pinned-section' }, [
				el( 'div', { class: 'seopm-notes-section-head' }, [
					el( 'span', { class: 'dashicons dashicons-admin-post', style: { color: '#f59e0b', fontSize: '18px' } } ),
					el( 'h2', { text: 'یادداشت‌های سنجاق‌شده' } ),
					el( 'span', { class: 'seopm-badge seopm-badge-pending', text: String( pinnedNotes.length ) } )
				] ),
				renderNotesGrid( pinnedNotes )
			] );
			appContainer.appendChild( pinnedSection );
		}

		// 3. Regular Notes Section
		if ( otherNotes.length > 0 ) {
			var regularSection = el( 'div', { class: 'seopm-notes-section' }, [
				pinnedNotes.length > 0 ? el( 'div', { class: 'seopm-notes-section-head' }, [
					el( 'span', { class: 'dashicons dashicons-edit-page', style: { color: '#64748b', fontSize: '18px' } } ),
					el( 'h2', { text: 'سایر یادداشت‌ها' } ),
					el( 'span', { class: 'seopm-badge seopm-badge-secondary', text: String( otherNotes.length ) } )
				] ) : null,
				renderNotesGrid( otherNotes )
			] );
			appContainer.appendChild( regularSection );
		}
	}

	function renderFilterBar() {
		// Business Options
		var bizOptions = [
			el( 'option', { value: '', text: 'همه کسب‌وکارها و یادداشت‌های عمومی' } ),
			el( 'option', { value: '0', text: 'فقط یادداشت‌های عمومی (همه پروژه‌ها)' } )
		];
		( state.businesses || [] ).forEach( function ( b ) {
			bizOptions.push( el( 'option', { value: String( b.id ), text: b.name } ) );
		} );

		var bizSelect = el( 'select', {
			class: 'seopm-select seopm-filter-biz',
			onchange: function ( e ) {
				state.filterBiz = e.target.value;
				fetchNotes();
			}
		}, bizOptions );
		bizSelect.value = state.filterBiz;

		// Search Input
		var searchInput = el( 'input', {
			type: 'search',
			class: 'seopm-input seopm-filter-search',
			placeholder: 'جستجو در عنوان، متن یا برچسب‌ها...',
			value: state.filterSearch,
			oninput: debounce( function ( e ) {
				state.filterSearch = e.target.value.trim();
				fetchNotes();
			}, 350 )
		} );

		// Color Filter
		var colorOptions = [ el( 'option', { value: '', text: 'همه رنگ‌ها' } ) ];
		Object.keys( state.colors || {} ).forEach( function ( ck ) {
			colorOptions.push( el( 'option', { value: ck, text: state.colors[ ck ].label } ) );
		} );
		var colorSelect = el( 'select', {
			class: 'seopm-select seopm-filter-color',
			onchange: function ( e ) {
				state.filterColor = e.target.value;
				fetchNotes();
			}
		}, colorOptions );
		colorSelect.value = state.filterColor;

		// Pin Status Filter
		var pinSelect = el( 'select', {
			class: 'seopm-select seopm-filter-pin',
			onchange: function ( e ) {
				state.filterPinned = e.target.value;
				fetchNotes();
			}
		}, [
			el( 'option', { value: 'all', text: 'همه وضعیت‌ها' } ),
			el( 'option', { value: 'pinned', text: '📌 فقط سنجاق‌شده‌ها' } ),
			el( 'option', { value: 'unpinned', text: 'سایر یادداشت‌ها' } )
		] );
		pinSelect.value = state.filterPinned;

		return el( 'div', { class: 'seopm-card seopm-notes-filter-bar' }, [
			el( 'div', { class: 'seopm-filter-group' }, [
				el( 'label', { class: 'seopm-filter-label', text: 'کسب‌وکار:' } ),
				bizSelect
			] ),
			el( 'div', { class: 'seopm-filter-group seopm-filter-search-group' }, [
				el( 'label', { class: 'seopm-filter-label', text: 'جستجو:' } ),
				searchInput
			] ),
			el( 'div', { class: 'seopm-filter-group' }, [
				el( 'label', { class: 'seopm-filter-label', text: 'رنگ:' } ),
				colorSelect
			] ),
			el( 'div', { class: 'seopm-filter-group' }, [
				el( 'label', { class: 'seopm-filter-label', text: 'سنجاق:' } ),
				pinSelect
			] )
		] );
	}

	function renderNotesGrid( notes ) {
		var grid = el( 'div', { class: 'seopm-notes-grid' } );
		notes.forEach( function ( note ) {
			grid.appendChild( renderNoteCard( note ) );
		} );
		return grid;
	}

	function renderNoteCard( note ) {
		var colorKey = note.color || 'default';
		var meta     = note.color_meta || {};
		var bg       = meta.bg || '#ffffff';
		var border   = meta.border || '#e2e8f0';
		var textCol  = meta.text || '#1e293b';

		var card = el( 'div', {
			class: 'seopm-note-card' + ( note.is_pinned ? ' is-pinned' : '' ) + ' color-' + colorKey,
			style: {
				backgroundColor: bg,
				borderColor: border,
				color: textCol
			}
		} );

		// Card Header (Pin button + Business Badge + Action Buttons)
		var pinBtn = el( 'button', {
			type: 'button',
			class: 'seopm-note-pin-btn' + ( note.is_pinned ? ' is-active' : '' ),
			title: note.is_pinned ? 'برداشتن سنجاق' : 'سنجاق کردن به بالا',
			onclick: function () {
				togglePin( note );
			}
		}, [
			el( 'span', { class: 'dashicons dashicons-admin-post' } )
		] );

		var bizBadge = null;
		if ( note.business_id > 0 ) {
			bizBadge = el( 'span', {
				class: 'seopm-note-biz-badge',
				style: { borderColor: note.business_color || '#64748b' }
			}, [
				el( 'span', { class: 'seopm-biz-dot', style: { backgroundColor: note.business_color || '#64748b' } } ),
				el( 'span', { text: note.business_name } )
			] );
		} else {
			bizBadge = el( 'span', {
				class: 'seopm-note-biz-badge is-general'
			}, [
				el( 'span', { class: 'seopm-biz-dot', style: { backgroundColor: '#64748b' } } ),
				el( 'span', { text: 'عمومی (همه پروژه‌ها)' } )
			] );
		}

		var editBtn = el( 'button', {
			type: 'button',
			class: 'seopm-icon-btn seopm-icon-sm',
			title: 'ویرایش یادداشت',
			onclick: function () {
				openNoteModal( note );
			}
		}, [ ui.icon( 'edit' ) ] );

		var copyBtn = el( 'button', {
			type: 'button',
			class: 'seopm-icon-btn seopm-icon-sm',
			title: 'کپی متن یادداشت',
			onclick: function () {
				copyNoteContent( note );
			}
		}, [ ui.icon( 'admin-page' ) ] );

		var deleteBtn = el( 'button', {
			type: 'button',
			class: 'seopm-icon-btn seopm-icon-sm seopm-text-danger',
			title: 'حذف یادداشت',
			onclick: function () {
				deleteNote( note );
			}
		}, [ ui.icon( 'trash' ) ] );

		var cardHead = el( 'div', { class: 'seopm-note-card-head' }, [
			el( 'div', { class: 'seopm-note-head-left' }, [ pinBtn, bizBadge ] ),
			el( 'div', { class: 'seopm-note-head-actions' }, [ copyBtn, editBtn, deleteBtn ] )
		] );

		// Card Body (Title + Content)
		var titleEl = note.title ? el( 'h3', { class: 'seopm-note-title', text: note.title } ) : null;

		var contentEl = el( 'div', { class: 'seopm-note-content' } );
		// Split by newlines and preserve text safely
		var paragraphs = ( note.content || '' ).split( '\n' );
		paragraphs.forEach( function ( pText ) {
			if ( pText.trim() === '' ) {
				contentEl.appendChild( el( 'div', { class: 'seopm-note-p-spacer' } ) );
			} else {
				contentEl.appendChild( el( 'p', { text: pText } ) );
			}
		} );

		// Tags
		var tagsEl = null;
		if ( note.tags && note.tags.length > 0 ) {
			var tagItems = note.tags.map( function ( t ) {
				return el( 'span', { class: 'seopm-note-tag', text: '#' + t } );
			} );
			tagsEl = el( 'div', { class: 'seopm-note-tags' }, tagItems );
		}

		// Card Footer (Dates + Quick Color Picker)
		var dateText = note.updated_at_jalali ? ( 'بروزرسانی: ' + note.updated_at_jalali ) : ( note.created_at_jalali ? ( 'ایجاد: ' + note.created_at_jalali ) : '' );
		var dateEl   = el( 'span', { class: 'seopm-note-date', text: dateText } );

		var colorDots = [];
		Object.keys( state.colors || {} ).forEach( function ( ck ) {
			var cInfo = state.colors[ ck ];
			colorDots.push( el( 'button', {
				type: 'button',
				class: 'seopm-note-color-dot' + ( colorKey === ck ? ' is-active' : '' ),
				style: { backgroundColor: cInfo.bg, borderColor: cInfo.border },
				title: cInfo.label,
				onclick: function () {
					changeNoteColor( note, ck );
				}
			} ) );
		} );
		var colorPickerEl = el( 'div', { class: 'seopm-note-quick-colors' }, colorDots );

		var cardFoot = el( 'div', { class: 'seopm-note-card-foot' }, [
			dateEl,
			colorPickerEl
		] );

		card.appendChild( cardHead );
		if ( titleEl ) {
			card.appendChild( titleEl );
		}
		card.appendChild( contentEl );
		if ( tagsEl ) {
			card.appendChild( tagsEl );
		}
		card.appendChild( cardFoot );

		return card;
	}

	function renderEmptyState() {
		var isFiltered = state.filterBiz !== '' || state.filterSearch !== '' || state.filterColor !== '' || state.filterPinned !== 'all';

		return el( 'div', { class: 'seopm-card seopm-notes-empty' }, [
			el( 'div', { class: 'seopm-empty-icon' }, [
				el( 'span', { class: 'dashicons dashicons-welcome-write-blog', style: { fontSize: '48px', width: '48px', height: '48px', color: '#94a3b8' } } )
			] ),
			el( 'h3', { text: isFiltered ? 'هیچ یادداشتی با فیلترهای انتخابی یافت نشد.' : 'هنوز هیچ یادداشتی ثبت نشده است.' } ),
			el( 'p', { class: 'seopm-muted', text: isFiltered ? 'می‌توانید فیلترها را پاک کنید یا یادداشت جدیدی ثبت نمایید.' : 'ایده‌ها، چک‌لیست‌ها، اهداف سئو و نکات مهم پروژه‌های خود را اینجا یادداشت کنید.' } ),
			el( 'div', { style: { marginTop: '16px' } }, [
				isFiltered ? ui.button( 'پاکسازی فیلترها', 'ghost seopm-btn-sm', function () {
					state.filterBiz    = '';
					state.filterSearch = '';
					state.filterColor  = '';
					state.filterPinned = 'all';
					fetchNotes();
				}, 'dismiss' ) : null,
				ui.button( 'ثبت یادداشت جدید', 'primary seopm-btn-sm', function () {
					openNoteModal( null );
				}, 'plus-alt2' )
			] )
		] );
	}

	function openNoteModal( note ) {
		var isEdit    = Boolean( note && note.id );
		var selectedColor = ( note && note.color ) || 'default';

		var titleInput = el( 'input', {
			type: 'text',
			class: 'seopm-input seopm-w-full',
			placeholder: 'عنوان یادداشت (اختیاری)',
			value: ( note && note.title ) || ''
		} );

		var bizOptions = [
			el( 'option', { value: '0', text: 'یادداشت عمومی (همه پروژه‌ها)' } )
		];
		( state.businesses || [] ).forEach( function ( b ) {
			bizOptions.push( el( 'option', { value: String( b.id ), text: b.name } ) );
		} );
		var bizSelect = el( 'select', { class: 'seopm-select seopm-w-full' }, bizOptions );
		bizSelect.value = String( ( note && note.business_id ) || ( state.filterBiz && state.filterBiz !== 'all' ? state.filterBiz : '0' ) );

		var contentArea = el( 'textarea', {
			class: 'seopm-textarea seopm-w-full',
			rows: '7',
			placeholder: 'متن یادداشت، ایده‌ها، چک‌لیست یا توضیحات استراتژی...',
			text: ( note && note.content ) || ''
		} );

		var pinCheckbox = el( 'input', {
			type: 'checkbox',
			id: 'seopm-modal-pin-checkbox',
			class: 'seopm-checkbox'
		} );
		pinCheckbox.checked = Boolean( note && note.is_pinned );

		var pinLabel = el( 'label', {
			for: 'seopm-modal-pin-checkbox',
			class: 'seopm-checkbox-label',
			style: { cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }
		}, [
			el( 'span', { class: 'dashicons dashicons-admin-post', style: { color: '#f59e0b' } } ),
			el( 'span', { text: 'سنجاق کردن به بالای صفحه (Pinned)' } )
		] );

		var tagsInput = el( 'input', {
			type: 'text',
			class: 'seopm-input seopm-w-full',
			placeholder: 'برچسب‌ها با کاما (مثال: محتوا, تکنیکال, لینک‌سازی)',
			value: ( note && note.tags_raw ) || ''
		} );

		// Color Swatches
		var colorSwatches = el( 'div', { class: 'seopm-modal-color-swatches' } );
		Object.keys( state.colors || {} ).forEach( function ( ck ) {
			var cInfo = state.colors[ ck ];
			var swatch = el( 'button', {
				type: 'button',
				class: 'seopm-modal-color-swatch' + ( selectedColor === ck ? ' is-selected' : '' ),
				style: { backgroundColor: cInfo.bg, borderColor: cInfo.border },
				title: cInfo.label,
				onclick: function () {
					selectedColor = ck;
					colorSwatches.querySelectorAll( '.seopm-modal-color-swatch' ).forEach( function ( s ) {
						s.classList.remove( 'is-selected' );
					} );
					swatch.classList.add( 'is-selected' );
				}
			}, [
				selectedColor === ck ? el( 'span', { class: 'dashicons dashicons-yes' } ) : null
			] );
			colorSwatches.appendChild( swatch );
		} );

		var formBody = el( 'div', { class: 'seopm-note-form' }, [
			el( 'div', { class: 'seopm-form-field' }, [
				el( 'label', { class: 'seopm-label', text: 'عنوان یادداشت:' } ),
				titleInput
			] ),
			el( 'div', { class: 'seopm-form-field' }, [
				el( 'label', { class: 'seopm-label', text: 'کسب‌وکار مرتبط:' } ),
				bizSelect
			] ),
			el( 'div', { class: 'seopm-form-field' }, [
				el( 'label', { class: 'seopm-label', text: 'متن یادداشت:' } ),
				contentArea
			] ),
			el( 'div', { class: 'seopm-form-field' }, [
				el( 'label', { class: 'seopm-label', text: 'انتخاب رنگ یادداشت:' } ),
				colorSwatches
			] ),
			el( 'div', { class: 'seopm-form-field' }, [
				el( 'label', { class: 'seopm-label', text: 'برچسب‌ها:' } ),
				tagsInput
			] ),
			el( 'div', { class: 'seopm-form-field seopm-form-checkbox-field' }, [
				pinCheckbox,
				pinLabel
			] )
		] );

		var m = ui.modal( {
			title: isEdit ? 'ویرایش یادداشت' : 'یادداشت جدید',
			size: 'md',
			body: formBody,
			footer: [
				ui.button( 'انصراف', 'ghost', function () {
					m.close();
				} ),
				ui.button( isEdit ? 'ذخیره تغییرات' : 'ثبت یادداشت', 'primary', function () {
					var titleVal   = titleInput.value.trim();
					var contentVal = contentArea.value.trim();

					if ( ! titleVal && ! contentVal ) {
						ui.toast( 'لطفاً عنوان یا متن یادداشت را وارد کنید.', 'error' );
						contentArea.focus();
						return;
					}

					m.setBusy( true );

					var payload = {
						title: titleVal,
						content: contentVal,
						business_id: parseInt( bizSelect.value, 10 ) || 0,
						color: selectedColor,
						is_pinned: pinCheckbox.checked ? 1 : 0,
						tags: tagsInput.value.trim()
					};

					var req = isEdit
						? ui.api( '/notes/' + note.id, { method: 'POST', data: payload } )
						: ui.api( '/notes', { method: 'POST', data: payload } );

					req.then( function ( res ) {
						m.close();
						ui.toast( isEdit ? 'یادداشت با موفقیت بروزرسانی شد.' : 'یادداشت جدید با موفقیت ثبت شد.', 'success' );
						fetchNotes();
					} ).catch( function ( err ) {
						m.setBusy( false );
					} );
				}, isEdit ? 'yes' : 'plus-alt2' )
			]
		} );
	}

	function togglePin( note ) {
		ui.api( '/notes/' + note.id + '/pin', { method: 'POST' } ).then( function ( updated ) {
			note.is_pinned = updated.is_pinned;
			ui.toast( note.is_pinned ? 'یادداشت سنجاق شد.' : 'سنجاق یادداشت برداشته شد.', 'info' );
			fetchNotes();
		} ).catch( function () {} );
	}

	function changeNoteColor( note, newColor ) {
		if ( note.color === newColor ) {
			return;
		}
		ui.api( '/notes/' + note.id, {
			method: 'POST',
			data: { color: newColor }
		} ).then( function ( updated ) {
			note.color      = updated.color;
			note.color_meta = updated.color_meta;
			fetchNotes();
		} ).catch( function () {} );
	}

	function deleteNote( note ) {
		ui.confirm( 'آیا از حذف این یادداشت اطمینان دارید؟ این عملیات قابل بازگشت نیست.', {
			title: 'حذف یادداشت',
			danger: true,
			confirmText: 'حذف شود'
		} ).then( function ( ok ) {
			if ( ! ok ) {
				return;
			}
			ui.api( '/notes/' + note.id, { method: 'DELETE' } ).then( function () {
				ui.toast( 'یادداشت حذف شد.', 'success' );
				fetchNotes();
			} );
		} );
	}

	function copyNoteContent( note ) {
		var fullText = '';
		if ( note.title ) {
			fullText += note.title + '\n\n';
		}
		fullText += ( note.content || '' );
		if ( note.tags && note.tags.length ) {
			fullText += '\n\nبرچسب‌ها: ' + note.tags.join( ', ' );
		}

		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( fullText ).then( function () {
				ui.toast( 'متن یادداشت در کلیپ‌بورد کپی شد.', 'success' );
			} ).catch( function () {
				fallbackCopy( fullText );
			} );
		} else {
			fallbackCopy( fullText );
		}
	}

	function fallbackCopy( text ) {
		var ta = document.createElement( 'textarea' );
		ta.value = text;
		ta.style.position = 'fixed';
		ta.style.opacity = '0';
		document.body.appendChild( ta );
		ta.select();
		try {
			document.execCommand( 'copy' );
			ui.toast( 'متن یادداشت در کلیپ‌بورد کپی شد.', 'success' );
		} catch ( e ) {
			ui.toast( 'امکان کپی خودکار فراهم نشد.', 'error' );
		}
		ta.remove();
	}

	function debounce( fn, delay ) {
		var timer = null;
		return function () {
			var ctx = this;
			var args = arguments;
			clearTimeout( timer );
			timer = setTimeout( function () {
				fn.apply( ctx, args );
			}, delay );
		};
	}

	// Bootstrap when DOM is ready
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

} )( window, document );

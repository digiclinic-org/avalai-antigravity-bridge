/**
 * Dashboard page.
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var ui = SEOPM.ui;
	var J = SEOPM.jalali;
	var el = ui.el;
	var C = SEOPM.config;
	var root = document.getElementById( 'seopm-dashboard' );
	if ( ! root ) {
		return;
	}

	function load() {
		ui.api( '/dashboard' ).then( render );
	}

	function tasksUrl( query ) {
		return C.urls.tasks + ( query ? '&' + query : '' );
	}

	function stat( label, value, mod, iconName, href ) {
		return el( href ? 'a' : 'div', { class: 'seopm-stat seopm-stat-' + mod + ( href ? ' seopm-stat-link' : '' ), href: href || null }, [
			el( 'div', { class: 'seopm-stat-icon' }, ui.icon( iconName ) ),
			el( 'div', {}, [ el( 'div', { class: 'seopm-stat-value', text: J.faDigits( value ) } ), el( 'div', { class: 'seopm-stat-label', text: label } ) ] )
		] );
	}

	function ring( pct ) {
		var r = 26, c = 2 * Math.PI * r;
		var ns = 'http://www.w3.org/2000/svg';
		var svg = document.createElementNS( ns, 'svg' );
		svg.setAttribute( 'viewBox', '0 0 64 64' );
		svg.setAttribute( 'class', 'seopm-ring' );
		[ [ '#e5e7eb', c ], [ 'currentColor', c * ( 1 - pct / 100 ) ] ].forEach( function ( p, i ) {
			var circle = document.createElementNS( ns, 'circle' );
			circle.setAttribute( 'cx', '32' );
			circle.setAttribute( 'cy', '32' );
			circle.setAttribute( 'r', String( r ) );
			circle.setAttribute( 'fill', 'none' );
			circle.setAttribute( 'stroke', p[ 0 ] );
			circle.setAttribute( 'stroke-width', '7' );
			if ( i === 1 ) {
				circle.setAttribute( 'stroke-dasharray', String( c ) );
				circle.setAttribute( 'stroke-dashoffset', String( p[ 1 ] ) );
				circle.setAttribute( 'stroke-linecap', 'round' );
				circle.setAttribute( 'transform', 'rotate(-90 32 32)' );
			}
			svg.appendChild( circle );
		} );
		return svg;
	}

	function taskRow( task, extra ) {
		return el( 'li', { class: 'seopm-list-item', tabindex: '0', onclick: function () {
			SEOPM.taskForm.details( task, { onChange: load } );
		}, onkeydown: function ( e ) {
			if ( e.key === 'Enter' ) {
				SEOPM.taskForm.details( task, { onChange: load } );
			}
		} }, [
			el( 'i', { class: 'seopm-dot', style: { background: task.business_color } } ),
			el( 'div', { class: 'seopm-list-main' }, [
				el( 'div', { class: 'seopm-list-title', text: task.title } ),
				el( 'div', { class: 'seopm-list-sub seopm-muted', text: task.business_name + ' · ' + task.task_type_label } )
			] ),
			extra
		] );
	}

	function panel( title, iconName, items, emptyText, render, mod, moreHref ) {
		return el( 'section', { class: 'seopm-card seopm-panel ' + ( mod || '' ) }, [
			el( 'h3', {}, [
				ui.icon( iconName ),
				title,
				items.length ? el( 'span', { class: 'seopm-count', text: J.faDigits( items.length ) } ) : null,
				moreHref && items.length ? el( 'a', { class: 'seopm-panel-more', href: moreHref, text: 'مشاهده همه' } ) : null
			] ),
			items.length ? el( 'ul', { class: 'seopm-list' }, items.map( render ) ) : ui.emptyState( emptyText )
		] );
	}

	function render( data ) {
		ui.clear( root );
		var s = data.stats;

		var completion = el( 'div', { class: 'seopm-stat seopm-stat-rate' }, [
			el( 'div', { class: 'seopm-ring-wrap' }, [ ring( s.completion ), el( 'span', { text: J.faDigits( s.completion + '%' ) } ) ] ),
			el( 'div', {}, [ el( 'div', { class: 'seopm-stat-label', text: 'درصد تکمیل کل تسک‌ها' } ), el( 'div', { class: 'seopm-muted seopm-small', text: J.faDigits( s.completed ) + ' از ' + J.faDigits( s.total ) } ) ] )
		] );

		root.appendChild( el( 'div', { class: 'seopm-stats' }, [
			stat( 'کسب‌وکارها', s.businesses, 'biz', 'store', C.urls.businesses ),
			stat( 'کل تسک‌ها', s.total, 'total', 'list-view', tasksUrl() ),
			stat( 'در انتظار', s.pending, 'pending', 'clock', tasksUrl( 'status=pending' ) ),
			stat( 'در حال انجام', s.in_progress, 'in_progress', 'update', tasksUrl( 'status=in_progress' ) ),
			stat( 'تکمیل‌شده', s.completed, 'completed', 'yes-alt', tasksUrl( 'status=completed' ) ),
			completion
		] ) );

		root.appendChild( el( 'div', { class: 'seopm-two-col' }, [
			panel( 'تسک‌های عقب‌افتاده', 'warning', data.overdue, 'هیچ تسک عقب‌افتاده‌ای وجود ندارد. عالی است!', function ( t ) {
				return taskRow( t, el( 'div', { class: 'seopm-list-end' }, [
					el( 'span', { class: 'seopm-overdue-days', text: ui.dueText( t.due_date ) } ),
					el( 'button', { type: 'button', class: 'seopm-icon-btn seopm-quick-done', title: 'تکمیل شد', 'aria-label': 'علامت‌گذاری به‌عنوان تکمیل‌شده', onclick: function ( e ) {
						e.stopPropagation();
						SEOPM.taskForm.setStatus( t, 'completed' ).then( load );
					} }, ui.icon( 'yes' ) )
				] ) );
			}, 'seopm-panel-danger', tasksUrl( 'status=overdue' ) ),
			panel( 'نزدیک به موعد (۷ روز آینده)', 'clock', data.upcoming, 'تسکی برای هفته پیش رو برنامه‌ریزی نشده است.', function ( t ) {
				return taskRow( t, el( 'div', { class: 'seopm-list-end' }, [ ui.statusBadge( t ), el( 'span', { class: 'seopm-small seopm-muted', text: ui.dueText( t.due_date ) } ) ] ) );
			}, '', tasksUrl( 'status=open&from=' + data.today + '&to=' + J.addDays( data.today, 7 ) ) )
		] ) );

		var bizSection = el( 'section', { class: 'seopm-card seopm-panel' }, [ el( 'h3', {}, [ ui.icon( 'store' ), 'خلاصه فعالیت کسب‌وکارها' ] ) ] );
		if ( data.businesses.length ) {
			bizSection.appendChild( el( 'div', { class: 'seopm-biz-summary' }, data.businesses.map( function ( b ) {
				return el( 'a', { class: 'seopm-biz-row', href: C.urls.tasks + '&business=' + b.id, style: { '--seopm-biz': b.color } }, [
					el( 'div', { class: 'seopm-biz-name' }, [ el( 'i', { class: 'seopm-dot', style: { background: b.color } } ), b.name ] ),
					el( 'div', { class: 'seopm-biz-bar' }, ui.progress( b.completion, b.color ) ),
					el( 'div', { class: 'seopm-biz-nums seopm-small' }, [
						el( 'b', { text: J.faDigits( b.completion + '%' ) } ),
						el( 'span', { class: 'seopm-muted', text: J.faDigits( b.task_completed + '/' + b.task_total ) } ),
						b.task_overdue ? el( 'span', { class: 'seopm-text-danger', text: '⚠ ' + J.faDigits( b.task_overdue ) } ) : null
					] )
				] );
			} ) ) );
		} else {
			bizSection.appendChild( ui.emptyState( 'هنوز کسب‌وکاری ثبت نشده است.', el( 'a', { class: 'seopm-btn seopm-btn-primary', href: C.urls.businesses + '&new=1', text: 'ایجاد اولین کسب‌وکار' } ) ) );
		}

		root.appendChild( el( 'div', { class: 'seopm-two-col' }, [
			bizSection,
			panel( 'آخرین تسک‌های ایجادشده', 'plus-alt', data.recent, 'هنوز تسکی ایجاد نشده است.', function ( t ) {
				return taskRow( t, el( 'div', { class: 'seopm-list-end' }, [ ui.statusBadge( t ), el( 'span', { class: 'seopm-small seopm-muted', text: J.format( t.due_date ) } ) ] ) );
			}, '', tasksUrl( 'orderby=created_at&order=desc' ) )
		] ) );
	}

	document.addEventListener( 'seopm:new-task', function () {
		SEOPM.taskForm.open( { onSaved: load } );
	} );

	if ( C.initialData ) {
		var init = C.initialData;
		C.initialData = null;
		render( init );
	} else {
		load();
	}
}( window, document ) );

/**
 * Settings page: tabs, AI providers, media picker for logo, color picker, test connection.
 */
( function ( window, document, $ ) {
	'use strict';

	var SEOPM = window.SEOPM || {};
	var ui = SEOPM.ui;

	/* ------------------------------ Tabs ------------------------------ */
	var tabsContainer = document.getElementById( 'seopm-settings-tabs' );
	if ( tabsContainer ) {
		var tabButtons = tabsContainer.querySelectorAll( 'button[data-tab]' );
		var panes = {
			ai: document.getElementById( 'seopm-pane-ai' ),
			branding: document.getElementById( 'seopm-pane-branding' ),
			telegram: document.getElementById( 'seopm-pane-telegram' ),
			'task-types': document.getElementById( 'seopm-pane-task-types' ),
			system: document.getElementById( 'seopm-pane-system' )
		};

		function switchTab( targetTab ) {
			if ( ! panes[ targetTab ] ) {
				targetTab = 'ai';
			}
			tabButtons.forEach( function ( btn ) {
				var isActive = btn.getAttribute( 'data-tab' ) === targetTab;
				btn.classList.toggle( 'is-active', isActive );
			} );
			Object.keys( panes ).forEach( function ( k ) {
				if ( panes[ k ] ) {
					panes[ k ].style.display = ( k === targetTab ) ? 'block' : 'none';
				}
			} );
			if ( targetTab === 'task-types' && typeof loadTaskTypes === 'function' ) {
				loadTaskTypes();
			}
			if ( window.history && window.history.replaceState ) {
				window.history.replaceState( null, '', '#tab-' + targetTab );
			}
		}

		tabButtons.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				switchTab( btn.getAttribute( 'data-tab' ) );
			} );
		} );

		// Check hash on load
		var initialHash = ( window.location.hash || '' ).replace( '#tab-', '' );
		if ( initialHash && panes[ initialHash ] ) {
			switchTab( initialHash );
		} else {
			switchTab( 'ai' );
		}
	}

	/* -------------------- Active Provider Selector -------------------- */
	var providerRadios = document.querySelectorAll( 'input[name="seopm[ai_active_provider]"]' );
	var activateBtns = document.querySelectorAll( '.seopm-activate-provider-btn' );
	var providerCards = document.querySelectorAll( '.seopm-provider-config-card[data-provider-card]' );
	var activeBadge = document.getElementById( 'seopm-active-provider-badge' );

	function syncActiveProviderUI( selectedVal ) {
		var selectedLabel = '';
		var cards = document.querySelectorAll( '.seopm-ai-select-card' );
		cards.forEach( function ( c ) {
			var input = c.querySelector( 'input[type="radio"]' );
			var match = input && input.value === selectedVal;
			if ( input && match ) {
				input.checked = true;
				selectedLabel = c.getAttribute( 'data-provider-label' ) || selectedVal;
			}
			c.classList.toggle( 'is-selected', Boolean( match ) );
		} );

		providerCards.forEach( function ( card ) {
			var isAct = card.getAttribute( 'data-provider-card' ) === selectedVal;
			card.classList.toggle( 'is-active-provider', isAct );
		} );

		activateBtns.forEach( function ( btn ) {
			var isAct = btn.getAttribute( 'data-activate-provider' ) === selectedVal;
			btn.classList.toggle( 'is-active', isAct );
			var txt = btn.querySelector( '.seopm-activate-text' );
			if ( txt ) {
				txt.textContent = isAct ? 'ارائه‌دهنده فعال' : 'انتخاب به‌عنوان ارائه‌دهنده فعال';
			}
		} );

		if ( activeBadge && selectedLabel ) {
			activeBadge.textContent = 'ارائه‌دهنده فعال انتخابی: ' + selectedLabel + ' (برای اعمال ذخیره کنید)';
			activeBadge.style.background = '#ecfdf5';
			activeBadge.style.color = '#047857';
			activeBadge.style.borderColor = '#a7f3d0';
		}
	}

	providerRadios.forEach( function ( r ) {
		r.addEventListener( 'change', function () {
			if ( r.checked ) {
				syncActiveProviderUI( r.value );
			}
		} );
	} );

	activateBtns.forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var p = btn.getAttribute( 'data-activate-provider' );
			if ( p ) {
				syncActiveProviderUI( p );
				if ( ui && ui.toast ) {
					ui.toast( 'به‌عنوان ارائه‌دهنده فعال انتخاب شد — برای اعمال نهایی روی «ذخیره تنظیمات» کلیک کنید.' );
				}
			}
		} );
	} );

	/* ------------------- Key Visibility Toggle ------------------- */
	var toggleBtns = document.querySelectorAll( '.seopm-toggle-key-visibility' );
	toggleBtns.forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var targetId = btn.getAttribute( 'data-target' );
			var input = document.getElementById( targetId );
			if ( ! input ) {
				return;
			}
			var isPassword = input.type === 'password';
			input.type = isPassword ? 'text' : 'password';
			var icon = btn.querySelector( '.dashicons' );
			if ( icon ) {
				icon.className = 'dashicons dashicons-' + ( isPassword ? 'hidden' : 'visibility' );
			}
		} );
	} );

	/* -------------------- AI Test Connection -------------------- */
	var testBtns = document.querySelectorAll( '.seopm-test-ai-btn' );
	testBtns.forEach( function ( btn ) {
		btn.addEventListener( 'click', function () {
			var provider = btn.getAttribute( 'data-provider' );
			var keyInput = document.getElementById( 'seopm-' + provider + '-key' );
			var modelSelect = document.getElementById( 'seopm-' + provider + '-model' );
			var urlInput = document.getElementById( 'seopm-' + provider + '-url' );
			var resultBox = document.getElementById( 'seopm-test-result-' + provider );

			if ( ! resultBox ) {
				return;
			}

			var apiKey = keyInput ? keyInput.value.trim() : '';
			var customModelInput = document.getElementById( 'seopm-' + provider + '-custom-model' );
			var customModel = customModelInput ? customModelInput.value.trim() : '';
			var model = customModel || ( modelSelect ? modelSelect.value : '' );
			var baseUrl = urlInput ? urlInput.value.trim() : '';

			btn.disabled = true;
			btn.classList.add( 'is-loading' );
			resultBox.innerHTML = '<span class="seopm-test-spinner"></span> <span class="seopm-muted">در حال برقراری ارتباط و بررسی کلید...</span>';
			resultBox.className = 'seopm-test-result seopm-test-running';

			if ( ui && ui.api ) {
				ui.api( '/ai/test-connection', {
					method: 'POST',
					data: {
						provider: provider,
						api_key: apiKey,
						model: model,
						base_url: baseUrl
					},
					silent: true
				} ).then( function ( res ) {
					btn.disabled = false;
					btn.classList.remove( 'is-loading' );
					if ( res && res.success ) {
						resultBox.className = 'seopm-test-result seopm-test-success';
						resultBox.innerHTML = '<span class="dashicons dashicons-yes-alt" style="color:#047857; font-size:18px;"></span> ' +
							'<strong>اتصال موفق!</strong> ' + ( res.message || '' ) +
							( res.latency_ms ? ' <span class="seopm-badge" style="background:#dcfce7; color:#166534; font-size:11px;">' + res.latency_ms + 'ms</span>' : '' );
						if ( ui.toast ) {
							ui.toast( 'اتصال به ' + provider + ' با موفقیت برقرار شد.', 'success' );
						}
					} else {
						resultBox.className = 'seopm-test-result seopm-test-error';
						resultBox.innerHTML = '<span class="dashicons dashicons-warning" style="color:#b91c1c; font-size:18px;"></span> ' +
							'<strong>خطا در اتصال:</strong> ' + ( ( res && res.message ) || 'برقراری ارتباط با سرویس انجام نشد.' );
						if ( ui.toast ) {
							ui.toast( ( res && res.message ) || 'خطا در اتصال به API', 'error' );
						}
					}
				} ).catch( function ( err ) {
					btn.disabled = false;
					btn.classList.remove( 'is-loading' );
					resultBox.className = 'seopm-test-result seopm-test-error';
					resultBox.innerHTML = '<span class="dashicons dashicons-warning" style="color:#b91c1c; font-size:18px;"></span> ' +
						'<strong>خطا:</strong> ' + ( ( err && err.message ) || 'خطای غیرمنتظره در ارسال درخواست.' );
					if ( ui.toast ) {
						ui.toast( ( err && err.message ) || 'خطای غیرمنتظره', 'error' );
					}
				} );
			}
		} );
	} );

	/* ---------------------- Media Picker ---------------------- */
	var select = document.getElementById( 'seopm-logo-select' );
	var remove = document.getElementById( 'seopm-logo-remove' );
	var idInput = document.getElementById( 'seopm-logo-id' );
	var preview = document.getElementById( 'seopm-logo-preview' );
	var frame;

	function setPreview( url ) {
		while ( preview && preview.firstChild ) {
			preview.removeChild( preview.firstChild );
		}
		if ( url ) {
			var img = document.createElement( 'img' );
			img.src = url;
			img.alt = '';
			preview.appendChild( img );
		} else if ( preview ) {
			var icon = document.createElement( 'span' );
			icon.className = 'dashicons dashicons-format-image';
			preview.appendChild( icon );
		}
	}

	if ( select && window.wp && window.wp.media ) {
		select.addEventListener( 'click', function () {
			if ( ! frame ) {
				frame = window.wp.media( { title: 'انتخاب لوگو', button: { text: 'استفاده به‌عنوان لوگو' }, library: { type: 'image' }, multiple: false } );
				frame.on( 'select', function () {
					var a = frame.state().get( 'selection' ).first().toJSON();
					if ( idInput ) {
						idInput.value = a.id;
					}
					setPreview( ( a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url ) );
					if ( remove ) {
						remove.hidden = false;
					}
				} );
			}
			frame.open();
		} );
		if ( remove ) {
			remove.addEventListener( 'click', function () {
				if ( idInput ) {
					idInput.value = 0;
				}
				setPreview( '' );
				remove.hidden = true;
			} );
		}
	}

	if ( $ && $.fn.wpColorPicker ) {
		$( '.seopm-color' ).wpColorPicker();
	}

	var toggle = document.getElementById( 'seopm-use-business-color' );
	var colorField = document.getElementById( 'seopm-report-color-field' );
	function sync() {
		if ( toggle && colorField ) {
			colorField.classList.toggle( 'is-disabled', toggle.checked );
		}
	}
	if ( toggle ) {
		toggle.addEventListener( 'change', sync );
		sync();
	}

	/* ------------------------------ Telegram Settings ------------------------------ */
	var tgTokenInput = document.getElementById( 'seopm-tg-token' );
	var tgUsernameInput = document.getElementById( 'seopm-tg-username' );
	var tgProxyUrlInput = document.getElementById( 'seopm-tg-proxy-url' );
	var tgProxySecretInput = document.getElementById( 'seopm-tg-proxy-secret' );
	var tgAdminChatInput = document.getElementById( 'seopm-tg-admin-chat' );
	var testTgConnBtn = document.getElementById( 'seopm-btn-test-tg-conn' );
	var testTgMsgBtn = document.getElementById( 'seopm-btn-test-tg-msg' );
	var runTgDailyBtn = document.getElementById( 'seopm-btn-run-tg-daily' );
	var fetchRecentChatsBtn = document.getElementById( 'seopm-btn-fetch-recent-chats' );
	var tgTestStatus = document.getElementById( 'seopm-tg-test-status' );
	var tgDailyStatus = document.getElementById( 'seopm-tg-daily-status' );
	var tgRecentChatsWrap = document.getElementById( 'seopm-tg-recent-chats-wrap' );

	function showNotice( elTarget, type, msg ) {
		if ( ! elTarget ) {
			return;
		}
		elTarget.className = 'seopm-notice seopm-notice-' + ( type === 'success' ? 'success' : 'error' );
		elTarget.textContent = msg;
		elTarget.style.display = 'block';
	}

	if ( testTgConnBtn ) {
		testTgConnBtn.addEventListener( 'click', function () {
			var token = tgTokenInput ? tgTokenInput.value.trim() : '';
			if ( ! token ) {
				showNotice( tgTestStatus, 'error', 'لطفاً ابتدا توکن ربات تلگرام را وارد کنید.' );
				return;
			}
			testTgConnBtn.disabled = true;
			showNotice( tgTestStatus, 'info', 'در حال بررسی اتصال به سرورهای تلگرام...' );

			ui.api( '/telegram/test-connection', {
				method: 'POST',
				data: {
					bot_token: token,
					proxy_url: tgProxyUrlInput ? tgProxyUrlInput.value.trim() : '',
					proxy_secret: tgProxySecretInput ? tgProxySecretInput.value.trim() : ''
				},
				silent: true
			} ).then( function ( res ) {
				testTgConnBtn.disabled = false;
				if ( res && res.bot_username && tgUsernameInput ) {
					tgUsernameInput.value = res.bot_username;
				}
				showNotice( tgTestStatus, 'success', ( res && res.message ) || 'اتصال تلگرام با موفقیت برقرار شد.' );
			} ).catch( function ( err ) {
				testTgConnBtn.disabled = false;
				showNotice( tgTestStatus, 'error', ( err && err.message ) || 'خطا در برقراری اتصال به تلگرام.' );
			} );
		} );
	}

	if ( testTgMsgBtn ) {
		testTgMsgBtn.addEventListener( 'click', function () {
			var chatId = tgAdminChatInput ? tgAdminChatInput.value.trim() : '';
			if ( ! chatId ) {
				showNotice( tgTestStatus, 'error', 'لطفاً ابتدا شناسه چت مدیر (Chat ID) را وارد کنید.' );
				return;
			}
			testTgMsgBtn.disabled = true;
			showNotice( tgTestStatus, 'info', 'در حال ارسال پیام تست به تلگرام...' );

			ui.api( '/telegram/test-message', {
				method: 'POST',
				data: {
					chat_id: chatId,
					bot_token: tgTokenInput ? tgTokenInput.value.trim() : '',
					proxy_url: tgProxyUrlInput ? tgProxyUrlInput.value.trim() : '',
					proxy_secret: tgProxySecretInput ? tgProxySecretInput.value.trim() : ''
				},
				silent: true
			} ).then( function ( res ) {
				testTgMsgBtn.disabled = false;
				showNotice( tgTestStatus, 'success', ( res && res.message ) || 'پیام تست به تلگرام ارسال شد.' );
			} ).catch( function ( err ) {
				testTgMsgBtn.disabled = false;
				showNotice( tgTestStatus, 'error', ( err && err.message ) || 'خطا در ارسال پیام تست تلگرام.' );
			} );
		} );
	}

	if ( runTgDailyBtn ) {
		runTgDailyBtn.addEventListener( 'click', function () {
			runTgDailyBtn.disabled = true;
			showNotice( tgDailyStatus, 'info', 'در حال بررسی مقالات فردا و ارسال پیش‌نمایش‌ها...' );

			ui.api( '/telegram/run-daily-check', {
				method: 'POST',
				silent: true
			} ).then( function ( res ) {
				runTgDailyBtn.disabled = false;
				var sent = res.sent || 0;
				var skipped = res.skipped || 0;
				var errors = res.errors ? res.errors.length : 0;
				var msg = 'بررسی مقالات با موفقیت انجام شد: ' + sent + ' پیام ارسال شد، ' + skipped + ' مورد رد شد، ' + errors + ' خطا.';
				showNotice( tgDailyStatus, errors ? 'warning' : 'success', msg );
			} ).catch( function ( err ) {
				runTgDailyBtn.disabled = false;
				showNotice( tgDailyStatus, 'error', ( err && err.message ) || 'خطا در اجرای بررسی روزانه.' );
			} );
		} );
	}

	if ( fetchRecentChatsBtn && tgRecentChatsWrap ) {
		fetchRecentChatsBtn.addEventListener( 'click', function () {
			fetchRecentChatsBtn.disabled = true;
			tgRecentChatsWrap.innerHTML = '<span class="seopm-test-spinner"></span> در حال واکشی چت‌های اخیر ربات...';

			ui.api( '/telegram/recent-chats', { silent: true } ).then( function ( res ) {
				fetchRecentChatsBtn.disabled = false;
				var chats = ( res && res.chats ) ? res.chats : [];
				if ( ! chats.length ) {
					tgRecentChatsWrap.innerHTML = '<p class="seopm-muted seopm-small">هیچ چتی با ربات یافت نشد. لطفاً در تلگرام به ربات پیام بدهید یا دکمه Start را بزنید، سپس دوباره امتحان کنید.</p>';
					return;
				}

				var table = document.createElement( 'table' );
				table.className = 'seopm-table seopm-small';
				table.style.marginTop = '8px';
				table.innerHTML = '<thead><tr><th>نام / عنوان</th><th>نام کاربری</th><th>شناسه چت (Chat ID)</th><th>آخرین پیام</th><th>عملیات</th></tr></thead><tbody></tbody>';
				var tbody = table.querySelector( 'tbody' );

				chats.forEach( function ( c ) {
					var tr = document.createElement( 'tr' );
					tr.innerHTML = '<td><strong>' + ( c.title || '' ) + '</strong></td>'
						+ '<td dir="ltr">' + ( c.username || '-' ) + '</td>'
						+ '<td dir="ltr" style="font-family:monospace; font-weight:700;">' + c.chat_id + '</td>'
						+ '<td class="seopm-muted">' + ( c.last_text || '' ) + '</td>'
						+ '<td><button type="button" class="seopm-btn seopm-btn-ghost seopm-btn-xs seopm-use-chat-btn">استفاده به‌عنوان مدیر</button></td>';

					var useBtn = tr.querySelector( '.seopm-use-chat-btn' );
					useBtn.addEventListener( 'click', function () {
						if ( tgAdminChatInput ) {
							tgAdminChatInput.value = c.chat_id;
							showNotice( tgTestStatus, 'success', 'شناسه چت ' + c.chat_id + ' در کادر چت مدیر قرار گرفت؛ اکنون دکمه «ذخیره تنظیمات» را بزنید.' );
						}
					} );
					tbody.appendChild( tr );
				} );

				tgRecentChatsWrap.innerHTML = '';
				tgRecentChatsWrap.appendChild( table );
			} ).catch( function ( err ) {
				fetchRecentChatsBtn.disabled = false;
				tgRecentChatsWrap.innerHTML = '<p class="seopm-danger seopm-small">خطا: ' + ( ( err && err.message ) || 'واکشی ناموفق' ) + '</p>';
			} );
		} );
	}

	/* -------------------- Task Types Management -------------------- */
	var typesTableWrap = document.getElementById( 'seopm-types-table-wrap' );
	var newTypeLabel = document.getElementById( 'seopm-new-type-label' );
	var newTypeKey = document.getElementById( 'seopm-new-type-key' );
	var addTypeBtn = document.getElementById( 'seopm-btn-add-type' );
	var typeAddMsg = document.getElementById( 'seopm-type-add-msg' );

	function renderTypesTable( list ) {
		if ( ! typesTableWrap ) {
			return;
		}
		if ( ! list || ! list.length ) {
			typesTableWrap.innerHTML = '<p class="seopm-muted">هیچ نوع تسکی یافت نشد.</p>';
			return;
		}

		var table = document.createElement( 'table' );
		table.className = 'seopm-types-table';
		table.innerHTML = '<thead><tr>'
			+ '<th style="width:30%;">عنوان نوع تسک</th>'
			+ '<th style="width:25%;">شناسه (Key)</th>'
			+ '<th style="width:20%;">نوع</th>'
			+ '<th style="width:15%;">تعداد تسک‌های متصل</th>'
			+ '<th style="width:10%; text-align:center;">عملیات</th>'
			+ '</tr></thead><tbody></tbody>';

		var tbody = table.querySelector( 'tbody' );
		list.forEach( function ( item ) {
			var tr = document.createElement( 'tr' );
			var isBuiltin = item.is_builtin;
			var typeBadge = isBuiltin
				? '<span class="seopm-badge" style="background:#e0f2fe; color:#0369a1; font-size:11px;">پیش‌فرض سیستم</span>'
				: '<span class="seopm-badge" style="background:#fef3c7; color:#92400e; font-size:11px;">سفارشی کاربر</span>';

			var countText = ( item.task_count > 0 )
				? '<strong style="color:var(--seopm-primary);">' + item.task_count + ' تسک</strong>'
				: '<span class="seopm-muted">۰ تسک</span>';

			var actionHtml = '';
			if ( isBuiltin ) {
				actionHtml = '<span class="seopm-muted seopm-small" title="غیرقابل حذف">قفل شده</span>';
			} else if ( item.task_count > 0 ) {
				actionHtml = '<span class="seopm-muted seopm-small" title="دارای تسک متصل">در حال استفاده</span>';
			} else {
				actionHtml = '<button type="button" class="seopm-btn seopm-btn-danger-ghost seopm-btn-xs seopm-del-type-btn" data-key="' + item.key + '" data-label="' + ( item.label || '' ) + '">'
					+ '<span class="dashicons dashicons-trash" style="font-size:14px; width:14px; height:14px; vertical-align:middle;"></span> حذف'
					+ '</button>';
			}

			tr.innerHTML = '<td><strong>' + ( item.label || '' ) + '</strong></td>'
				+ '<td dir="ltr" style="font-family:monospace; font-size:12px; color:var(--seopm-text-2);">' + ( item.key || '' ) + '</td>'
				+ '<td>' + typeBadge + '</td>'
				+ '<td>' + countText + '</td>'
				+ '<td style="text-align:center;">' + actionHtml + '</td>';

			var delBtn = tr.querySelector( '.seopm-del-type-btn' );
			if ( delBtn ) {
				delBtn.addEventListener( 'click', function () {
					var k = delBtn.getAttribute( 'data-key' );
					var lbl = delBtn.getAttribute( 'data-label' );
					if ( ! confirm( 'آیا از حذف نوع تسک «' + lbl + '» مطمئن هستید؟' ) ) {
						return;
					}
					delBtn.disabled = true;
					ui.api( '/task-types/' + k, { method: 'DELETE' } ).then( function () {
						if ( SEOPM.config && SEOPM.config.types ) {
							delete SEOPM.config.types[ k ];
						}
						ui.toast( 'نوع تسک «' + lbl + '» حذف شد.' );
						loadTaskTypes();
					} ).catch( function ( err ) {
						delBtn.disabled = false;
						alert( ( err && err.message ) || 'خطا در حذف نوع تسک' );
					} );
				} );
			}

			tbody.appendChild( tr );
		} );

		typesTableWrap.innerHTML = '';
		typesTableWrap.appendChild( table );
	}

	function loadTaskTypes() {
		if ( ! typesTableWrap ) {
			return;
		}
		typesTableWrap.innerHTML = '<p class="seopm-muted">در حال بارگذاری لیست انواع تسک...</p>';
		ui.api( '/task-types?detailed=1' ).then( function ( list ) {
			renderTypesTable( list );
		} ).catch( function ( err ) {
			typesTableWrap.innerHTML = '<p class="seopm-danger">خطا در بارگذاری انواع تسک: ' + ( ( err && err.message ) || '' ) + '</p>';
		} );
	}

	if ( addTypeBtn && newTypeLabel ) {
		addTypeBtn.addEventListener( 'click', function () {
			var lbl = newTypeLabel.value.trim();
			var k = ( newTypeKey ? newTypeKey.value.trim() : '' );
			if ( ! lbl ) {
				showNotice( typeAddMsg, 'error', 'لطفاً عنوان نوع تسک را وارد کنید.' );
				newTypeLabel.focus();
				return;
			}
			addTypeBtn.disabled = true;
			ui.api( '/task-types', { method: 'POST', data: { label: lbl, key: k } } ).then( function ( res ) {
				addTypeBtn.disabled = false;
				newTypeLabel.value = '';
				if ( newTypeKey ) {
					newTypeKey.value = '';
				}
				if ( res && res.key && SEOPM.config && SEOPM.config.types ) {
					SEOPM.config.types[ res.key ] = res.label;
				}
				showNotice( typeAddMsg, 'success', 'نوع تسک «' + ( res.label || lbl ) + '» با موفقیت افزوده شد.' );
				loadTaskTypes();
			} ).catch( function ( err ) {
				addTypeBtn.disabled = false;
				showNotice( typeAddMsg, 'error', ( err && err.message ) || 'خطا در افزودن نوع تسک' );
			} );
		} );

		newTypeLabel.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Enter' ) {
				e.preventDefault();
				addTypeBtn.click();
			}
		} );
		if ( newTypeKey ) {
			newTypeKey.addEventListener( 'keydown', function ( e ) {
				if ( e.key === 'Enter' ) {
					e.preventDefault();
					addTypeBtn.click();
				}
			} );
		}
	}
}( window, document, window.jQuery ) );

=== SEO Project Manager ===
Contributors: seoprojectmanager
Tags: seo, project management, tasks, calendar, reports
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.15.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage SEO clients, keywords, tasks, a Jalali (Persian) task calendar, notes and professional Persian PDF reports from one dashboard.

== Description ==

SEO Project Manager (مدیریت پروژه‌های سئو) is a Persian, RTL-first project management panel for SEO agencies and freelancers.

* Businesses (clients) with website, sitemap, brand color and weighted keywords.
* Tasks with five activity types and three statuses, filters, search, sorting, quick status change and bulk actions.
* Jalali calendar (monthly / weekly / daily) built on FullCalendar, with multi-business filter, click-to-create and drag & drop rescheduling.
* Dashboard with live statistics, overdue and upcoming tasks.
* Monthly and custom-range reports stored as immutable, versioned snapshots, with A4 RTL PDF output (mPDF) and three report themes.

All dates are stored as Gregorian in the database and shown as Jalali in the interface and PDFs.

== Installation ==

1. Upload the ZIP via Plugins → Add New → Upload Plugin, or extract it to wp-content/plugins.
2. Activate the plugin.
3. Configure branding under "مدیریت پروژه‌های سئو → تنظیمات".

== Frequently Asked Questions ==

= Is my data deleted when I deactivate the plugin? =

No. Data is removed on uninstall only if "delete all data on uninstall" is enabled in settings.

= Where are PDF files stored? =

In wp-content/uploads/seopm-reports with random file names and direct access blocked. Downloads go through an authenticated, nonce-protected endpoint. On Nginx, add a deny rule for that folder.

== Changelog ==

= 1.15.0 =
* Rename menu item and business card buttons from "مقالات پیشنهادی" to "مقالات" (Articles).
* Major enhancement to Site Articles & Pages table:
  - Add Content Summary (خلاصه محتوا / Excerpt) for every page and article.
  - Add Headings outline (هدینگ‌ها H2/H3) with item count and interactive expander.
  - Add Target Keyword (کلمه کلیدی هدف) matched against project keywords or content semantics.
  - Add Page Type (نوع صفحه: مقاله آموزشی، مقاله کلاستر وبلاگ، صفحه لندینگ/پیلار، محصول، صفحه اصلی).
* Automatic extraction of rich excerpt and H2-H4 headings from WordPress REST API content with intelligent fallbacks.
* Bump cache version to seopm_site_content_v3_ for automatic re-crawl and fresh data loading.

= 1.14.0 =
* Enhance Business Setup into 3 Structured Sections:
  - Section 1 (اطلاعات کسب و کار): Business Name, Website URL, Sitemap URL, Industry & Services, Target Location, and Priority Focus Products/Services.
  - Section 2 (هدف تولید محتوا): Multi-select Content Priority Checkboxes (جذب ورودی از گوگل، دریافت تماس و مشاوره، فروش محصول، افزایش آگاهی از برند، حمایت از رتبه صفحات خدمات).
  - Section 3 (ویژگی‌های مخاطب و تست ابزارهای سئو): Target Audience Persona & Concerns textarea, plus 2 live diagnostic test buttons for Sitemap Accessibility and Google Search Console (GSC) Ownership Verification.
* Add live Sitemap tester with HTTP status, latency, XML validation, sub-sitemap/URL count, and sample URLs.
* Add live Google Search Console tester verifying meta tags, local Rank Math / Site Kit configurations, and GTM connectivity.
* Deeply personalize AI suggestions and article writing prompts with geography, target audience, focus services, and conversion goals.
* Database migration to DB_VERSION 1.8.0.

= 1.13.0 =
* Reduce suggested article batch from 20 to 10 articles to completely eliminate model fatigue, maximize strategic depth, and guarantee high-quality briefing per article.
* Eliminate sitemap truncation risk: implement semantic & keyword relevance ranking for existing content so historical articles relevant to target keywords are always fed to the AI and anti-cannibalization checks.
* Reinforce Search Intent realism: prioritize real-world conversational search terms, practical doubt queries, costs, insurance, and high CTR titles over generic conceptual headings.
* Add two-way internal linking architecture: generate reverse link guidance (Pillar to Cluster backlink recommendations) and inter-cluster sister link suggestions in article briefs and calendar tasks.

= 1.12.0 =
* Add two dedicated custom prompt boxes to business settings: (4) Sources & External Linking Guidelines (پرامپت منابع مورد استفاده و لینک‌دهی خارجی) and (5) Internal Linking Strategy (پرامپت لینک‌دهی داخلی).
* Connect internal and external linking prompts directly into the AI article generation pipeline and content briefer with high priority.
* Update business prompt counter badge to 5 prompts total.
* Automatically migrate database schema with new prompt columns for existing and future businesses.

= 1.11.0 =
* Add customizable Task Types (تعریف و مدیریت انواع تسک): allow defining and creating new custom task types on the fly directly inside the task modal (+ نوع جدید) and via a new dedicated management tab in Settings.
* Support persistent custom task types with automatic key generation, built-in type protection, in-use task validation, and REST API management endpoints.
* Integrate dynamic task types across filters, calendar, reports, and task forms.

= 1.10.0 =
* Add new "یادداشت‌ها" (Notes) section: full CRUD sticky notes board with business filtering, search, pastel color themes, pinned notes section, tags, and one-click copy.
* Isolate domain-specific suggestions: strictly limit clinical physiotherapy heuristic profiles to businesses explicitly in the physiotherapy domain, ensuring other businesses always receive dynamic niche-tailored SEO clusters.
* Add automated cache invalidation when keywords or business sitemaps are updated.
* Connect "بروزرسانی داده‌های سایت" button to automatically force refresh of suggested articles.

= 1.2.1 =
* Transform suggested articles into true SEO Topic Cluster articles: replace generic guide titles with deep problem-solving, symptom-focused, exercise, timeline and comparison cluster posts.
* Add Pillar Internal Linking Strategy: identify target service landing pages (sub-pillars), recommend exact and LSI anchor texts, and provide contextual in-content linking placement guidelines.
* Add target pillar badge and direct link column in suggestions table.

= 1.2.0 =
* Add AI SEO Content Strategy & Suggested Articles (مقالات پیشنهادی): 20 strategic article proposals proportionally distributed by keyword weights, comprehensive sitemap/content audit, cannibalization check, search intent classification, 6-phase content briefs, and direct "+ تقویم تسک" integration.

= 1.1.0 =
* Add project site report modal on clicking business title: comprehensive report with target keywords, linked articles, and pages audit via live WP REST API and XML sitemaps.

= 1.0.0 =
* First release (MVP).

== Third-party libraries ==

* FullCalendar 6.1.15 — MIT
* Chart.js 4.4.4 — MIT
* mPDF 8.2 — GPL-2.0 (bundled fonts: XB Riyaz, DejaVu Sans)

<?php
/**
 * Businesses (clients / SEO projects).
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Business repository.
 */
class Business {

	/**
	 * List businesses with aggregated task stats.
	 *
	 * @param array $args { search }.
	 * @return array
	 */
	public static function all( array $args = array() ) {
		global $wpdb;
		$b     = Database::table( 'businesses' );
		$t     = Database::table( 'tasks' );
		$k     = Database::table( 'keywords' );
		$today = Jalali::today();

		$where  = '1=1';
		$params = array( $today );
		if ( ! empty( $args['search'] ) ) {
			$where   .= ' AND b.name LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		$sql = "SELECT b.*,
				COALESCE(ts.total,0) AS task_total,
				COALESCE(ts.completed,0) AS task_completed,
				COALESCE(ts.overdue,0) AS task_overdue,
				(SELECT COUNT(*) FROM {$k} kk WHERE kk.business_id = b.id) AS keyword_count
			FROM {$b} b
			LEFT JOIN (
				SELECT business_id,
					COUNT(*) AS total,
					SUM(status = 'completed') AS completed,
					SUM(status <> 'completed' AND due_date < %s) AS overdue
				FROM {$t} GROUP BY business_id
			) ts ON ts.business_id = b.id
			WHERE {$where}
			ORDER BY b.name ASC";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		// phpcs:enable

		return array_map( array( __CLASS__, 'format' ), $rows ? $rows : array() );
	}

	/**
	 * Minimal list for selects: id, name, color.
	 *
	 * @return array
	 */
	public static function options() {
		$cached = wp_cache_get( 'options', 'seopm_businesses' );
		if ( false !== $cached ) {
			return $cached;
		}
		global $wpdb;
		$b    = Database::table( 'businesses' );
		$rows = $wpdb->get_results( "SELECT id, name, color FROM {$b} ORDER BY name ASC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out  = array_map(
			static function ( $r ) {
				return array(
					'id'    => (int) $r['id'],
					'name'  => $r['name'],
					'color' => $r['color'],
				);
			},
			$rows ? $rows : array()
		);
		wp_cache_set( 'options', $out, 'seopm_businesses', 300 );
		return $out;
	}

	/**
	 * Get business.
	 *
	 * @param int  $id            ID.
	 * @param bool $with_keywords Include keywords.
	 * @return array|null
	 */
	public static function get( $id, $with_keywords = true ) {
		global $wpdb;
		$b   = Database::table( 'businesses' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$b} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $row ) {
			return null;
		}
		$data = self::format( $row );
		if ( $with_keywords ) {
			$data['keywords'] = Keyword::for_business( $id );
		}
		return $data;
	}

	/**
	 * Whether a business exists.
	 *
	 * @param int $id ID.
	 * @return bool
	 */
	public static function exists( $id ) {
		global $wpdb;
		$b = Database::table( 'businesses' );
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$b} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Sanitize an AI prompt without stripping HTML tags or newlines.
	 *
	 * @param mixed $value Raw prompt text.
	 * @return string
	 */
	private static function sanitize_prompt( $value ) {
		$value = wp_check_invalid_utf8( (string) $value );
		$value = str_replace( "\0", '', $value );
		return trim( $value );
	}

	/**
	 * Sanitize publish time HH:MM (defaults to 21:00).
	 *
	 * @param mixed $value Raw time string.
	 * @return string
	 */
	private static function sanitize_publish_time( $value ) {
		$value = trim( (string) $value );
		if ( preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $value ) ) {
			return $value;
		}
		return '21:00';
	}

	/**
	 * Fetch raw WordPress publishing credentials for internal publisher use.
	 *
	 * @param int $id Business ID.
	 * @return array|null
	 */
	public static function get_wp_credentials( $id ) {
		global $wpdb;
		$b   = Database::table( 'businesses' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, name, website_url, wp_username, wp_app_password, wp_publish_time, wp_default_category FROM {$b} WHERE id = %d", absint( $id ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $row ) {
			return null;
		}
		return array(
			'id'                  => (int) $row['id'],
			'name'                => (string) $row['name'],
			'website_url'         => (string) ( $row['website_url'] ?? '' ),
			'wp_username'         => trim( (string) ( $row['wp_username'] ?? '' ) ),
			'wp_app_password'     => trim( (string) ( $row['wp_app_password'] ?? '' ) ),
			'wp_publish_time'     => self::sanitize_publish_time( $row['wp_publish_time'] ?? '21:00' ),
			'wp_default_category' => absint( $row['wp_default_category'] ?? 0 ),
		);
	}

	/**
	 * Validate input.
	 *
	 * @param array $data         Raw data.
	 * @param array $existing_raw Optional existing raw DB row for preserving masked secrets.
	 * @return array|\WP_Error
	 */
	private static function clean( array $data, array $existing_raw = array() ) {
		$name = trim( sanitize_text_field( $data['name'] ?? '' ) );
		if ( '' === $name ) {
			return new \WP_Error( 'seopm_business_name', __( 'نام کسب‌وکار الزامی است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}

		$existing_pass = trim( (string) ( $existing_raw['wp_app_password'] ?? '' ) );
		if ( array_key_exists( 'wp_app_password', $data ) ) {
			$raw_pass = trim( (string) $data['wp_app_password'] );
			if ( '' === $raw_pass && empty( $data['clear_wp_password'] ) && '' !== $existing_pass ) {
				$wp_pass = $existing_pass;
			} elseif ( false !== strpos( $raw_pass, '****' ) || false !== strpos( $raw_pass, '...' ) ) {
				$wp_pass = $existing_pass;
			} else {
				$wp_pass = $raw_pass;
			}
		} else {
			$wp_pass = $existing_pass;
		}
		if ( ! empty( $data['clear_wp_password'] ) ) {
			$wp_pass = '';
		}

		return array(
			'name'                    => mb_substr( $name, 0, 191 ),
			'website_url'             => Security::sanitize_url( $data['website_url'] ?? '' ),
			'sitemap_url'             => Security::sanitize_url( $data['sitemap_url'] ?? '' ),
			'color'                   => Security::sanitize_color( $data['color'] ?? '' ),
			'description'             => sanitize_textarea_field( $data['description'] ?? '' ),
			'prompt_article_writing'  => self::sanitize_prompt( $data['prompt_article_writing'] ?? '' ),
			'prompt_html_conversion'  => self::sanitize_prompt( $data['prompt_html_conversion'] ?? '' ),
			'prompt_image_generation' => self::sanitize_prompt( $data['prompt_image_generation'] ?? '' ),
			'wp_username'             => mb_substr( trim( sanitize_text_field( $data['wp_username'] ?? '' ) ), 0, 191 ),
			'wp_app_password'         => $wp_pass,
			'wp_publish_time'         => self::sanitize_publish_time( $data['wp_publish_time'] ?? '21:00' ),
			'wp_default_category'     => absint( $data['wp_default_category'] ?? 0 ),
			'telegram_chat_id'        => mb_substr( preg_replace( '/[^0-9\-]/', '', trim( (string) ( $data['telegram_chat_id'] ?? '' ) ) ), 0, 64 ),
			'telegram_username'       => mb_substr( trim( sanitize_text_field( $data['telegram_username'] ?? '' ) ), 0, 100 ),
			'telegram_notify_enabled' => isset( $data['telegram_notify_enabled'] ) ? ( empty( $data['telegram_notify_enabled'] ) ? 0 : 1 ) : 1,
		);
	}

	/**
	 * Create business (optionally with keywords).
	 *
	 * @param array $data Data.
	 * @return array|\WP_Error
	 */
	public static function create( array $data ) {
		global $wpdb;
		$clean = self::clean( $data );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$now                 = Database::now();
		$clean['created_by'] = get_current_user_id();
		$clean['created_at'] = $now;
		$clean['updated_at'] = $now;
		$ok                  = $wpdb->insert(
			Database::table( 'businesses' ),
			$clean,
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%s', '%s' )
		);
		if ( ! $ok ) {
			return new \WP_Error( 'seopm_db_error', __( 'خطا در ذخیره اطلاعات.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}
		$id = (int) $wpdb->insert_id;
		if ( isset( $data['keywords'] ) && is_array( $data['keywords'] ) ) {
			Keyword::sync( $id, $data['keywords'] );
		}
		wp_cache_delete( 'options', 'seopm_businesses' );
		do_action( 'seopm_business_created', $id );
		return self::get( $id );
	}

	/**
	 * Update business (and keywords if provided).
	 *
	 * @param int   $id   ID.
	 * @param array $data Data.
	 * @return array|\WP_Error
	 */
	public static function update( $id, array $data ) {
		global $wpdb;
		$b        = Database::table( 'businesses' );
		$raw_row  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$b} WHERE id = %d", absint( $id ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $raw_row ) {
			return new \WP_Error( 'seopm_business_not_found', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$current = self::format( $raw_row );
		$merged  = array_merge( $current, $data );
		if ( ! array_key_exists( 'wp_app_password', $data ) ) {
			unset( $merged['wp_app_password'] );
		}
		$clean = self::clean( $merged, $raw_row );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$clean['updated_at'] = Database::now();
		$wpdb->update(
			$b,
			$clean,
			array( 'id' => absint( $id ) ),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%d', '%s' ),
			array( '%d' )
		);
		if ( isset( $data['keywords'] ) && is_array( $data['keywords'] ) ) {
			Keyword::sync( $id, $data['keywords'] );
		}
		wp_cache_delete( 'options', 'seopm_businesses' );
		$cache_dirty = (
			$clean['name'] !== (string) ( $current['name'] ?? '' ) ||
			$clean['website_url'] !== (string) ( $current['website_url'] ?? '' ) ||
			$clean['sitemap_url'] !== (string) ( $current['sitemap_url'] ?? '' ) ||
			$clean['description'] !== (string) ( $current['description'] ?? '' ) ||
			( isset( $data['keywords'] ) && is_array( $data['keywords'] ) )
		);
		if ( $cache_dirty ) {
			Site_Crawler::clear_cache( $id );
			Content_Suggester::clear_cache( $id );
		}
		do_action( 'seopm_business_updated', $id );
		return self::get( $id );
	}

	/**
	 * Counts of related records (for delete confirmation).
	 *
	 * @param int $id ID.
	 * @return array
	 */
	public static function related_counts( $id ) {
		global $wpdb;
		$t = Database::table( 'tasks' );
		$r = Database::table( 'reports' );
		$k = Database::table( 'keywords' );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array(
			'tasks'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE business_id = %d", $id ) ),
			'reports'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$r} WHERE business_id = %d", $id ) ),
			'keywords' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$k} WHERE business_id = %d", $id ) ),
		);
		// phpcs:enable
	}

	/**
	 * Delete business with its keywords and tasks; reports are deleted unless kept.
	 *
	 * @param int  $id           ID.
	 * @param bool $keep_reports Keep report archive (snapshots are self-contained).
	 * @return bool|\WP_Error
	 */
	public static function delete( $id, $keep_reports = false ) {
		global $wpdb;
		if ( ! self::exists( $id ) ) {
			return new \WP_Error( 'seopm_business_not_found', __( 'کسب‌وکار یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$wpdb->query( 'START TRANSACTION' );
		Keyword::delete_for_business( $id );
		$wpdb->delete( Database::table( 'article_drafts' ), array( 'business_id' => $id ), array( '%d' ) );
		$wpdb->delete( Database::table( 'tasks' ), array( 'business_id' => $id ), array( '%d' ) );
		$wpdb->delete( Database::table( 'businesses' ), array( 'id' => $id ), array( '%d' ) );
		$wpdb->query( 'COMMIT' );

		if ( ! $keep_reports ) {
			foreach ( Report::ids_for_business( $id ) as $report_id ) {
				Report::delete( $report_id );
			}
		}
		wp_cache_delete( 'options', 'seopm_businesses' );
		Site_Crawler::clear_cache( $id );
		Content_Suggester::clear_cache( $id );
		do_action( 'seopm_business_deleted', $id );
		return true;
	}

	/**
	 * Format row.
	 *
	 * @param array $row Row.
	 * @return array
	 */
	public static function format( array $row ) {
		$raw_wp_pass  = trim( (string) ( $row['wp_app_password'] ?? '' ) );
		$wp_user      = trim( (string) ( $row['wp_username'] ?? '' ) );
		$site_url     = (string) ( $row['website_url'] ?? '' );
		$tg_chat_id   = trim( (string) ( $row['telegram_chat_id'] ?? '' ) );
		$tg_username  = trim( (string) ( $row['telegram_username'] ?? '' ) );
		$tg_notify    = isset( $row['telegram_notify_enabled'] ) ? (bool) (int) $row['telegram_notify_enabled'] : true;

		$data = array(
			'id'                      => (int) $row['id'],
			'name'                    => $row['name'],
			'website_url'             => $site_url,
			'sitemap_url'             => $row['sitemap_url'],
			'color'                   => $row['color'],
			'description'             => (string) ( $row['description'] ?? '' ),
			'prompt_article_writing'  => (string) ( $row['prompt_article_writing'] ?? '' ),
			'prompt_html_conversion'  => (string) ( $row['prompt_html_conversion'] ?? '' ),
			'prompt_image_generation' => (string) ( $row['prompt_image_generation'] ?? '' ),
			'wp_username'             => $wp_user,
			'wp_app_password'         => Settings::mask_key( $raw_wp_pass ),
			'wp_has_password'         => '' !== $raw_wp_pass,
			'wp_connected'            => '' !== $site_url && '' !== $wp_user && '' !== $raw_wp_pass,
			'wp_publish_time'         => self::sanitize_publish_time( $row['wp_publish_time'] ?? '21:00' ),
			'wp_default_category'     => absint( $row['wp_default_category'] ?? 0 ),
			'telegram_chat_id'        => $tg_chat_id,
			'telegram_username'       => $tg_username,
			'telegram_notify_enabled' => $tg_notify,
			'telegram_connected'      => '' !== $tg_chat_id,
			'created_at'              => $row['created_at'],
			'updated_at'              => $row['updated_at'],
		);
		if ( isset( $row['task_total'] ) ) {
			$total                  = (int) $row['task_total'];
			$completed              = (int) $row['task_completed'];
			$data['task_total']     = $total;
			$data['task_completed'] = $completed;
			$data['task_overdue']   = (int) $row['task_overdue'];
			$data['keyword_count']  = (int) $row['keyword_count'];
			$data['completion']     = Task::rate( $completed, $total );
		}
		return $data;
	}
}

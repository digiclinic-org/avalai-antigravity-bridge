<?php
/**
 * Site Crawler: fetches articles (posts), pages, and sitemaps for SEO project reports.
 *
 * @package SEOPM
 */

namespace SEOPM;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Site Crawler service.
 */
class Site_Crawler {

	const CACHE_KEY_PREFIX = 'seopm_site_content_';
	const CACHE_TTL        = 21600; // 6 hours.

	/**
	 * Get comprehensive site report: keywords, linked articles, and pages.
	 *
	 * @param int  $business_id   Business ID.
	 * @param bool $force_refresh Whether to bypass transient cache.
	 * @return array|WP_Error
	 */
	public static function get_report( $business_id, $force_refresh = false ) {
		$business_id = Article_Generator::resolve_business_id( $business_id );
		$business    = $business_id ? Business::get( $business_id, true ) : null;
		if ( ! $business ) {
			return new WP_Error(
				'seopm_business_not_found',
				__( 'پروژه مورد نظر یافت نشد.', 'seo-project-manager' ),
				array( 'status' => 404 )
			);
		}

		$cache_key = self::CACHE_KEY_PREFIX . $business_id;
		if ( ! $force_refresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && ! empty( $cached['stats'] ) ) {
				// Always update with latest keywords from database even if posts/pages are cached.
				$cached['business'] = $business;
				$cached['keywords'] = self::enrich_keywords(
					$business['keywords'],
					$cached['posts'] ?? array(),
					$cached['pages'] ?? array()
				);
				$cached['stats']['keyword_count'] = count( $cached['keywords'] );
				return $cached;
			}
		}

		$website_url = trim( $business['website_url'] ?? '' );
		$sitemap_url = trim( $business['sitemap_url'] ?? '' );

		$base_url = self::normalize_base_url( $website_url, $sitemap_url );

		$posts  = array();
		$pages  = array();
		$source = 'none';

		// Step 1: Attempt to fetch via WordPress REST API if base URL is available.
		if ( $base_url ) {
			$wp_data = self::fetch_wp_rest( $base_url );
			if ( ! empty( $wp_data['posts'] ) ) {
				$posts  = $wp_data['posts'];
				$source = 'wp_rest';
			}
			if ( ! empty( $wp_data['pages'] ) ) {
				$pages = $wp_data['pages'];
				if ( 'none' === $source ) {
					$source = 'wp_rest';
				}
			}
		}

		// Step 2: Crawl XML Sitemap if explicit sitemap_url is configured for the business.
		if ( ! empty( $sitemap_url ) ) {
			$sitemap_data = self::crawl_sitemap( $sitemap_url );
			if ( ! empty( $sitemap_data['posts'] ) || ! empty( $sitemap_data['pages'] ) ) {
				$posts  = self::merge_content_items( $posts, $sitemap_data['posts'] ?? array() );
				$pages  = self::merge_content_items( $pages, $sitemap_data['pages'] ?? array() );
				$source = ( 'wp_rest' === $source ) ? 'hybrid' : 'sitemap';
			}
		}

		// Sort posts by date / modified descending.
		usort(
			$posts,
			static function ( $a, $b ) {
				$da = $a['modified'] ?? $a['date'] ?? '';
				$db = $b['modified'] ?? $b['date'] ?? '';
				return strcmp( $db, $da );
			}
		);

		// Sort pages by title or modified.
		usort(
			$pages,
			static function ( $a, $b ) {
				$da = $a['modified'] ?? $a['date'] ?? '';
				$db = $b['modified'] ?? $b['date'] ?? '';
				return strcmp( $db, $da );
			}
		);

		$enriched_keywords = self::enrich_keywords( $business['keywords'], $posts, $pages );

		$report = array(
			'business'    => $business,
			'sitemap_url' => $sitemap_target,
			'keywords'    => $enriched_keywords,
			'posts'       => $posts,
			'pages'       => $pages,
			'stats'       => array(
				'keyword_count' => count( $enriched_keywords ),
				'post_count'    => count( $posts ),
				'page_count'    => count( $pages ),
				'synced_at'     => current_time( 'mysql' ),
				'source'        => $source,
				'sitemap_url'   => $sitemap_target,
			),
		);

		set_transient( $cache_key, $report, self::CACHE_TTL );

		return $report;
	}

	/**
	 * Clear cached site report for a business.
	 *
	 * @param int $business_id Business ID.
	 */
	public static function clear_cache( $business_id ) {
		delete_transient( self::CACHE_KEY_PREFIX . $business_id );
	}

	/**
	 * Normalize base URL from website URL or sitemap URL.
	 *
	 * @param string $website_url Website URL.
	 * @param string $sitemap_url Sitemap URL.
	 * @return string
	 */
	private static function normalize_base_url( $website_url, $sitemap_url ) {
		$url = $website_url;
		if ( empty( $url ) && ! empty( $sitemap_url ) ) {
			$parts = wp_parse_url( $sitemap_url );
			if ( ! empty( $parts['host'] ) ) {
				$scheme = ! empty( $parts['scheme'] ) ? $parts['scheme'] : 'https';
				$url    = $scheme . '://' . $parts['host'];
			}
		}

		if ( empty( $url ) ) {
			return '';
		}

		$url = trim( $url );
		if ( ! preg_match( '#^https?://#i', $url ) ) {
			$url = 'https://' . $url;
		}

		return rtrim( $url, '/' );
	}

	/**
	 * Fetch posts and pages from a WordPress site REST API.
	 *
	 * @param string $base_url Site base URL.
	 * @return array{posts:array,pages:array}
	 */
	private static function fetch_wp_rest( $base_url ) {
		$results = array(
			'posts' => array(),
			'pages' => array(),
		);

		$headers = array(
			'Accept'     => 'application/json',
			'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; SEO-Project-Manager',
		);

		// Fetch Posts.
		$posts_url = add_query_arg(
			array(
				'per_page' => 100,
				'_fields'  => 'id,title,link,date,modified',
			),
			$base_url . '/wp-json/wp/v2/posts'
		);

		$res = wp_remote_get(
			$posts_url,
			array(
				'timeout'   => 12,
				'sslverify' => false,
				'headers'   => $headers,
			)
		);

		if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
			$body = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( is_array( $body ) ) {
				foreach ( $body as $item ) {
					$title = html_entity_decode( wp_strip_all_tags( $item['title']['rendered'] ?? '' ), ENT_QUOTES, 'UTF-8' );
					$url   = esc_url_raw( $item['link'] ?? '' );
					if ( $title && $url ) {
						$results['posts'][] = array(
							'id'       => (int) ( $item['id'] ?? 0 ),
							'title'    => $title,
							'url'      => $url,
							'date'     => sanitize_text_field( $item['date'] ?? '' ),
							'modified' => sanitize_text_field( $item['modified'] ?? '' ),
							'type'     => 'post',
						);
					}
				}
			}
		}

		// Fetch Pages.
		$pages_url = add_query_arg(
			array(
				'per_page' => 100,
				'_fields'  => 'id,title,link,date,modified',
			),
			$base_url . '/wp-json/wp/v2/pages'
		);

		$res = wp_remote_get(
			$pages_url,
			array(
				'timeout'   => 12,
				'sslverify' => false,
				'headers'   => $headers,
			)
		);

		if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
			$body = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( is_array( $body ) ) {
				foreach ( $body as $item ) {
					$title = html_entity_decode( wp_strip_all_tags( $item['title']['rendered'] ?? '' ), ENT_QUOTES, 'UTF-8' );
					$url   = esc_url_raw( $item['link'] ?? '' );
					if ( $url ) {
						if ( empty( $title ) ) {
							$title = self::slug_to_title( $url );
						}
						$results['pages'][] = array(
							'id'       => (int) ( $item['id'] ?? 0 ),
							'title'    => $title,
							'url'      => $url,
							'date'     => sanitize_text_field( $item['date'] ?? '' ),
							'modified' => sanitize_text_field( $item['modified'] ?? '' ),
							'type'     => 'page',
						);
					}
				}
			}
		}

		return $results;
	}

	/**
	 * Crawl XML sitemap (handles both index and urlsets, resilient to namespaces).
	 *
	 * @param string $sitemap_url Sitemap URL.
	 * @return array{posts:array,pages:array}
	 */
	private static function crawl_sitemap( $sitemap_url ) {
		$results = array(
			'posts' => array(),
			'pages' => array(),
		);

		$xml = self::fetch_xml( $sitemap_url );
		if ( ! $xml ) {
			return $results;
		}

		// Handle namespace if present.
		$sitemaps = array();
		if ( isset( $xml->sitemap ) && count( $xml->sitemap ) > 0 ) {
			$sitemaps = $xml->sitemap;
		} elseif ( method_exists( $xml, 'children' ) ) {
			$ns_ch = $xml->children( 'http://www.sitemaps.org/schemas/sitemap/0.9' );
			if ( isset( $ns_ch->sitemap ) ) {
				$sitemaps = $ns_ch->sitemap;
			}
		}

		// If sitemap index: fetch child sitemaps.
		if ( ! empty( $sitemaps ) ) {
			foreach ( $sitemaps as $sm ) {
				$loc = trim( (string) $sm->loc );
				if ( ! $loc || self::is_ignored_sitemap_url( $loc ) ) {
					continue;
				}

				$is_post = ( false !== stripos( $loc, 'post' ) );
				$is_page = ( false !== stripos( $loc, 'page' ) );

				$child_xml = self::fetch_xml( $loc );
				if ( ! $child_xml ) {
					continue;
				}

				$urls = array();
				if ( isset( $child_xml->url ) && count( $child_xml->url ) > 0 ) {
					$urls = $child_xml->url;
				} elseif ( method_exists( $child_xml, 'children' ) ) {
					$ns_ch2 = $child_xml->children( 'http://www.sitemaps.org/schemas/sitemap/0.9' );
					if ( isset( $ns_ch2->url ) ) {
						$urls = $ns_ch2->url;
					}
				}

				foreach ( $urls as $u ) {
					$url     = trim( (string) $u->loc );
					$lastmod = trim( (string) ( $u->lastmod ?? '' ) );
					if ( ! $url || self::is_ignored_sitemap_url( $url ) ) {
						continue;
					}

					$item = array(
						'id'       => 0,
						'title'    => self::slug_to_title( $url ),
						'url'      => esc_url_raw( $url ),
						'date'     => $lastmod,
						'modified' => $lastmod,
						'type'     => $is_post ? 'post' : ( $is_page ? 'page' : 'item' ),
					);

					if ( $is_post ) {
						$results['posts'][] = $item;
					} else {
						$results['pages'][] = $item;
					}
				}
			}
		} else {
			// Single sitemap with URLs.
			$urls = array();
			if ( isset( $xml->url ) && count( $xml->url ) > 0 ) {
				$urls = $xml->url;
			} elseif ( method_exists( $xml, 'children' ) ) {
				$ns_ch = $xml->children( 'http://www.sitemaps.org/schemas/sitemap/0.9' );
				if ( isset( $ns_ch->url ) ) {
					$urls = $ns_ch->url;
				}
			}

			foreach ( $urls as $u ) {
				$url     = trim( (string) $u->loc );
				$lastmod = trim( (string) ( $u->lastmod ?? '' ) );
				if ( ! $url || self::is_ignored_sitemap_url( $url ) ) {
					continue;
				}

				$is_post = ( false !== stripos( $sitemap_url, 'post' ) );
				$item    = array(
					'id'       => 0,
					'title'    => self::slug_to_title( $url ),
					'url'      => esc_url_raw( $url ),
					'date'     => $lastmod,
					'modified' => $lastmod,
					'type'     => $is_post ? 'post' : 'page',
				);

				if ( $is_post ) {
					$results['posts'][] = $item;
				} else {
					$results['pages'][] = $item;
				}
			}
		}

		return $results;
	}

	/**
	 * Merge content items by URL, preserving primary rich data (e.g. Persian titles from WP REST)
	 * while ensuring every URL from the sitemap is included.
	 *
	 * @param array $primary_items Primary items (e.g. from WP REST API).
	 * @param array $sitemap_items Sitemap items.
	 * @return array
	 */
	private static function merge_content_items( array $primary_items, array $sitemap_items ) {
		$merged    = array();
		$seen_urls = array();

		// Add primary items first (they have real WordPress titles, IDs, dates).
		foreach ( $primary_items as $item ) {
			$norm_url = self::normalize_url_key( $item['url'] ?? '' );
			if ( '' !== $norm_url && ! isset( $seen_urls[ $norm_url ] ) ) {
				$seen_urls[ $norm_url ] = true;
				$merged[]               = $item;
			}
		}

		// Add sitemap items that aren't already included.
		foreach ( $sitemap_items as $s_item ) {
			$raw_url = $s_item['url'] ?? '';
			if ( self::is_ignored_sitemap_url( $raw_url ) ) {
				continue;
			}
			$norm_url = self::normalize_url_key( $raw_url );
			if ( '' !== $norm_url && ! isset( $seen_urls[ $norm_url ] ) ) {
				$seen_urls[ $norm_url ] = true;
				$merged[]               = $s_item;
			}
		}

		return $merged;
	}

	/**
	 * Normalize URL for robust duplicate detection (scheme, host, path without trailing slash).
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private static function normalize_url_key( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		$parts = wp_parse_url( $url );
		if ( empty( $parts['host'] ) ) {
			return rtrim( strtolower( $url ), '/' );
		}
		$scheme = strtolower( $parts['scheme'] ?? 'https' );
		$host   = strtolower( $parts['host'] );
		$path   = isset( $parts['path'] ) ? rtrim( urldecode( $parts['path'] ), '/' ) : '';
		return $scheme . '://' . $host . $path;
	}

	/**
	 * Check if a sitemap URL points to a non-page file (kml, xml, images, archives).
	 *
	 * @param string $url URL.
	 * @return bool
	 */
	private static function is_ignored_sitemap_url( $url ) {
		$path = strtolower( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		return (bool) preg_match( '/\.(kml|xml|xsl|pdf|zip|rar|jpg|jpeg|png|webp|gif|svg|mp4|css|js)$/i', $path );
	}

	/**
	 * Fetch and parse XML string.
	 *
	 * @param string $url URL.
	 * @return \SimpleXMLElement|null
	 */
	private static function fetch_xml( $url ) {
		$res = wp_remote_get(
			$url,
			array(
				'timeout'   => 15,
				'sslverify' => false,
				'headers'   => array(
					'Accept'     => 'application/xml, text/xml, */*',
					'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; SEO-Project-Manager',
				),
			)
		);

		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			return null;
		}

		$body = wp_remote_retrieve_body( $res );
		if ( empty( $body ) ) {
			return null;
		}

		libxml_use_internal_errors( true );
		$xml = simplexml_load_string( $body );
		libxml_clear_errors();

		return ( $xml instanceof \SimpleXMLElement ) ? $xml : null;
	}

	/**
	 * Generate human-readable title from URL slug.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private static function slug_to_title( $url ) {
		$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		if ( empty( $path ) ) {
			return __( 'صفحه اصلی', 'seo-project-manager' );
		}

		$segments = explode( '/', $path );
		$slug     = end( $segments );
		$decoded  = urldecode( $slug );

		$title = str_replace( array( '-', '_', '+' ), ' ', $decoded );
		return trim( $title );
	}

	/**
	 * Enrich keywords with matched posts and pages on the site.
	 *
	 * @param array $keywords Keywords list.
	 * @param array $posts    Posts list.
	 * @param array $pages    Pages list.
	 * @return array
	 */
	private static function enrich_keywords( array $keywords, array $posts, array $pages ) {
		$enriched = array();

		foreach ( $keywords as $k ) {
			$text = mb_strtolower( trim( $k['keyword'] ?? '' ) );
			if ( empty( $text ) ) {
				$enriched[] = $k;
				continue;
			}

			// Clean search tokens.
			$tokens = array_filter( explode( ' ', $text ), static function ( $t ) {
				return mb_strlen( $t ) > 2;
			} );

			$matched_posts = array();
			foreach ( $posts as $p ) {
				$p_title = mb_strtolower( $p['title'] ?? '' );
				$p_url   = urldecode( mb_strtolower( $p['url'] ?? '' ) );

				if ( false !== mb_strpos( $p_title, $text ) || false !== mb_strpos( $p_url, $text ) ) {
					$matched_posts[] = array(
						'title' => $p['title'],
						'url'   => $p['url'],
					);
				}
			}

			$matched_pages = array();
			foreach ( $pages as $pg ) {
				$pg_title = mb_strtolower( $pg['title'] ?? '' );
				$pg_url   = urldecode( mb_strtolower( $pg['url'] ?? '' ) );

				if ( false !== mb_strpos( $pg_title, $text ) || false !== mb_strpos( $pg_url, $text ) ) {
					$matched_pages[] = array(
						'title' => $pg['title'],
						'url'   => $pg['url'],
					);
				}
			}

			$k['matched_posts'] = $matched_posts;
			$k['matched_pages'] = $matched_pages;
			$k['match_count']   = count( $matched_posts ) + count( $matched_pages );

			$enriched[] = $k;
		}

		return $enriched;
	}
}

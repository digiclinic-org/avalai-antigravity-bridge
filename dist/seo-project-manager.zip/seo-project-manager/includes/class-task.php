<?php
/**
 * Tasks.
 *
 * @package SEOPM
 */

namespace SEOPM;

defined( 'ABSPATH' ) || exit;

/**
 * Task repository and statistics.
 */
class Task {

	/**
	 * Task types (key => label). Filterable for future versions.
	 *
	 * @return array
	 */
	public static function types() {
		return apply_filters(
			'seopm_task_types',
			array(
				'article_writing'  => __( 'نگارش مقاله جدید', 'seo-project-manager' ),
				'page_design'      => __( 'طراحی صفحه جدید', 'seo-project-manager' ),
				'tool_development' => __( 'طراحی ابزار', 'seo-project-manager' ),
				'article_update'   => __( 'بروزرسانی مقاله', 'seo-project-manager' ),
				'page_update'      => __( 'بروزرسانی صفحه', 'seo-project-manager' ),
			)
		);
	}

	/**
	 * Task statuses.
	 *
	 * @return array
	 */
	public static function statuses() {
		return array(
			'pending'     => __( 'در انتظار انجام', 'seo-project-manager' ),
			'in_progress' => __( 'در حال انجام', 'seo-project-manager' ),
			'completed'   => __( 'تکمیل شده', 'seo-project-manager' ),
		);
	}

	/**
	 * Completion percentage; 0 when total is 0.
	 *
	 * @param int $completed Completed.
	 * @param int $total     Total.
	 * @return int
	 */
	public static function rate( $completed, $total ) {
		return $total > 0 ? (int) round( $completed / $total * 100 ) : 0;
	}

	/**
	 * Build WHERE clause from filters.
	 *
	 * @param array $args Filters.
	 * @return array [sql, params]
	 */
	private static function where( array $args ) {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();

		$ids = Security::id_list( $args['business_ids'] ?? array() );
		if ( ! empty( $args['business_id'] ) ) {
			$ids[] = absint( $args['business_id'] );
		}
		if ( $ids ) {
			$where[] = 't.business_id IN (' . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')';
			$params  = array_merge( $params, $ids );
		}
		if ( ! empty( $args['type'] ) && isset( self::types()[ $args['type'] ] ) ) {
			$where[]  = 't.task_type = %s';
			$params[] = $args['type'];
		}
		if ( ! empty( $args['status'] ) ) {
			if ( 'overdue' === $args['status'] ) {
				$where[]  = "t.status <> 'completed' AND t.due_date < %s";
				$params[] = Jalali::today();
			} elseif ( 'open' === $args['status'] ) {
				$where[] = "t.status <> 'completed'";
			} elseif ( isset( self::statuses()[ $args['status'] ] ) ) {
				$where[]  = 't.status = %s';
				$params[] = $args['status'];
			}
		}
		if ( ! empty( $args['search'] ) ) {
			$where[]  = 't.title LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}
		$from = Security::sanitize_date( $args['from'] ?? '' );
		$to   = Security::sanitize_date( $args['to'] ?? '' );
		if ( $from ) {
			$where[]  = 't.due_date >= %s';
			$params[] = $from;
		}
		if ( $to ) {
			$where[]  = 't.due_date <= %s';
			$params[] = $to;
		}
		return array( implode( ' AND ', $where ), $params );
	}

	/**
	 * Query tasks.
	 *
	 * @param array $args business_ids, business_id, type, status, search, from, to, orderby, order, page, per_page.
	 * @param bool  $count_total Whether to calculate the total count.
	 * @return array{items:array,total:int,pages:int}
	 */
	public static function query( array $args = array(), $count_total = true ) {
		global $wpdb;
		$t = Database::table( 'tasks' );
		$b = Database::table( 'businesses' );

		list( $where, $params ) = self::where( $args );

		$orderby_map = array(
			'due_date'   => 't.due_date',
			'created_at' => 't.created_at',
			'updated_at' => 't.updated_at',
			'title'      => 't.title',
			'status'     => 't.status',
		);
		$orderby  = $orderby_map[ $args['orderby'] ?? 'due_date' ] ?? 't.due_date';
		$order    = 'DESC' === strtoupper( $args['order'] ?? 'ASC' ) ? 'DESC' : 'ASC';
		$per_page = max( 1, min( 500, (int) ( $args['per_page'] ?? 20 ) ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$offset   = ( $page - 1 ) * $per_page;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		if ( $count_total ) {
			$count_sql = "SELECT COUNT(*) FROM {$t} t WHERE {$where}";
			$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );
		} else {
			$total = 0;
		}

		$sql  = "SELECT t.*, b.name AS business_name, b.color AS business_color
			FROM {$t} t LEFT JOIN {$b} b ON b.id = t.business_id
			WHERE {$where}
			ORDER BY {$orderby} {$order}, t.id {$order}
			LIMIT %d OFFSET %d";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $params, array( $per_page, $offset ) ) ), ARRAY_A );
		// phpcs:enable

		return array(
			'items' => array_map( array( __CLASS__, 'format' ), $rows ? $rows : array() ),
			'total' => $total,
			'pages' => $count_total ? (int) ceil( $total / $per_page ) : 1,
		);
	}

	/**
	 * Status counts for the given filters (status filter ignored).
	 *
	 * @param array $args Filters.
	 * @return array
	 */
	public static function counts( array $args = array() ) {
		global $wpdb;
		$t = Database::table( 'tasks' );
		unset( $args['status'] );
		list( $where, $params ) = self::where( $args );
		$params                 = array_merge( array( Jalali::today() ), $params );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS total,
					SUM(t.status = 'pending') AS pending,
					SUM(t.status = 'in_progress') AS in_progress,
					SUM(t.status = 'completed') AS completed,
					SUM(t.status <> 'completed' AND t.due_date < %s) AS overdue
				FROM {$t} t WHERE {$where}",
				$params
			),
			ARRAY_A
		);
		// phpcs:enable
		$out = array();
		foreach ( array( 'total', 'pending', 'in_progress', 'completed', 'overdue' ) as $k ) {
			$out[ $k ] = (int) ( $row[ $k ] ?? 0 );
		}
		$out['completion'] = self::rate( $out['completed'], $out['total'] );
		return $out;
	}

	/**
	 * Get task.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$t   = Database::table( 'tasks' );
		$b   = Database::table( 'businesses' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT t.*, b.name AS business_name, b.color AS business_color FROM {$t} t LEFT JOIN {$b} b ON b.id = t.business_id WHERE t.id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $row ? self::format( $row ) : null;
	}

	/**
	 * Validate input.
	 *
	 * @param array $data Raw data.
	 * @return array|\WP_Error
	 */
	private static function clean( array $data ) {
		$title = trim( sanitize_text_field( $data['title'] ?? '' ) );
		if ( '' === $title ) {
			return new \WP_Error( 'seopm_task_title', __( 'عنوان تسک الزامی است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		$business_id = absint( $data['business_id'] ?? 0 );
		if ( ! $business_id || ! Business::exists( $business_id ) ) {
			return new \WP_Error( 'seopm_task_business', __( 'کسب‌وکار معتبر انتخاب کنید.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		$type = $data['task_type'] ?? '';
		if ( ! isset( self::types()[ $type ] ) ) {
			return new \WP_Error( 'seopm_task_type', __( 'نوع تسک نامعتبر است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		$due = Security::sanitize_date( $data['due_date'] ?? '' );
		if ( ! $due ) {
			return new \WP_Error( 'seopm_task_date', __( 'تاریخ انجام نامعتبر است.', 'seo-project-manager' ), array( 'status' => 400 ) );
		}
		$status = $data['status'] ?? 'pending';
		if ( ! isset( self::statuses()[ $status ] ) ) {
			$status = 'pending';
		}
		$article_key = sanitize_key( $data['article_key'] ?? '' );
		if ( '' === $article_key && 'article_writing' === $type ) {
			$article_key = Article_Generator::make_key( $title );
		}
		return array(
			'title'       => mb_substr( $title, 0, 255 ),
			'business_id' => $business_id,
			'task_type'   => $type,
			'due_date'    => $due,
			'description' => sanitize_textarea_field( $data['description'] ?? '' ),
			'article_key' => $article_key,
			'status'      => $status,
		);
	}

	/**
	 * Create task.
	 *
	 * @param array $data Data.
	 * @return array|\WP_Error
	 */
	public static function create( array $data ) {
		global $wpdb;
		$clean = self::clean( $data );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$now                   = Database::now();
		$clean['completed_at'] = 'completed' === $clean['status'] ? $now : null;
		$clean['created_by']   = get_current_user_id();
		$clean['created_at']   = $now;
		$clean['updated_at']   = $now;
		$ok                    = $wpdb->insert( Database::table( 'tasks' ), $clean, array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' ) );
		if ( ! $ok ) {
			return new \WP_Error( 'seopm_db_error', __( 'خطا در ذخیره اطلاعات.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}
		$id = (int) $wpdb->insert_id;
		do_action( 'seopm_task_created', $id );
		return self::get( $id );
	}

	/**
	 * Update task (partial data allowed).
	 *
	 * @param int   $id   ID.
	 * @param array $data Data.
	 * @return array|\WP_Error
	 */
	public static function update( $id, array $data ) {
		global $wpdb;
		$current = self::get( $id );
		if ( ! $current ) {
			return new \WP_Error( 'seopm_task_not_found', __( 'تسک یافت نشد.', 'seo-project-manager' ), array( 'status' => 404 ) );
		}
		$clean = self::clean( array_merge( $current, array_intersect_key( $data, array_flip( array( 'title', 'business_id', 'task_type', 'due_date', 'description', 'article_key', 'status' ) ) ) ) );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$now                 = Database::now();
		$clean['updated_at'] = $now;
		$formats             = array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' );

		if ( $clean['status'] !== $current['status'] ) {
			$clean['completed_at'] = 'completed' === $clean['status'] ? $now : null;
			$formats[]             = '%s';
		}
		$wpdb->update( Database::table( 'tasks' ), $clean, array( 'id' => $id ), $formats, array( '%d' ) );

		if ( $clean['status'] !== $current['status'] ) {
			do_action( 'seopm_task_status_changed', $id, $clean['status'], $current['status'] );
		}
		do_action( 'seopm_task_updated', $id );
		return self::get( $id );
	}

	/**
	 * Update remote WordPress publish tracking metadata on a task.
	 *
	 * @param int   $id  Task ID.
	 * @param array $pub { remote_post_id, remote_post_url, remote_status, scheduled_for, status }.
	 * @return array|null
	 */
	public static function update_remote_publish( $id, array $pub ) {
		global $wpdb;
		$id  = absint( $id );
		$now = Database::now();
		$upd = array(
			'remote_post_id'  => absint( $pub['remote_post_id'] ?? 0 ),
			'remote_post_url' => esc_url_raw( $pub['remote_post_url'] ?? '' ),
			'remote_status'   => sanitize_key( $pub['remote_status'] ?? '' ),
			'scheduled_for'   => ! empty( $pub['scheduled_for'] ) ? sanitize_text_field( $pub['scheduled_for'] ) : null,
			'updated_at'      => $now,
		);
		$formats = array( '%d', '%s', '%s', '%s', '%s' );
		if ( ! empty( $pub['article_key'] ) ) {
			$upd['article_key'] = sanitize_key( $pub['article_key'] );
			$formats[]          = '%s';
		}
		if ( ! empty( $pub['status'] ) && isset( self::statuses()[ $pub['status'] ] ) ) {
			$upd['status'] = $pub['status'];
			$formats[]     = '%s';
			if ( 'completed' === $pub['status'] ) {
				$upd['completed_at'] = $now;
				$formats[]           = '%s';
			}
		}
		$wpdb->update( Database::table( 'tasks' ), $upd, array( 'id' => $id ), $formats, array( '%d' ) );
		return self::get( $id );
	}

	/**
	 * Find a calendar task matching a business + article_key (or title).
	 *
	 * @param int    $business_id Business ID.
	 * @param string $article_key Article key.
	 * @param string $title       Optional title fallback.
	 * @return array|null
	 */
	public static function find_by_article( $business_id, $article_key, $title = '' ) {
		global $wpdb;
		$t           = Database::table( 'tasks' );
		$b           = Database::table( 'businesses' );
		$business_id = absint( $business_id );
		$article_key = sanitize_key( $article_key );
		if ( '' !== $article_key ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT t.*, b.name AS business_name, b.color AS business_color FROM {$t} t LEFT JOIN {$b} b ON b.id = t.business_id WHERE t.business_id = %d AND t.article_key = %s ORDER BY t.id DESC LIMIT 1",
					$business_id,
					$article_key
				),
				ARRAY_A
			); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( $row ) {
				return self::format( $row );
			}
		}
		$title = trim( (string) $title );
		if ( '' !== $title ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT t.*, b.name AS business_name, b.color AS business_color FROM {$t} t LEFT JOIN {$b} b ON b.id = t.business_id WHERE t.business_id = %d AND t.title = %s ORDER BY t.id DESC LIMIT 1",
					$business_id,
					$title
				),
				ARRAY_A
			); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( $row ) {
				return self::format( $row );
			}
		}
		return null;
	}

	/**
	 * Delete task.
	 *
	 * @param int $id ID.
	 * @return bool
	 */
	public static function delete( $id ) {
		global $wpdb;
		$ok = (bool) $wpdb->delete( Database::table( 'tasks' ), array( 'id' => $id ), array( '%d' ) );
		if ( $ok ) {
			do_action( 'seopm_task_deleted', $id );
		}
		return $ok;
	}

	/**
	 * Raw DB row (used to allow undoing a delete).
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function raw( $id ) {
		global $wpdb;
		$t   = Database::table( 'tasks' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $row ? $row : null;
	}

	/**
	 * Restore a previously deleted task with its original ID and timestamps.
	 *
	 * @param array $row Row returned by raw() before deletion.
	 * @return array|\WP_Error
	 */
	public static function restore( array $row ) {
		global $wpdb;
		$id = absint( $row['id'] ?? 0 );
		if ( ! $id || self::raw( $id ) ) {
			return new \WP_Error( 'seopm_task_restore', __( 'بازگردانی این تسک ممکن نیست.', 'seo-project-manager' ), array( 'status' => 409 ) );
		}
		$clean = self::clean( $row );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$datetime = static function ( $v, $fallback ) {
			return is_string( $v ) && preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $v ) ? $v : $fallback;
		};
		$now                   = Database::now();
		$clean['id']           = $id;
		$clean['completed_at'] = 'completed' === $clean['status'] ? $datetime( $row['completed_at'] ?? '', $now ) : null;
		$clean['created_by']   = absint( $row['created_by'] ?? get_current_user_id() );
		$clean['created_at']   = $datetime( $row['created_at'] ?? '', $now );
		$clean['updated_at']   = $datetime( $row['updated_at'] ?? '', $now );
		$ok                    = $wpdb->insert( Database::table( 'tasks' ), $clean, array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' ) );
		if ( ! $ok ) {
			return new \WP_Error( 'seopm_db_error', __( 'خطا در بازگردانی تسک.', 'seo-project-manager' ), array( 'status' => 500 ) );
		}
		do_action( 'seopm_task_restored', $id );
		return self::get( $id );
	}

	/**
	 * Tasks of a business inside a due-date range (used by reports).
	 *
	 * @param int    $business_id Business ID.
	 * @param string $start       Y-m-d.
	 * @param string $end         Y-m-d.
	 * @return array Raw rows.
	 */
	public static function in_range( $business_id, $start, $end ) {
		global $wpdb;
		$t = Database::table( 'tasks' );
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$t} WHERE business_id = %d AND due_date BETWEEN %s AND %s ORDER BY due_date ASC, id ASC", $business_id, $start, $end ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			ARRAY_A
		);
	}

	/**
	 * Count tasks for a business in a range (report form preview).
	 *
	 * @param int    $business_id Business ID.
	 * @param string $start       Y-m-d.
	 * @param string $end         Y-m-d.
	 * @return int
	 */
	public static function count_in_range( $business_id, $start, $end ) {
		global $wpdb;
		$t = Database::table( 'tasks' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE business_id = %d AND due_date BETWEEN %s AND %s", $business_id, $start, $end ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Format row for API.
	 *
	 * @param array $row Row.
	 * @return array
	 */
	public static function format( array $row ) {
		$types    = self::types();
		$statuses = self::statuses();
		$today    = Jalali::today();
		$art_key  = (string) ( $row['article_key'] ?? '' );
		if ( '' === $art_key && 'article_writing' === ( $row['task_type'] ?? '' ) && ! empty( $row['title'] ) ) {
			$art_key = Article_Generator::make_key( $row['title'] );
		}
		return array(
			'id'              => (int) $row['id'],
			'business_id'     => (int) $row['business_id'],
			'business_name'   => $row['business_name'] ?? '',
			'business_color'  => $row['business_color'] ?? '#64748b',
			'title'           => $row['title'],
			'task_type'       => $row['task_type'],
			'task_type_label' => $types[ $row['task_type'] ] ?? $row['task_type'],
			'due_date'        => $row['due_date'],
			'description'     => (string) $row['description'],
			'article_key'     => $art_key,
			'remote_post_id'  => (int) ( $row['remote_post_id'] ?? 0 ),
			'remote_post_url' => (string) ( $row['remote_post_url'] ?? '' ),
			'remote_status'   => (string) ( $row['remote_status'] ?? '' ),
			'scheduled_for'   => $row['scheduled_for'] ?? null,
			'status'          => $row['status'],
			'status_label'    => $statuses[ $row['status'] ] ?? $row['status'],
			'overdue'         => 'completed' !== $row['status'] && $row['due_date'] < $today,
			'completed_at'    => $row['completed_at'],
			'created_at'      => $row['created_at'],
			'updated_at'      => $row['updated_at'],
		);
	}
}

=== SEO Project Manager ===
Contributors: seoprojectmanager
Tags: seo, project management, tasks, calendar, reports
Requires at least: 6.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.10.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage SEO clients, keywords, tasks, a Jalali (Persian) task calendar, notes and professional Persian PDF reports from one dashboard.

== Description ==

SEO Project Manager (مدیریت پروژه‌های سئو) is a Persian, RTL-first project management panel for SEO agencies and freelancers.

* Businesses (clients) with website, sitemap, brand color and weighted keywords.
* Tasks with five activity types and three statuses, filters, search, sorting, quick status change and bulk actions.
* Jalali calendar (monthly / weekly / daily) built on FullCalendar, with multi-business filter, click-to-create and drag & drop rescheduling.
* Dashboard with live statistics, overdue and upcoming tasks.
* Monthly and custom-range reports stored as immutable, versioned snapshots, with A4 RTL PDF output (mPDF) and three report themes.

All dates are stored as Gregorian in the database and shown as Jalali in the interface and PDFs.

== Installation ==

1. Upload the ZIP via Plugins → Add New → Upload Plugin, or extract it to wp-content/plugins.
2. Activate the plugin.
3. Configure branding under "مدیریت پروژه‌های سئو → تنظیمات".

== Frequently Asked Questions ==

= Is my data deleted when I deactivate the plugin? =

No. Data is removed on uninstall only if "delete all data on uninstall" is enabled in settings.

= Where are PDF files stored? =

In wp-content/uploads/seopm-reports with random file names and direct access blocked. Downloads go through an authenticated, nonce-protected endpoint. On Nginx, add a deny rule for that folder.

== Changelog ==

= 1.9.6 =
* Fix heuristic suggester fallback: replace hardcoded Tehran Home Care physiotherapy templates with dynamic, niche-agnostic SEO cluster profiles built directly from target keywords and business context.
* Fix target pillar resolver: dynamically match service and landing pages from sitemap and fall back to the client business homepage instead of hardcoded external physiotherapy endpoints.
* Ensure all client businesses receive authentic, domain-relevant suggested articles across both heuristic and AI generation modes.

= 1.9.5 =
* Enforce strict prerequisites before generating article suggestions: require explicit and valid Sitemap URL and at least 5 target keywords registered in business settings.
* Add comprehensive Prerequisite Status UI with direct navigation buttons to edit business settings or manage keywords.
* Prevent indefinite loading or hallucinated cluster allocations when business data is incomplete.

= 1.9.4 =
* Deep semantic anti-cannibalization gatekeeper matching pathology & intent across sitemap content.

= 1.10.0 =
* Add new "یادداشت‌ها" (Notes) section: full CRUD sticky notes board with business filtering, search, pastel color themes, pinned notes section, tags, and one-click copy.
* Isolate domain-specific suggestions: strictly limit clinical physiotherapy heuristic profiles to businesses explicitly in the physiotherapy domain, ensuring other businesses always receive dynamic niche-tailored SEO clusters.
* Add automated cache invalidation when keywords or business sitemaps are updated.
* Connect "بروزرسانی داده‌های سایت" button to automatically force refresh of suggested articles.

= 1.2.1 =
* Transform suggested articles into true SEO Topic Cluster articles: replace generic guide titles with deep problem-solving, symptom-focused, exercise, timeline and comparison cluster posts.
* Add Pillar Internal Linking Strategy: identify target service landing pages (sub-pillars), recommend exact and LSI anchor texts, and provide contextual in-content linking placement guidelines.
* Add target pillar badge and direct link column in suggestions table.

= 1.2.0 =
* Add AI SEO Content Strategy & Suggested Articles (مقالات پیشنهادی): 20 strategic article proposals proportionally distributed by keyword weights, comprehensive sitemap/content audit, cannibalization check, search intent classification, 6-phase content briefs, and direct "+ تقویم تسک" integration.

= 1.1.0 =
* Add project site report modal on clicking business title: comprehensive report with target keywords, linked articles, and pages audit via live WP REST API and XML sitemaps.

= 1.0.0 =
* First release (MVP).

== Third-party libraries ==

* FullCalendar 6.1.15 — MIT
* Chart.js 4.4.4 — MIT
* mPDF 8.2 — GPL-2.0 (bundled fonts: XB Riyaz, DejaVu Sans)

/**
 * Shared task create/edit form and task details modal
 * (used by dashboard, task list and calendar).
 */
( function ( window ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var ui = SEOPM.ui;
	var J = SEOPM.jalali;
	var el = ui.el;
	var C = SEOPM.config;

	/**
	 * Create / edit form.
	 * @param {Object} opts {task, date, businessId, onSaved(task), onDeleted(id)}
	 */
	function open( opts ) {
		opts = opts || {};
		var task = opts.task || null;
		var isEdit = Boolean( task && task.id );

		if ( ! ( C.businesses || [] ).length ) {
			ui.confirm( 'برای ایجاد تسک ابتدا باید حداقل یک کسب‌وکار تعریف کنید.', { title: 'کسب‌وکاری وجود ندارد', confirmText: 'ایجاد کسب‌وکار' } ).then( function ( ok ) {
				if ( ok ) {
					window.location.href = C.urls.businesses + '&new=1';
				}
			} );
			return;
		}

		var title = el( 'input', { type: 'text', required: true, maxlength: '255', value: task && task.title ? task.title : '', placeholder: 'مثلاً: نگارش مقاله راهنمای خرید', autofocus: true } );
		var last = lastChoice();
		var defaultBiz = ( task && task.business_id ) ? task.business_id : ( opts.businessId || ( ui.findBusiness( last.business_id ) ? last.business_id : ( C.businesses[ 0 ] && C.businesses[ 0 ].id ) ) );
		var business = ui.select( ui.businessOptions(), defaultBiz, { required: true } );
		var type = ui.select( ui.mapOptions( C.types ), ( task && task.task_type && C.types[ task.task_type ] ) ? task.task_type : ( C.types[ last.task_type ] ? last.task_type : 'article_writing' ) );
		var status = ui.select( ui.mapOptions( C.statuses ), ( task && task.status && C.statuses[ task.status ] ) ? task.status : 'pending' );
		var date = SEOPM.datepicker.create( { value: ( task && task.due_date ) ? task.due_date : ( opts.date || C.today ), allowEmpty: false, label: 'تاریخ انجام' } );
		var error = el( 'div', { class: 'seopm-form-error', role: 'alert', hidden: true } );

		var swatch = el( 'i', { class: 'seopm-select-swatch' } );
		function paintSwatch() {
			var b = ui.findBusiness( business.value );
			swatch.style.background = b ? b.color : '#94a3b8';
		}
		business.addEventListener( 'change', paintSwatch );
		paintSwatch();

		var form = el( 'form', { class: 'seopm-form-grid', novalidate: true }, [
			ui.field( 'عنوان تسک *', title, 'seopm-span-2' ),
			ui.field( 'کسب‌وکار *', el( 'div', { class: 'seopm-select-with-swatch' }, [ swatch, business ] ) ),
			ui.field( 'نوع تسک *', type ),
			el( 'div', { class: isEdit ? 'seopm-field' : 'seopm-field seopm-span-2' }, [ el( 'span', { text: 'تاریخ انجام *' } ), date.element ] ),
			isEdit ? ui.field( 'وضعیت', status ) : null,
			error
		] );

		var buttons = [];
		if ( isEdit ) {
			buttons.push( el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-danger-ghost seopm-push', onclick: function () {
				remove( task, function () {
					m.close();
					if ( opts.onDeleted ) {
						opts.onDeleted( task.id );
					}
				} );
			} }, [ ui.icon( 'trash' ), 'حذف' ] ) );
		}
		buttons.push( ui.button( 'انصراف', 'ghost', function () {
			m.close();
		} ) );
		var saveBtn = ui.button( isEdit ? 'ذخیره تغییرات' : 'ایجاد تسک', 'primary', submit );
		buttons.push( saveBtn );

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			submit();
		} );
		title.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Enter' ) {
				e.preventDefault();
				submit();
			}
		} );

		var m = ui.modal( { title: isEdit ? 'ویرایش تسک' : 'تسک جدید', body: form, footer: buttons, size: 'md' } );

		function submit() {
			date.input.blur();
			var data = {
				title: title.value.trim(),
				business_id: +business.value,
				task_type: type.value,
				due_date: date.getValue(),
				status: status.value,
				description: ( isEdit && task && task.description ) ? task.description : ''
			};
			if ( task && task.article_key ) {
				data.article_key = task.article_key;
			}
			if ( ! data.title ) {
				return showError( 'عنوان تسک را وارد کنید.', title );
			}
			if ( ! data.due_date ) {
				return showError( 'تاریخ انجام معتبر نیست.', date.input );
			}
			m.setBusy( true );
			ui.api( isEdit ? '/tasks/' + task.id : '/tasks', { method: isEdit ? 'PUT' : 'POST', data: data, silent: true } ).then( function ( saved ) {
				rememberChoice( data.business_id, data.task_type );
				ui.toast( isEdit ? 'تسک به‌روزرسانی شد.' : 'تسک ایجاد شد.' );
				m.close();
				if ( opts.onSaved ) {
					opts.onSaved( saved );
				}
			} ).catch( function ( err ) {
				m.setBusy( false );
				showError( ( err && err.message ) || 'خطا در ذخیره تسک' );
			} );
		}

		function showError( msg, focusEl ) {
			error.textContent = msg;
			error.hidden = false;
			if ( focusEl ) {
				focusEl.focus();
			}
		}
	}

	var LAST_KEY = 'seopm_last_task_choice';
	function lastChoice() {
		try {
			return JSON.parse( window.localStorage.getItem( LAST_KEY ) ) || {};
		} catch ( e ) {
			return {};
		}
	}
	function rememberChoice( businessId, taskType ) {
		try {
			window.localStorage.setItem( LAST_KEY, JSON.stringify( { business_id: businessId, task_type: taskType } ) );
		} catch ( e ) {}
	}

	/**
	 * Delete immediately and offer "undo" in the toast (no blocking confirm).
	 * @param {Object}   task
	 * @param {Function} done Called after delete and again after a successful undo.
	 */
	function remove( task, done ) {
		ui.api( '/tasks/' + task.id, { method: 'DELETE' } ).then( function ( res ) {
			done();
			ui.toast( '«' + task.title + '» حذف شد.', 'success', {
				label: 'بازگردانی',
				onClick: function () {
					ui.api( '/tasks/restore', { method: 'POST', data: { task: res.task } } ).then( function () {
						ui.toast( 'تسک بازگردانی شد.' );
						done();
					} );
				}
			} );
		} );
	}

	/** Quick status change. */
	function setStatus( task, status ) {
		return ui.api( '/tasks/' + task.id + '/status', { method: 'PATCH', data: { status: status } } ).then( function ( saved ) {
			ui.toast( 'وضعیت به «' + C.statuses[ status ] + '» تغییر کرد.' );
			return saved;
		} );
	}

	/**
	 * Details modal with quick status change, edit and delete.
	 * @param {Object} task
	 * @param {Object} opts {onChange(task|null)}
	 */
	function details( task, opts ) {
		opts = opts || {};
		var notify = function ( t ) {
			if ( opts.onChange ) {
				opts.onChange( t );
			}
		};

		var statusGroup = el( 'div', { class: 'seopm-segmented seopm-segmented-status', role: 'group', 'aria-label': 'وضعیت' } );
		function drawStatus() {
			ui.clear( statusGroup );
			Object.keys( C.statuses ).forEach( function ( key ) {
				statusGroup.appendChild( el( 'button', {
					type: 'button',
					class: 'seopm-st-btn seopm-st-btn-' + key + ( task.status === key ? ' is-active' : '' ),
					'aria-pressed': task.status === key ? 'true' : 'false',
					onclick: function () {
						if ( task.status === key ) {
							return;
						}
						setStatus( task, key ).then( function ( saved ) {
							task = saved;
							drawStatus();
							drawMeta();
							notify( saved );
						} );
					}
				}, [ ui.icon( ui.STATUS_ICONS[ key ] ), C.statuses[ key ] ] ) );
			} );
		}

		var meta = el( 'div', { class: 'seopm-details' } );
		function drawMeta() {
			ui.clear( meta );
			ui.append( meta, [
				row( 'کسب‌وکار', ui.businessChip( task.business_name, task.business_color ) ),
				row( 'نوع', task.task_type_label ),
				row( 'تاریخ انجام', el( 'span', {}, [ J.format( task.due_date, 'long' ), ' ', el( 'small', { class: task.overdue ? 'seopm-text-danger' : 'seopm-muted', text: '(' + ui.dueText( task.due_date, task.status === 'completed' ) + ')' } ) ] ) ),
				row( 'وضعیت فعلی', ui.statusBadge( task ) ),
				task.description ? row( 'توضیحات', el( 'div', { class: 'seopm-pre', text: task.description } ) ) : null,
				el( 'div', { class: 'seopm-details-foot seopm-muted' }, [
					'ایجاد: ' + fmtUtc( task.created_at ),
					' · آخرین ویرایش: ' + fmtUtc( task.updated_at ),
					task.completed_at ? ' · تکمیل: ' + fmtUtc( task.completed_at ) : ''
				] )
			] );
		}

		drawStatus();
		drawMeta();

		var publishCard = null;
		if ( task.task_type === 'article_writing' ) {
			publishCard = el( 'div', { class: 'seopm-publish-card' } );
			renderTaskPublishCard( publishCard, task, function ( updatedTask ) {
				if ( updatedTask ) {
					task = updatedTask;
					drawStatus();
					drawMeta();
					notify( updatedTask );
				}
			} );
		}

		var m = ui.modal( {
			title: task.title,
			accent: task.business_color,
			body: [ statusGroup, meta, publishCard ],
			footer: [
				el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-danger-ghost seopm-push', onclick: function () {
					remove( task, function () {
						m.close();
						notify( null );
					} );
				} }, [ ui.icon( 'trash' ), 'حذف' ] ),
				ui.button( 'ویرایش', 'primary', function () {
					m.close();
					open( { task: task, onSaved: notify, onDeleted: function () {
						notify( null );
					} } );
				}, 'edit' )
			]
		} );
	}

	/**
	 * Render remote WordPress scheduled-publish card inside an article_writing task's details modal.
	 */
	function renderTaskPublishCard( box, task, onUpdated ) {
		function loadStatus() {
			ui.clear( box );
			box.appendChild( el( 'div', { class: 'seopm-publish-loading' }, [
				el( 'span', { class: 'seopm-test-spinner' } ),
				document.createTextNode( ' در حال بررسی وضعیت آمادگی مقاله برای انتشار در سایت مقصد...' )
			] ) );

			ui.api( '/tasks/' + task.id + '/publish-status', { silent: true } ).then( function ( st ) {
				drawStatus( st );
			} ).catch( function ( err ) {
				ui.clear( box );
				box.appendChild( el( 'div', { class: 'seopm-notice seopm-notice-error', text: ( err && err.message ) || 'خطا در بررسی وضعیت انتشار' } ) );
			} );
		}

		function checkItem( ok, label, extra ) {
			return el( 'div', { class: 'seopm-pub-check ' + ( ok ? 'is-ok' : 'is-missing' ) }, [
				ui.icon( ok ? 'yes-alt' : 'dismiss' ),
				el( 'span', { text: label } ),
				extra ? el( 'small', { class: 'seopm-muted', text: extra } ) : null
			] );
		}

		function drawStatus( st ) {
			ui.clear( box );
			var checks = st.checks || {};
			var prev = st.preview || {};
			var remote = st.remote || {};
			var pTime = st.publish_time || '21:00';
			var dueLabel = J.format( st.due_date || task.due_date, 'long' );
			var bizWpUrl = ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&edit=' + st.business_id + '&tab=wp';
			var sugUrl = ( C.urls && C.urls.suggestions ? C.urls.suggestions : 'admin.php?page=seopm-suggestions' ) + '&business=' + st.business_id + '&tab=suggestions';

			var head = el( 'div', { class: 'seopm-pub-head' }, [
				el( 'div', { class: 'seopm-pub-title' }, [
					ui.icon( 'cloud-upload' ),
					el( 'strong', { text: 'انتشار زمان‌بندی‌شده در سایت مقصد' } )
				] ),
				el( 'span', { class: 'seopm-pub-schedule-pill', text: dueLabel + ' · ساعت ' + J.faDigits( pTime ) } )
			] );

			var checklist = el( 'div', { class: 'seopm-pub-checklist' }, [
				checkItem( checks.title, 'عنوان مقاله' ),
				checkItem( checks.slug, 'اسلاگ (Slug)', prev.url_slug ? prev.url_slug : 'تولید نشده' ),
				checkItem( checks.html, 'کد HTML مقاله' ),
				checkItem( checks.image, 'تصویر شاخص مقاله' )
			] );

			var prevImages = Array.isArray( prev.images ) ? prev.images : [];
			var thumbWrap = null;
			if ( prevImages.length > 0 && st.article_key ) {
				var imgGrid = el( 'div', { class: 'seopm-images-grid is-compact' } );
				prevImages.forEach( function ( im, idx ) {
					var isFeat = Boolean( im.is_featured );
					var isInBody = Boolean( im.is_in_content );

					function persistModalImages( toastText ) {
						statusMsg.hidden = false;
						statusMsg.className = 'seopm-pub-action-msg is-loading';
						statusMsg.textContent = 'در حال ذخیره انتخاب تصاویر...';
						ui.api( '/businesses/' + st.business_id + '/articles/draft', {
							method: 'POST',
							data: {
								article_key: st.article_key,
								title: prev.title || task.title,
								url_slug: prev.url_slug || '',
								images: prevImages
							},
							silent: true
						} ).then( function () {
							ui.toast( toastText, 'success' );
							loadStatus();
						} ).catch( function ( err ) {
							statusMsg.className = 'seopm-pub-action-msg is-error';
							statusMsg.textContent = ( err && err.message ) || 'خطا در ذخیره انتخاب تصویر.';
						} );
					}

					var featCb = el( 'input', { type: 'checkbox' } );
					featCb.checked = isFeat;
					featCb.addEventListener( 'change', function () {
						var chk = featCb.checked;
						prevImages.forEach( function ( x ) { x.is_featured = false; } );
						im.is_featured = chk;
						persistModalImages( chk ? 'تصویر شاخص انتخاب شد.' : 'انتخاب تصویر شاخص برداشته شد.' );
					} );

					var inBodyCb = el( 'input', { type: 'checkbox' } );
					inBodyCb.checked = isInBody;
					inBodyCb.addEventListener( 'change', function () {
						im.is_in_content = inBodyCb.checked;
						persistModalImages( inBodyCb.checked ? 'تصویر میان‌متنی (فول‌سایز قبل از H2) فعال شد.' : 'تصویر میان‌متنی برداشته شد.' );
					} );

					imgGrid.appendChild( el( 'div', { class: 'seopm-image-card is-compact' + ( isFeat ? ' is-featured' : '' ) + ( isInBody ? ' is-in-content' : '' ) }, [
						el( 'div', { class: 'seopm-image-card-media' }, [
							el( 'a', { href: im.url, target: '_blank', rel: 'noopener noreferrer' }, [
								el( 'img', { src: im.url, alt: prev.title || '', class: 'seopm-image-card-img' } )
							] ),
							el( 'span', { class: 'seopm-image-card-num', text: 'تصویر ' + J.faDigits( idx + 1 ) } )
						] ),
						el( 'div', { class: 'seopm-image-card-body' }, [
							el( 'label', { class: 'seopm-image-check-label' + ( isFeat ? ' is-checked' : '' ) }, [
								featCb,
								el( 'span', { text: 'تصویر شاخص' } )
							] ),
							el( 'label', { class: 'seopm-image-check-label' + ( isInBody ? ' is-checked-body' : '' ) }, [
								inBodyCb,
								el( 'span', { text: 'میان‌متنی (فول‌سایز قبل از H2)' } )
							] )
						] )
					] ) );
				} );
				thumbWrap = el( 'div', { style: { marginBottom: '12px' } }, [
					el( 'div', { class: 'seopm-small seopm-muted', style: { marginBottom: '6px' }, text: 'اسلاگ: ' + ( prev.url_slug || '—' ) + ( prev.keyword ? '  |  کلیدواژه Rank Math: ' + prev.keyword : '' ) } ),
					imgGrid
				] );
			} else if ( prev.featured_image_url ) {
				thumbWrap = el( 'div', { class: 'seopm-pub-thumb-row' }, [
					el( 'img', { src: prev.featured_image_url, alt: prev.title || '', class: 'seopm-pub-thumb' } ),
					el( 'div', { class: 'seopm-pub-thumb-meta' }, [
						el( 'div', { class: 'seopm-small', text: 'اسلاگ: ' + ( prev.url_slug || '—' ) } ),
						prev.keyword ? el( 'div', { class: 'seopm-small seopm-muted', text: 'کلیدواژه کانونی Rank Math: ' + prev.keyword } ) : null
					] )
				] );
			}

			var remoteBar = null;
			if ( remote.post_id > 0 ) {
				var isFuture = remote.status === 'future';
				remoteBar = el( 'div', { class: 'seopm-pub-remote-bar ' + ( isFuture ? 'is-scheduled' : 'is-published' ) }, [
					ui.icon( isFuture ? 'clock' : 'yes-alt' ),
					el( 'span', { text: isFuture ? 'زمان‌بندی شده در سایت مقصد برای ساعت ' + J.faDigits( pTime ) : 'منتشر شده در سایت مقصد' } ),
					remote.post_url ? el( 'a', { href: remote.post_url, target: '_blank', rel: 'noopener noreferrer', class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: 'مشاهده پست' } ) : null
				] );
			}

			var alertBox = null;
			if ( ! st.content_ready ) {
				alertBox = el( 'div', { class: 'seopm-pub-alert is-error' }, [
					ui.icon( 'warning' ),
					el( 'span', { text: 'امکان ارسال وجود ندارد! موارد ناقص: ' + ( st.missing || [] ).join( '، ' ) } )
				] );
			} else if ( ! st.wp_connected ) {
				alertBox = el( 'div', { class: 'seopm-pub-alert is-warn' }, [
					ui.icon( 'admin-network' ),
					el( 'span', { text: 'اتصال وردپرس (نام کاربری و رمز عبور برنامه) برای «' + st.business_name + '» ثبت نشده است.' } ),
					el( 'a', { href: bizWpUrl, class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: 'تنظیم اتصال وردپرس' } )
				] );
			}

			var statusMsg = el( 'div', { class: 'seopm-pub-action-msg', hidden: true } );
			var actions = el( 'div', { class: 'seopm-pub-actions' } );

			var sendBtn = ui.button(
				remote.post_id > 0 ? 'بروزرسانی زمان‌بندی در سایت (ساعت ' + J.faDigits( pTime ) + ')' : 'ارسال به سایت (زمان‌بندی ساعت ' + J.faDigits( pTime ) + ')',
				'primary seopm-btn-sm',
				function () {
					sendBtn.disabled = true;
					statusMsg.hidden = false;
					statusMsg.className = 'seopm-pub-action-msg is-loading';
					ui.clear( statusMsg );
					statusMsg.appendChild( el( 'span', { class: 'seopm-test-spinner' } ) );
					statusMsg.appendChild( document.createTextNode( ' در حال آپلود تصویر شاخص، ثبت کد HTML، زمان‌بندی ساعت ' + J.faDigits( pTime ) + ' و ثبت Rank Math SEO...' ) );

					ui.api( '/tasks/' + task.id + '/publish', {
						method: 'POST',
						data: { due_date: st.due_date || task.due_date },
						silent: true
					} ).then( function ( r ) {
						ui.toast( ( r && r.message ) || 'مقاله با موفقیت زمان‌بندی شد.', 'success' );
						if ( onUpdated && r && r.task ) {
							onUpdated( r.task );
						}
						loadStatus();
					} ).catch( function ( err ) {
						sendBtn.disabled = false;
						statusMsg.className = 'seopm-pub-action-msg is-error';
						statusMsg.textContent = ( err && err.message ) || 'خطا در ارسال مقاله به سایت مقصد.';
					} );
				},
				'cloud-upload'
			);
			if ( ! st.ready ) {
				sendBtn.disabled = true;
			}
			actions.appendChild( sendBtn );

			// Quick inline 2-image generator/uploader if featured image is not yet selected!
			if ( ! checks.image && st.article_key ) {
				var canGenImg = Boolean( prev.has_article && prev.has_html );
				var quickImgBtn = ui.button( 'تولید ۲ تصویر با AI', 'ghost seopm-btn-sm', function () {
					if ( ! canGenImg ) {
						ui.toast( 'تا زمانی که متن مقاله و کد HTML تولید نشده باشند، امکان تولید تصویر وجود ندارد.', 'warning' );
						return;
					}
					quickImgBtn.disabled = true;
					statusMsg.hidden = false;
					statusMsg.className = 'seopm-pub-action-msg is-loading';
					ui.clear( statusMsg );
					statusMsg.appendChild( el( 'span', { class: 'seopm-test-spinner' } ) );
					statusMsg.appendChild( document.createTextNode( ' در حال تولید ۲ تصویر با هوش مصنوعی مطابق پرامپت کسب‌وکار...' ) );
					ui.api( '/businesses/' + st.business_id + '/articles/generate-image', {
						method: 'POST',
						data: {
							article_key: st.article_key,
							title: prev.title || task.title,
							keyword: prev.keyword || '',
							url_slug: prev.url_slug || '',
							count: 2
						},
						silent: true
					} ).then( function () {
						ui.toast( '۲ تصویر تولید شد؛ اکنون تیک «تصویر شاخص» را روی گزینه دلخواه بزنید.', 'success' );
						loadStatus();
					} ).catch( function ( err ) {
						quickImgBtn.disabled = false;
						statusMsg.className = 'seopm-pub-action-msg is-error';
						statusMsg.textContent = ( err && err.message ) || 'خطا در تولید تصویر شاخص.';
					} );
				}, 'format-image' );
				if ( ! canGenImg ) {
					quickImgBtn.disabled = true;
					quickImgBtn.title = 'ابتدا متن مقاله و کد HTML باید تولید شده باشند';
				}
				actions.appendChild( quickImgBtn );

				var fileInput = el( 'input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', hidden: true } );
				fileInput.addEventListener( 'change', function () {
					var f = fileInput.files && fileInput.files[ 0 ];
					if ( ! f ) {
						return;
					}
					var reader = new FileReader();
					reader.onload = function () {
						statusMsg.hidden = false;
						statusMsg.className = 'seopm-pub-action-msg is-loading';
						statusMsg.textContent = 'در حال آپلود تصویر شاخص...';
						ui.api( '/businesses/' + st.business_id + '/articles/upload-image', {
							method: 'POST',
							data: {
								article_key: st.article_key,
								title: prev.title || task.title,
								url_slug: prev.url_slug || '',
								data_url: reader.result
							},
							silent: true
						} ).then( function () {
							ui.toast( 'تصویر شاخص آپلود و ذخیره شد.', 'success' );
							loadStatus();
						} ).catch( function ( err ) {
							statusMsg.className = 'seopm-pub-action-msg is-error';
							statusMsg.textContent = ( err && err.message ) || 'خطا در آپلود تصویر.';
						} );
					};
					reader.readAsDataURL( f );
				} );
				actions.appendChild( fileInput );
				actions.appendChild( ui.button( 'آپلود تصویر', 'ghost seopm-btn-sm', function () {
					fileInput.click();
				}, 'upload' ) );
			}

			if ( ! checks.html || ! checks.slug ) {
				actions.appendChild( el( 'a', { href: sugUrl, class: 'seopm-btn seopm-btn-ghost seopm-btn-sm' }, [ ui.icon( 'edit-page' ), 'تکمیل در مقالات پیشنهادی' ] ) );
			}

			if ( st.article_key ) {
				var tgTaskBtn = ui.button( 'ارسال به تلگرام کارفرما', 'ghost seopm-btn-sm', function () {
					tgTaskBtn.disabled = true;
					ui.toast( 'در حال ارسال لینک پیش‌نمایش به تلگرام کارفرما...', 'info' );
					ui.api( '/tasks/' + task.id + '/send-telegram-preview', {
						method: 'POST',
						silent: true
					} ).then( function ( r ) {
						tgTaskBtn.disabled = false;
						ui.toast( ( r && r.message ) || 'پیش‌نمایش به تلگرام کارفرما ارسال شد.', 'success' );
						loadStatus();
					} ).catch( function ( err ) {
						tgTaskBtn.disabled = false;
						ui.toast( ( err && err.message ) || 'خطا در ارسال به تلگرام کارفرما.', 'error' );
					} );
				}, 'share' );
				actions.appendChild( tgTaskBtn );
			}

			var reviewBox = null;
			if ( prev.review_token || prev.review_status ) {
				var rStat = prev.review_status || 'pending';
				var rText = 'در انتظار بررسی کارفرما';
				if ( rStat === 'approved' ) {
					rText = 'تأیید شده برای انتشار توسط کارفرما ✓';
				} else if ( rStat === 'changes_requested' ) {
					rText = 'کارفرما درخواست اصلاحیه داده است ✏️';
				}
				var pUrl = prev.review_token ? ( window.location.origin + '/?seopm_preview=' + encodeURIComponent( prev.review_token ) ) : '';
				reviewBox = el( 'div', { class: 'seopm-pub-alert ' + ( rStat === 'approved' ? 'is-ok' : ( rStat === 'changes_requested' ? 'is-warn' : 'is-info' ) ), style: { marginTop: '10px' } }, [
					ui.icon( rStat === 'approved' ? 'yes-alt' : ( rStat === 'changes_requested' ? 'edit' : 'clock' ) ),
					el( 'div', { style: { flex: '1' } }, [
						el( 'strong', { text: 'وضعیت بررسی کارفرما: ' + rText } ),
						prev.review_feedback ? el( 'div', { style: { marginTop: '4px', fontSize: '12px' }, text: 'یادداشت کارفرما: ' + prev.review_feedback } ) : null
					] ),
					pUrl ? el( 'a', { href: pUrl, target: '_blank', rel: 'noopener noreferrer', class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: 'مشاهده پیش‌نمایش' } ) : null
				] );
			}

			ui.append( box, [ head, remoteBar, checklist, thumbWrap, alertBox, reviewBox, actions, statusMsg ] );
		}

		loadStatus();
	}

	function row( label, value ) {
		return el( 'div', { class: 'seopm-details-row' }, [ el( 'span', { class: 'seopm-muted', text: label } ), el( 'div', {}, value ) ] );
	}

	/** UTC "Y-m-d H:i:s" -> local Jalali string. */
	function fmtUtc( utc ) {
		if ( ! utc ) {
			return '—';
		}
		var d = new Date( utc.replace( ' ', 'T' ) + 'Z' );
		if ( isNaN( d ) ) {
			return '—';
		}
		return J.format( J.isoFromDate( d ) ) + ' ' + J.faDigits( J.pad( d.getHours() ) + ':' + J.pad( d.getMinutes() ) );
	}

	/**
	 * Single clickable status badge that opens a small status menu.
	 * @param {Object}   task
	 * @param {Function} onChanged(savedTask)
	 */
	var openMenu = null;
	function closeMenu() {
		if ( openMenu ) {
			openMenu.remove();
			openMenu = null;
		}
	}
	document.addEventListener( 'mousedown', function ( e ) {
		if ( openMenu && ! openMenu.contains( e.target ) ) {
			closeMenu();
		}
	} );
	document.addEventListener( 'keydown', function ( e ) {
		if ( e.key === 'Escape' ) {
			closeMenu();
		}
	} );

	function statusPicker( task, onChanged ) {
		var label = C.statuses[ task.status ];
		var btn = el( 'button', {
			type: 'button',
			class: 'seopm-badge seopm-badge-btn seopm-badge-' + task.status,
			'aria-haspopup': 'menu',
			'aria-label': 'وضعیت: ' + label + ' (برای تغییر کلیک کنید)'
		}, [ ui.icon( ui.STATUS_ICONS[ task.status ] ), label, ui.icon( 'arrow-down-alt2' ) ] );
		btn.addEventListener( 'click', function ( e ) {
			e.stopPropagation();
			var wasOpenHere = openMenu && openMenu.owner === btn;
			closeMenu();
			if ( wasOpenHere ) {
				return;
			}
			var menu = el( 'div', { class: 'seopm-status-menu seopm-app', dir: 'rtl', role: 'menu' } );
			Object.keys( C.statuses ).forEach( function ( key ) {
				menu.appendChild( el( 'button', {
					type: 'button',
					role: 'menuitemradio',
					'aria-checked': key === task.status ? 'true' : 'false',
					class: 'seopm-status-menu-item' + ( key === task.status ? ' is-current' : '' ),
					onclick: function () {
						closeMenu();
						if ( key === task.status ) {
							return;
						}
						btn.disabled = true;
						setStatus( task, key ).then( onChanged ).catch( function () {
							btn.disabled = false;
						} );
					}
				}, [ el( 'span', { class: 'seopm-badge seopm-badge-' + key }, [ ui.icon( ui.STATUS_ICONS[ key ] ), C.statuses[ key ] ] ) ] ) );
			} );
			menu.owner = btn;
			document.body.appendChild( menu );
			var r = btn.getBoundingClientRect();
			menu.style.top = ( r.bottom + window.scrollY + 4 ) + 'px';
			menu.style.left = Math.max( 8, r.right + window.scrollX - menu.offsetWidth ) + 'px';
			openMenu = menu;
			var first = menu.querySelector( '.is-current' ) || menu.firstChild;
			first.focus();
		} );
		return btn;
	}

	SEOPM.taskForm = { open: open, details: details, remove: remove, setStatus: setStatus, fmtUtc: fmtUtc, statusPicker: statusPicker };

	// Global "new task" buttons.
	document.addEventListener( 'click', function ( e ) {
		var btn = e.target.closest( '[data-action="new-task"]' );
		if ( btn && ! btn.dataset.handled ) {
			e.preventDefault();
			document.dispatchEvent( new CustomEvent( 'seopm:new-task' ) );
		}
	} );
}( window ) );

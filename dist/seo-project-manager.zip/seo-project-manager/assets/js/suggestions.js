/**
 * Suggested Articles & Project SEO Strategy full-page workspace.
 */
( function ( window, document ) {
	'use strict';

	var SEOPM = window.SEOPM;
	var ui = SEOPM.ui;
	var J = SEOPM.jalali;
	var el = ui.el;
	var C = SEOPM.config;
	var root = document.getElementById( 'seopm-suggestions-page' );
	var bizSelect = document.getElementById( 'seopm-sug-business-select' );
	var bizWrap = document.getElementById( 'seopm-sug-biz-wrap' );
	var copyKwBtn = document.getElementById( 'seopm-sug-copy-kw' );
	var editBizLink = document.getElementById( 'seopm-sug-edit-biz' );

	if ( ! root ) {
		return;
	}

	var all = [];
	var activeBizId = 0;
	var activeTab = 'suggestions';
	var currentReportData = null;

	function cleanSlug( slug ) {
		return String( slug || '' ).trim().replace( /^\/?blog\//i, '' ).replace( /^\/+|\/+$/g, '' );
	}

	function copyPlainText( text, successMsg ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( function () {
				ui.toast( successMsg || 'کپی شد.' );
			} ).catch( function () {
				fallbackCopy( text, successMsg );
			} );
		} else {
			fallbackCopy( text, successMsg );
		}
	}

	function fallbackCopy( text, successMsg ) {
		var ta = document.createElement( 'textarea' );
		ta.value = text;
		ta.style.position = 'fixed';
		ta.style.opacity = '0';
		document.body.appendChild( ta );
		ta.select();
		try {
			document.execCommand( 'copy' );
			ui.toast( successMsg || 'کپی شد.' );
		} catch ( e ) {
			ui.toast( 'امکان کپی خودکار وجود نداشت.', 'error' );
		}
		document.body.removeChild( ta );
	}

	function copyRichHtml( html, plain, successMsg ) {
		if ( window.ClipboardItem && navigator.clipboard && navigator.clipboard.write ) {
			try {
				var item = new window.ClipboardItem( {
					'text/html': new Blob( [ html ], { type: 'text/html' } ),
					'text/plain': new Blob( [ plain ], { type: 'text/plain' } )
				} );
				navigator.clipboard.write( [ item ] ).then( function () {
					ui.toast( successMsg || 'متن مقاله همراه با لینک‌ها کپی شد.' );
				} ).catch( function () {
					copyPlainText( plain, successMsg || 'متن کپی شد.' );
				} );
				return;
			} catch ( e ) {
				// Fallback below.
			}
		}
		copyPlainText( plain, successMsg || 'متن کپی شد.' );
	}

	function syncUrl( bizId, tab ) {
		try {
			var url = new URL( window.location.href );
			if ( bizId ) {
				url.searchParams.set( 'business', String( bizId ) );
			}
			if ( tab ) {
				url.searchParams.set( 'tab', tab );
			}
			window.history.replaceState( null, '', url.toString() );
		} catch ( e ) {
			// Ignore URL sync errors on older environments.
		}
		try {
			if ( bizId ) {
				window.localStorage.setItem( 'seopm_last_sug_biz', String( bizId ) );
			}
		} catch ( e ) {
			// Ignore storage errors.
		}
	}

	function updateHeaderControls( bizId ) {
		if ( editBizLink ) {
			editBizLink.href = ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&edit=' + bizId;
			editBizLink.hidden = ! bizId;
		}
		if ( copyKwBtn ) {
			copyKwBtn.hidden = ! bizId;
		}
	}

	if ( copyKwBtn ) {
		copyKwBtn.addEventListener( 'click', function () {
			if ( currentReportData && currentReportData.keywords && currentReportData.keywords.length ) {
				var text = currentReportData.keywords.map( function ( k ) { return k.keyword; } ).join( '\n' );
				if ( navigator.clipboard && navigator.clipboard.writeText ) {
					navigator.clipboard.writeText( text );
				}
				ui.toast( J.faDigits( currentReportData.keywords.length ) + ' کلمه کلیدی در کلیپ‌بورد کپی شد.' );
			} else {
				ui.toast( 'هنوز کلمه کلیدی برای این کسب‌وکار ثبت نشده است.', 'error' );
			}
		} );
	}

	function populateBusinesses( list ) {
		all = list || [];
		C.businesses = all.map( function ( b ) {
			return { id: b.id, name: b.name, color: b.color };
		} );

		if ( ! all.length ) {
			if ( bizWrap ) {
				bizWrap.hidden = true;
			}
			updateHeaderControls( 0 );
			ui.clear( root );
			root.appendChild( el( 'div', { class: 'seopm-card' }, [
				ui.emptyState(
					'هنوز کسب‌وکاری ثبت نشده است. برای دریافت مقالات پیشنهادی و تحلیل سایت، ابتدا اولین کسب‌وکار خود را ایجاد کنید.',
					el( 'a', {
						class: 'seopm-btn seopm-btn-primary',
						href: ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&new=1'
					}, [ ui.icon( 'plus-alt2' ), 'ایجاد اولین کسب‌وکار' ] )
				)
			] ) );
			return;
		}

		var params = new URLSearchParams( window.location.search );
		var reqBiz = parseInt( params.get( 'business' ) || '0', 10 );
		var reqTab = params.get( 'tab' ) || 'suggestions';
		var validTabs = [ 'suggestions', 'keywords', 'posts', 'pages' ];
		activeTab = validTabs.indexOf( reqTab ) !== -1 ? reqTab : 'suggestions';

		var savedBiz = 0;
		try {
			savedBiz = parseInt( window.localStorage.getItem( 'seopm_last_sug_biz' ) || '0', 10 );
		} catch ( e ) {
			savedBiz = 0;
		}

		var found = all.find( function ( b ) { return b.id === reqBiz; } )
			|| all.find( function ( b ) { return b.id === savedBiz; } )
			|| all[ 0 ];

		activeBizId = found.id;

		if ( bizSelect ) {
			ui.clear( bizSelect );
			all.forEach( function ( b ) {
				var opt = el( 'option', { value: String( b.id ), text: b.name } );
				if ( b.id === activeBizId ) {
					opt.selected = true;
				}
				bizSelect.appendChild( opt );
			} );
			if ( bizWrap ) {
				bizWrap.hidden = false;
			}
		}

		updateHeaderControls( activeBizId );
		syncUrl( activeBizId, activeTab );
		fetchReport( activeBizId, false );
	}

	if ( bizSelect ) {
		bizSelect.addEventListener( 'change', function () {
			var nextId = parseInt( bizSelect.value, 10 );
			if ( ! nextId || nextId === activeBizId ) {
				return;
			}
			activeBizId = nextId;
			updateHeaderControls( activeBizId );
			syncUrl( activeBizId, activeTab );
			fetchReport( activeBizId, false );
		} );
	}

	/* --------------------------- Fetch & Render Page --------------------------- */

	function fetchReport( id, refresh ) {
		var biz = all.find( function ( x ) { return x.id === id; } ) || { id: id, name: 'پروژه', color: '#4f46e5' };
		currentReportData = null;

		ui.clear( root );
		root.appendChild( el( 'div', { class: 'seopm-card seopm-empty', style: { padding: '56px 24px' } }, [
			el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon', style: { fontSize: '36px', width: '36px', height: '36px', color: biz.color || '#4f46e5' } } ),
			el( 'p', { text: refresh ? 'در حال بروزرسانی داده‌های پروژه از وب‌سایت...' : 'در حال بارگذاری اطلاعات سایت، کلمات کلیدی و مقالات «' + biz.name + '»...', style: { marginTop: '14px', fontWeight: '700', fontSize: '15px' } } ),
			el( 'span', { class: 'seopm-muted seopm-small', text: 'در حال خواندن محتوا از وب‌سایت و نقشه سایت (Sitemap)...' } )
		] ) );

		var query = refresh ? { refresh: 1 } : {};
		ui.api( '/businesses/' + id + '/site-report', { query: query } ).then( function ( data ) {
			if ( id !== activeBizId ) {
				return;
			}
			currentReportData = data;
			renderReportView( root, data, function () {
				fetchReport( id, true );
			}, id, activeTab, Boolean( refresh ) );
		} ).catch( function ( err ) {
			if ( id !== activeBizId ) {
				return;
			}
			ui.clear( root );
			root.appendChild( el( 'div', { class: 'seopm-card seopm-empty seopm-notice-error', style: { padding: '42px 24px' } }, [
				el( 'span', { class: 'dashicons dashicons-warning', style: { fontSize: '36px', width: '36px', height: '36px', color: '#ef4444' } } ),
				el( 'p', { text: 'خطا در بارگذاری گزارش: ' + ( ( err && err.message ) || 'عدم دسترسی به اطلاعات سایت' ), style: { marginTop: '12px', fontWeight: '700' } } ),
				el( 'div', { style: { marginTop: '16px', display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' } }, [
					ui.button( 'تلاش مجدد', 'primary seopm-btn-sm', function () {
						fetchReport( id, false );
					}, 'update' ),
					el( 'a', {
						class: 'seopm-btn seopm-btn-ghost seopm-btn-sm',
						href: ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&edit=' + id
					}, [ ui.icon( 'edit' ), 'ویرایش آدرس سایت یا سایت‌مپ' ] )
				] )
			] ) );
		} );
	}

	function renderReportView( container, data, onRefresh, currentBizId, initialTab, shouldRefreshSuggestions ) {
		ui.clear( container );
		var b = data.business || {};
		var stats = data.stats || {};
		var keywords = data.keywords || [];
		var posts = data.posts || [];
		var pages = data.pages || [];

		var sourceLabel = 'اطلاعات پروژه';
		if ( stats.source === 'wp_rest' ) {
			sourceLabel = 'اتصال زنده وردپرس (REST API)';
		} else if ( stats.source === 'sitemap' ) {
			sourceLabel = 'نقشه سایت XML (Sitemap)';
		} else if ( stats.source === 'hybrid' ) {
			sourceLabel = 'ترکیبی (REST API + Sitemap)';
		}

		var headBar = el( 'div', {
			class: 'seopm-report-topbar seopm-project-hero',
			style: { borderRight: '4px solid ' + ( b.color || '#4f46e5' ) }
		}, [
			el( 'div', { class: 'seopm-report-biz-info' }, [
				el( 'div', { class: 'seopm-biz-avatar', style: { background: b.color || '#4f46e5', color: ui.contrast( b.color || '#4f46e5' ), width: '46px', height: '46px', fontSize: '20px' }, text: ( b.name || '' ).trim().charAt( 0 ) } ),
				el( 'div', {}, [
					el( 'h2', { text: b.name || '', style: { margin: '0 0 6px', fontSize: '18px', fontWeight: '800' } } ),
					el( 'div', { class: 'seopm-report-links' }, [
						b.website_url ? el( 'a', { href: b.website_url, target: '_blank', rel: 'noopener noreferrer', dir: 'ltr', class: 'seopm-link-badge', title: 'مشاهده سایت اصلی' }, [
							ui.icon( 'admin-links' ),
							b.website_url.replace( /^https?:\/\//, '' )
						] ) : null,
						b.sitemap_url ? el( 'a', { href: b.sitemap_url, target: '_blank', rel: 'noopener noreferrer', dir: 'ltr', class: 'seopm-link-badge', title: 'مشاهده نقشه سایت' }, [
							ui.icon( 'networking' ),
							'سایت‌مپ'
						] ) : null,
						el( 'span', { class: 'seopm-tag seopm-source-tag', title: 'نحوه دریافت داده‌ها' }, [
							ui.icon( 'yes-alt' ),
							sourceLabel
						] )
					] )
				] )
			] ),
			el( 'div', { class: 'seopm-report-actions' }, [
				ui.button( 'بروزرسانی داده‌های سایت', 'ghost seopm-btn-sm', onRefresh, 'update' )
			] )
		] );

		var rawSitemapUrl = ( b.sitemap_url || '' ).trim();
		var hasValidSitemap = Boolean( rawSitemapUrl && /^https?:\/\//i.test( rawSitemapUrl ) );
		var kwListCount = ( keywords && keywords.length ) || 0;
		var hasMinKeywords = kwListCount >= 5;
		var hasPrereqs = hasValidSitemap && hasMinKeywords;

		var statSuggestions = el( 'div', { class: 'seopm-report-stat-card is-clickable' + ( hasPrereqs ? '' : ' is-prereq-missing' ), dataset: { tab: 'suggestions' }, onclick: function () { switchTab( 'suggestions' ); } }, [
			el( 'div', { class: 'seopm-stat-icon-wrap', style: { background: hasPrereqs ? 'rgba(245, 158, 11, 0.12)' : 'rgba(239, 68, 68, 0.1)', color: hasPrereqs ? '#f59e0b' : '#ef4444' } }, [ ui.icon( 'lightbulb' ) ] ),
			el( 'div', { class: 'seopm-stat-content' }, [
				el( 'div', { class: 'seopm-stat-num', text: hasPrereqs ? J.faDigits( 20 ) : '۰' } ),
				el( 'div', { class: 'seopm-stat-label', text: hasPrereqs ? 'مقالات پیشنهادی (استراتژیک)' : 'مقالات پیشنهادی (نیاز به اطلاعات)' } )
			] )
		] );

		var statKeywords = el( 'div', { class: 'seopm-report-stat-card is-clickable', dataset: { tab: 'keywords' }, onclick: function () { switchTab( 'keywords' ); } }, [
			el( 'div', { class: 'seopm-stat-icon-wrap', style: { background: 'rgba(79, 70, 229, 0.1)', color: '#4f46e5' } }, [ ui.icon( 'tag' ) ] ),
			el( 'div', { class: 'seopm-stat-content' }, [
				el( 'div', { class: 'seopm-stat-num', text: J.faDigits( stats.keyword_count || keywords.length ) } ),
				el( 'div', { class: 'seopm-stat-label', text: 'کلمات کلیدی هدف' } )
			] )
		] );

		var statPosts = el( 'div', { class: 'seopm-report-stat-card is-clickable', dataset: { tab: 'posts' }, onclick: function () { switchTab( 'posts' ); } }, [
			el( 'div', { class: 'seopm-stat-icon-wrap', style: { background: 'rgba(16, 185, 129, 0.1)', color: '#10b981' } }, [ ui.icon( 'admin-post' ) ] ),
			el( 'div', { class: 'seopm-stat-content' }, [
				el( 'div', { class: 'seopm-stat-num', text: J.faDigits( stats.post_count || posts.length ) } ),
				el( 'div', { class: 'seopm-stat-label', text: 'مقالات سایت (لینک‌دار)' } )
			] )
		] );

		var statPages = el( 'div', { class: 'seopm-report-stat-card is-clickable', dataset: { tab: 'pages' }, onclick: function () { switchTab( 'pages' ); } }, [
			el( 'div', { class: 'seopm-stat-icon-wrap', style: { background: 'rgba(14, 165, 233, 0.1)', color: '#0ea5e9' } }, [ ui.icon( 'page' ) ] ),
			el( 'div', { class: 'seopm-stat-content' }, [
				el( 'div', { class: 'seopm-stat-num', text: J.faDigits( stats.page_count || pages.length ) } ),
				el( 'div', { class: 'seopm-stat-label', text: 'صفحات و برگه‌های سایت' } )
			] )
		] );

		var statsGrid = el( 'div', { class: 'seopm-report-stats-grid' }, [
			statSuggestions,
			statKeywords,
			statPosts,
			statPages
		] );

		var tabContent = el( 'div', { class: 'seopm-report-tab-body' } );

		var tabsNav = el( 'div', { class: 'seopm-segmented seopm-report-tabs' }, [
			el( 'button', {
				type: 'button',
				dataset: { tab: 'suggestions' },
				onclick: function () { switchTab( 'suggestions' ); }
			}, [ ui.icon( 'lightbulb' ), hasPrereqs ? 'مقالات پیشنهادی (۲۰ عنوان)' : 'مقالات پیشنهادی (نیاز به اطلاعات)' ] ),
			el( 'button', {
				type: 'button',
				dataset: { tab: 'keywords' },
				onclick: function () { switchTab( 'keywords' ); }
			}, [ ui.icon( 'tag' ), 'لیست کلمات کلیدی (' + J.faDigits( keywords.length ) + ')' ] ),
			el( 'button', {
				type: 'button',
				dataset: { tab: 'posts' },
				onclick: function () { switchTab( 'posts' ); }
			}, [ ui.icon( 'admin-post' ), 'عناوین مقالات سایت (' + J.faDigits( posts.length ) + ')' ] ),
			el( 'button', {
				type: 'button',
				dataset: { tab: 'pages' },
				onclick: function () { switchTab( 'pages' ); }
			}, [ ui.icon( 'page' ), 'گزارش صفحات سایت (' + J.faDigits( pages.length ) + ')' ] )
		] );

		var workspaceCard = el( 'div', { class: 'seopm-card seopm-page-tab-card' }, [
			tabsNav,
			tabContent
		] );

		function switchTab( tab ) {
			activeTab = tab;
			syncUrl( currentBizId || b.id, tab );

			tabsNav.querySelectorAll( 'button' ).forEach( function ( btn ) {
				btn.classList.toggle( 'is-active', btn.dataset.tab === tab );
			} );
			statsGrid.querySelectorAll( '.seopm-report-stat-card' ).forEach( function ( c ) {
				c.classList.toggle( 'is-active-stat', c.dataset.tab === tab );
			} );

			ui.clear( tabContent );
			if ( tab === 'keywords' ) {
				renderKeywordsTab( tabContent, keywords );
			} else if ( tab === 'suggestions' ) {
				renderSuggestionsTab( tabContent, b, currentBizId || b.id, shouldRefreshSuggestions );
				shouldRefreshSuggestions = false;
			} else if ( tab === 'posts' ) {
				renderPostsTab( tabContent, posts );
			} else if ( tab === 'pages' ) {
				renderPagesTab( tabContent, pages );
			}
		}

		container.appendChild( headBar );
		container.appendChild( statsGrid );
		container.appendChild( workspaceCard );

		switchTab( initialTab || 'suggestions' );
	}

	/* --------------------------- Keywords Tab --------------------------- */

	function renderKeywordsTab( container, keywords ) {
		var searchInput = el( 'input', { type: 'search', placeholder: 'جستجو در کلمات کلیدی هدف...' } );
		var searchBar = el( 'div', { class: 'seopm-report-search-bar' }, [
			searchInput,
			el( 'span', { class: 'seopm-muted seopm-small', text: 'مجموع: ' + J.faDigits( keywords.length ) + ' عبارت کلیدی' } )
		] );

		var tableWrap = el( 'div', { class: 'seopm-table-wrap' } );

		function updateList() {
			var q = ( searchInput.value || '' ).trim().toLowerCase();
			var filtered = keywords.filter( function ( k ) {
				return ! q || ( k.keyword || '' ).toLowerCase().indexOf( q ) !== -1;
			} );

			ui.clear( tableWrap );
			if ( ! filtered.length ) {
				tableWrap.appendChild( ui.emptyState( 'هیچ کلمه کلیدی با این عنوان یافت نشد.' ) );
				return;
			}

			var tbody = el( 'tbody' );
			filtered.forEach( function ( k, idx ) {
				var matchesWrap = el( 'div', { style: { display: 'flex', gap: '4px', flexWrap: 'wrap' } } );
				var hasMatch = false;

				if ( k.matched_posts && k.matched_posts.length ) {
					hasMatch = true;
					k.matched_posts.slice( 0, 2 ).forEach( function ( mp ) {
						matchesWrap.appendChild( el( 'a', {
							href: mp.url,
							target: '_blank',
							rel: 'noopener noreferrer',
							class: 'seopm-match-badge',
							title: 'مقاله: ' + mp.title
						}, [ ui.icon( 'admin-post' ), el( 'span', { text: mp.title } ) ] ) );
					} );
				}

				if ( k.matched_pages && k.matched_pages.length ) {
					hasMatch = true;
					k.matched_pages.slice( 0, 2 ).forEach( function ( mpg ) {
						matchesWrap.appendChild( el( 'a', {
							href: mpg.url,
							target: '_blank',
							rel: 'noopener noreferrer',
							class: 'seopm-match-badge',
							style: { background: '#f0f9ff', color: '#0369a1', borderColor: '#bae6fd' },
							title: 'برگه: ' + mpg.title
						}, [ ui.icon( 'page' ), el( 'span', { text: mpg.title } ) ] ) );
					} );
				}

				if ( ! hasMatch ) {
					matchesWrap.appendChild( el( 'span', { class: 'seopm-muted seopm-small', text: '—' } ) );
				}

				var weightWidth = Math.max( 10, Math.min( 100, ( ( k.weight || 5 ) / 10 ) * 100 ) ) + '%';
				var weightPill = el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } }, [
					el( 'span', { class: 'seopm-tag', text: 'وزن ' + J.faDigits( k.weight || 5 ) } ),
					el( 'div', { class: 'seopm-weight-meter', style: { width: '48px' } }, [
						el( 'span', { style: { width: weightWidth } } )
					] )
				] );

				var copyAction = el( 'button', {
					type: 'button',
					class: 'seopm-icon-btn',
					title: 'کپی کلمه کلیدی',
					onclick: function () {
						if ( navigator.clipboard && navigator.clipboard.writeText ) {
							navigator.clipboard.writeText( k.keyword );
						}
						ui.toast( '«' + k.keyword + '» کپی شد.' );
					}
				}, ui.icon( 'admin-page' ) );

				tbody.appendChild( el( 'tr', {}, [
					el( 'td', { style: { width: '40px', textAlign: 'center', color: 'var(--seopm-muted)' } }, J.faDigits( idx + 1 ) ),
					el( 'td', { style: { fontWeight: '700', fontSize: '14px' } }, k.keyword ),
					el( 'td', { style: { width: '140px' } }, weightPill ),
					el( 'td', {}, matchesWrap ),
					el( 'td', { style: { width: '50px', textAlign: 'center' } }, copyAction )
				] ) );
			} );

			var tbl = el( 'table', { class: 'seopm-table' }, [
				el( 'thead', {}, [
					el( 'tr', {}, [
						el( 'th', { style: { width: '40px', textAlign: 'center' } }, '#' ),
						el( 'th', {}, 'کلمه کلیدی' ),
						el( 'th', { style: { width: '140px' } }, 'اولویت / وزن' ),
						el( 'th', {}, 'محتوای منطبق در سایت' ),
						el( 'th', { style: { width: '50px', textAlign: 'center' } }, 'کپی' )
					] )
				] ),
				tbody
			] );

			tableWrap.appendChild( tbl );
		}

		searchInput.addEventListener( 'input', ui.debounce( updateList, 120 ) );
		container.appendChild( searchBar );
		container.appendChild( tableWrap );
		updateList();
	}

	/* --------------------------- Posts Tab --------------------------- */

	function renderPostsTab( container, posts ) {
		var notice = el( 'div', { class: 'seopm-notice', style: { marginBottom: '14px' } }, [
			ui.icon( 'info' ),
			' تمام عناوین مقالات زیر لینک شده‌اند؛ با کلیک بر روی هر عنوان یا دکمه «مشاهده مقاله»، مستقیماً مقاله در تب جدید باز می‌شود.'
		] );

		var searchInput = el( 'input', { type: 'search', placeholder: 'جستجو در عناوین مقالات سایت...' } );
		var searchBar = el( 'div', { class: 'seopm-report-search-bar' }, [
			searchInput,
			el( 'span', { class: 'seopm-muted seopm-small', text: 'مجموع: ' + J.faDigits( posts.length ) + ' مقاله' } )
		] );

		var tableWrap = el( 'div', { class: 'seopm-table-wrap' } );

		function updateList() {
			var q = ( searchInput.value || '' ).trim().toLowerCase();
			var filtered = posts.filter( function ( p ) {
				return ! q || ( p.title || '' ).toLowerCase().indexOf( q ) !== -1 || ( p.url || '' ).toLowerCase().indexOf( q ) !== -1;
			} );

			ui.clear( tableWrap );
			if ( ! filtered.length ) {
				tableWrap.appendChild( ui.emptyState( 'هیچ مقاله‌ای یافت نشد.' ) );
				return;
			}

			var tbody = el( 'tbody' );
			filtered.forEach( function ( p, idx ) {
				var dateStr = p.date ? J.format( p.date.slice( 0, 10 ), 'short' ) : '—';
				var modStr = p.modified ? J.format( p.modified.slice( 0, 10 ), 'short' ) : dateStr;

				var titleLink = el( 'div', {}, [
					el( 'a', {
						href: p.url,
						target: '_blank',
						rel: 'noopener noreferrer',
						class: 'seopm-table-title-link',
						title: 'مشاهده مقاله در سایت: ' + p.title
					}, [
						el( 'span', { text: p.title } ),
						ui.icon( 'external' )
					] ),
					el( 'span', { class: 'seopm-table-url-sub', text: p.url } )
				] );

				var actionBtn = el( 'a', {
					href: p.url,
					target: '_blank',
					rel: 'noopener noreferrer',
					class: 'seopm-btn seopm-btn-ghost seopm-btn-sm',
					title: 'مشاهده مقاله در برگه جدید'
				}, [
					ui.icon( 'external' ),
					'مشاهده مقاله'
				] );

				tbody.appendChild( el( 'tr', {}, [
					el( 'td', { style: { width: '40px', textAlign: 'center', color: 'var(--seopm-muted)' } }, J.faDigits( idx + 1 ) ),
					el( 'td', {}, titleLink ),
					el( 'td', { style: { width: '120px', fontSize: '12px', whiteSpace: 'nowrap' } }, dateStr ),
					el( 'td', { style: { width: '120px', fontSize: '12px', whiteSpace: 'nowrap' } }, modStr ),
					el( 'td', { style: { width: '130px', textAlign: 'left' } }, actionBtn )
				] ) );
			} );

			var tbl = el( 'table', { class: 'seopm-table' }, [
				el( 'thead', {}, [
					el( 'tr', {}, [
						el( 'th', { style: { width: '40px', textAlign: 'center' } }, '#' ),
						el( 'th', {}, 'عنوان مقاله (لینک شده)' ),
						el( 'th', { style: { width: '120px' } }, 'تاریخ انتشار' ),
						el( 'th', { style: { width: '120px' } }, 'آخرین بروزرسانی' ),
						el( 'th', { style: { width: '130px', textAlign: 'left' } }, 'عملیات' )
					] )
				] ),
				tbody
			] );

			tableWrap.appendChild( tbl );
		}

		searchInput.addEventListener( 'input', ui.debounce( updateList, 120 ) );
		container.appendChild( notice );
		container.appendChild( searchBar );
		container.appendChild( tableWrap );
		updateList();
	}

	/* --------------------------- Pages Tab --------------------------- */

	function renderPagesTab( container, pages ) {
		var notice = el( 'div', { class: 'seopm-notice', style: { marginBottom: '14px', background: 'var(--seopm-surface-2)', color: 'var(--seopm-text-2)' } }, [
			ui.icon( 'info' ),
			' تمام برگه‌ها، لندینگ‌ها و صفحات ساختار سایت در زیر لیست شده‌اند.'
		] );

		var searchInput = el( 'input', { type: 'search', placeholder: 'جستجو در صفحات سایت...' } );
		var searchBar = el( 'div', { class: 'seopm-report-search-bar' }, [
			searchInput,
			el( 'span', { class: 'seopm-muted seopm-small', text: 'مجموع: ' + J.faDigits( pages.length ) + ' برگه و صفحه' } )
		] );

		var tableWrap = el( 'div', { class: 'seopm-table-wrap' } );

		function updateList() {
			var q = ( searchInput.value || '' ).trim().toLowerCase();
			var filtered = pages.filter( function ( pg ) {
				return ! q || ( pg.title || '' ).toLowerCase().indexOf( q ) !== -1 || ( pg.url || '' ).toLowerCase().indexOf( q ) !== -1;
			} );

			ui.clear( tableWrap );
			if ( ! filtered.length ) {
				tableWrap.appendChild( ui.emptyState( 'هیچ برگه‌ای یافت نشد.' ) );
				return;
			}

			var tbody = el( 'tbody' );
			filtered.forEach( function ( pg, idx ) {
				var modStr = pg.modified ? J.format( pg.modified.slice( 0, 10 ), 'short' ) : '—';

				var titleLink = el( 'div', {}, [
					el( 'a', {
						href: pg.url,
						target: '_blank',
						rel: 'noopener noreferrer',
						class: 'seopm-table-title-link',
						title: 'مشاهده برگه: ' + pg.title
					}, [
						el( 'span', { text: pg.title } ),
						ui.icon( 'external' )
					] ),
					el( 'span', { class: 'seopm-table-url-sub', text: pg.url } )
				] );

				var actionBtn = el( 'a', {
					href: pg.url,
					target: '_blank',
					rel: 'noopener noreferrer',
					class: 'seopm-btn seopm-btn-ghost seopm-btn-sm',
					title: 'مشاهده برگه در پنجره جدید'
				}, [
					ui.icon( 'external' ),
					'مشاهده برگه'
				] );

				tbody.appendChild( el( 'tr', {}, [
					el( 'td', { style: { width: '40px', textAlign: 'center', color: 'var(--seopm-muted)' } }, J.faDigits( idx + 1 ) ),
					el( 'td', {}, titleLink ),
					el( 'td', { style: { width: '140px', fontSize: '12px', whiteSpace: 'nowrap' } }, modStr ),
					el( 'td', { style: { width: '130px', textAlign: 'left' } }, actionBtn )
				] ) );
			} );

			var tbl = el( 'table', { class: 'seopm-table' }, [
				el( 'thead', {}, [
					el( 'tr', {}, [
						el( 'th', { style: { width: '40px', textAlign: 'center' } }, '#' ),
						el( 'th', {}, 'عنوان برگه (لینک شده)' ),
						el( 'th', { style: { width: '140px' } }, 'آخرین تغییر' ),
						el( 'th', { style: { width: '130px', textAlign: 'left' } }, 'عملیات' )
					] )
				] ),
				tbody
			] );

			tableWrap.appendChild( tbl );
		}

		searchInput.addEventListener( 'input', ui.debounce( updateList, 120 ) );
		container.appendChild( notice );
		container.appendChild( searchBar );
		container.appendChild( tableWrap );
		updateList();
	}

	/* ------------------------ Suggested Articles Tab ------------------------ */

	function renderSuggestionsTab( container, biz, bizId, initialRefresh ) {
		function loadSuggestions( refresh, forceAi ) {
			ui.clear( container );

			var loadMsg = forceAi ? 'در حال ارسال پرامپت استراتژیست سئو به موتور هوش مصنوعی و دریافت ۲۰ مقاله کلاستر...' : 'در حال تولید استراتژی محتوا، بررسی تداخل با سایت‌مپ و توزیع بر اساس وزن کلمات...';
			var loadSub = forceAi ? 'ارزیابی هوشمند Cannibalization، اهداف جستجو (Search Intent) و لینک‌سازی به پیلار...' : 'ارزیابی همنوع‌خواری محتوا (Cannibalization) و شناسایی Search Intent کاربر طبق استاندارد استراتژیست سئو...';

			var customLoading = el( 'div', { class: 'seopm-empty', style: { padding: '56px 20px' } }, [
				el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon', style: { fontSize: '36px', width: '36px', height: '36px', color: biz.color || '#4f46e5' } } ),
				el( 'p', { text: loadMsg, style: { marginTop: '14px', fontWeight: '700', fontSize: '15px' } } ),
				el( 'span', { class: 'seopm-muted seopm-small', text: loadSub } )
			] );
			container.appendChild( customLoading );

			var query = refresh ? { refresh: 1 } : {};
			if ( forceAi ) {
				query.force_ai = 1;
			}
			ui.api( '/businesses/' + bizId + '/suggested-articles', { query: query } ).then( function ( res ) {
				if ( bizId !== activeBizId || activeTab !== 'suggestions' ) {
					return;
				}
				renderSuggestionsView( container, biz, bizId, res, loadSuggestions );
			} ).catch( function ( err ) {
				if ( bizId !== activeBizId || activeTab !== 'suggestions' ) {
					return;
				}
				ui.clear( container );
				container.appendChild( el( 'div', { class: 'seopm-empty seopm-notice-error', style: { padding: '40px 20px' } }, [
					el( 'span', { class: 'dashicons dashicons-warning', style: { fontSize: '36px', width: '36px', height: '36px', color: '#ef4444' } } ),
					el( 'p', { text: 'خطا در بارگذاری مقالات پیشنهادی: ' + ( ( err && err.message ) || 'لطفاً دوباره تلاش کنید' ), style: { marginTop: '12px', fontWeight: '700' } } ),
					el( 'div', { style: { marginTop: '14px' } }, [
						ui.button( 'تلاش مجدد', 'primary seopm-btn-sm', function () { loadSuggestions( false, false ); }, 'update' )
					] )
				] ) );
			} );
		}

		loadSuggestions( Boolean( initialRefresh ), false );
	}

	function renderPrerequisitesView( container, biz, bizId, prereq, reloadFn ) {
		ui.clear( container );
		prereq = prereq || {};
		var hasSitemap = Boolean( prereq.has_sitemap );
		var sitemapUrl = prereq.sitemap_url || ( biz && biz.sitemap_url ) || '';
		var kwCount = parseInt( prereq.keyword_count || 0, 10 );
		var hasKw = Boolean( prereq.has_min_keywords );
		var minKw = parseInt( prereq.min_keywords || 5, 10 );

		var editBizUrl = ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&edit=' + bizId;

		var sitemapBadge = el( 'span', {
			class: 'seopm-badge ' + ( hasSitemap ? 'seopm-badge-success' : 'seopm-badge-danger' ),
			text: hasSitemap ? 'ثبت شده' : 'ثبت نشده (الزامی)'
		} );

		var sitemapRow = el( 'div', { class: 'seopm-prereq-item ' + ( hasSitemap ? 'is-valid' : 'is-missing' ) }, [
			el( 'div', { class: 'seopm-prereq-icon-wrap' }, [ ui.icon( hasSitemap ? 'yes-alt' : 'warning' ) ] ),
			el( 'div', { class: 'seopm-prereq-info' }, [
				el( 'div', { class: 'seopm-prereq-title-row' }, [
					el( 'b', { text: '۱. آدرس نقشه سایت (Sitemap URL)' } ),
					sitemapBadge
				] ),
				el( 'p', { class: 'seopm-prereq-desc', text: hasSitemap
					? ( 'آدرس نقشه سایت معتبر ثبت شده است: ' + sitemapUrl )
					: 'آدرس نقشه سایت (XML Sitemap) در تنظیمات کسب‌وکار ثبت نشده است. برای تطبیق دقیق صفحات و جلوگیری ۱۰۰٪ از همنوع‌خواری محتوا (Cannibalization)، ثبت نقشه سایت الزامی است.' } )
			] ),
			! hasSitemap ? el( 'a', { href: editBizUrl, class: 'seopm-btn seopm-btn-primary seopm-btn-xs' }, [ ui.icon( 'edit' ), 'ثبت نقشه سایت' ] ) : null
		] );

		var kwBadge = el( 'span', {
			class: 'seopm-badge ' + ( hasKw ? 'seopm-badge-success' : 'seopm-badge-warning' ),
			text: hasKw ? ( J.faDigits( kwCount ) + ' کلمه ثبت شده' ) : ( J.faDigits( kwCount ) + ' از ' + J.faDigits( minKw ) + ' کلمه' )
		} );

		var kwRow = el( 'div', { class: 'seopm-prereq-item ' + ( hasKw ? 'is-valid' : 'is-missing' ) }, [
			el( 'div', { class: 'seopm-prereq-icon-wrap' }, [ ui.icon( hasKw ? 'yes-alt' : 'warning' ) ] ),
			el( 'div', { class: 'seopm-prereq-info' }, [
				el( 'div', { class: 'seopm-prereq-title-row' }, [
					el( 'b', { text: '۲. کلمات کلیدی هدف (حداقل ' + J.faDigits( minKw ) + ' کلمه با اولویت‌بندی)' } ),
					kwBadge
				] ),
				el( 'p', { class: 'seopm-prereq-desc', text: hasKw
					? ( 'حداقل ' + J.faDigits( minKw ) + ' کلمه کلیدی هدف با اولویت‌بندی ثبت شده است (مجموعاً ' + J.faDigits( kwCount ) + ' کلمه).' )
					: ( 'در حال حاضر ' + J.faDigits( kwCount ) + ' کلمه کلیدی ثبت شده است. برای تقسیم عادلانه سهمیه و تدوین استراتژی کلاستر محتوا، حداقل ' + J.faDigits( minKw ) + ' کلمه کلیدی با اولویت‌بندی نیاز است (' + J.faDigits( Math.max( 0, minKw - kwCount ) ) + ' کلمه دیگر اضافه کنید).' ) } )
			] ),
			! hasKw ? el( 'a', { href: editBizUrl, class: 'seopm-btn seopm-btn-primary seopm-btn-xs' }, [ ui.icon( 'tag' ), 'ثبت کلمات کلیدی' ] ) : null
		] );

		var card = el( 'div', { class: 'seopm-card seopm-prereq-box' }, [
			el( 'div', { class: 'seopm-prereq-banner-header' }, [
				el( 'div', { class: 'seopm-prereq-header-icon' }, [ ui.icon( 'admin-generic' ) ] ),
				el( 'div', { class: 'seopm-prereq-header-text' }, [
					el( 'h3', { text: 'پیش‌نیازهای ارائه مقالات پیشنهادی تکمیل نشده است' } ),
					el( 'p', { text: 'طبق اصول سئو و استراتژی محتوا، ارائه مقالات پیشنهادی تنها زمانی مجاز است که «آدرس نقشه سایت» و «حداقل ۵ کلمه کلیدی هدف» در تنظیمات کسب‌وکار ثبت شده باشند.' } )
				] )
			] ),
			el( 'div', { class: 'seopm-prereq-list' }, [
				sitemapRow,
				kwRow
			] ),
			el( 'div', { class: 'seopm-prereq-footer' }, [
				el( 'a', { href: editBizUrl, class: 'seopm-btn seopm-btn-primary seopm-btn-sm' }, [
					ui.icon( 'edit' ),
					'ویرایش اطلاعات کسب‌وکار «' + ( ( biz && biz.name ) || 'پروژه' ) + '»'
				] ),
				ui.button( 'بررسی مجدد پس از ذخیره', 'ghost seopm-btn-sm', function () {
					if ( reloadFn ) {
						reloadFn( true, false );
					}
				}, 'update' )
			] )
		] );

		container.appendChild( card );
	}

	function renderSuggestionsView( container, biz, bizId, res, reloadFn ) {
		ui.clear( container );
		var suggestions = res.suggestions || [];
		var prereq = res.prerequisites || null;

		if ( prereq && ! prereq.ready ) {
			renderPrerequisitesView( container, biz, bizId, prereq, reloadFn );
			return;
		}

		if ( ! suggestions.length ) {
			container.appendChild( ui.emptyState(
				'هنوز هیچ مقاله پیشنهادی برای این کسب‌وکار یافت نشد. لطفاً در بخش ویرایش کسب‌وکار، کلمات کلیدی هدف و آدرس نقشه سایت را بررسی کنید.',
				el( 'a', {
					class: 'seopm-btn seopm-btn-primary seopm-btn-sm',
					href: ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&edit=' + bizId
				}, [ ui.icon( 'edit' ), 'ویرایش کسب‌وکار' ] )
			) );
			return;
		}

		var shortAiName = res.ai_provider === 'avalai' ? 'اول‌ای‌آی (AvalAI)' :
			( res.ai_provider === 'gemini' ? 'جمنای' :
			( res.ai_provider === 'openai' ? 'ChatGPT' :
			( res.ai_provider === 'deepseek' ? 'دیپ‌سیک' :
			( res.ai_provider === 'claude' ? 'کلود' : 'هوش مصنوعی' ) ) ) );

		var aiBadgeText = res.ai_generated
			? ( '🤖 تولید زنده با هوش مصنوعی (' + ( res.ai_provider_name || shortAiName ) + ')' )
			: ( res.ai_enabled
				? ( '💡 هوش مصنوعی آماده: ' + ( res.ai_provider_name || shortAiName ) + ' — جهت تولید یا بازنویسی با AI دکمه بالا را بزنید.' )
				: '⚡ موتور سئو محلی فعال است — جهت اتصال به Gemini، ChatGPT، DeepSeek یا Claude به تنظیمات API بروید.' );
		var aiBadgeBg = ( res.ai_generated || res.ai_enabled ) ? '#ecfdf5' : '#f8fafc';
		var aiBadgeColor = ( res.ai_generated || res.ai_enabled ) ? '#047857' : '#475569';
		var aiBadgeBorder = ( res.ai_generated || res.ai_enabled ) ? '#a7f3d0' : '#cbd5e1';

		var actionButtons = [
			el( 'a', {
				href: ( C.urls && C.urls.settings ? C.urls.settings + '#tab-ai' : 'admin.php?page=seopm-settings#tab-ai' ),
				class: 'seopm-btn seopm-btn-ghost seopm-btn-sm',
				title: 'مدیریت کلیدهای API جمنای، چت‌جی‌پی‌تی، دیپ‌سیک و کلود'
			}, [
				ui.icon( 'admin-generic' ),
				document.createTextNode( ' تنظیمات API' )
			] )
		];

		if ( res.ai_enabled ) {
			actionButtons.unshift( ui.button( 'تولید زنده با ' + shortAiName, 'primary seopm-btn-sm', function () {
				if ( reloadFn ) {
					reloadFn( true, true );
				} else {
					renderSuggestionsTab( container, biz, bizId );
				}
			}, 'admin-site-alt3' ) );
		} else {
			actionButtons.unshift( ui.button( 'تولید مجدد استراتژی', 'ghost seopm-btn-sm', function () {
				if ( reloadFn ) {
					reloadFn( true, false );
				} else {
					renderSuggestionsTab( container, biz, bizId );
				}
			}, 'update' ) );
		}

		var countBadge = el( 'span', { class: 'seopm-badge', style: { background: '#fef3c7', color: '#b45309', border: '1px solid #fde68a', fontWeight: '700' }, text: J.faDigits( suggestions.length ) + ' عنوان منتخب' } );

		var bannerTop = el( 'div', { class: 'seopm-sug-banner-header' }, [
			el( 'div', { class: 'seopm-sug-banner-title-wrap' }, [
				el( 'span', { class: 'dashicons dashicons-lightbulb seopm-sug-bulb-icon' } ),
				el( 'h4', { class: 'seopm-sug-banner-title', text: 'مقالات پیشنهادی استراتژیک سئو (۲۰ عنوان برتر)' } ),
				countBadge
			] ),
			el( 'div', { class: 'seopm-sug-banner-actions' }, actionButtons )
		] );

		var bannerStatus = el( 'div', { class: 'seopm-sug-banner-status-pill', style: { background: aiBadgeBg, color: aiBadgeColor, borderColor: aiBadgeBorder } }, [
			el( 'span', { class: 'dashicons ' + ( res.ai_enabled ? 'dashicons-yes-alt' : 'dashicons-info' ) } ),
			el( 'span', { text: aiBadgeText } )
		] );

		var bannerDesc = el( 'p', {
			class: 'seopm-sug-banner-desc seopm-muted seopm-small',
			text: 'تمام کلمات کلیدی به‌صورت مستقل بررسی شدند (' + J.faDigits( res.total_candidates_evaluated || 72 ) + ' عنوان کلاستر ارزیابی و امتیازدهی گردیدند)؛ در نهایت ۲۰ عنوان دارای بالاترین امتیاز سئو، با رعایت دقیق نسبت وزنی کلمات (وزن ۱۰ دو برابر وزن ۵) جهت تقویت صفحات پیلار انتخاب شدند.'
		} );

		var banner = el( 'div', { class: 'seopm-suggestion-banner' }, [
			bannerTop,
			bannerStatus,
			bannerDesc
		] );

		var searchInput = el( 'input', { type: 'search', placeholder: 'جستجو در عناوین پیشنهادی و کلمات کلیدی...' } );
		var intentSelect = ui.select( [
			{ value: '', label: 'همه اهداف جستجو (Search Intent)' },
			{ value: 'Informational', label: 'اطلاعاتی (Informational)' },
			{ value: 'Commercial Investigation', label: 'بررسی تجاری (Commercial Investigation)' },
			{ value: 'Transactional', label: 'معاملاتی (Transactional)' }
		], '' );
		var sortSelect = ui.select( [
			{ value: 'default', label: 'مرتب‌سازی: ترتیب لیست (پیش‌فرض)' },
			{ value: 'score', label: 'مرتب‌سازی: بیشترین امتیاز سئو' },
			{ value: 'weight', label: 'مرتب‌سازی: بیشترین وزن کلمه' },
			{ value: 'keyword', label: 'مرتب‌سازی: نام کلمه کلیدی' }
		], 'default' );

		var searchBar = el( 'div', { class: 'seopm-report-search-bar', style: { marginBottom: '14px', flexWrap: 'wrap' } }, [
			searchInput,
			intentSelect,
			sortSelect,
			el( 'span', { class: 'seopm-muted seopm-small', id: 'seopm-sug-count', text: 'نمایش: ' + J.faDigits( suggestions.length ) + ' مورد' } )
		] );

		var tableWrap = el( 'div', { class: 'seopm-table-wrap' } );
		var pendingReplacements = 0;

		function removeAndReplenishSuggestion( sug ) {
			var removedKey = sug.article_key || '';
			var removedTitle = sug.best_title || '';
			var removedKeyword = sug.keyword || '';

			suggestions = suggestions.filter( function ( item ) {
				if ( item === sug ) {
					return false;
				}
				if ( removedKey && item.article_key && item.article_key === removedKey ) {
					return false;
				}
				return item.best_title !== removedTitle;
			} );
			suggestions.forEach( function ( item, i ) {
				item.id = i + 1;
			} );

			pendingReplacements++;
			updateList();
			ui.toast( 'مقاله در تقویم ثبت و از لیست حذف شد؛ در حال افزودن عنوان جدید به انتهای لیست...', 'info' );

			ui.api( '/businesses/' + bizId + '/suggested-articles/replace', {
				method: 'POST',
				data: {
					title: removedTitle,
					article_key: removedKey,
					keyword: removedKeyword
				}
			} ).then( function ( repRes ) {
				pendingReplacements = Math.max( 0, pendingReplacements - 1 );
				if ( bizId !== activeBizId || activeTab !== 'suggestions' ) {
					return;
				}
				if ( repRes && Array.isArray( repRes.suggestions ) && repRes.suggestions.length ) {
					suggestions = repRes.suggestions;
				} else if ( repRes && repRes.replacement ) {
					repRes.replacement.is_new_replacement = true;
					suggestions.push( repRes.replacement );
					suggestions.forEach( function ( item, i ) {
						item.id = i + 1;
					} );
				}
				updateList();
				if ( repRes && repRes.replacement && repRes.replacement.best_title ) {
					ui.toast( 'عنوان جدید به انتهای لیست اضافه شد: «' + repRes.replacement.best_title + '»', 'success' );
				} else {
					ui.toast( 'لیست مقالات پیشنهادی بروزرسانی شد.', 'success' );
				}
			} ).catch( function () {
				pendingReplacements = Math.max( 0, pendingReplacements - 1 );
				updateList();
				ui.toast( 'مقاله از لیست حذف شد، اما دریافت عنوان جایگزین با خطا مواجه شد.', 'error' );
			} );
		}

		function updateList() {
			var q = ( searchInput.value || '' ).trim().toLowerCase();
			var intentFilter = intentSelect.value;
			var sortBy = sortSelect.value;
			var countSpan = document.getElementById( 'seopm-sug-count' );

			var filtered = suggestions.filter( function ( s ) {
				var matchText = ! q || ( s.best_title || '' ).toLowerCase().indexOf( q ) !== -1 || ( s.keyword || '' ).toLowerCase().indexOf( q ) !== -1;
				var matchIntent = ! intentFilter || s.search_intent === intentFilter;
				return matchText && matchIntent;
			} );

			if ( sortBy === 'score' ) {
				filtered.sort( function ( a, b ) { return ( b.score || 0 ) - ( a.score || 0 ); } );
			} else if ( sortBy === 'weight' ) {
				filtered.sort( function ( a, b ) { return ( b.weight || 0 ) - ( a.weight || 0 ); } );
			} else if ( sortBy === 'keyword' ) {
				filtered.sort( function ( a, b ) { return ( a.keyword || '' ).localeCompare( b.keyword || '', 'fa' ); } );
			}

			if ( countSpan ) {
				countSpan.textContent = 'نمایش: ' + J.faDigits( filtered.length ) + ' از ' + J.faDigits( suggestions.length ) + ' مورد';
			}
			if ( countBadge ) {
				countBadge.textContent = J.faDigits( suggestions.length ) + ' عنوان منتخب';
			}

			ui.clear( tableWrap );
			if ( ! filtered.length ) {
				tableWrap.appendChild( ui.emptyState( 'هیچ عنوان پیشنهادی با فیلتر انتخابی مطابقت ندارد.' ) );
				return;
			}

			var tbody = el( 'tbody' );

			filtered.forEach( function ( s, idx ) {
				var slugClean = cleanSlug( s.url_slug );
				s.url_slug = slugClean;

				var weightBg = s.weight >= 8 ? '#f3e8ff' : '#e0f2fe';
				var weightColor = s.weight >= 8 ? '#7e22ce' : '#0369a1';
				var weightBorder = s.weight >= 8 ? '#d8b4fe' : '#bae6fd';

				// Intent badge
				var intentClass = 'seopm-intent-info';
				if ( s.search_intent === 'Transactional' ) {
					intentClass = 'seopm-intent-trans';
				} else if ( s.search_intent === 'Commercial Investigation' ) {
					intentClass = 'seopm-intent-comm';
				}

				// Score badge
				var scoreVal = s.score || 85;
				var scoreBg = scoreVal >= 90 ? '#ecfdf5' : ( scoreVal >= 75 ? '#eff6ff' : '#fef3c7' );
				var scoreColor = scoreVal >= 90 ? '#047857' : ( scoreVal >= 75 ? '#1d4ed8' : '#b45309' );
				var scoreBorder = scoreVal >= 90 ? '#a7f3d0' : ( scoreVal >= 75 ? '#bfdbfe' : '#fde68a' );
				var sb = s.score_breakdown || {};
				var scoreTooltip = 'امتیاز سئو: ' + scoreVal + ' از ۱۰۰ | وزن: ' + ( sb.weight_score || 0 ) + ' | خلاء محتوا: ' + ( sb.gap_score || 0 ) + ' | پیلار: ' + ( sb.pillar_score || 0 ) + ' | نیت: ' + ( sb.intent_score || 0 );

				var scoreCell = el( 'td', { style: { width: '82px', textAlign: 'center' } }, [
					el( 'div', {
						class: 'seopm-badge',
						style: { background: scoreBg, color: scoreColor, border: '1px solid ' + scoreBorder, fontWeight: '800', fontSize: '11.5px', padding: '3px 7px', cursor: 'help', display: 'inline-flex', alignItems: 'center', gap: '3px' },
						title: scoreTooltip
					}, [
						el( 'span', { class: 'dashicons dashicons-star-filled', style: { fontSize: '11px', width: '11px', height: '11px' } } ),
						document.createTextNode( J.faDigits( scoreVal ) )
					] )
				] );

				var kwCell = el( 'div', {}, [
					el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '5px', flexWrap: 'wrap', marginBottom: '3px' } }, [
						el( 'strong', { text: s.keyword, style: { fontSize: '12.5px', lineHeight: '1.4' } } ),
						el( 'span', {
							class: 'seopm-badge',
							style: { background: weightBg, color: weightColor, border: '1px solid ' + weightBorder, fontSize: '10px', padding: '1px 5px' },
							text: 'وزن ' + J.faDigits( s.weight )
						} )
					] ),
					el( 'div', { class: 'seopm-small seopm-muted', style: { fontSize: '11px', lineHeight: '1.35' }, text: s.angle_label || '' } )
				] );

				var titleCell = el( 'div', { class: 'seopm-sug-title-cell' }, [
					el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' } }, [
						s.is_new_replacement ? el( 'span', { class: 'seopm-sug-new-badge', text: 'جدید' } ) : null,
						el( 'span', { class: 'seopm-sug-best-title', text: s.best_title } )
					] ),
					el( 'div', { class: 'seopm-sug-slug-row' }, [
						el( 'span', { class: 'dashicons dashicons-admin-links' } ),
						el( 'code', { dir: 'ltr', text: slugClean, title: slugClean } )
					] )
				] );

				// Pillar Target cell
				var pillarCell = s.pillar ? el( 'div', { class: 'seopm-pillar-cell' }, [
					el( 'a', {
						href: s.pillar.target_pillar_url,
						target: '_blank',
						rel: 'noopener noreferrer',
						class: 'seopm-pillar-badge seopm-pillar-badge-wide',
						title: 'مشاهده صفحه لندینگ پیلار: ' + s.pillar.target_pillar_title
					}, [
						el( 'span', { class: 'dashicons dashicons-admin-links' } ),
						el( 'span', { text: s.pillar.target_pillar_title } )
					] ),
					el( 'div', { class: 'seopm-small seopm-muted seopm-pillar-anchor-sub seopm-pillar-anchor-wide', title: 'انکرتکست دقیق: ' + ( s.pillar.primary_anchor || s.keyword ) }, [
						document.createTextNode( 'انکر: ' ),
						el( 'strong', { style: { color: '#4f46e5' }, text: s.pillar.primary_anchor || s.keyword } )
					] )
				] ) : el( 'span', { class: 'seopm-muted seopm-small', text: '—' } );

				// Add to Calendar Task button (fixed task_added + proper new-task fields)
				var isAdded = Boolean( s.task_added || s.is_in_tasks );
				var taskBtn;
				if ( isAdded ) {
					taskBtn = el( 'button', {
						type: 'button',
						class: 'seopm-btn seopm-btn-success seopm-btn-xs',
						disabled: true,
						title: 'این مقاله قبلاً در تقویم تسک‌ها ثبت شده است'
					}, [
						ui.icon( 'yes' ),
						document.createTextNode( ' در تقویم' )
					] );
				} else {
					taskBtn = el( 'button', {
						type: 'button',
						class: 'seopm-btn seopm-btn-primary seopm-btn-xs',
						title: 'افزودن این مقاله به تقویم تسک‌های پروژه'
					}, [
						ui.icon( 'calendar-alt' ),
						document.createTextNode( ' + تقویم' )
					] );

					taskBtn.onclick = ( function ( sug, btn ) {
						return function () {
							var descLines = [
								'کلمه کلیدی هدف: ' + sug.keyword + ' (وزن: ' + sug.weight + ')',
								'هدف جستجو (Search Intent): ' + sug.search_intent_fa,
								'اسلاگ پیشنهادی: ' + cleanSlug( sug.url_slug ),
								'تصمیم سئو: ' + sug.decision_label,
								'نیاز اصلی کاربر: ' + sug.user_core_need
							];
							if ( sug.pillar ) {
								descLines.push( '' );
								descLines.push( 'استراتژی لینک‌سازی به پیلار:' );
								descLines.push( 'صفحه پیلار هدف: ' + sug.pillar.target_pillar_title + ' (' + sug.pillar.target_pillar_url + ')' );
								descLines.push( 'انکرتکست اصلی: ' + sug.pillar.primary_anchor );
							}
							if ( sug.titles && sug.titles.length > 1 ) {
								descLines.push( '' );
								descLines.push( 'عناوین جایگزین:' );
								sug.titles.forEach( function ( t, i ) {
									descLines.push( ( i + 1 ) + '. ' + t );
								} );
							}

							if ( SEOPM.taskForm && SEOPM.taskForm.open ) {
								SEOPM.taskForm.open( {
									task: {
										business_id: bizId,
										title: sug.best_title,
										article_key: sug.article_key || '',
										task_type: 'article_writing',
										status: 'pending',
										description: '',
										due_date: typeof C.today === 'string' ? C.today : ''
									},
									onSaved: function () {
										removeAndReplenishSuggestion( sug );
									}
								} );
							} else {
								btn.disabled = true;
								ui.api( '/businesses/' + bizId + '/suggested-articles/add-to-tasks', {
									method: 'POST',
									data: {
										title: sug.best_title,
										article_key: sug.article_key || '',
										keyword: sug.keyword,
										url_slug: cleanSlug( sug.url_slug ),
										search_intent: sug.search_intent_fa,
										description: descLines.join( '\n' )
									}
								} ).then( function ( addRes ) {
									if ( addRes && Array.isArray( addRes.suggestions ) && addRes.suggestions.length ) {
										suggestions = addRes.suggestions;
										updateList();
									} else {
										removeAndReplenishSuggestion( sug );
										return;
									}
									if ( addRes.replacement && addRes.replacement.best_title ) {
										ui.toast( 'مقاله در تقویم ثبت و از لیست حذف شد؛ عنوان جدید اضافه شد: «' + addRes.replacement.best_title + '»', 'success' );
									} else {
										ui.toast( 'مقاله در تقویم ثبت و از لیست حذف شد.', 'success' );
									}
								} ).catch( function ( err ) {
									btn.disabled = false;
									ui.toast( 'خطا در افزودن به تقویم: ' + ( ( err && err.message ) || '' ), 'error' );
								} );
							}
						};
					} )( s, taskBtn );
				}

				// Studio Row Buttons: Brief, Article Writer, HTML Code
				var briefBtn = el( 'button', {
					type: 'button',
					class: 'seopm-btn seopm-btn-ghost seopm-btn-xs seopm-brief-toggle',
					title: 'مشاهده بریف و تحلیل کامل سئو'
				}, [
					ui.icon( 'visibility' ),
					document.createTextNode( ' بریف' )
				] );

				var writeBtn = el( 'button', {
					type: 'button',
					class: 'seopm-btn seopm-btn-ghost seopm-btn-xs seopm-write-btn' + ( s.has_article ? ' is-saved' : '' ),
					title: s.has_article ? 'مشاهده و ویرایش متن مقاله ذخیره‌شده' : 'نگارش متن کامل مقاله با هوش مصنوعی (بر اساس بریف و پرامپت کسب‌وکار)'
				}, [
					ui.icon( s.has_article ? 'yes-alt' : 'edit-page' ),
					document.createTextNode( ' نگارش مقاله' )
				] );

				var htmlBtn = el( 'button', {
					type: 'button',
					class: 'seopm-btn seopm-btn-ghost seopm-btn-xs seopm-html-btn' + ( s.has_html ? ' is-saved' : '' ),
					title: s.has_html ? 'مشاهده و کپی کد HTML مقاله' : 'تبدیل متن مقاله به کد HTML (بر اساس پرامپت HTML کسب‌وکار)'
				}, [
					ui.icon( s.has_html ? 'yes-alt' : 'editor-code' ),
					document.createTextNode( ' کد HTML' )
				] );

				var imageRowBtn = el( 'button', {
					type: 'button',
					class: 'seopm-btn seopm-btn-ghost seopm-btn-xs seopm-image-row-btn' + ( s.has_image ? ' is-saved' : ( ( s.images_count || 0 ) > 0 ? ' is-pending-pick' : '' ) ),
					title: s.has_image ? 'تصویر شاخص انتخاب شده است (مشاهده / ویرایش تصاویر)' : ( ( s.images_count || 0 ) > 0 ? '۲ تصویر تولید شده — کلیک برای انتخاب تصویر شاخص و میان‌متنی' : 'تولید و انتخاب تصویر شاخص و میان‌متنی مقاله (پس از تکمیل متن و کد HTML)' )
				} );

				function paintImageRowBtn( generating ) {
					ui.clear( imageRowBtn );
					imageRowBtn.classList.toggle( 'is-saved', Boolean( s.has_image ) );
					imageRowBtn.classList.toggle( 'is-pending-pick', ! s.has_image && ( s.images_count || 0 ) > 0 );
					if ( generating ) {
						imageRowBtn.appendChild( el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon' } ) );
						imageRowBtn.appendChild( document.createTextNode( ' در حال تولید ۲ تصویر...' ) );
					} else if ( s.has_image ) {
						imageRowBtn.appendChild( ui.icon( 'yes-alt' ) );
						imageRowBtn.appendChild( document.createTextNode( ' تصویر شاخص' + ( s.has_in_content_image ? ' + میان‌متنی' : '' ) ) );
					} else if ( ( s.images_count || 0 ) > 0 ) {
						imageRowBtn.appendChild( ui.icon( 'format-image' ) );
						imageRowBtn.appendChild( document.createTextNode( ' تصویر شاخص (' + J.faDigits( s.images_count ) + ' آماده انتخاب)' ) );
					} else {
						imageRowBtn.appendChild( ui.icon( 'format-image' ) );
						imageRowBtn.appendChild( document.createTextNode( ' تصویر شاخص' ) );
					}
				}
				paintImageRowBtn( false );

				var studioMount = el( 'td', { colspan: '7', style: { padding: '0', background: 'var(--seopm-surface-2)' } } );
				var accordionRow = el( 'tr', { class: 'seopm-brief-accordion-tr', style: { display: 'none' } }, [ studioMount ] );

				var studioCtrl = createArticleStudio( s, biz, bizId, res.prompts_configured || {}, {
					onClose: function () {
						accordionRow.style.display = 'none';
						briefBtn.classList.remove( 'is-active' );
						writeBtn.classList.remove( 'is-active' );
						htmlBtn.classList.remove( 'is-active' );
						imageRowBtn.classList.remove( 'is-active' );
					},
					onDraftStateChange: function ( state ) {
						if ( state.has_article ) {
							s.has_article = true;
							writeBtn.classList.add( 'is-saved' );
							ui.clear( writeBtn );
							writeBtn.appendChild( ui.icon( 'yes-alt' ) );
							writeBtn.appendChild( document.createTextNode( ' نگارش مقاله' ) );
						}
						if ( state.has_html ) {
							s.has_html = true;
							htmlBtn.classList.add( 'is-saved' );
							ui.clear( htmlBtn );
							htmlBtn.appendChild( ui.icon( 'yes-alt' ) );
							htmlBtn.appendChild( document.createTextNode( ' کد HTML' ) );
						}
						s.has_image = Boolean( state.has_image );
						if ( Array.isArray( state.images ) ) {
							s.images_count = state.images.length;
							s.has_in_content_image = state.images.some( function ( im ) { return Boolean( im.is_in_content ); } );
						}
						paintImageRowBtn( Boolean( state.is_generating_image ) );
					},
					onPublished: function () {
						removeAndReplenishSuggestion( s );
					},
					onTabActive: function ( tabKey ) {
						briefBtn.classList.toggle( 'is-active', tabKey === 'brief' );
						writeBtn.classList.toggle( 'is-active', tabKey === 'article' );
						htmlBtn.classList.toggle( 'is-active', tabKey === 'html' );
						imageRowBtn.classList.toggle( 'is-active', tabKey === 'image' );
					}
				} );
				studioMount.appendChild( studioCtrl.element );

				function toggleStudioTab( tabKey, autoAction ) {
					var isOpen = accordionRow.style.display !== 'none';
					if ( isOpen && studioCtrl.getCurrentTab() === tabKey && ! autoAction ) {
						studioCtrl.close();
						return;
					}
					accordionRow.style.display = 'table-row';
					studioCtrl.openTab( tabKey, autoAction );
				}

				briefBtn.onclick = function () {
					toggleStudioTab( 'brief', false );
				};
				writeBtn.onclick = function () {
					toggleStudioTab( 'article', true );
				};
				htmlBtn.onclick = function () {
					toggleStudioTab( 'html', true );
				};
				imageRowBtn.onclick = function () {
					toggleStudioTab( 'image', true );
				};

				var deleteRowBtn = el( 'button', {
					type: 'button',
					class: 'seopm-btn seopm-btn-ghost seopm-btn-xs seopm-danger-hover seopm-sug-delete-btn',
					title: 'حذف این مقاله پیشنهادی از لیست و دریافت عنوان جایگزین جدید'
				}, [
					ui.icon( 'trash' ),
					document.createTextNode( ' حذف مقاله' )
				] );

				deleteRowBtn.onclick = function () {
					var hasContent = s.has_article || s.has_html || s.has_image;
					var confirmMsg = hasContent
						? 'این مقاله دارای محتوا یا تصویر تولیدشده است. آیا از حذف کامل «' + ( s.best_title || s.keyword ) + '» و جایگزینی آن با عنوان جدید مطمئن هستید؟'
						: 'آیا از حذف مقاله پیشنهادی «' + ( s.best_title || s.keyword ) + '» و دریافت عنوان جدید مطمئن هستید؟';
					if ( ! window.confirm( confirmMsg ) ) {
						return;
					}
					deleteRowBtn.disabled = true;
					removeAndReplenishSuggestion( s );
				};

				var mainRow = el( 'tr', { class: 'seopm-sug-main-row' + ( s.is_new_replacement ? ' is-new-replacement' : '' ) }, [
					el( 'td', { style: { width: '34px', textAlign: 'center', color: 'var(--seopm-muted)', fontWeight: '700' } }, J.faDigits( s.id || ( idx + 1 ) ) ),
					el( 'td', { style: { width: '150px' } }, kwCell ),
					el( 'td', { class: 'seopm-sug-title-cell' }, titleCell ),
					scoreCell,
					el( 'td', { style: { width: '150px' } }, pillarCell ),
					el( 'td', { style: { width: '105px', textAlign: 'center' } }, [
						el( 'span', { class: 'seopm-badge ' + intentClass, style: { fontSize: '11px', padding: '3px 7px' }, text: s.search_intent_fa } )
					] ),
					el( 'td', { style: { width: '225px', textAlign: 'left' } }, [
						el( 'div', { class: 'seopm-sug-actions-grid' }, [
							briefBtn,
							taskBtn,
							writeBtn,
							htmlBtn,
							imageRowBtn,
							deleteRowBtn
						] )
					] )
				] );

				tbody.appendChild( mainRow );
				tbody.appendChild( accordionRow );
			} );

			if ( pendingReplacements > 0 ) {
				tbody.appendChild( el( 'tr', { class: 'seopm-sug-replenishing-row' }, [
					el( 'td', { colspan: '7' }, [
						el( 'span', { class: 'seopm-test-spinner' } ),
						document.createTextNode( ' در حال تولید و افزودن عنوان پیشنهادی جدید به انتهای لیست...' )
					] )
				] ) );
			}

			var tbl = el( 'table', { class: 'seopm-table seopm-suggestions-table' }, [
				el( 'thead', {}, [
					el( 'tr', {}, [
						el( 'th', { style: { width: '34px', textAlign: 'center' } }, '#' ),
						el( 'th', { style: { width: '150px' } }, 'کلمه کلیدی هدف' ),
						el( 'th', {}, 'عنوان مقاله کلاستر (پیشنهادی)' ),
						el( 'th', { style: { width: '82px', textAlign: 'center' } }, 'امتیاز' ),
						el( 'th', { style: { width: '150px' } }, 'پیلار هدف (لینک داخلی)' ),
						el( 'th', { style: { width: '105px', textAlign: 'center' } }, 'هدف جستجو' ),
						el( 'th', { style: { width: '215px', textAlign: 'center' } }, 'عملیات تولید محتوا' )
					] )
				] ),
				tbody
			] );

			tableWrap.appendChild( tbl );
		}

		searchInput.addEventListener( 'input', ui.debounce( updateList, 100 ) );
		intentSelect.addEventListener( 'change', updateList );
		sortSelect.addEventListener( 'change', updateList );

		container.appendChild( banner );
		container.appendChild( searchBar );
		container.appendChild( tableWrap );
		updateList();
	}

	/* --------------------------- Article Studio Drawer --------------------------- */

	function createArticleStudio( s, biz, bizId, promptsConfigured, callbacks ) {
		callbacks = callbacks || {};
		var validBizList = Array.isArray( C.businesses ) && C.businesses.length ? C.businesses : ( Array.isArray( all ) && all.length ? all : [] );
		function isValidBiz( candidate ) {
			var num = parseInt( candidate, 10 );
			return num > 0 && validBizList.some( function ( item ) { return parseInt( item.id, 10 ) === num; } );
		}
		var chosenBizId = 0;
		if ( isValidBiz( bizId ) ) {
			chosenBizId = parseInt( bizId, 10 );
		} else if ( biz && isValidBiz( biz.id ) ) {
			chosenBizId = parseInt( biz.id, 10 );
		} else if ( s && isValidBiz( s.business_id ) ) {
			chosenBizId = parseInt( s.business_id, 10 );
		} else if ( isValidBiz( activeBizId ) ) {
			chosenBizId = parseInt( activeBizId, 10 );
		} else if ( validBizList.length ) {
			chosenBizId = parseInt( validBizList[ 0 ].id, 10 );
		} else {
			chosenBizId = 1;
		}
		bizId = chosenBizId;
		var currentTab = 'brief';
		var draftLoaded = false;
		var isGeneratingArticle = false;
		var isConvertingHtml = false;
		var isGeneratingImage = false;
		var draftData = {
			article_key: s.article_key || '',
			article_content: '',
			article_html: '',
			featured_image_url: '',
			images: [],
			image_prompt: '',
			url_slug: cleanSlug( s.url_slug ),
			keyword: s.keyword || '',
			seo_title: s.best_title || '',
			seo_description: '',
			remote_post_id: s.remote_post_id || 0,
			remote_post_url: s.remote_post_url || '',
			remote_status: s.remote_status || '',
			scheduled_for: s.scheduled_for || null,
			has_article: Boolean( s.has_article ),
			has_html: Boolean( s.has_html ),
			has_image: Boolean( s.has_image ),
			is_generating_image: false
		};

		var promptsEditUrl = ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&edit=' + bizId + '&tab=prompts';
		var wpEditUrl = ( C.urls && C.urls.businesses ? C.urls.businesses : 'admin.php?page=seopm-businesses' ) + '&edit=' + bizId + '&tab=wp';
		var aiSettingsUrl = ( C.urls && C.urls.settings ? C.urls.settings + '#tab-ai' : 'admin.php?page=seopm-settings#tab-ai' );

		var tabBriefBtn = el( 'button', { type: 'button', class: 'seopm-studio-tab is-active', onclick: function () { openTab( 'brief', false ); } }, [
			ui.icon( 'visibility' ),
			document.createTextNode( ' بریف سئو' )
		] );
		var tabArticleBtn = el( 'button', { type: 'button', class: 'seopm-studio-tab', onclick: function () { openTab( 'article', false ); } }, [
			ui.icon( 'edit-page' ),
			document.createTextNode( ' متن مقاله' )
		] );
		var tabHtmlBtn = el( 'button', { type: 'button', class: 'seopm-studio-tab', onclick: function () { openTab( 'html', false ); } }, [
			ui.icon( 'editor-code' ),
			document.createTextNode( ' کد HTML' )
		] );
		var tabImageBtn = el( 'button', { type: 'button', class: 'seopm-studio-tab' + ( s.has_image ? ' is-ready' : '' ), onclick: function () { openTab( 'image', false ); } }, [
			ui.icon( 'format-image' ),
			document.createTextNode( ' تصویر شاخص' )
		] );
		var tabPublishBtn = el( 'button', { type: 'button', class: 'seopm-studio-tab seopm-studio-tab-publish', onclick: function () { openTab( 'publish', false ); } }, [
			ui.icon( 'cloud-upload' ),
			document.createTextNode( ' ارسال به سایت' )
		] );

		var closeStudioBtn = el( 'button', {
			type: 'button',
			class: 'seopm-icon-btn',
			title: 'بستن پنل',
			onclick: function () {
				if ( callbacks.onClose ) {
					callbacks.onClose();
				}
			}
		}, ui.icon( 'no-alt' ) );

		var studioHeader = el( 'div', { class: 'seopm-studio-head' }, [
			el( 'div', { class: 'seopm-studio-title-col' }, [
				el( 'strong', { class: 'seopm-studio-title', text: s.best_title } ),
				el( 'code', { dir: 'ltr', class: 'seopm-studio-slug', text: cleanSlug( s.url_slug ) } )
			] ),
			el( 'div', { class: 'seopm-studio-tabs-wrap' }, [
				tabBriefBtn,
				tabArticleBtn,
				tabHtmlBtn,
				tabImageBtn,
				tabPublishBtn,
				closeStudioBtn
			] )
		] );

		/* --- Pane 1: Brief --- */
		var briefPane = el( 'div', { class: 'seopm-studio-pane' }, [
			renderBriefBox( s )
		] );

		/* --- Pane 2: Rich Editable Article Editor --- */
		var articlePane = el( 'div', { class: 'seopm-studio-pane', hidden: true } );
		var articleStatusBanner = el( 'div', { class: 'seopm-studio-status', hidden: true } );
		var editorStats = el( 'span', { class: 'seopm-studio-stats', text: '۰ کلمه · ۰ لینک' } );

		var editorSurface = el( 'div', {
			class: 'seopm-rich-editor',
			contenteditable: 'true',
			dir: 'rtl',
			spellcheck: 'false',
			'data-placeholder': 'متن مقاله پس از نگارش با هوش مصنوعی اینجا نمایش داده می‌شود و کاملاً قابل ویرایش است...'
		} );

		var linksAuditList = el( 'div', { class: 'seopm-links-audit-bar', hidden: true } );

		function refreshEditorStats() {
			var html = editorSurface.innerHTML || '';
			var plain = ( editorSurface.innerText || editorSurface.textContent || '' ).replace( /\s+/g, ' ' ).trim();
			var words = plain ? plain.split( ' ' ).length : 0;
			var anchors = editorSurface.querySelectorAll( 'a[href]' );
			editorStats.textContent = J.faDigits( words ) + ' کلمه · ' + J.faDigits( anchors.length ) + ' لینک فعال';

			ui.clear( linksAuditList );
			if ( anchors.length ) {
				linksAuditList.hidden = false;
				linksAuditList.appendChild( el( 'span', { class: 'seopm-links-audit-label', text: 'لینک‌های داخل متن:' } ) );
				anchors.forEach( function ( a ) {
					var href = a.getAttribute( 'href' ) || '';
					var txt = ( a.textContent || '' ).trim() || href;
					a.setAttribute( 'title', 'آدرس لینک: ' + href + ' (برای باز کردن Ctrl+Click بزنید)' );
					linksAuditList.appendChild( el( 'a', {
						href: href,
						target: '_blank',
						rel: 'noopener noreferrer',
						class: 'seopm-editor-link-chip',
						title: href
					}, [
						ui.icon( 'admin-links' ),
						el( 'span', { text: txt } )
					] ) );
				} );
			} else {
				linksAuditList.hidden = true;
			}
			draftData.article_content = html;
		}

		editorSurface.addEventListener( 'input', ui.debounce( refreshEditorStats, 180 ) );
		editorSurface.addEventListener( 'click', function ( e ) {
			var a = e.target && e.target.closest ? e.target.closest( 'a[href]' ) : null;
			if ( a && ( e.ctrlKey || e.metaKey ) ) {
				e.preventDefault();
				window.open( a.getAttribute( 'href' ), '_blank', 'noopener,noreferrer' );
			}
		} );

		function execFormat( cmd, val ) {
			editorSurface.focus();
			try {
				document.execCommand( cmd, false, val || null );
			} catch ( e ) {
				// Ignore unsupported commands.
			}
			refreshEditorStats();
		}

		function insertOrEditLink() {
			editorSurface.focus();
			var sel = window.getSelection();
			var defaultUrl = ( s.pillar && s.pillar.target_pillar_url ) ? s.pillar.target_pillar_url : 'https://';
			var existingAnchor = null;
			if ( sel && sel.anchorNode ) {
				var node = sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement;
				if ( node && node.closest ) {
					existingAnchor = node.closest( 'a[href]' );
				}
			}
			var url = window.prompt( 'آدرس لینک (URL) را وارد کنید:', existingAnchor ? existingAnchor.getAttribute( 'href' ) : defaultUrl );
			if ( ! url ) {
				return;
			}
			url = url.trim();
			if ( ! /^https?:\/\//i.test( url ) && url.indexOf( '/' ) !== 0 ) {
				url = 'https://' + url;
			}
			if ( existingAnchor ) {
				existingAnchor.setAttribute( 'href', url );
				existingAnchor.setAttribute( 'target', '_blank' );
				existingAnchor.setAttribute( 'rel', 'noopener' );
			} else {
				execFormat( 'createLink', url );
				editorSurface.querySelectorAll( 'a[href]' ).forEach( function ( a ) {
					a.setAttribute( 'target', '_blank' );
					a.setAttribute( 'rel', 'noopener' );
				} );
			}
			refreshEditorStats();
		}

		function tbBtn( label, title, onClick, iconName ) {
			var children = iconName ? [ ui.icon( iconName ) ] : [];
			if ( label ) {
				children.push( document.createTextNode( ( iconName ? ' ' : '' ) + label ) );
			}
			return el( 'button', {
				type: 'button',
				class: 'seopm-tb-btn',
				title: title,
				onmousedown: function ( e ) { e.preventDefault(); },
				onclick: onClick
			}, children );
		}

		var editorToolbar = el( 'div', { class: 'seopm-editor-toolbar' }, [
			el( 'div', { class: 'seopm-tb-group' }, [
				tbBtn( 'H2', 'تیتر اصلی (H2)', function () { execFormat( 'formatBlock', '<h2>' ); } ),
				tbBtn( 'H3', 'زیرتیتر (H3)', function () { execFormat( 'formatBlock', '<h3>' ); } ),
				tbBtn( 'پاراگراف', 'پاراگراف عادی', function () { execFormat( 'formatBlock', '<p>' ); } ),
				el( 'span', { class: 'seopm-tb-sep' } ),
				tbBtn( 'B', 'بولد (Bold)', function () { execFormat( 'bold' ); } ),
				tbBtn( 'I', 'ایتالیک (Italic)', function () { execFormat( 'italic' ); } ),
				el( 'span', { class: 'seopm-tb-sep' } ),
				tbBtn( '', 'لیست نقطه‌ای', function () { execFormat( 'insertUnorderedList' ); }, 'editor-ul' ),
				tbBtn( '', 'لیست شماره‌دار', function () { execFormat( 'insertOrderedList' ); }, 'editor-ol' ),
				el( 'span', { class: 'seopm-tb-sep' } ),
				tbBtn( 'لینک', 'افزودن یا ویرایش هایپرلینک روی متن انتخاب‌شده', insertOrEditLink, 'admin-links' ),
				tbBtn( '', 'حذف لینک از متن انتخاب‌شده', function () { execFormat( 'unlink' ); }, 'editor-unlink' )
			] ),
			editorStats
		] );

		var saveArticleBtn = ui.button( 'ذخیره ویرایش‌ها', 'ghost seopm-btn-sm', function () {
			saveDraftContent( true, false );
		}, 'saved' );

		var copyArticleBtn = ui.button( 'کپی متن (با لینک‌ها)', 'ghost seopm-btn-sm', function () {
			var html = editorSurface.innerHTML || '';
			var plain = editorSurface.innerText || editorSurface.textContent || '';
			if ( ! plain.trim() ) {
				ui.toast( 'متنی برای کپی وجود ندارد.', 'error' );
				return;
			}
			copyRichHtml( html, plain, 'متن مقاله همراه با هدینگ‌ها و هایپرلینک‌ها کپی شد.' );
		}, 'admin-page' );

		var regenArticleBtn = ui.button( 'تولید مجدد با هوش مصنوعی', 'ghost seopm-btn-sm', function () {
			if ( ( editorSurface.innerText || '' ).trim() ) {
				ui.confirm( 'متن فعلی جایگزین متن جدید تولیدشده توسط هوش مصنوعی خواهد شد. ادامه می‌دهید؟', { title: 'تولید مجدد مقاله', confirmText: 'تولید مجدد' } ).then( function ( ok ) {
					if ( ok ) {
						runGenerateArticle();
					}
				} );
			} else {
				runGenerateArticle();
			}
		}, 'update' );

		var toHtmlBtn = ui.button( 'تبدیل این متن به کد HTML', 'primary seopm-btn-sm', function () {
			openTab( 'html', false );
			runConvertHtml();
		}, 'editor-code' );

		var articlePromptBadge = el( 'a', {
			href: promptsEditUrl,
			class: 'seopm-prompt-status-link',
			title: 'ویرایش پرامپت اختصاصی نگارش مقاله در تنظیمات کسب‌وکار'
		}, [
			ui.icon( promptsConfigured.article_writing ? 'yes-alt' : 'info' ),
			document.createTextNode( promptsConfigured.article_writing ? 'پرامپت اختصاصی نگارش فعال است (ویرایش)' : 'پرامپت نگارش ثبت نشده؛ از استاندارد پیش‌فرض استفاده می‌شود (تنظیم پرامپت)' )
		] );

		var articleBodyWrap = el( 'div', { class: 'seopm-studio-editor-wrap' }, [
			el( 'div', { class: 'seopm-studio-bar' }, [
				el( 'div', { class: 'seopm-studio-bar-btns' }, [
					toHtmlBtn,
					saveArticleBtn,
					copyArticleBtn,
					regenArticleBtn
				] ),
				articlePromptBadge
			] ),
			articleStatusBanner,
			editorToolbar,
			editorSurface,
			linksAuditList
		] );

		articlePane.appendChild( articleBodyWrap );

		/* --- Pane 3: HTML Code & Live Preview --- */
		var htmlPane = el( 'div', { class: 'seopm-studio-pane', hidden: true } );
		var htmlStatusBanner = el( 'div', { class: 'seopm-studio-status', hidden: true } );
		var htmlViewMode = 'split';

		var htmlTextarea = el( 'textarea', {
			class: 'seopm-html-code-editor',
			dir: 'ltr',
			rows: '16',
			spellcheck: 'false',
			placeholder: 'کد HTML نهایی مقاله پس از تبدیل در اینجا قرار می‌گیرد و قابل ویرایش و کپی است...'
		} );
		var htmlPreviewBox = el( 'div', { class: 'seopm-html-preview', dir: 'rtl' } );
		var htmlSplitGrid = el( 'div', { class: 'seopm-html-split is-split' }, [
			el( 'div', { class: 'seopm-html-col seopm-html-code-col' }, [
				el( 'div', { class: 'seopm-html-col-head', text: 'کد HTML آماده انتشار (قابل ویرایش)' } ),
				htmlTextarea
			] ),
			el( 'div', { class: 'seopm-html-col seopm-html-preview-col' }, [
				el( 'div', { class: 'seopm-html-col-head', text: 'پیش‌نمایش زنده خروجی HTML' } ),
				htmlPreviewBox
			] )
		] );

		function syncHtmlPreview() {
			var code = htmlTextarea.value || '';
			draftData.article_html = code;
			htmlPreviewBox.innerHTML = code || '<p class="seopm-muted seopm-small" style="text-align:center; padding:24px;">پیش‌نمایش کد HTML اینجا نمایش داده می‌شود.</p>';
		}
		htmlTextarea.addEventListener( 'input', ui.debounce( syncHtmlPreview, 180 ) );

		var modeCodeBtn = el( 'button', { type: 'button', class: 'seopm-mode-btn', text: 'فقط کد HTML', onclick: function () { setHtmlMode( 'code' ); } } );
		var modeSplitBtn = el( 'button', { type: 'button', class: 'seopm-mode-btn is-active', text: 'کد + پیش‌نمایش', onclick: function () { setHtmlMode( 'split' ); } } );
		var modePreviewBtn = el( 'button', { type: 'button', class: 'seopm-mode-btn', text: 'فقط پیش‌نمایش', onclick: function () { setHtmlMode( 'preview' ); } } );

		function setHtmlMode( mode ) {
			htmlViewMode = mode;
			modeCodeBtn.classList.toggle( 'is-active', mode === 'code' );
			modeSplitBtn.classList.toggle( 'is-active', mode === 'split' );
			modePreviewBtn.classList.toggle( 'is-active', mode === 'preview' );
			htmlSplitGrid.className = 'seopm-html-split is-' + mode;
		}

		var copyHtmlBtn = ui.button( 'کپی کد HTML', 'primary seopm-btn-sm', function () {
			if ( ! htmlTextarea.value.trim() ) {
				ui.toast( 'کد HTML برای کپی موجود نیست.', 'error' );
				return;
			}
			copyPlainText( htmlTextarea.value, 'کد HTML کامل مقاله در کلیپ‌بورد کپی شد.' );
		}, 'admin-page' );

		var saveHtmlBtn = ui.button( 'ذخیره کد HTML', 'ghost seopm-btn-sm', function () {
			saveDraftContent( false, true );
		}, 'saved' );

		var convertHtmlBtn = ui.button( 'تبدیل از متن مقاله با AI', 'ghost seopm-btn-sm', function () {
			runConvertHtml();
		}, 'update' );

		var htmlPromptBadge = el( 'a', {
			href: promptsEditUrl,
			class: 'seopm-prompt-status-link',
			title: 'ویرایش پرامپت تبدیل مقاله به کد HTML در تنظیمات کسب‌وکار'
		}, [
			ui.icon( promptsConfigured.html_conversion ? 'yes-alt' : 'info' ),
			document.createTextNode( promptsConfigured.html_conversion ? 'پرامپت اختصاصی HTML فعال است (ویرایش)' : 'پرامپت HTML ثبت نشده؛ از استاندارد پیش‌فرض استفاده می‌شود (تنظیم پرامپت)' )
		] );

		htmlPane.appendChild( el( 'div', { class: 'seopm-studio-editor-wrap' }, [
			el( 'div', { class: 'seopm-studio-bar' }, [
				el( 'div', { class: 'seopm-studio-bar-btns' }, [
					copyHtmlBtn,
					saveHtmlBtn,
					convertHtmlBtn,
					el( 'div', { class: 'seopm-mode-switch' }, [ modeCodeBtn, modeSplitBtn, modePreviewBtn ] )
				] ),
				htmlPromptBadge
			] ),
			htmlStatusBanner,
			htmlSplitGrid
		] ) );

		/* --- Pane 4: Dual Featured & In-Content Image Generator & Selector --- */
		var imagePane = el( 'div', { class: 'seopm-studio-pane', hidden: true } );
		var imageStatusBanner = el( 'div', { class: 'seopm-studio-status', hidden: true } );
		var imageModelSelect = ui.select( [
			{ value: 'gemini-2.5-flash-image', label: 'Gemini 2.5 Flash Image (سریع و بسیار باکیفیت - پیشنهادی)' },
			{ value: 'gpt-image-2.5-flare', label: 'ChatGPT Image (gpt-image-2.5-flare)' },
			{ value: 'gpt-image-2.6-flare', label: 'ChatGPT Image (gpt-image-2.6-flare)' },
			{ value: 'muse-image-1.0', label: 'Muse Image 1.0' },
			{ value: 'imagen-3.0-generate-002', label: 'Google Imagen 3' }
		], 'gemini-2.5-flash-image' );
		var imagePromptInput = el( 'textarea', {
			rows: '2',
			class: 'seopm-prompt-textarea',
			placeholder: 'اختیاری: اگر خالی بگذارید، ۲ تصویر دقیقاً مطابق «پرامپت تولید تصویر» ثبت‌شده برای این کسب‌وکار ساخته می‌شوند...'
		} );
		var imagePreviewWrap = el( 'div', { class: 'seopm-image-preview-wrap' } );

		function isArticleAndHtmlReady() {
			var hasArt = Boolean( draftData.has_article || ( editorSurface.innerText || '' ).trim() );
			var hasHtm = Boolean( draftData.has_html || ( htmlTextarea.value || '' ).trim() );
			return hasArt && hasHtm;
		}

		function saveImageSelections( notifyMsg ) {
			return ui.api( '/businesses/' + bizId + '/articles/draft', {
				method: 'POST',
				data: {
					business_id: bizId,
					article_key: draftData.article_key,
					title: s.best_title,
					keyword: s.keyword,
					url_slug: cleanSlug( s.url_slug ),
					images: draftData.images
				},
				silent: true
			} ).then( function ( saved ) {
				if ( saved ) {
					draftData.images = Array.isArray( saved.images ) ? saved.images : draftData.images;
					draftData.featured_image_url = saved.featured_image_url || '';
					draftData.has_image = Boolean( saved.has_image );
					if ( typeof saved.article_html === 'string' && saved.article_html !== htmlTextarea.value ) {
						draftData.article_html = saved.article_html;
						htmlTextarea.value = saved.article_html;
						syncHtmlPreview();
					}
					tabImageBtn.classList.toggle( 'is-ready', draftData.has_image );
					if ( callbacks.onDraftStateChange ) {
						callbacks.onDraftStateChange( draftData );
					}
					renderImagePreview();
				}
				if ( notifyMsg ) {
					ui.toast( notifyMsg, 'success' );
				}
			} ).catch( function ( err ) {
				ui.toast( ( err && err.message ) || 'خطا در ذخیره انتخاب تصویر.', 'error' );
			} );
		}

		function renderImagePreview() {
			ui.clear( imagePreviewWrap );
			var readyPrereq = isArticleAndHtmlReady();
			genImageBtn.disabled = isGeneratingImage || ! readyPrereq;

			if ( ! readyPrereq ) {
				imagePreviewWrap.appendChild( el( 'div', { class: 'seopm-pub-alert is-warn', style: { marginBottom: '12px' } }, [
					ui.icon( 'lock' ),
					el( 'span', { text: 'تا زمانی که هم «متن مقاله» و هم «کد HTML» تولید نشده باشند، تولید تصویر غیرفعال است. به‌محض آماده شدن متن و کد HTML، ۲ تصویر به‌صورت خودکار مطابق پرامپت کسب‌وکار تولید می‌شوند.' } ),
					! draftData.has_article ? ui.button( 'رفتن به نگارش مقاله', 'ghost seopm-btn-xs', function () { openTab( 'article', false ); } ) : ui.button( 'تبدیل به کد HTML', 'ghost seopm-btn-xs', function () { openTab( 'html', true ); } )
				] ) );
			}

			var imgs = Array.isArray( draftData.images ) ? draftData.images : [];
			if ( ! imgs.length ) {
				imagePreviewWrap.appendChild( el( 'div', { class: 'seopm-image-empty-box' }, [
					ui.icon( 'format-image' ),
					el( 'p', { text: 'هنوز تصویری برای این مقاله تولید یا آپلود نشده است.' } ),
					el( 'small', { class: 'seopm-muted', text: readyPrereq ? 'برای تولید همزمان ۲ تصویر مطابق پرامپت تصویر کسب‌وکار روی دکمه بالا بزنید یا تصویر دستی آپلود کنید.' : 'ابتدا متن مقاله و کد HTML را تکمیل کنید تا ۲ تصویر به‌صورت خودکار تولید شوند.' } )
				] ) );
				return;
			}

			var grid = el( 'div', { class: 'seopm-images-grid' } );
			imgs.forEach( function ( im, idx ) {
				var isFeat = Boolean( im.is_featured );
				var isInBody = Boolean( im.is_in_content );

				var featCb = el( 'input', { type: 'checkbox' } );
				featCb.checked = isFeat;
				featCb.addEventListener( 'change', function () {
					var checked = featCb.checked;
					draftData.images.forEach( function ( item ) {
						item.is_featured = false;
					} );
					im.is_featured = checked;
					saveImageSelections( checked ? 'تصویر ' + J.faDigits( idx + 1 ) + ' به‌عنوان تصویر شاخص انتخاب شد.' : 'انتخاب تصویر شاخص برداشته شد.' );
				} );

				var inBodyCb = el( 'input', { type: 'checkbox' } );
				inBodyCb.checked = isInBody;
				inBodyCb.addEventListener( 'change', function () {
					im.is_in_content = inBodyCb.checked;
					saveImageSelections( inBodyCb.checked ? 'تصویر ' + J.faDigits( idx + 1 ) + ' به‌صورت فول‌سایز قبل از H2 بعدی در کد HTML قرار گرفت.' : 'تصویر میان‌متنی از کد HTML حذف شد.' );
				} );

				var badges = [];
				if ( isFeat ) {
					badges.push( el( 'span', { class: 'seopm-img-role-pill is-featured', text: '✓ تصویر شاخص' } ) );
				}
				if ( isInBody ) {
					badges.push( el( 'span', { class: 'seopm-img-role-pill is-in-content', text: '✓ میان‌متنی (فول‌سایز قبل از H2)' } ) );
				}
				if ( ! isFeat && ! isInBody ) {
					badges.push( el( 'span', { class: 'seopm-img-role-pill is-none', text: 'انتخاب نشده' } ) );
				}

				var card = el( 'div', { class: 'seopm-image-card' + ( isFeat ? ' is-featured' : '' ) + ( isInBody ? ' is-in-content' : '' ) }, [
					el( 'div', { class: 'seopm-image-card-media' }, [
						el( 'a', { href: im.url, target: '_blank', rel: 'noopener noreferrer', title: 'مشاهده تصویر در سایز اصلی' }, [
							el( 'img', { src: im.url, alt: s.best_title || '', class: 'seopm-image-card-img' } )
						] ),
						el( 'span', { class: 'seopm-image-card-num', text: 'تصویر ' + J.faDigits( idx + 1 ) } ),
						el( 'button', {
							type: 'button',
							class: 'seopm-image-card-del',
							title: 'حذف این تصویر از لیست',
							onclick: function () {
								draftData.images.splice( idx, 1 );
								saveImageSelections( 'تصویر حذف شد.' );
							}
						}, ui.icon( 'trash' ) )
					] ),
					el( 'div', { class: 'seopm-image-card-body' }, [
						el( 'div', { class: 'seopm-image-card-badges' }, badges ),
						el( 'label', { class: 'seopm-image-check-label' + ( isFeat ? ' is-checked' : '' ) }, [
							featCb,
							el( 'span', { text: 'انتخاب به‌عنوان تصویر شاخص' } )
						] ),
						el( 'label', { class: 'seopm-image-check-label' + ( isInBody ? ' is-checked-body' : '' ) }, [
							inBodyCb,
							el( 'span', { text: 'انتخاب به‌عنوان تصویر میان‌متنی (فول‌سایز قبل از H2 بعدی)' } )
						] )
					] )
				] );
				grid.appendChild( card );
			} );

			imagePreviewWrap.appendChild( grid );
		}

		function runGenerateImages( count, replaceExisting, isAuto ) {
			if ( isGeneratingImage ) {
				return Promise.resolve( false );
			}
			if ( ! isArticleAndHtmlReady() ) {
				setBanner( imageStatusBanner, 'warning', [
					ui.icon( 'lock' ),
					el( 'span', { text: 'تا زمانی که هم متن مقاله و هم کد HTML آن نوشته نشده باشند، امکان تولید تصویر وجود ندارد.' } )
				] );
				return Promise.resolve( false );
			}
			isGeneratingImage = true;
			draftData.is_generating_image = true;
			genImageBtn.disabled = true;
			if ( callbacks.onDraftStateChange ) {
				callbacks.onDraftStateChange( draftData );
			}
			setBanner( imageStatusBanner, 'loading', [
				el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon' } ),
				el( 'span', { text: ( isAuto ? 'تولید خودکار ' : 'در حال تولید ' ) + J.faDigits( count || 2 ) + ' تصویر با هوش مصنوعی مطابق پرامپت تصویر کسب‌وکار... (ممکن است ۲۰ تا ۶۰ ثانیه زمان ببرد)' } )
			] );

			return ui.api( '/businesses/' + bizId + '/articles/generate-image', {
				method: 'POST',
				data: {
					business_id: bizId,
					article_key: draftData.article_key,
					title: s.best_title,
					keyword: s.keyword,
					url_slug: cleanSlug( s.url_slug ),
					image_prompt: imagePromptInput.value.trim(),
					image_model: imageModelSelect.value,
					count: count || 2,
					replace: Boolean( replaceExisting )
				},
				silent: true
			} ).then( function ( d ) {
				isGeneratingImage = false;
				draftData.is_generating_image = false;
				draftLoaded = true;
				draftData.images = Array.isArray( d.images ) ? d.images : [];
				draftData.featured_image_url = d.featured_image_url || '';
				draftData.image_prompt = d.image_prompt || '';
				draftData.has_image = Boolean( d.has_image );
				if ( draftData.image_prompt && ! imagePromptInput.value.trim() ) {
					imagePromptInput.value = draftData.image_prompt;
				}
				tabImageBtn.classList.toggle( 'is-ready', draftData.has_image );
				renderImagePreview();
				if ( callbacks.onDraftStateChange ) {
					callbacks.onDraftStateChange( draftData );
				}
				var gCount = d.generated_count || draftData.images.length;
				setBanner( imageStatusBanner, 'success', [
					ui.icon( 'yes-alt' ),
					el( 'span', { text: J.faDigits( gCount ) + ' تصویر با موفقیت تولید شد. اکنون تیک «تصویر شاخص» و/یا «تصویر میان‌متنی» را روی تصاویر دلخواه بزنید.' } )
				] );
				if ( isAuto ) {
					ui.toast( J.faDigits( gCount ) + ' تصویر پیشنهادی مقاله به‌صورت خودکار تولید شد؛ از تب «تصویر شاخص» انتخاب کنید.', 'success' );
				}
				return true;
			} ).catch( function ( err ) {
				isGeneratingImage = false;
				draftData.is_generating_image = false;
				renderImagePreview();
				if ( callbacks.onDraftStateChange ) {
					callbacks.onDraftStateChange( draftData );
				}
				setBanner( imageStatusBanner, 'error', [
					ui.icon( 'warning' ),
					el( 'span', { text: ( err && err.message ) || 'خطا در تولید تصویر با هوش مصنوعی.' } )
				] );
				return false;
			} );
		}

		var genImageBtn = ui.button( 'تولید ۲ تصویر با هوش مصنوعی', 'primary seopm-btn-sm', function () {
			runGenerateImages( 2, false, false );
		}, 'format-image' );

		var manualImgFile = el( 'input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', hidden: true } );
		manualImgFile.addEventListener( 'change', function () {
			var f = manualImgFile.files && manualImgFile.files[ 0 ];
			if ( ! f ) {
				return;
			}
			var reader = new FileReader();
			reader.onload = function () {
				setBanner( imageStatusBanner, 'loading', [
					el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon' } ),
					el( 'span', { text: 'در حال آپلود و ذخیره تصویر...' } )
				] );
				ui.api( '/businesses/' + bizId + '/articles/upload-image', {
					method: 'POST',
					data: {
						article_key: draftData.article_key,
						title: s.best_title,
						keyword: s.keyword,
						url_slug: cleanSlug( s.url_slug ),
						data_url: reader.result
					},
					silent: true
				} ).then( function ( d ) {
					draftLoaded = true;
					draftData.images = Array.isArray( d.images ) ? d.images : [];
					draftData.featured_image_url = d.featured_image_url || '';
					draftData.has_image = Boolean( d.has_image );
					tabImageBtn.classList.toggle( 'is-ready', draftData.has_image );
					renderImagePreview();
					if ( callbacks.onDraftStateChange ) {
						callbacks.onDraftStateChange( draftData );
					}
					setBanner( imageStatusBanner, 'success', [
						ui.icon( 'yes-alt' ),
						el( 'span', { text: 'تصویر با موفقیت آپلود و به لیست تصاویر مقاله اضافه شد.' } )
					] );
				} ).catch( function ( err ) {
					setBanner( imageStatusBanner, 'error', [
						ui.icon( 'warning' ),
						el( 'span', { text: ( err && err.message ) || 'خطا در آپلود تصویر.' } )
					] );
				} );
			};
			reader.readAsDataURL( f );
		} );

		var uploadImgBtn = ui.button( 'آپلود تصویر دستی', 'ghost seopm-btn-sm', function () {
			manualImgFile.click();
		}, 'upload' );

		var imgPromptBadge = el( 'a', {
			href: promptsEditUrl,
			class: 'seopm-prompt-status-link',
			title: 'ویرایش پرامپت تولید تصویر در تنظیمات کسب‌وکار'
		}, [
			ui.icon( promptsConfigured.image_generation ? 'yes-alt' : 'warning' ),
			document.createTextNode( promptsConfigured.image_generation ? 'پرامپت اختصاصی تصویر کسب‌وکار فعال است (ویرایش)' : 'پرامپت تولید تصویر کسب‌وکار خالی است! (کلیک برای ثبت)' )
		] );

		imagePane.appendChild( el( 'div', { class: 'seopm-studio-editor-wrap' }, [
			el( 'div', { class: 'seopm-studio-bar' }, [
				el( 'div', { class: 'seopm-studio-bar-btns' }, [
					genImageBtn,
					uploadImgBtn,
					manualImgFile,
					imageModelSelect
				] ),
				imgPromptBadge
			] ),
			imageStatusBanner,
			el( 'div', { class: 'seopm-image-studio-body' }, [
				el( 'label', { class: 'seopm-field' }, [
					el( 'span', { text: 'پرامپت سفارشی تصویر (اختیاری — اگر خالی باشد، دقیقاً از «پرامپت تولید تصویر» کسب‌وکار استفاده می‌شود)' } ),
					imagePromptInput
				] ),
				imagePreviewWrap
			] )
		] ) );

		/* --- Pane 5: Scheduled Publish to Target WordPress Site (21:00) + Rank Math --- */
		var publishPane = el( 'div', { class: 'seopm-studio-pane', hidden: true } );
		var publishBody = el( 'div', { class: 'seopm-studio-editor-wrap' } );
		publishPane.appendChild( publishBody );

		function loadStudioPublishPane() {
			ui.clear( publishBody );
			publishBody.appendChild( el( 'div', { class: 'seopm-publish-loading', style: { padding: '28px' } }, [
				el( 'span', { class: 'seopm-test-spinner' } ),
				document.createTextNode( ' در حال بررسی شرایط ارسال و اتصال وردپرس مقصد...' )
			] ) );

			ui.api( '/businesses/' + bizId + '/articles/publish-status', {
				query: { article_key: draftData.article_key },
				silent: true
			} ).then( function ( st ) {
				renderStudioPublishUI( st );
			} ).catch( function ( err ) {
				ui.clear( publishBody );
				publishBody.appendChild( el( 'div', { class: 'seopm-notice seopm-notice-error', style: { margin: '14px' }, text: ( err && err.message ) || 'خطا در بررسی وضعیت ارسال' } ) );
			} );
		}

		function renderStudioPublishUI( st ) {
			ui.clear( publishBody );
			var checks = st.checks || {};
			var prev = st.preview || {};
			var remote = st.remote || {};
			var pTime = st.publish_time || '21:00';
			var statusBar = el( 'div', { class: 'seopm-studio-status', hidden: true } );

			var slugInput = el( 'input', { type: 'text', dir: 'ltr', value: cleanSlug( prev.url_slug || s.url_slug || '' ), placeholder: 'article-slug' } );
			var kwInput = el( 'input', { type: 'text', value: prev.keyword || s.keyword || '', placeholder: 'کلمه کلیدی کانونی Rank Math' } );
			var seoTitleInput = el( 'input', { type: 'text', value: prev.seo_title || s.best_title || '', placeholder: 'عنوان سئو (Rank Math Title)' } );
			var seoDescInput = el( 'textarea', { rows: '2', placeholder: 'توضیحات متا (Rank Math Meta Description)' } );
			seoDescInput.value = prev.seo_description || '';
			var schedulePicker = SEOPM.datepicker.create( { value: st.due_date || C.today, allowEmpty: false, label: 'تاریخ انتشار در تقویم' } );

			function mkCheck( ok, label, actionLabel, targetTab ) {
				return el( 'div', { class: 'seopm-pub-check ' + ( ok ? 'is-ok' : 'is-missing' ) }, [
					ui.icon( ok ? 'yes-alt' : 'dismiss' ),
					el( 'span', { text: label } ),
					( ! ok && targetTab ) ? el( 'button', { type: 'button', class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: actionLabel, onclick: function () { openTab( targetTab, false ); } } ) : null
				] );
			}

			var checklist = el( 'div', { class: 'seopm-pub-checklist' }, [
				mkCheck( checks.title, '۱. عنوان مقاله' ),
				mkCheck( checks.slug || Boolean( slugInput.value.trim() ), '۲. اسلاگ (Slug) مقاله' ),
				mkCheck( checks.html, '۳. کد HTML مقاله', 'تولید کد HTML', 'html' ),
				mkCheck( checks.image, '۴. تصویر شاخص مقاله', 'تولید/آپلود تصویر', 'image' )
			] );

			var sendBtn = ui.button(
				remote.post_id > 0
					? 'بروزرسانی مقاله زمان‌بندی‌شده در سایت (ساعت ' + J.faDigits( pTime ) + ')'
					: 'ارسال به سایت با زمان‌بندی ساعت ' + J.faDigits( pTime ),
				'primary seopm-btn-sm',
				function () {
					var slugVal = cleanSlug( slugInput.value );
					if ( ! slugVal ) {
						ui.toast( 'اسلاگ (Slug) مقاله الزامی است.', 'error' );
						return;
					}
					sendBtn.disabled = true;
					setBanner( statusBar, 'loading', [
						el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon' } ),
						el( 'span', { text: 'در حال آپلود تصویر شاخص، ارسال کد HTML، زمان‌بندی برای ساعت ' + J.faDigits( pTime ) + ' و ثبت Rank Math SEO...' } )
					] );

					ui.api( '/businesses/' + bizId + '/articles/publish', {
						method: 'POST',
						data: {
							article_key: draftData.article_key,
							task_id: st.task_id || 0,
							title: s.best_title,
							url_slug: slugVal,
							keyword: kwInput.value.trim(),
							seo_title: seoTitleInput.value.trim(),
							seo_description: seoDescInput.value.trim(),
							due_date: schedulePicker.getValue()
						},
						silent: true
					} ).then( function ( r ) {
						sendBtn.disabled = false;
						setBanner( statusBar, 'success', [
							ui.icon( 'yes-alt' ),
							el( 'span', { text: ( r && r.message ) || 'مقاله با موفقیت زمان‌بندی شد.' } ),
							( r && r.remote_post_url ) ? el( 'a', { href: r.remote_post_url, target: '_blank', rel: 'noopener noreferrer', class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: 'مشاهده در سایت مقصد' } ) : null
						] );
						ui.toast( ( r && r.message ) || 'مقاله با موفقیت در سایت مقصد زمان‌بندی شد.', 'success' );
						if ( callbacks.onPublished ) {
							setTimeout( function () { callbacks.onPublished( r ); }, 1200 );
						}
					} ).catch( function ( err ) {
						sendBtn.disabled = false;
						setBanner( statusBar, 'error', [
							ui.icon( 'warning' ),
							el( 'span', { text: ( err && err.message ) || 'خطا در ارسال به سایت مقصد.' } )
						] );
					} );
				},
				'cloud-upload'
			);

			var canSend = Boolean( checks.title && ( checks.slug || slugInput.value.trim() ) && checks.html && checks.image && st.wp_connected );
			sendBtn.disabled = ! canSend;

			var warnBanner = null;
			if ( ! st.content_ready ) {
				warnBanner = el( 'div', { class: 'seopm-pub-alert is-error' }, [
					ui.icon( 'warning' ),
					el( 'span', { text: 'تا زمانی که هر ۴ مورد (عنوان، اسلاگ، کد HTML و تصویر شاخص) کامل نباشند امکان ارسال وجود ندارد. موارد ناقص: ' + ( st.missing || [] ).join( '، ' ) } )
				] );
			} else if ( ! st.wp_connected ) {
				warnBanner = el( 'div', { class: 'seopm-pub-alert is-warn' }, [
					ui.icon( 'admin-network' ),
					el( 'span', { text: 'اتصال انتشار خودکار وردپرس برای «' + st.business_name + '» تنظیم نشده است.' } ),
					el( 'a', { href: wpEditUrl, class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: 'تنظیم اتصال وردپرس' } )
				] );
			}

			publishBody.appendChild( el( 'div', { class: 'seopm-studio-bar' }, [
				el( 'div', { class: 'seopm-studio-bar-btns' }, [
					sendBtn,
					ui.button( 'بررسی مجدد وضعیت', 'ghost seopm-btn-sm', loadStudioPublishPane, 'update' )
				] ),
				el( 'a', { href: wpEditUrl, class: 'seopm-prompt-status-link' }, [
					ui.icon( st.wp_connected ? 'yes-alt' : 'admin-network' ),
					document.createTextNode( st.wp_connected ? 'متصل به ' + ( st.website_url || '' ).replace( /^https?:\/\//, '' ) + ' (ساعت ' + J.faDigits( pTime ) + ')' : 'تنظیم اتصال وردپرس کسب‌وکار' )
				] )
			] ) );

			publishBody.appendChild( statusBar );
			publishBody.appendChild( el( 'div', { class: 'seopm-publish-studio-body' }, [
				warnBanner,
				checklist,
				el( 'div', { class: 'seopm-form-grid', style: { marginTop: '14px' } }, [
					el( 'div', { class: 'seopm-field' }, [ el( 'span', { text: 'تاریخ انتشار در تقویم (ساعت ' + J.faDigits( pTime ) + ')' } ), schedulePicker.element ] ),
					ui.field( 'اسلاگ نهایی (URL Slug) *', slugInput ),
					ui.field( 'کلیدواژه کانونی Rank Math', kwInput ),
					ui.field( 'عنوان سئو Rank Math', seoTitleInput ),
					ui.field( 'توضیحات متا Rank Math (Meta Description)', seoDescInput, 'seopm-span-2' )
				] ),
				( function () {
					var previewToken = ( st.preview && st.preview.review_token ) || draftData.review_token || '';
					var previewUrl = previewToken ? ( window.location.origin + '/?seopm_preview=' + encodeURIComponent( previewToken ) ) : '';
					var reviewStatus = ( st.preview && st.preview.review_status ) || draftData.review_status || 'pending';
					var reviewStatusText = 'در انتظار بررسی کارفرما';
					if ( reviewStatus === 'approved' ) {
						reviewStatusText = 'تأیید شده برای انتشار توسط کارفرما ✓';
					} else if ( reviewStatus === 'changes_requested' ) {
						reviewStatusText = 'کارفرما درخواست اصلاحیه ثبت کرده است ✏️';
					}

					var tgSendBtn = ui.button( 'ارسال پیش‌نمایش به تلگرام کارفرما', 'ghost seopm-btn-sm', function () {
						tgSendBtn.disabled = true;
						ui.toast( 'در حال ارسال لینک پیش‌نمایش به تلگرام کارفرما...', 'info' );
						ui.api( '/businesses/' + bizId + '/articles/send-telegram-preview', {
							method: 'POST',
							data: { article_key: draftData.article_key, force: true },
							silent: true
						} ).then( function ( r ) {
							tgSendBtn.disabled = false;
							ui.toast( ( r && r.message ) || 'پیش‌نمایش به تلگرام کارفرما ارسال شد.', 'success' );
							loadStudioPublishPane();
						} ).catch( function ( err ) {
							tgSendBtn.disabled = false;
							ui.toast( ( err && err.message ) || 'خطا در ارسال به تلگرام کارفرما.', 'error' );
						} );
					}, 'share' );

					var tgBox = el( 'div', { class: 'seopm-studio-tg-card', style: { marginTop: '16px', padding: '14px', background: 'var(--seopm-surface)', border: '1px solid var(--seopm-border)', borderRadius: '8px' } }, [
						el( 'div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' } }, [
							el( 'div', {}, [
								el( 'h4', { style: { margin: '0 0 4px', fontSize: '13px', fontWeight: '700' }, text: 'پیش‌نمایش و تأییدیه تلگرام کارفرما' } ),
								el( 'p', { class: 'seopm-muted seopm-small', style: { margin: '0' }, text: 'وضعیت: ' + reviewStatusText } )
							] ),
							el( 'div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } }, [
								previewUrl ? el( 'a', { href: previewUrl, target: '_blank', rel: 'noopener noreferrer', class: 'seopm-btn seopm-btn-ghost seopm-btn-sm', text: 'مشاهده صفحه پیش‌نمایش' } ) : null,
								tgSendBtn
							] )
						] )
					] );

					var fbText = ( st.preview && st.preview.review_feedback ) || draftData.review_feedback;
					if ( fbText ) {
						tgBox.appendChild( el( 'div', { class: 'seopm-pub-alert is-warn', style: { marginTop: '10px' } }, [
							ui.icon( 'edit' ),
							el( 'strong', { text: 'یادداشت کارفرما: ' } ),
							el( 'span', { text: fbText } )
						] ) );
					}
					return tgBox;
				} )()
			] ) );
		}

		/* --- Helper Status & API Calls --- */

		function setBanner( bannerEl, type, content ) {
			ui.clear( bannerEl );
			if ( ! content ) {
				bannerEl.hidden = true;
				return;
			}
			bannerEl.className = 'seopm-studio-status is-' + type;
			bannerEl.hidden = false;
			if ( typeof content === 'string' ) {
				bannerEl.textContent = content;
			} else {
				ui.append( bannerEl, content );
			}
		}

		function loadDraftIfNeeded() {
			if ( draftLoaded || ! draftData.article_key ) {
				return Promise.resolve( draftData );
			}
			return ui.api( '/businesses/' + bizId + '/articles/draft', {
				query: { article_key: draftData.article_key },
				silent: true
			} ).then( function ( d ) {
				draftLoaded = true;
				if ( d ) {
					draftData.article_content = d.article_content || '';
					draftData.article_html = d.article_html || '';
					draftData.featured_image_url = d.featured_image_url || '';
					draftData.images = Array.isArray( d.images ) ? d.images : [];
					draftData.image_prompt = d.image_prompt || '';
					draftData.seo_title = d.seo_title || s.best_title || '';
					draftData.seo_description = d.seo_description || '';
					draftData.remote_post_id = d.remote_post_id || 0;
					draftData.remote_post_url = d.remote_post_url || '';
					draftData.remote_status = d.remote_status || '';
					draftData.scheduled_for = d.scheduled_for || null;
					draftData.has_article = Boolean( d.has_article );
					draftData.has_html = Boolean( d.has_html );
					draftData.has_image = Boolean( d.has_image );
					tabImageBtn.classList.toggle( 'is-ready', draftData.has_image );
					if ( draftData.article_content && ! editorSurface.innerHTML.trim() ) {
						editorSurface.innerHTML = draftData.article_content;
						refreshEditorStats();
					}
					if ( draftData.article_html && ! htmlTextarea.value.trim() ) {
						htmlTextarea.value = draftData.article_html;
						syncHtmlPreview();
					}
					if ( draftData.image_prompt && ! imagePromptInput.value.trim() ) {
						imagePromptInput.value = draftData.image_prompt;
					}
					renderImagePreview();
				}
				return draftData;
			} ).catch( function () {
				draftLoaded = true;
				return draftData;
			} );
		}

		function saveDraftContent( saveArticle, saveHtml ) {
			var payload = {
				business_id: bizId,
				article_key: draftData.article_key,
				title: s.best_title,
				keyword: s.keyword,
				url_slug: cleanSlug( s.url_slug )
			};
			if ( saveArticle ) {
				payload.article_content = editorSurface.innerHTML || '';
			}
			if ( saveHtml ) {
				payload.article_html = htmlTextarea.value || '';
			}
			ui.api( '/businesses/' + bizId + '/articles/draft', {
				method: 'POST',
				data: payload
			} ).then( function ( saved ) {
				if ( saved ) {
					draftData.has_article = Boolean( saved.has_article );
					draftData.has_html = Boolean( saved.has_html );
					if ( callbacks.onDraftStateChange ) {
						callbacks.onDraftStateChange( draftData );
					}
				}
				ui.toast( 'تغییرات با موفقیت ذخیره شد.' );
			} );
		}

		function runGenerateArticle() {
			if ( isGeneratingArticle ) {
				return Promise.resolve( false );
			}
			isGeneratingArticle = true;
			regenArticleBtn.disabled = true;
			toHtmlBtn.disabled = true;
			setBanner( articleStatusBanner, 'loading', [
				el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon' } ),
				el( 'span', { text: 'در حال نگارش کامل متن مقاله همراه با هایپرلینک‌ها بر اساس بریف سئو و پرامپت اختصاصی کسب‌وکار... (ممکن است ۲۰ تا ۶۰ ثانیه زمان ببرد)' } )
			] );

			return ui.api( '/businesses/' + bizId + '/articles/generate', {
				method: 'POST',
				data: Object.assign( {}, s, { url_slug: cleanSlug( s.url_slug ), business_id: bizId } ),
				silent: true
			} ).then( function ( resData ) {
				isGeneratingArticle = false;
				regenArticleBtn.disabled = false;
				toHtmlBtn.disabled = false;
				draftLoaded = true;
				draftData.article_content = resData.article_content || '';
				draftData.has_article = Boolean( resData.has_article );
				editorSurface.innerHTML = draftData.article_content;
				refreshEditorStats();
				if ( callbacks.onDraftStateChange ) {
					callbacks.onDraftStateChange( draftData );
				}
				setBanner( articleStatusBanner, 'success', [
					ui.icon( 'yes-alt' ),
					el( 'span', { text: 'متن مقاله با موفقیت تولید و ذخیره شد (' + J.faDigits( resData.word_count || 0 ) + ' کلمه و ' + J.faDigits( resData.link_count || 0 ) + ' هایپرلینک فعال). می‌توانید متن را همین‌جا ویرایش کرده و سپس به کد HTML تبدیل کنید.' } )
				] );
				return true;
			} ).catch( function ( err ) {
				isGeneratingArticle = false;
				regenArticleBtn.disabled = false;
				toHtmlBtn.disabled = false;
				var msg = ( err && err.message ) || 'خطا در ارتباط با سرویس هوش مصنوعی.';
				setBanner( articleStatusBanner, 'error', [
					ui.icon( 'warning' ),
					el( 'span', { text: msg } ),
					el( 'a', { href: aiSettingsUrl, class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: 'تنظیمات API' } )
				] );
				return false;
			} );
		}

		function runConvertHtml() {
			if ( isConvertingHtml ) {
				return;
			}
			var currentArticleHtml = ( editorSurface.innerHTML || draftData.article_content || '' ).trim();
			var plainCheck = ( editorSurface.innerText || currentArticleHtml.replace( /<[^>]+>/g, '' ) ).trim();
			if ( ! plainCheck ) {
				setBanner( htmlStatusBanner, 'warning', [
					ui.icon( 'info' ),
					el( 'span', { text: 'هنوز متنی برای این مقاله نگارش نشده است. ابتدا متن مقاله را تهیه کنید یا دکمه مقابل را بزنید تا به‌صورت خودکار نگارش و سپس به کد HTML تبدیل شود:' } ),
					ui.button( 'نگارش خودکار و تبدیل به HTML', 'primary seopm-btn-xs', function () {
						openTab( 'article', false );
						runGenerateArticle().then( function ( ok ) {
							if ( ok ) {
								openTab( 'html', false );
								runConvertHtml();
							}
						} );
					}, 'admin-site-alt3' )
				] );
				return;
			}

			isConvertingHtml = true;
			convertHtmlBtn.disabled = true;
			setBanner( htmlStatusBanner, 'loading', [
				el( 'span', { class: 'dashicons dashicons-update seopm-spin-icon' } ),
				el( 'span', { text: 'در حال تبدیل متن مقاله به کد HTML استاندارد بر اساس پرامپت HTML کسب‌وکار...' } )
			] );

			ui.api( '/businesses/' + bizId + '/articles/convert-html', {
				method: 'POST',
				data: {
					business_id: bizId,
					article_key: draftData.article_key,
					title: s.best_title,
					keyword: s.keyword,
					url_slug: cleanSlug( s.url_slug ),
					pillar: s.pillar || {},
					article_content: currentArticleHtml
				},
				silent: true
			} ).then( function ( resData ) {
				isConvertingHtml = false;
				convertHtmlBtn.disabled = false;
				draftLoaded = true;
				draftData.article_html = resData.article_html || '';
				draftData.has_html = Boolean( resData.has_html );
				draftData.has_article = Boolean( resData.has_article || draftData.has_article );
				if ( Array.isArray( resData.images ) ) {
					draftData.images = resData.images;
				}
				htmlTextarea.value = draftData.article_html;
				syncHtmlPreview();
				if ( callbacks.onDraftStateChange ) {
					callbacks.onDraftStateChange( draftData );
				}
				// Auto-generate 2 images once BOTH article text and HTML code exist and no images exist yet!
				var willAutoImages = isArticleAndHtmlReady() && ( ! draftData.images || ! draftData.images.length );
				setBanner( htmlStatusBanner, 'success', [
					ui.icon( 'yes-alt' ),
					el( 'span', { text: willAutoImages
						? 'کد HTML مقاله ذخیره شد و تولید خودکار ۲ تصویر پیشنهادی مقاله (بر اساس پرامپت تصویر کسب‌وکار) آغاز گردید...'
						: 'کد HTML مقاله با موفقیت تولید و ذخیره شد. می‌توانید آن را کپی کنید یا در کادر زیر ویرایش و پیش‌نمایش زنده را مشاهده کنید.' } )
				] );
				if ( willAutoImages ) {
					ui.toast( 'کد HTML آماده شد؛ در حال تولید خودکار ۲ تصویر برای مقاله...', 'info' );
					runGenerateImages( 2, false, true );
				}
			} ).catch( function ( err ) {
				isConvertingHtml = false;
				convertHtmlBtn.disabled = false;
				var msg = ( err && err.message ) || 'خطا در تبدیل متن به کد HTML.';
				setBanner( htmlStatusBanner, 'error', [
					ui.icon( 'warning' ),
					el( 'span', { text: msg } ),
					el( 'a', { href: aiSettingsUrl, class: 'seopm-btn seopm-btn-ghost seopm-btn-xs', text: 'تنظیمات API' } )
				] );
			} );
		}

		function openTab( tabKey, autoAction ) {
			currentTab = tabKey;
			tabBriefBtn.classList.toggle( 'is-active', tabKey === 'brief' );
			tabArticleBtn.classList.toggle( 'is-active', tabKey === 'article' );
			tabHtmlBtn.classList.toggle( 'is-active', tabKey === 'html' );
			tabImageBtn.classList.toggle( 'is-active', tabKey === 'image' );
			tabPublishBtn.classList.toggle( 'is-active', tabKey === 'publish' );

			briefPane.hidden = tabKey !== 'brief';
			articlePane.hidden = tabKey !== 'article';
			htmlPane.hidden = tabKey !== 'html';
			imagePane.hidden = tabKey !== 'image';
			publishPane.hidden = tabKey !== 'publish';

			if ( callbacks.onTabActive ) {
				callbacks.onTabActive( tabKey );
			}

			if ( tabKey === 'article' ) {
				loadDraftIfNeeded().then( function ( d ) {
					if ( d && d.article_content && ! ( editorSurface.innerText || '' ).trim() ) {
						editorSurface.innerHTML = d.article_content;
						refreshEditorStats();
					}
					if ( autoAction && ! ( editorSurface.innerText || '' ).trim() ) {
						runGenerateArticle();
					}
				} );
			} else if ( tabKey === 'html' ) {
				loadDraftIfNeeded().then( function () {
					syncHtmlPreview();
					if ( autoAction && ! htmlTextarea.value.trim() ) {
						runConvertHtml();
					}
				} );
			} else if ( tabKey === 'image' ) {
				loadDraftIfNeeded().then( function () {
					renderImagePreview();
					if ( autoAction && isArticleAndHtmlReady() && ( ! draftData.images || ! draftData.images.length ) ) {
						runGenerateImages( 2, false, false );
					}
				} );
			} else if ( tabKey === 'publish' ) {
				loadDraftIfNeeded().then( function () {
					loadStudioPublishPane();
				} );
			}
		}

		var rootBox = el( 'div', { class: 'seopm-article-studio' }, [
			studioHeader,
			briefPane,
			articlePane,
			htmlPane,
			imagePane,
			publishPane
		] );

		return {
			element: rootBox,
			openTab: openTab,
			getCurrentTab: function () { return currentTab; },
			close: function () {
				if ( callbacks.onClose ) {
					callbacks.onClose();
				}
			}
		};
	}

	/* --------------------------- SEO Brief Box --------------------------- */

	function renderBriefBox( s ) {
		var audit = s.audit || {};
		var closest = audit.closest_pages || [];

		var pagesTableRows = [];
		if ( closest.length ) {
			closest.forEach( function ( p ) {
				pagesTableRows.push( el( 'tr', {}, [
					el( 'td', {}, [
						el( 'a', { href: p.url, target: '_blank', rel: 'noopener noreferrer', dir: 'ltr', class: 'seopm-small seopm-table-title-link', text: p.url } )
					] ),
					el( 'td', { text: p.title } ),
					el( 'td', {}, [ el( 'span', { class: 'seopm-badge seopm-badge-ghost', text: p.relevance } ) ] ),
					el( 'td', { text: p.intent } ),
					el( 'td', {}, [
						el( 'span', { class: 'seopm-badge', style: { background: ( p.conflict_risk && p.conflict_risk.indexOf( 'کم' ) !== -1 ) ? '#ecfdf5' : '#fef3c7', color: ( p.conflict_risk && p.conflict_risk.indexOf( 'کم' ) !== -1 ) ? '#047857' : '#b45309' }, text: p.conflict_risk } )
					] )
				] ) );
			} );
		} else {
			pagesTableRows.push( el( 'tr', {}, [
				el( 'td', { colspan: '5', class: 'seopm-muted seopm-small', style: { textAlign: 'center', padding: '12px' }, text: 'صفحه یا مقاله مستقیمی با این عبارت در سایت یافت نشد (خلاء محتوایی کامل).' } )
			] ) );
		}

		var pagesTbl = el( 'table', { class: 'seopm-mini-table', style: { width: '100%', marginTop: '6px' } }, [
			el( 'thead', {}, [
				el( 'tr', {}, [
					el( 'th', {}, 'URL صفحه موجود' ),
					el( 'th', {}, 'عنوان صفحه' ),
					el( 'th', { style: { width: '90px' } }, 'ارتباط' ),
					el( 'th', { style: { width: '130px' } }, 'هدف جستجوی صفحه' ),
					el( 'th', { style: { width: '130px' } }, 'احتمال تداخل با مقاله' )
				] )
			] ),
			el( 'tbody', {}, pagesTableRows )
		] );

		var titlesList = ( s.titles || [] ).map( function ( t, tIdx ) {
			var isBest = t === s.best_title;
			return el( 'li', { class: isBest ? 'seopm-title-item seopm-best-title-item' : 'seopm-title-item' }, [
				el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, [
					isBest ? el( 'span', { class: 'seopm-badge', style: { background: '#fef3c7', color: '#b45309', border: '1px solid #fde68a', fontWeight: '800' }, text: '⭐ گزینه برتر' } ) : el( 'span', { class: 'seopm-badge seopm-badge-ghost', text: 'عنوان ' + J.faDigits( tIdx + 1 ) } ),
					el( 'strong', { text: t, style: { fontSize: '13px' } } )
				] ),
				isBest && s.best_title_reason ? el( 'p', { class: 'seopm-small seopm-muted', style: { margin: '4px 0 0 0', paddingRight: '20px' }, text: 'دلیل انتخاب: ' + s.best_title_reason } ) : null
			] );
		} );

		return el( 'div', { class: 'seopm-brief-box' }, [
			el( 'div', { class: 'seopm-brief-header' }, [
				el( 'h4', { text: 'بریف و استراتژی تولید محتوا: ' + s.keyword, style: { margin: 0, fontSize: '14px', fontWeight: '800' } } ),
				el( 'span', { class: 'seopm-badge', style: { background: '#fff', border: '1px solid var(--seopm-border)' }, text: 'طبق فرمت استاندارد استراتژیست سئو' } )
			] ),

			el( 'div', { class: 'seopm-brief-grid' }, [
				// ۱. وضعیت بررسی سایت
				el( 'div', { class: 'seopm-brief-card' }, [
					el( 'h5', { text: '۱. وضعیت بررسی سایت و سایت‌مپ' } ),
					el( 'ul', { class: 'seopm-brief-ul' }, [
						el( 'li', {}, [ document.createTextNode( 'تعداد کل URLهای بررسی شده: ' ), el( 'strong', { text: J.faDigits( audit.total_urls_checked || 0 ) + ' صفحه و مقاله' } ) ] ),
						el( 'li', {}, [ document.createTextNode( 'صفحات مرتبط شناسایی شده: ' ), el( 'strong', { text: J.faDigits( audit.matched_existing_count || 0 ) + ' مورد' } ) ] ),
						el( 'li', {}, [ document.createTextNode( 'نزدیک‌ترین صفحه: ' ), el( 'strong', { text: closest.length && closest[ 0 ] ? closest[ 0 ].title : 'هیچ صفحه تکراری موجود نیست' } ) ] )
					] )
				] ),

				// ۳. تحلیل سئو
				el( 'div', { class: 'seopm-brief-card' }, [
					el( 'h5', { text: '۳. تحلیل سئو و Search Intent' } ),
					el( 'ul', { class: 'seopm-brief-ul' }, [
						el( 'li', {}, [ document.createTextNode( 'کلمه کلیدی اصلی: ' ), el( 'strong', { text: s.keyword } ) ] ),
						el( 'li', {}, [ document.createTextNode( 'Search Intent: ' ), el( 'strong', { text: s.search_intent_fa } ) ] ),
						el( 'li', {}, [ document.createTextNode( 'نیاز اصلی کاربر: ' ), el( 'span', { class: 'seopm-muted', text: s.user_core_need } ) ] ),
						el( 'li', {}, [ document.createTextNode( 'احتمال Keyword Cannibalization: ' ), el( 'strong', { style: { color: s.cannibalization_risk === 'کم' || s.cannibalization_risk === 'صفر' ? '#10b981' : '#f59e0b' }, text: s.cannibalization_risk } ) ] )
					] )
				] ),

				// امتیاز سئو و اولویت تولید
				el( 'div', { class: 'seopm-brief-card seopm-span-2', style: { background: '#f8fafc', borderColor: '#e2e8f0' } }, [
					el( 'div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' } }, [
						el( 'h5', { style: { margin: 0, border: 'none', padding: 0 }, text: 'تحلیل امتیاز سئو و شانس رتبه (SEO Opportunity Score)' } ),
						el( 'span', { class: 'seopm-badge', style: { background: '#ecfdf5', color: '#047857', border: '1px solid #a7f3d0', fontWeight: '800', fontSize: '13px' } }, 'امتیاز کل: ' + J.faDigits( s.score || 85 ) + ' از ۱۰۰' )
					] ),
					el( 'div', { class: 'seopm-score-box', style: { margin: '8px 0' } }, [
						el( 'div', { class: 'seopm-score-part' }, [
							el( 'span', { class: 'seopm-score-part-label', text: 'وزن در بیزینس' } ),
							el( 'span', { class: 'seopm-score-part-val', text: J.faDigits( ( s.score_breakdown && s.score_breakdown.weight_score ) || 0 ) + ' / ۴۰' } )
						] ),
						el( 'div', { class: 'seopm-score-part' }, [
							el( 'span', { class: 'seopm-score-part-label', text: 'خلاء محتوایی سایت' } ),
							el( 'span', { class: 'seopm-score-part-val', text: J.faDigits( ( s.score_breakdown && s.score_breakdown.gap_score ) || 0 ) + ' / ۲۵' } )
						] ),
						el( 'div', { class: 'seopm-score-part' }, [
							el( 'span', { class: 'seopm-score-part-label', text: 'تقویت پیلار هدف' } ),
							el( 'span', { class: 'seopm-score-part-val', text: J.faDigits( ( s.score_breakdown && s.score_breakdown.pillar_score ) || 0 ) + ' / ۲۰' } )
						] ),
						el( 'div', { class: 'seopm-score-part' }, [
							el( 'span', { class: 'seopm-score-part-label', text: 'ارزش جذب لید و نیت' } ),
							el( 'span', { class: 'seopm-score-part-val', text: J.faDigits( ( s.score_breakdown && s.score_breakdown.intent_score ) || 0 ) + ' / ۱۵' } )
						] )
					] ),
					el( 'p', { class: 'seopm-small seopm-muted', style: { margin: '6px 0 0 0' }, text: 'این عنوان از بین تمام زوایای بررسی‌شده برای کلمه کلیدی «' + s.keyword + '» بالاترین امتیاز سئو را کسب کرده و بر اساس سهمیه توزیع وزنی در ۲۰ مقاله منتخب قرار گرفته است.' } )
				] ),

				// ۴. تصمیم نهایی
				el( 'div', { class: 'seopm-brief-card seopm-span-2', style: { background: '#f8fafc', borderColor: '#cbd5e1' } }, [
					el( 'h5', { text: '۴. تصمیم نهایی سئو' } ),
					el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' } }, [
						el( 'span', { class: 'seopm-badge ' + ( s.decision === 'optimize_existing' ? 'seopm-decision-opt' : 'seopm-decision-new' ), style: { fontSize: '13px', padding: '4px 10px' }, text: s.decision_label } )
					] ),
					el( 'p', { class: 'seopm-small', style: { margin: 0 }, text: s.decision_reason } )
				] ),

				// ۲. تحلیل صفحات موجود
				el( 'div', { class: 'seopm-brief-card seopm-span-2' }, [
					el( 'h5', { text: '۲. تحلیل صفحات موجود سایت (بررسی احتمال تداخل)' } ),
					pagesTbl
				] ),

				// ۵. عناوین پیشنهادی
				el( 'div', { class: 'seopm-brief-card seopm-span-2' }, [
					el( 'h5', { text: '۵. عناوین پیشنهادی (۳ عنوان متفاوت و سئوپسند)' } ),
					el( 'ul', { class: 'seopm-titles-ul' }, titlesList )
				] ),

				// ۶. پیشنهاد ساختار URL
				el( 'div', { class: 'seopm-brief-card seopm-span-2', style: { background: '#f1f5f9' } }, [
					el( 'h5', { text: '۶. پیشنهاد ساختار اسلاگ (URL Slug) کوتاه و سئوپسند' } ),
					el( 'div', { style: { display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' } }, [
						el( 'code', { dir: 'ltr', class: 'seopm-brief-code', text: cleanSlug( s.url_slug ) } ),
						el( 'span', { class: 'seopm-small seopm-muted', text: 'بررسی عدم تداخل با URLهای موجود سایت انجام شده است.' } )
					] )
				] ),

				// ۷. استراتژی لینک‌سازی به پیلار
				s.pillar ? el( 'div', { class: 'seopm-brief-card seopm-span-2', style: { background: '#f0fdf4', borderColor: '#bbf7d0' } }, [
					el( 'h5', { style: { color: '#166534', borderBottomColor: '#bbf7d0' } }, [
						el( 'span', { class: 'dashicons dashicons-admin-links', style: { color: '#16a34a' } } ),
						document.createTextNode( '۷. استراتژی لینک‌سازی به پیلار (Pillar Internal Linking)' )
					] ),
					el( 'div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '12px', marginBottom: '10px' } }, [
						el( 'div', { style: { background: '#fff', padding: '10px 12px', borderRadius: '8px', border: '1px solid #dcfce7' } }, [
							el( 'div', { class: 'seopm-small seopm-muted', text: 'صفحه پیلار هدف (لندینگ خدمات):' } ),
							el( 'a', { href: s.pillar.target_pillar_url, target: '_blank', rel: 'noopener noreferrer', class: 'seopm-table-title-link', style: { marginTop: '4px', display: 'inline-flex' } }, [
								el( 'strong', { text: s.pillar.target_pillar_title } ),
								el( 'span', { class: 'dashicons dashicons-external' } )
							] ),
							el( 'div', { class: 'seopm-table-url-sub', dir: 'ltr', text: s.pillar.target_pillar_url } ),
							el( 'div', { style: { marginTop: '6px' } }, [
								el( 'span', { class: 'seopm-badge', style: { background: '#ecfdf5', color: '#047857', fontSize: '10.5px' }, text: s.pillar.pillar_role } )
							] )
						] ),
						el( 'div', { style: { background: '#fff', padding: '10px 12px', borderRadius: '8px', border: '1px solid #dcfce7' } }, [
							el( 'div', { class: 'seopm-small seopm-muted', text: 'انکرتکست‌های پیشنهادی برای لینک به پیلار:' } ),
							el( 'div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '6px' } }, [
								el( 'span', { class: 'seopm-badge', style: { background: '#16a34a', color: '#fff', fontWeight: '700' }, title: 'انکر تکست دقیق (Exact Match)' }, 'انکر دقیق: ' + ( s.pillar.primary_anchor || s.keyword ) )
							].concat(
								( s.pillar.secondary_anchors || [] ).map( function ( anc ) {
									return el( 'span', { class: 'seopm-badge', style: { background: '#f0fdf4', color: '#166534', border: '1px solid #86efac' }, title: 'انکر تکست مکمل / توصیفی' }, anc );
								} )
							) )
						] )
					] ),
					el( 'div', { style: { background: '#fff', padding: '10px 12px', borderRadius: '8px', border: '1px solid #dcfce7' } }, [
						el( 'div', { style: { fontWeight: '700', fontSize: '12px', color: '#166534', marginBottom: '6px' }, text: 'راهنمای جایگذاری لینک‌ها در متن مقاله:' } ),
						el( 'ul', { class: 'seopm-brief-ul' }, [
							el( 'li', {}, ( s.pillar.placement_strategy && s.pillar.placement_strategy.intro_link ) || 'لینک اول در پاراگراف‌های آغازین روی انکرتکست دقیق جهت معرفی خدمت اصلی.' ),
							el( 'li', {}, ( s.pillar.placement_strategy && s.pillar.placement_strategy.body_link ) || 'لینک دوم در بخش میانی روی انکرتکست توصیفی یا عبارتی.' ),
							el( 'li', {}, ( s.pillar.placement_strategy && s.pillar.placement_strategy.cta_link ) || 'لینک سوم در بخش نتیجه‌گیری و باکس دعوت به اقدام (CTA) رزرو نوبت در منزل.' )
						] ),
						el( 'p', { class: 'seopm-small seopm-muted', style: { margin: '6px 0 0 0' }, text: 'نقش در معماری سئو: ' + ( s.pillar.seo_goal || 'تقویت Topical Authority بدون ایجاد رقابت محتوایی.' ) } )
					] )
				] ) : null
			] )
		] );
	}

	/* --------------------------- Boot --------------------------- */

	if ( C.initialData ) {
		var init = C.initialData;
		C.initialData = null;
		populateBusinesses( init );
	} else {
		ui.api( '/businesses' ).then( populateBusinesses );
	}
}( window, document ) );

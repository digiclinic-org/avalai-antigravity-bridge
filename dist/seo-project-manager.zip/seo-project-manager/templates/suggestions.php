<?php
/**
 * Suggested Articles & Project SEO Strategy page.
 *
 * @package SEOPM
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="seopm-page-head">
	<div>
		<h1><?php esc_html_e( 'مقالات پیشنهادی و استراتژی محتوا', 'seo-project-manager' ); ?></h1>
		<p class="seopm-sub"><?php esc_html_e( 'تحلیل جامع سایت، کلمات کلیدی هدف، ۲۰ مقاله کلاستر پیشنهادی و معماری لینک‌سازی داخلی به پیلارها', 'seo-project-manager' ); ?></p>
	</div>
	<div class="seopm-actions seopm-sug-page-actions">
		<label class="seopm-biz-switcher-wrap" id="seopm-sug-biz-wrap" hidden>
			<span class="dashicons dashicons-store" aria-hidden="true"></span>
			<select id="seopm-sug-business-select" aria-label="<?php esc_attr_e( 'انتخاب کسب‌وکار', 'seo-project-manager' ); ?>"></select>
		</label>
		<button type="button" id="seopm-sug-copy-kw" class="seopm-btn seopm-btn-ghost" hidden>
			<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
			<?php esc_html_e( 'کپی کلمات کلیدی', 'seo-project-manager' ); ?>
		</button>
		<a id="seopm-sug-edit-biz" href="<?php echo esc_url( SEOPM\Admin\Admin_Pages::url( 'businesses' ) ); ?>" class="seopm-btn seopm-btn-ghost" hidden>
			<span class="dashicons dashicons-edit" aria-hidden="true"></span>
			<?php esc_html_e( 'ویرایش پروژه', 'seo-project-manager' ); ?>
		</a>
		<a href="<?php echo esc_url( SEOPM\Admin\Admin_Pages::url( 'businesses' ) ); ?>" class="seopm-btn seopm-btn-ghost">
			<span class="dashicons dashicons-arrow-right-alt" aria-hidden="true"></span>
			<?php esc_html_e( 'کسب‌وکارها', 'seo-project-manager' ); ?>
		</a>
	</div>
</div>
<div id="seopm-suggestions-page" class="seopm-suggestions-workspace" aria-live="polite">
	<div class="seopm-skeleton seopm-skeleton-cards"></div>
</div>
